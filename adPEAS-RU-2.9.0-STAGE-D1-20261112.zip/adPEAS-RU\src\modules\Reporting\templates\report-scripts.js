﻿// ============================================================
        // CONSTANTS
        // ============================================================
        const UI_CONSTANTS = {
            KEYBOARD_FOCUS_DURATION: 2000,      // ms - how long keyboard focus highlight stays
            SEARCH_DEBOUNCE_DELAY: 150,         // ms - delay before search filter applies
            TOOLTIP_CLOSE_DELAY: 100,           // ms - delay before tooltip click-to-close activates
            SCROLL_DELAY: 100,                  // ms - delay before scrollIntoView after DOM changes
            VIEWPORT_PADDING: 20,               // px - padding from viewport edges for positioning
            COPY_FEEDBACK_DURATION: 2000,       // ms - how long "Copied!" feedback shows on copy button
            A11Y_ANNOUNCEMENT_DELAY: 100        // ms - delay before screen reader announcements
        };

        // ============================================================
        // ACCESSIBILITY HELPERS
        // ============================================================

        // Announce message to screen readers via live region
        function announceToScreenReader(message, priority = 'polite') {
            const liveRegion = document.getElementById('a11yAnnouncements');
            if (!liveRegion) return;

            // Set priority (polite or assertive)
            liveRegion.setAttribute('aria-live', priority);

            // Clear and set message (timing helps screen readers pick up the change)
            liveRegion.textContent = '';
            setTimeout(() => {
                liveRegion.textContent = message;
            }, UI_CONSTANTS.A11Y_ANNOUNCEMENT_DELAY);
        }

        // Update ARIA pressed state for toggle buttons
        function updateAriaPressed(element, isPressed) {
            if (element) {
                element.setAttribute('aria-pressed', isPressed ? 'true' : 'false');
            }
        }

        // Update ARIA expanded state for collapsible elements
        function updateAriaExpanded(element, isExpanded) {
            if (element) {
                element.setAttribute('aria-expanded', isExpanded ? 'true' : 'false');
            }
        }

        // Manage focus for modal-like elements (tooltips, help modal)
        let previouslyFocusedElement = null;

        function trapFocus(element) {
            previouslyFocusedElement = document.activeElement;
            const focusableElements = element.querySelectorAll(
                'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
            );
            const firstFocusable = focusableElements[0];
            const lastFocusable = focusableElements[focusableElements.length - 1];

            if (firstFocusable) {
                firstFocusable.focus();
            }

            element.addEventListener('keydown', function handleTab(e) {
                if (e.key === 'Tab') {
                    if (e.shiftKey && document.activeElement === firstFocusable) {
                        e.preventDefault();
                        lastFocusable.focus();
                    } else if (!e.shiftKey && document.activeElement === lastFocusable) {
                        e.preventDefault();
                        firstFocusable.focus();
                    }
                }
            });
        }

        function restoreFocus() {
            if (previouslyFocusedElement && previouslyFocusedElement.focus) {
                previouslyFocusedElement.focus();
                previouslyFocusedElement = null;
            }
        }

        function toggleTheme() {
            const html = document.documentElement;
            const newTheme = html.getAttribute('data-theme') === 'light' ? 'dark' : 'light';
            html.setAttribute('data-theme', newTheme);
            safeSetItem('adpeas-theme', newTheme);
            updateThemeUI(newTheme);
            announceToScreenReader('Тема изменена: ' + newTheme + ' mode');
        }

        function updateThemeUI(theme) {
            document.getElementById('themeIcon').innerHTML = theme === 'dark' ? '&#9788;' : '&#9790;';
            document.getElementById('themeLabel').textContent = theme === 'dark' ? 'Светлая' : 'Тёмная';
            // Update ARIA state for theme toggle
            const themeToggle = document.querySelector('.theme-toggle');
            if (themeToggle) {
                updateAriaPressed(themeToggle, theme === 'dark');
            }
        }

        function toggleFinding(header) {
            // Don't toggle if the click was actually a text selection (allow copy)
            if (window.getSelection && window.getSelection().toString().length > 0) return;
            const card = header.closest('.finding-card');
            card.classList.toggle('expanded');

            // Highlight the category in the sidebar navigation
            highlightCategoryForCard(card);
        }

        function highlightCategoryForCard(card) {
            // Remove previous category highlight
            document.querySelectorAll('.category-filter.category-highlight').forEach(f => f.classList.remove('category-highlight'));

            if (!card.classList.contains('expanded')) return;

            // Get the card's category and highlight the matching nav item
            const category = card.dataset.category;
            if (category) {
                const navItem = document.querySelector('.category-filter[data-category="' + category + '"]');
                if (navItem) navItem.classList.add('category-highlight');
            }
        }

        function toggleExtendedAttrs(objectId) {
            const extSection = document.getElementById('ext-' + objectId);
            const toggleBtn = extSection.previousElementSibling;
            const icon = document.getElementById('icon-' + objectId);

            if (extSection.style.display === 'none') {
                extSection.style.display = 'block';
                toggleBtn.classList.add('expanded');
                toggleBtn.querySelector('span:last-child').textContent =
                    toggleBtn.querySelector('span:last-child').textContent.replace('Show', 'Hide');
            } else {
                extSection.style.display = 'none';
                toggleBtn.classList.remove('expanded');
                toggleBtn.querySelector('span:last-child').textContent =
                    toggleBtn.querySelector('span:last-child').textContent.replace('Hide', 'Show');
            }
        }

        // Toggle individual object card (collapsed/expanded)
        function toggleObjectCard(objectId) {
            // Don't toggle if the click was actually a text selection (allow copy)
            if (window.getSelection && window.getSelection().toString().length > 0) return;
            const card = document.getElementById('obj-' + objectId);
            if (card) {
                card.classList.toggle('expanded');
            }
        }

        // Expand all object cards in a finding-card
        function expandAllObjects(findingCardId) {
            const findingCard = document.getElementById(findingCardId);
            if (findingCard) {
                findingCard.querySelectorAll('.object-detail').forEach(obj => {
                    obj.classList.add('expanded');
                });
                updateExpandCollapseButton(findingCardId, true);
            }
        }

        // Collapse all object cards in a finding-card
        function collapseAllObjects(findingCardId) {
            const findingCard = document.getElementById(findingCardId);
            if (findingCard) {
                findingCard.querySelectorAll('.object-detail').forEach(obj => {
                    obj.classList.remove('expanded');
                });
                updateExpandCollapseButton(findingCardId, false);
            }
        }

        // Toggle all object cards in a finding-card
        function toggleAllObjects(findingCardId) {
            const findingCard = document.getElementById(findingCardId);
            if (findingCard) {
                const objects = findingCard.querySelectorAll('.object-detail');
                const expandedCount = findingCard.querySelectorAll('.object-detail.expanded').length;
                const shouldExpand = expandedCount < objects.length / 2;

                objects.forEach(obj => {
                    if (shouldExpand) {
                        obj.classList.add('expanded');
                    } else {
                        obj.classList.remove('expanded');
                    }
                });
                updateExpandCollapseButton(findingCardId, shouldExpand);
            }
        }

        // Update the expand/collapse button text
        function updateExpandCollapseButton(findingCardId, isExpanded) {
            const btn = document.querySelector(`#${findingCardId} .expand-collapse-btn`);
            if (btn) {
                btn.innerHTML = isExpanded
                    ? '<span>&#9660;</span> Свернуть всё'
                    : '<span>&#9654;</span> Развернуть всё';
            }
        }

        let currentSeverityFilter = 'all';
        let currentCategoryFilter = 'all';
        let currentSearchQuery = '';
        let hideCompletedEnabled = false;

        function filterBySeverity(severity) {
            currentSeverityFilter = severity;
            // Reset category filter when severity is clicked
            currentCategoryFilter = 'all';

            // Update active state and ARIA pressed - severity gets highlighted, categories reset
            document.querySelectorAll('.severity-filter').forEach(link => {
                const isActive = link.dataset.severity === severity;
                link.classList.toggle('active', isActive);
                updateAriaPressed(link, isActive);
            });
            // Remove active and card-highlight from ALL categories
            document.querySelectorAll('.category-filter').forEach(link => {
                link.classList.remove('active', 'category-highlight');
                updateAriaPressed(link, false);
            });

            applyFilters();

            // Announce filter change to screen readers
            const count = document.querySelectorAll('.finding-card:not([style*="display: none"])').length;
            const severityLabel = severity === 'all' ? 'all severities' : severity;
            announceToScreenReader('Filtered by ' + severityLabel + '. ' + count + ' findings shown.');
        }

        function filterByCategory(category) {
            currentCategoryFilter = category;
            // Reset severity filter when category is clicked
            currentSeverityFilter = 'all';

            // Update active state and ARIA pressed - category gets highlighted, severities reset
            // Also clear card-highlight since user is now actively filtering
            document.querySelectorAll('.category-filter').forEach(link => {
                const isActive = link.dataset.category === category;
                link.classList.toggle('active', isActive);
                link.classList.remove('category-highlight');
                updateAriaPressed(link, isActive);
            });
            // Remove active from ALL severities (no highlight)
            document.querySelectorAll('.severity-filter').forEach(link => {
                link.classList.remove('active');
                updateAriaPressed(link, false);
            });

            applyFilters();

            // Announce filter change to screen readers
            const count = document.querySelectorAll('.finding-card:not([style*="display: none"])').length;
            announceToScreenReader('Filtered by category ' + category + '. ' + count + ' findings shown.');
        }

        function updateItemCount(card, visible, total) {
            const countEl = card.querySelector('.finding-count');
            if (countEl) {
                if (!countEl.dataset.originalText) {
                    countEl.dataset.originalText = countEl.textContent;
                }
                countEl.textContent = visible + ' of ' + total + ' item(s)';
            }
        }

        function resetItemCount(card) {
            const countEl = card.querySelector('.finding-count');
            if (countEl && countEl.dataset.originalText) {
                countEl.textContent = countEl.dataset.originalText;
            }
        }

        function applyFilters() {
            // Filter finding cards with item-level search filtering
            document.querySelectorAll('.finding-card').forEach(card => {
                const cardSeverity = card.dataset.severity;
                const cardCategory = card.dataset.category;
                const cardId = card.dataset.cardId;

                const matchesSeverity = currentSeverityFilter === 'all' || cardSeverity === currentSeverityFilter;
                const matchesCategory = currentCategoryFilter === 'all' || cardCategory === currentCategoryFilter;
                const isCompleted = completedFindings[cardId] === true;
                const matchesCompleted = !hideCompletedEnabled || !isCompleted;

                // Non-search filters: card-level only
                if (!matchesSeverity || !matchesCategory || !matchesCompleted) {
                    card.style.display = 'none';
                    return;
                }

                // No search query: show card, reset all items to visible
                if (currentSearchQuery === '') {
                    card.style.display = '';
                    card.querySelectorAll('.object-detail, .finding-item, .section-scope').forEach(item => {
                        item.style.display = '';
                    });
                    resetItemCount(card);
                    return;
                }

                // Search active: filter individual items within card
                // .section-scope: the lines a card opens with, in one block - searched and
                // hidden as one item, like an object.
                const items = card.querySelectorAll(':scope > .finding-body > .object-detail, :scope > .finding-body > .finding-item, :scope > .finding-body > .section-scope');
                let visibleCount = 0;
                const totalCount = items.length;

                // Check if card header/title matches (show all items if card title matches)
                const header = card.querySelector('.finding-header');
                const headerMatches = header && header.textContent.toLowerCase().includes(currentSearchQuery);

                items.forEach(item => {
                    const itemText = item.textContent.toLowerCase();
                    if (itemText.includes(currentSearchQuery) || headerMatches) {
                        item.style.display = '';
                        visibleCount++;
                    } else {
                        item.style.display = 'none';
                    }
                });

                // Show card only if at least 1 item matches (or header matches)
                if (visibleCount > 0 || headerMatches) {
                    card.style.display = '';
                    if (visibleCount < totalCount && !headerMatches) {
                        updateItemCount(card, visibleCount, totalCount);
                    } else {
                        resetItemCount(card);
                    }
                } else {
                    card.style.display = 'none';
                }
            });
        }

        // Finding definitions (embedded from adPEAS-FindingDefinitions.ps1)
        const findingDefinitions = {{FINDING_DEFINITIONS_JSON}};

        // Check descriptions (embedded from adPEAS-ObjectTypes.ps1)
        const checkDescriptions = {{CHECK_DESCRIPTIONS_JSON}};

        // RU display catalog. Canonical IDs, data attributes and scoring remain unchanged.
        const ruFindingTitles = {"KERBEROASTABLE_SPN":"Учётная запись службы, уязвимая к Kerberoasting","ASREP_ROASTABLE":"Учётная запись без предварительной проверки подлинности Kerberos (AS-REP Roasting)","KERBEROAST_WITHOUT_PREAUTH":"Kerberoasting без учётных данных через запись без предварительной проверки подлинности","KERBEROS_HASH_CRACKABLE":"Хеш Kerberos, доступный для автономного подбора пароля","KRBTGT_PASSWORD_OLD":"Пароль учётной записи krbtgt давно не менялся","GUEST_ACCOUNT_ENABLED":"Встроенная учётная запись «Гость» включена","GUEST_ACCOUNT_DISABLED":"Встроенная учётная запись «Гость» отключена","UNCONSTRAINED_DELEGATION":"Разрешено неограниченное делегирование Kerberos","UNCONSTRAINED_DELEGATION_DC":"Неограниченное делегирование на контроллере домена","UNCONSTRAINED_DELEGATION_EXPOSED_ACCOUNTS":"Привилегированные учётные записи передают TGT узлам с неограниченным делегированием","CONSTRAINED_DELEGATION_PROTOCOL_TRANSITION":"Ограниченное делегирование с переходом протокола","GPO_NOT_CURRENTLY_EFFECTIVE":"Этот параметр групповой политики сейчас не применяется","PRIVILEGED_ACCOUNT_AFFECTED":"Затронута привилегированная учётная запись","ROASTABLE_PRIVILEGED_ACCOUNT":"Привилегированная учётная запись допускает подбор пароля по билетам Kerberos","CONSTRAINED_DELEGATION_TO_DC":"Ограниченное делегирование на контроллер домена","CONSTRAINED_DELEGATION_TRANSITION_NO_TARGET":"Переход протокола без указанной цели делегирования","RBCD_DANGEROUS_PRINCIPALS":"Опасные разрешения делегирования на основе ресурса (RBCD)","ESC1_TEMPLATE":"ESC1 — уязвимый шаблон сертификата","ESC_ENROLLMENT_RIGHTS_UNREAD":"Не удалось прочитать права регистрации по шаблону сертификата","ESC2_TEMPLATE":"ESC2 — шаблон сертификата «Любое назначение» или SubCA","ESC3_TEMPLATE":"ESC3 — шаблон сертификата агента запросов","ESC3_TARGET_TEMPLATE":"ESC3 — шаблон для выдачи сертификата от имени другого пользователя","ESC4_TEMPLATE":"ESC4 — опасные права доступа к шаблону сертификата","ESC5_PKI_CONTAINER_ACL":"ESC5 — опасные разрешения на контейнеры PKI","ESC8_WEB_ENROLLMENT":"ESC8 — возможность NTLM Relay к веб-регистрации сертификатов","ADCS_HTTP_AVAILABLE":"Доступна регистрация сертификатов ЦС по HTTP","ADCS_NONPRIV_ENROLLMENT":"Регистрация сертификатов доступна непривилегированным субъектам","ADCS_CLIENT_AUTH_EKU":"В шаблоне разрешено EKU «Проверка подлинности клиента»","ADCS_SMARTCARD_LOGON_EKU":"В шаблоне разрешено EKU «Вход со смарт-картой»","DANGEROUS_ACL_GENERICALL":"Право GenericAll на чувствительном объекте","DANGEROUS_ACL_GENERICWRITE":"Право GenericWrite на чувствительном объекте","DANGEROUS_ACL_WRITEDACL":"Право WriteDACL на чувствительном объекте","DANGEROUS_ACL_WRITEOWNER":"Право WriteOwner на чувствительном объекте","DANGEROUS_ACL_GPO_WRITEPROPERTY":"Право WriteProperty на объекте GPO","DANGEROUS_ACL_GPO_WRITEPROPERTY_SCOPED":"Право WriteProperty на атрибут GPO, не управляющий содержимым политики","DANGEROUS_ACL_GPO_DELETE":"Разрешение удаления объекта GPO","DANGEROUS_ACL_GPO_EXTENDED":"Право Self или ExtendedRight на объекте GPO","GPO_SYSVOL_WRITABLE":"Право записи в папку GPO в SYSVOL","GPO_NON_DEFAULT_OWNER":"Нестандартный владелец объекта групповой политики","GPO_SYSVOL_GPT_MISSING":"У объекта GPO отсутствует папка или gpt.ini в SYSVOL","GPO_SYSVOL_FOLDER_ORPHANED":"Папка SYSVOL не связана с объектом GPO","GPO_UNLINKED_BROAD_WRITE":"Широкая группа может изменить непривязанный объект GPO","DOMAIN_ROOT_GPLINK_WRITE":"Право записи в атрибут gPLink корневого объекта домена","DOMAIN_ROOT_SID_HISTORY_WRITE":"Право Migrate-SID-History на объекте домена","DOMAIN_ROOT_REPLICA_INSTALL":"Право DS-Install-Replica на объекте домена","CRITICAL_OBJECT_CONTROL":"Управление схемой, конфигурацией, разделами, ролями или сайтами AD","RODC_PRIVILEGED_PASSWORD_ALLOWED":"RODC может кэшировать пароли привилегированных учётных записей","RODC_PRIVILEGED_PASSWORD_REVEALED":"Привилегированные секреты уже кэшированы на RODC","RODC_DENIED_GROUP_MISSING":"Защищаемая группа отсутствует в списке запрета репликации паролей RODC","UNREGISTERED_DOMAIN_CONTROLLER":"Компьютер с ролью контроллера домена не зарегистрирован как контроллер","DOMAIN_ROOT_REANIMATE_TOMBSTONES":"Право Reanimate-Tombstones на объекте домена","DOMAIN_ROOT_MAQ_WRITE":"Право изменения ms-DS-MachineAccountQuota","DOMAIN_ROOT_FSMO_TRANSFER":"Право передачи роли эмулятора PDC на объекте домена","DOMAIN_ROOT_NON_DEFAULT_OWNER":"Нестандартный владелец корневого объекта домена","OU_NON_DEFAULT_OWNER":"Нестандартный владелец организационной единицы","DANGEROUS_ACL_REPLICATION_NO_SECRETS":"Права репликации без секретов: недостаточно одного разрешения для DCSync","DANGEROUS_ACL_REPLICATION_INERT_HALF":"Право репликации неактивно без парного разрешения","DANGEROUS_ACL_DCSYNC_BROAD":"Права DCSync предоставлены широкой группе","DANGEROUS_ACL_BROAD_GROUP":"Широкой группе предоставлены опасные права на объект домена","DANGEROUS_ACL_DCSYNC":"Права DCSync на репликацию данных каталога","OU_PERM_WRITEPROPERTY_ALL":"Разрешение WriteProperty на все свойства объектов OU","OU_PERM_PASSWORD_RESET":"Право сброса паролей в OU","OU_PERM_USERACCOUNTCONTROL":"Право изменения userAccountControl в OU","OU_PERM_USER_ACCOUNT_RESTRICTIONS":"Право изменения набора User-Account-Restrictions в OU","OU_PERM_GROUP_MEMBERSHIP":"Право изменения состава групп через атрибут member в OU","OU_PERM_SELF_ALL_VALIDATED":"Все проверяемые операции записи Validated Writes в OU","OU_PERM_SELF_MEMBERSHIP":"Право на самостоятельное изменение членства в группах OU","OU_PERM_SPN_WRITE":"Право изменения servicePrincipalName в OU","OU_PERM_VALIDATED_SPN":"Разрешение Validated-SPN в OU","OU_PERM_DNSHOSTNAME_WRITE":"Право изменения dNSHostName в OU","OU_PERM_KEYCREDENTIALLINK_WRITE":"Право изменения msDS-KeyCredentialLink в OU","ADMINSDHOLDER_PROPAGATED_RIGHT":"Право на AdminSDHolder, распространяемое SDProp на защищённые объекты","OU_PERM_DNS_HOST_NAME_ATTRIBUTES":"Право изменения DNS-Host-Name-Attributes в OU","OU_PERM_VALIDATED_DNS":"Разрешение Validated-DNS-Host-Name в OU","OU_PERM_SCRIPTPATH":"Право изменения scriptPath в OU","OU_PERM_CONSTRAINED_DELEGATION":"Право изменения msDS-AllowedToDelegateTo в OU","OU_PERM_RBCD":"Право изменения msDS-AllowedToActOnBehalfOfOtherIdentity в OU","OU_PERM_LAPS_READ":"Право чтения паролей LAPS в OU","OU_PERM_CREATE_CHILD":"Право создания дочерних объектов в OU","OU_PERM_CREATE_DMSA":"Право создания делегированных управляемых учётных записей dMSA","OU_PERM_GPLINK":"Право изменения привязок GPO через gPLink в OU","OU_PERM_GPOPTIONS":"Право изменения gPOptions в OU","OU_PERM_GENERICWRITE":"Право GenericWrite в OU","OU_PERM_READALL":"Право чтения всех свойств в OU","PASSWORD_NEVER_EXPIRES":"Срок действия пароля не ограничен","PASSWORD_NOT_REQUIRED":"Установлен флаг PASSWD_NOTREQD: пароль не обязателен","PRECREATED_COMPUTER_ACCOUNT":"Предварительно созданная учётная запись компьютера не использовалась","INTERDOMAIN_TRUST_ACCOUNT":"Учётная запись междоменного доверия","ESX_ADMINS_MEMBER":"Участник группы ESX Admins (администраторы VMware ESXi)","PRIVILEGED_GROUP_MEMBERSHIP":"Членство в привилегированной группе уровня Tier 0","OPERATOR_GROUP_MEMBERSHIP":"Членство в операторской группе или группе с широким доступом","EXCHANGE_GROUP_PERMISSIONS":"Штатные разрешения служебной группы Exchange","EXCHANGE_GROUP_LOW_PRIV_MEMBER":"Непривилегированная учётная запись в служебной группе Exchange","LDAP_SIGNING_NOT_REQUIRED":"Подпись LDAP не обязательна","LDAP_CHANNEL_BINDING_NOT_REQUIRED":"Привязка канала LDAP не обязательна","LDAP_ANONYMOUS_BINDING_ALLOWED":"Разрешены анонимные операции LDAP","DSHEURISTICS_ANONYMOUS_NSPI":"Разрешён анонимный доступ NSPI","DSHEURISTICS_ADMINSDHOLDER_EXCLUSION":"Операторские группы исключены из защиты AdminSDHolder","DSHEURISTICS_UNIQUENESS_DISABLED":"Отключена проверка уникальности UPN или SPN","SID_HISTORY_INJECTION":"Привилегированный SID этого домена в sIDHistory","SID_HISTORY_OWN_DOMAIN":"SID этого домена в атрибуте sIDHistory","SID_HISTORY_FOREIGN_PRIVILEGED":"Привилегированный SID другого домена в sIDHistory","SID_HISTORY_ORPHANED":"SID из недоверенного домена или домена вне леса в sIDHistory","GPO_DANGEROUS_PERMISSIONS":"Опасные разрешения на объект GPO","GPO_SCOPE_DOMAIN_WIDE":"Объект GPO привязан к корню домена и действует на весь домен","LAPS_NOT_DEPLOYED":"Защита LAPS не внедрена","LAPS_PASSWORD_READABLE":"Пароль LAPS доступен для чтения","BITLOCKER_KEY_READABLE":"Ключ восстановления BitLocker доступен для чтения","BITLOCKER_RECOVERY_DELEGATED":"Чтение пароля восстановления BitLocker делегировано субъекту","GPO_USERRIGHT_SEDEBUG":"Право «Отладка программ» (SeDebugPrivilege) назначено через GPO сверх стандартных значений","GPO_USERRIGHT_SETCB":"Право «Работа в режиме операционной системы» (SeTcbPrivilege) назначено через GPO","GPO_USERRIGHT_SECREATETOKEN":"Право «Создание объекта токена» (SeCreateTokenPrivilege) назначено через GPO","GPO_USERRIGHT_SEIMPERSONATE":"Право «Имитация клиента после проверки подлинности» (SeImpersonatePrivilege) выдано через GPO","GPO_USERRIGHT_SEASSIGNPRIMARYTOKEN":"Право «Замена токена уровня процесса» (SeAssignPrimaryTokenPrivilege) выдано через GPO","GPO_USERRIGHT_SELOADDRIVER":"Право «Загрузка и выгрузка драйверов устройств» (SeLoadDriverPrivilege) выдано через GPO","GPO_USERRIGHT_SEBACKUP":"Право «Архивирование файлов и каталогов» (SeBackupPrivilege) выдано через GPO","GPO_USERRIGHT_SERESTORE":"Право «Восстановление файлов и каталогов» (SeRestorePrivilege) выдано через GPO","GPO_USERRIGHT_SETAKEOWNERSHIP":"Право «Смена владельцев файлов и других объектов» (SeTakeOwnershipPrivilege) выдано через GPO","GPO_USERRIGHT_SEENABLEDELEGATION":"Право доверия учётных записей для делегирования (SeEnableDelegationPrivilege) выдано через GPO","GPO_USERRIGHT_SESYNCAGENT":"Право «Синхронизация данных службы каталогов» (SeSyncAgentPrivilege) выдано через GPO","GPO_USERRIGHT_SEMANAGEVOLUME":"Право обслуживания томов (SeManageVolumePrivilege) выдано через GPO","GPO_USERRIGHT_SESECURITY":"Право управления аудитом и журналом безопасности (SeSecurityPrivilege) выдано через GPO","GPO_USERRIGHT_SERELABEL":"Право изменения метки объекта (SeRelabelPrivilege) выдано через GPO","GPO_USERRIGHT_SETRUSTEDCREDMANACCESS":"Доступ к диспетчеру учётных данных как доверенного вызывающего (SeTrustedCredManAccessPrivilege)","GPO_USERRIGHT_SEREMOTEINTERACTIVELOGON":"Право входа через службы удалённых рабочих столов (SeRemoteInteractiveLogonRight) расширено через GPO","GPO_USERRIGHT_SEINTERACTIVELOGON":"Право локального входа (SeInteractiveLogonRight) расширено через GPO","GPO_USERRIGHT_SEBATCHLOGON":"Право пакетного входа (SeBatchLogonRight) расширено через GPO","GPO_USERRIGHT_SESERVICELOGON":"Право входа в качестве службы (SeServiceLogonRight) назначено через GPO","GPO_USERRIGHT_SESYSTEMTIME":"Право изменения системного времени (SeSystemtimePrivilege) расширено через GPO","GPO_USERRIGHT_SEREMOTESHUTDOWN":"Право принудительного удалённого завершения работы (SeRemoteShutdownPrivilege) расширено через GPO","GPO_USERRIGHT_SESHUTDOWN":"Право завершения работы системы (SeShutdownPrivilege) расширено через GPO","GPO_USERRIGHT_SECREATESYMBOLICLINK":"Право создания символических ссылок (SeCreateSymbolicLinkPrivilege) расширено через GPO","GPO_USERRIGHT_SEDELEGATESESSIONUSERIMPERSONATE":"Право получения токена другого пользователя в сеансе (SeDelegateSessionUserImpersonatePrivilege) выдано через GPO","GPO_USERRIGHT_SEAUDIT":"Право формирования аудита безопасности (SeAuditPrivilege) расширено через GPO","GPO_USERRIGHT_SESYSTEMENVIRONMENT":"Право изменения параметров среды микропрограммы (SeSystemEnvironmentPrivilege) расширено через GPO","GPO_USERRIGHT_SECREATEGLOBAL":"Право создания глобальных объектов (SeCreateGlobalPrivilege) расширено через GPO","GPO_USERRIGHT_SEPROFILESINGLEPROCESS":"Право профилирования отдельного процесса (SeProfileSingleProcessPrivilege) расширено через GPO","GPO_USERRIGHT_SESYSTEMPROFILE":"Право профилирования производительности системы (SeSystemProfilePrivilege) расширено через GPO","GPO_USERRIGHT_DEFAULT_REMOVED":"Групповая политика исключает стандартного владельца права пользователя","LAPS_ENCRYPTED_READ_NO_DECRYPTOR":"Доступно чтение зашифрованного пароля LAPS без возможности расшифрования","LAPS_PASSWORD_READ_ACCESS":"Разрешения на чтение пароля LAPS","LAPS_READ_BLOCKED_BY_CONFIDENTIAL":"Чтение всех свойств OU компьютеров ограничено флагом конфиденциальности","SMB_SIGNING_DISABLED":"Цифровая подпись SMB не обязательна","CREDENTIAL_IN_DESCRIPTION":"Учётные данные обнаружены в текстовом атрибуте","DELETED_OBJECT_CREDENTIAL":"Учётные данные сохранились в удалённом объекте","DELETED_OBJECTS_READ_DELEGATED":"Чтение удалённых объектов разрешено вне Tier 0","DELETED_OBJECTS_READ_BROAD":"Широкой группе разрешено читать удалённые объекты","CREDENTIAL_GPP_PASSWORD":"Пароль в предпочтениях групповой политики (GPP)","CREDENTIAL_AUTOADMINLOGON":"Учётные данные AutoAdminLogon в GPO","GPO_REGISTRY_PASSWORD":"Пароль в значении реестра, развёрнутом через GPO","CREDENTIAL_UNATTEND_PASSWORD":"Пароль в файле ответов установки Windows","CREDENTIAL_VNC_PASSWORD":"Пароль VNC доступен для чтения","CREDENTIAL_NET_USE":"Пароль указан прямо в команде net use","CREDENTIAL_SCRIPT_PASSWORD":"Пароль обнаружен в файле сценария","CREDENTIAL_CONNECTION_STRING":"Учётные данные в строке подключения к базе данных","CREDENTIAL_MENTION_REVIEW":"Возможное упоминание учётных данных — требуется проверка","REVERSIBLE_ENCRYPTION":"Пароль хранится с обратимым шифрованием","GMSA_PASSWORD_READABLE":"Управляемый пароль gMSA доступен для получения","SHADOW_CREDENTIALS":"Атрибут ключевых учётных данных msDS-KeyCredentialLink заполнен","TRUST_SID_FILTERING_DISABLED":"Фильтрация SID в доверительных отношениях отключена","RBCD_CONFIGURED":"Настроено ограниченное делегирование на основе ресурса (RBCD)","KERBEROS_TICKET_LIFETIME_EXTENDED":"Срок действия билета Kerberos превышает стандартный","TRUST_USES_RC4":"Доверительные отношения используют Kerberos без AES","TRUST_PASSWORD_STALE":"Пароль доверительных отношений давно не обновлялся","TRUST_BIDIRECTIONAL":"Двусторонние доверительные отношения","TRUST_TRANSITIVE":"Транзитивные доверительные отношения","TRUST_SELECTIVE_AUTH":"Включена выборочная проверка подлинности","TRUST_TREAT_AS_EXTERNAL":"Ослаблена фильтрация SID для лесного доверия","NETWORK_SUBNET_DOMAIN_CONTROLLERS":"Подсеть с контроллерами домена","OS_EXTENDED_SECURITY_UPDATES_ONLY":"ОС вне основной поддержки, доступны только платные ESU","OUTDATED_OS":"Операционная система снята с поддержки","AGING_OS":"Операционная система приближается к окончанию поддержки","EXCHANGE_VULNERABLE_VERSION":"Версия Exchange Server вышла из поддержки","EXCHANGE_SHARED_PERMISSIONS_MODEL":"Модель общих разрешений Exchange: WriteDACL на объекте домена","EXCHANGE_PERMISSIONS_MODEL_CLEAN":"Exchange не имеет действующих прав повышения привилегий на объекте домена","EXCHANGE_AD_SPLIT_PERMISSIONS":"В Exchange применяется разделённая модель разрешений AD","EXCHANGE_SMTP_OPEN_RELAY":"SMTP-соединитель Exchange ретранслирует сообщения анонимных отправителей","EXCHANGE_SMTP_ANONYMOUS_SPOOFING":"Анонимные отправители могут использовать внутренние адреса отправителя","EXCHANGE_SMTP_BROAD_RELAY":"SMTP-соединитель позволяет ретрансляцию всем прошедшим проверку подлинности","EXCHANGE_SMTP_ANONYMOUS_AUTHENTICATED":"Анонимная почта считается прошедшей проверку подлинности","EXCHANGE_SMTP_ANONYMOUS_BYPASS_ANTISPAM":"Анонимные сообщения могут обходить антиспам-защиту Exchange","EXCHANGE_SMTP_BROAD_SPOOFING":"Любая доменная учётная запись может подменить внутреннего отправителя","EXCHANGE_SMTP_CONNECTOR_AUTHENTICATED":"Принимающий SMTP-соединитель требует проверки подлинности","EXCHANGE_SMTP_CONNECTOR_UNREADABLE":"Не удалось прочитать разрешения принимающего SMTP-соединителя","EXCHANGE_HYBRID_DEPLOYMENT":"Гибридный Exchange: компрометация локальной инфраструктуры может затронуть облачный тенант","EXCHANGE_RBAC_MAILBOX_IMPORT_EXPORT":"Назначена роль Mailbox Import Export","EXCHANGE_RBAC_APPLICATION_IMPERSONATION":"Назначена роль ApplicationImpersonation","EXCHANGE_RBAC_ROLE_MANAGEMENT":"Роль Role Management назначена вне группы Organization Management","EXCHANGE_RBAC_UNSCOPED_ROLE_MANAGEMENT":"Назначена роль Unscoped Role Management","EXCHANGE_RBAC_MAILBOX_SEARCH":"Роль Mailbox Search назначена вне группы Discovery Management","EXCHANGE_RBAC_AD_PERMISSIONS":"Роль Active Directory Permissions назначена вне Organization Management","EXCHANGE_RBAC_DEFAULT_ASSIGNMENT":"Критически важная роль Exchange назначена стандартной группе ролей","COMPUTER_OBJECT_EXPLICIT_RIGHT":"Явное разрешение на объекте компьютера вне Tier 0","COMPUTER_PASSWORD_NOT_ROTATED":"Пароль компьютерной учётной записи давно не обновлялся","DC_PASSWORD_NOT_ROTATED":"Пароль учётной записи контроллера домена давно не обновлялся","MACHINE_QUOTA_UNRESTRICTED":"Квота создания компьютерных учётных записей не ограничена","INACTIVE_PRIVILEGED_ACCOUNT":"Неактивная привилегированная учётная запись","ORPHANED_ADMIN_ACCOUNT":"Осиротевшая административная запись: adminCount без членства в защищаемой группе","STALE_PASSWORD":"Пароль не менялся продолжительное время","STALE_PASSWORD_MEDIUM":"Предупреждение: пароль не менялся от одного года до пяти лет","WEAK_PASSWORD_POLICY":"Слабая доменная политика паролей","WEAK_FGPP":"Тонкая политика паролей слабее доменной политики по умолчанию","NO_MAX_PASSWORD_AGE":"Максимальный срок действия пароля не ограничен","WEAK_LOCKOUT_DURATION":"Недостаточная продолжительность блокировки учётной записи","NO_ACCOUNT_LOCKOUT":"Политика блокировки учётных записей отключена или слишком слабая","NO_MIN_PASSWORD_AGE":"Минимальный срок действия пароля не установлен","PASSWORD_HISTORY_DISABLED":"История паролей отключена","ESC9_CT_NO_SECURITY_EXTENSION":"ESC9 — шаблон сертификата без расширения безопасности","SCCM_SYSTEM_MANAGEMENT_ACL":"Право записи в контейнер SCCM System Management","SCOM_PRIVILEGED_SERVICE_ACCOUNT":"Привилегированная служебная учётная запись SCOM","SCCM_SITE_HIERARCHY":"Обнаружена иерархия SCCM с несколькими сайтами","SCCM_PXE_EXPOSURE":"Обнаружен сервер сетевой загрузки PXE","SCCM_SERVICE_ACCOUNT":"Служебная учётная запись SCCM с SPN","SCCM_GROUP_BROAD_MEMBER":"Широкая группа состоит в группе, связанной с SCCM","AZURE_AD_CONNECT_EXPOSED":"Возможное раскрытие доступа к серверу Microsoft Entra Connect","ADFS_DKM_CONTAINER":"AD FS развёрнут: ключ подписи токенов хранится в каталоге","MSSQL_SERVICE_ACCOUNT_PRIVILEGED":"SQL Server работает от привилегированной доменной учётной записи","LAPS_PASSWORD_NOT_ROTATED":"Пароль LAPS перестал регулярно обновляться","DSRM_PASSWORD_UNMANAGED":"Пароль DSRM не управляется Windows LAPS","NON_DEFAULT_COMPUTER_OWNERS":"Нестандартный владелец компьютерного объекта","COMPUTER_OWNERSHIP_REASSIGNED":"Владелец компьютерного объекта изменён после создания","NON_DEFAULT_USER_OWNERS":"Нестандартный владелец пользовательского объекта","READABLE_UNIX_PASSWORD_ATTRIBUTES":"Парольные атрибуты UNIX доступны для чтения","STANDALONE_MSA_LEGACY":"Устаревшая автономная управляемая учётная запись службы (sMSA)","GPO_TASK_SYSTEM_UNC_PATH":"Задача GPO запускается от SYSTEM или привилегированной записи по UNC-пути","GPO_TASK_UNQUOTED_PATH":"В задаче GPO не заключён в кавычки путь исполняемого файла","GPO_TASK_CMD_UNQUOTED_PATH":"Задача GPO передаёт cmd.exe путь без кавычек","ESC15_SCHEMA_V1_ENROLLEE_SUBJECT":"ESC15 — шаблон схемы v1 позволяет задавать субъект сертификата заявителю","CREDENTIAL_ROAMING_PRESENT":"Credential Roaming: закрытые ключи и мастер-ключи DPAPI хранятся в AD","CREDENTIAL_ROAMING_READABLE":"Credential Roaming: данные доступны всем прошедшим проверку подлинности","CREDENTIAL_ROAMING_DELEGATED":"Credential Roaming: чтение закрытых и мастер-ключей делегировано","ESC14_WEAK_EXPLICIT_MAPPING":"ESC14 — слабое явное сопоставление сертификатов","ESC14_WRITABLE_MAPPING":"ESC14 — непривилегированный субъект может изменить altSecurityIdentities","ESC13_ISSUANCE_POLICY_GROUP_LINK":"ESC13 — политика выдачи сертификата связана с группой AD","ADCS_CA_WEAK_SIGNATURE":"В сертификате ЦС используется слабый алгоритм подписи","ADCS_CA_SHORT_KEY":"Недостаточная длина ключа сертификата ЦС","ADCS_CA_CERT_EXPIRED":"Срок действия сертификата ЦС истёк","ADCS_CA_CROSS_DOMAIN":"Сервер центра сертификации находится в другом домене","PRIVILEGED_GROUP_ACL":"Возможность управления привилегированной группой вне защиты AdminSDHolder","PRIVILEGED_ACCOUNT_ACL":"Возможность управления привилегированной учётной записью","NTAUTH_FOREIGN_ISSUER":"Хранилище NTAuth содержит издателя вне корпоративных ЦС этого леса","PKI_WEAK_SIGNATURE_ALGORITHM":"В сертификате PKI используется слабый алгоритм подписи","PKI_SHORT_KEY_LENGTH":"Недостаточная длина ключа сертификата PKI","PKI_CERTIFICATE_EXPIRED":"Срок действия сертификата PKI истёк","COMPUTER_CONTAINER_CREATE_BROAD":"Широкой группе разрешено создавать компьютерные объекты","COMPUTER_CONTAINER_CREATE_PERMISSIONS":"Нестандартные разрешения на создание компьютерных объектов","GPO_SEMACHINEACCOUNTPRIVILEGE_BROAD":"Право SeMachineAccountPrivilege назначено через GPO","BLOODHOUND_COLLECTION_COMPLETE":"Сбор данных BloodHound","LDAP_SIGNING_REQUIRED":"Цифровая подпись LDAP обязательна","LDAP_CHANNEL_BINDING_ALWAYS":"Привязка канала LDAP обязательна всегда","LDAP_ANONYMOUS_BINDING_RESTRICTED":"Анонимные подключения LDAP ограничены","ANONYMOUS_SAM_ENUMERATION_ALLOWED":"Разрешено анонимное перечисление учётных записей SAM и общих ресурсов","ANONYMOUS_SID_NAME_TRANSLATION_ALLOWED":"Разрешено анонимное преобразование SID в имена","SMB_SIGNING_REQUIRED":"Цифровая подпись SMB обязательна","ENROLLMENT_REQUIRES_APPROVAL":"Для регистрации сертификата необходимо одобрение","ACCOUNT_DISABLED":"Учётная запись отключена","SMARTCARD_REQUIRED":"Для интерактивного входа обязательна смарт-карта","ACCOUNT_NOT_DELEGATED":"Учётная запись помечена как конфиденциальная и не допускает делегирования","WEB_ENDPOINT_EPA_ENABLED":"Включена расширенная защита проверки подлинности (EPA)","PKI_STRONG_SIGNATURE_ALGORITHM":"Сертификат PKI использует стойкий алгоритм подписи","PKI_STRONG_KEY_LENGTH":"Сертификат PKI использует достаточную длину ключа","PASSWORD_COMPLEXITY_ENABLED":"Требования к сложности пароля включены","LOCKOUT_DURATION_FOREVER":"Разблокировка учётной записи требует действий администратора","PRIMARY_GROUP_IS_DC_GROUP":"У некомуьпьютерной записи основная группа контроллеров домена","TIER0_NOT_IN_PROTECTED_USERS":"Учётная запись уровня Tier 0 отсутствует в группе Protected Users","OPERATOR_GROUP_MEMBERS":"В операторской группе есть активные участники","INACTIVE_ACCOUNT":"Обнаружена неактивная учётная запись","OLD_FUNCTIONAL_LEVEL":"Устаревший функциональный уровень домена или леса","AD_RECYCLE_BIN_DISABLED":"Корзина Active Directory не включена","SYSVOL_FRS_REPLICATION":"Репликация SYSVOL всё ещё использует FRS","TOMBSTONE_LIFETIME_SHORT":"Срок хранения удалённых объектов меньше 180 дней","PREWIN2000_ANONYMOUS_MEMBER":"Anonymous Logon состоит в группе Pre-Windows 2000 Compatible Access","PREWIN2000_DEFAULT_MEMBER":"Authenticated Users состоит в группе Pre-Windows 2000 Compatible Access","PREWIN2000_BROAD_MEMBER":"Широкая группа включена в Pre-Windows 2000 Compatible Access","ANON_LDAP_READABLE_ATTRS":"Атрибуты LDAP доступны анонимному чтению","LAPS_UNPROTECTED_COMPUTERS":"Компьютеры не защищены LAPS","LAPS_COVERAGE_NOT_IN_AD":"Не удаётся определить охват LAPS по данным Active Directory","GPO_WIDE_IMPACT":"Объект GPO влияет на большое количество компьютеров","LAPS_GPO_PASSWORD_LENGTH":"Длина пароля LAPS меньше стандартного значения","LAPS_GPO_PASSWORD_AGE":"Интервал смены пароля LAPS превышает стандартный","LAPS_GPO_DISABLED":"LAPS отключён групповой политикой","LAPS_GPO_NO_POST_AUTH_RESET":"Windows LAPS не сбрасывает пароль после использования","GMSA_ROTATION_INTERVAL_LONG":"Пароль gMSA меняется слишком редко","GMSA_MEMBERSHIP_OWNER":"Дескриптор доступа к паролю gMSA принадлежит непривилегированному субъекту","AUTHN_SILO_NOT_EFFECTIVE":"Хранилище политик проверки подлинности никого не ограничивает","AUTHN_SILO_INCOMPLETE_ENROLLMENT":"Учётная запись не включена в назначенное хранилище политики проверки подлинности","AUTHN_POLICY_EXEMPT_ADMINISTRATOR":"Встроенная запись «Администратор» подпадает под политику проверки подлинности","AUTHN_POLICY_NOT_EFFECTIVE":"Политика проверки подлинности работает в режиме аудита","AUTHN_POLICY_BROAD_CONDITION":"Условие политики проверки подлинности допускает широкую группу","AUTHN_POLICY_OBJECT_WRITABLE":"Объект политики проверки подлинности доступен для записи вне Tier 0","AUTHN_KDC_ARMORING_NOT_SUPPORTED":"Контроллеры домена не поддерживают утверждения и защищённый Kerberos (Armoring)","DMSA_LINK_IRREGULAR":"Учётная запись связана с dMSA вне штатной процедуры миграции","DMSA_LINK_ONE_SIDED":"Ссылка между dMSA и исходной записью существует только в одном направлении","DMSA_PRIVILEGED_PREDECESSOR":"Привилегированная учётная запись заменена на dMSA","DMSA_USABLE_BY_NONPRIVILEGED":"dMSA доступна непривилегированным субъектам","DMSA_MEMBERSHIP_OWNER":"Дескриптор использования dMSA принадлежит непривилегированному субъекту","GMSA_MEMBERSHIP_INFO":"Сведения о разрешениях использования gMSA","ACL_INHERITED_FROM":"Источник наследования ACL","ADMIN_COUNT_INDICATOR":"Установлен adminCount без членства в защищаемой группе","LAPS_ACCOUNT_INFO":"Управляемая учётная запись LAPS","DANGEROUS_RIGHTS_SEVERITY":"Классификация разрешений по уровню риска","DANGEROUS_RIGHTS_AFFECTED_OUS":"Организационные единицы, затронутые опасными разрешениями","ADCS_CLIENT_AUTH_SEVERITY":"Разрешена проверка подлинности клиента","ADCS_MANAGER_APPROVAL":"Состояние одобрения заявок администратором сертификатов","CERT_FLAG_SEVERITY":"Классификация флагов шаблона сертификата","EXCHANGE_WEB_ENDPOINTS":"Защищённость веб-интерфейсов Exchange","CONSTRAINED_DELEGATION":"Настроено ограниченное делегирование Kerberos","LAPS_INSTALLED":"Установлен Windows LAPS","LAPS_LEGACY":"Используется прежняя версия LAPS","META_SEVERITY_PASSTHROUGH":"Индикатор уровня опасности","META_STATUS_INDICATOR":"Индикатор состояния","CREDENTIAL_USERNAME_EXPOSED":"Имя пользователя обнаружено в раскрытых учётных данных","CREDENTIAL_PASSWORD_EXPOSED":"Пароль обнаружен в раскрытых учётных данных","CREDENTIAL_MATCHED_LINE":"Строка с найденными учётными данными","CREDENTIAL_TYPE_INFO":"Тип обнаруженных учётных данных","LAPS_ENCRYPTED_PASSWORD":"Доступно чтение зашифрованного пароля LAPS без ключа расшифрования","NON_DEFAULT_OWNER":"Нестандартный владелец объекта","ENCRYPTION_RC4_ONLY":"Учётная запись поддерживает только RC4 для Kerberos","ENCRYPTION_DES_ENABLED":"Для Kerberos разрешён алгоритм DES","ENCRYPTION_NOT_CONFIGURED":"Типы шифрования не заданы у учётной записи с SPN","ENCRYPTION_AES_ONLY":"Учётная запись Kerberos ограничена шифрованием AES","KERBEROASTABLE_USER_SPN":"Пользовательская учётная запись с SPN допускает Kerberoasting","DANGEROUS_RIGHTS_CONTEXT":"Опасные разрешения с учётом контекста","GPO_SCOPE_SEVERITY":"Состояние применения групповой политики","GPO_LOCAL_GROUP_RISKY_MEMBER":"Широкая группа добавлена в локальную группу через GPO","GPO_LOCAL_GROUP_MEMBER":"Учётная запись добавлена в привилегированную локальную группу через GPO","GPO_LINK_REACHES_DC":"Привязка GPO затрагивает контроллер домена","GPO_TASK_FIELD_SEVERITY":"Классификация параметра запланированного задания","GPO_LINKED_OUS_SEVERITY":"GPO привязан к корню домена","WEB_ENDPOINT_SECURITY":"Классификация защищённости веб-интерфейсов","REGISTRY_ESC10_KDC_BINDING":"ESC10 — Kerberos игнорирует SID-расширение сертификата из-за настройки GPO","REGISTRY_ESC10_KDC_BINDING_COMPAT":"ESC10 — Kerberos принимает сертификаты без SID-расширения из-за настройки GPO","REGISTRY_ESC10_SCHANNEL_UPN":"ESC10 — Schannel сопоставляет сертификаты по UPN из-за настройки GPO","REGISTRY_WDIGEST":"Кэширование учётных данных WDigest в открытом виде включено через GPO","REGISTRY_ONELOGON":"Уязвимый список разрешений защищённого канала Netlogon (Zerologon/OneLogon)","REGISTRY_AUTOLOGON":"Автоматический вход AutoAdminLogon включён через GPO","REGISTRY_LMCOMPAT":"Через GPO разрешена слабая проверка подлинности LM/NTLMv1","REGISTRY_NOLMHASH":"Сохранение LM-хешей разрешено через GPO","REGISTRY_REMOTEUAC":"Удалена фильтрация токенов Remote UAC через GPO","REGISTRY_ALWAYSINSTALLELEVATED":"Установка MSI с повышенными правами AlwaysInstallElevated включена через GPO","REGISTRY_ENABLELUA":"Контроль учётных записей (UAC) отключён через GPO","REGISTRY_RESTRICTEDADMIN":"Режим Restricted Admin для RDP включён через GPO","REGISTRY_WSUS_HTTP":"Сервер обновлений WSUS настроен по незашифрованному HTTP","REGISTRY_DEFENDER_DISABLED":"Антивирус Microsoft Defender отключён через GPO","REGISTRY_RUNASPPL":"Защита процесса LSA (RunAsPPL) явно отключена через GPO","REGISTRY_CREDGUARD":"Credential Guard явно отключён через GPO","REGISTRY_FILTERADMINTOKEN":"Фильтрация UAC для встроенного администратора RID 500 отключена через GPO","REGISTRY_CREDSSP_ORACLE":"Уязвимая настройка CredSSP Encryption Oracle задана через GPO","REGISTRY_MACHINE_PASSWORD_STATIC":"Смена пароля компьютерной учётной записи отключена через GPO","REGISTRY_NULL_SESSION":"Анонимный доступ (Null Session) расширен через GPO","REGISTRY_RDP_NLA":"Проверка подлинности на уровне сети (NLA) для RDP отключена через GPO","REGISTRY_RDP_SECURITYLAYER":"Уровень безопасности RDP понижен через GPO","REGISTRY_RDP_ENCRYPTION":"Для RDP установлен низкий уровень шифрования через GPO","REGISTRY_FIREWALL_DISABLED":"Брандмауэр Windows отключён через GPO","REGISTRY_INSECURE_GUEST_AUTH":"Небезопасный гостевой вход SMB разрешён через GPO","REGISTRY_SMB1_SERVER":"Серверный компонент SMBv1 включён через GPO","REGISTRY_SMB1_CLIENT":"Клиентский компонент SMBv1 включён через GPO","REGISTRY_SMB2_SERVER_DISABLED":"Серверный компонент SMBv2/v3 отключён через GPO","REGISTRY_SMB_UNENCRYPTED_ACCESS":"Разрешён доступ без шифрования к ресурсам SMB, требующим шифрования","REGISTRY_DSRM_ADMIN_LOGON":"Вход администратора DSRM разрешён в любое время через GPO","REGISTRY_PRINT_RPC_PRIVACY":"Усиленная защита конфиденциальности RPC службы печати отключена через GPO","REGISTRY_WSUS_USER_PROXY":"Проверка обновлений WSUS может использовать прокси пользователя","REGISTRY_MACHINE_PASSWORD_AGE":"Период смены пароля компьютера через GPO превышает 30 дней","REGISTRY_SCRIPTBLOCK_LOGGING_OFF":"Журналирование блоков сценариев PowerShell отключено через GPO","REGISTRY_UAC_NO_PROMPT":"Администраторы повышают привилегии без запроса UAC из-за GPO","REGISTRY_LEGACY_TLS":"SSL 3.0 или TLS 1.0 включён через GPO","REGISTRY_WINRM_UNENCRYPTED":"WinRM разрешает незашифрованные подключения через GPO","REGISTRY_WINRM_BASIC":"В WinRM разрешена базовая проверка подлинности через GPO","REGISTRY_CREDSSP_DELEGATE_ANY":"CredSSP делегирует учётные данные любому серверу через GPO","REGISTRY_LLMNR_ON":"Многоадресное разрешение имён LLMNR включено через GPO","REGISTRY_CACHED_LOGONS":"Число кэшируемых входов в домен превышает стандартное значение","REGISTRY_REMOTE_ASSISTANCE_OFFER":"Незапрошенная удалённая помощь разрешена через GPO","REGISTRY_LDAP_CLIENT_SIGNING_OFF":"Подпись LDAP на клиенте отключена через GPO","REGISTRY_KERBEROS_WEAK_ETYPES":"Kerberos разрешает шифрование DES или RC4 через GPO","REGISTRY_OFFICE_MACROS_ON":"Макросы Office запускаются без предупреждения из-за GPO","GPO_POINTANDPRINT_EXPLOITABLE":"Point and Print позволяет непривилегированным пользователям устанавливать драйверы без подтверждения (PrintNightmare)","GPO_POINTANDPRINT_NONADMIN_INSTALL":"Установка драйверов принтеров разрешена неадминистраторам","GPO_POINTANDPRINT_LATENT":"Запросы повышения прав Point and Print скрыты, но эксплуатация сейчас блокируется","GPO_POINTANDPRINT_USER_SCOPE":"Ограничения Point and Print заданы в конфигурации пользователя и игнорируются Windows","GPO_POINTANDPRINT_DRIVER_SOURCE":"Драйверы принтеров могут загружаться с любого сервера печати","GPO_PRINT_SPOOLER_RPC":"Диспетчер печати принимает удалённые RPC-подключения через GPO","GPO_PRINT_QUEUE_SPECIFIC_FILES":"Диспетчер печати может копировать произвольные файлы очереди печати","GPO_PRINT_DRIVER_HARDENING":"Усиленная защита доставки драйверов принтеров отключена","LAPS_GPO_ENCRYPTION_DISABLED":"Шифрование паролей Windows LAPS в AD отключено через GPO","LAPS_GPO_NO_AD_BACKUP":"Windows LAPS не сохраняет пароли в этой Active Directory","LAPS_GPO_EXPIRATION_PROTECTION_DISABLED":"Защита срока действия пароля Windows LAPS отключена через GPO","LAPS_GPO_WEAK_PASSWORD_COMPLEXITY":"Через GPO задана слабая сложность паролей LAPS","LAPS_GPO_NOT_LINKED":"Настройка LAPS содержится в непривязанном объекте GPO","GPO_SCRIPT_OUTSIDE_POLICY_STORE":"Сценарий GPO запускается вне хранилища групповых политик","LOGON_SCRIPT_WRITABLE":"Сценарий входа может изменить непривилегированный субъект","SCRIPTPATH_HARDCODED":"Путь сценария входа задан жёстко","UAC_SEVERITY_OVERRIDE":"Классификация риска параметров контроля учётных записей"};
        const ruFindingExplanations = {"KERBEROASTABLE_SPN":{"description":"Для пользовательской учётной записи задан SPN. Любой прошедший проверку подлинности пользователь домена может запросить билет службы TGS, зашифрованный ключом этой записи, и попытаться подобрать пароль вне домена.","impact":["Возможна компрометация служебной записи, особенно если у неё слабый пароль или повышенные полномочия."],"remediation":["По возможности используйте gMSA, задавайте длинные случайные пароли, включайте AES и контролируйте запросы TGS."]},"ASREP_ROASTABLE":{"description":"У учётной записи отключена предварительная проверка подлинности Kerberos (DONT_REQUIRE_PREAUTH). Посторонний субъект может запросить AS-REP и попытаться подобрать пароль автономно.","impact":["Подбор пароля возможен без предварительного входа в домен."],"remediation":["Включите предварительную проверку подлинности Kerberos и проверьте необходимость исключений."]},"KERBEROAST_WITHOUT_PREAUTH":{"description":"При наличии записи без предварительной проверки подлинности злоумышленник может запросить билеты служб других учётных записей с SPN без собственных доменных учётных данных.","impact":["Все доступные для Kerberoasting служебные записи оказываются под повышенным риском."],"remediation":["Включите предварительную проверку подлинности для всех записей и применяйте gMSA или длинные случайные пароли для служб."]},"KERBEROS_HASH_CRACKABLE":{"description":"Выделенный из билета Kerberos материал допускает автономную проверку вариантов пароля без новых обращений к контроллеру домена.","impact":["Подобранный пароль может дать доступ от имени соответствующей учётной записи."],"remediation":["Смените слабые пароли, применяйте AES и управляемые учётные записи служб."]},"KRBTGT_PASSWORD_OLD":{"description":"Пароль встроенной учётной записи krbtgt не обновлялся продолжительное время. Он используется в криптографических операциях Kerberos, связанных с билетами домена.","impact":["При компрометации ключей krbtgt возможны поддельные билеты Golden Ticket."],"remediation":["Планируйте штатную двойную смену пароля krbtgt по процедуре Microsoft с учётом репликации всех контроллеров домена."]},"GUEST_ACCOUNT_ENABLED":{"description":"Встроенная запись «Гость» (RID 501) активна и может предоставлять ненужную возможность доступа.","impact":["Дополнительная точка входа и риск анонимного или слабоконтролируемого доступа."],"remediation":["Отключите встроенную запись «Гость» и проверьте членство в группах и явные разрешения."]},"UNCONSTRAINED_DELEGATION":{"description":"На объекте разрешено неограниченное делегирование Kerberos. Узел может получать пересылаемые билеты TGT пользователей, подключающихся к его службам.","impact":["Компрометация узла позволяет злоупотреблять билетами пользователей, включая привилегированных."],"remediation":["Откажитесь от неограниченного делегирования; используйте ограниченное делегирование или RBCD и запретите делегирование привилегированных учётных записей."]},"UNCONSTRAINED_DELEGATION_EXPOSED_ACCOUNTS":{"description":"Привилегированные учётные записи могут передавать билеты TGT компьютерам с неограниченным делегированием.","impact":["Компрометация такого компьютера создаёт риск захвата привилегированных сеансов."],"remediation":["Ограничьте делегирование и пометьте критические записи как конфиденциальные, не допускающие делегирования."]},"CONSTRAINED_DELEGATION_PROTOCOL_TRANSITION":{"description":"Разрешено ограниченное делегирование с переходом протокола (S4U). При неверных границах доверия это может позволить выдавать себя за других пользователей при доступе к разрешённым службам.","impact":["Возможна подмена контекста пользователя на службе назначения."],"remediation":["Проверьте список служб msDS-AllowedToDelegateTo, учётную запись службы и необходимость перехода протокола."]},"RBCD_DANGEROUS_PRINCIPALS":{"description":"Разрешения на ограниченное делегирование на основе ресурса (RBCD) предоставлены субъектам, не соответствующим ожидаемой модели доверия.","impact":["Субъект с соответствующими полномочиями может получать доступ к ресурсу от имени других пользователей."],"remediation":["Ограничьте значения msDS-AllowedToActOnBehalfOfOtherIdentity только доверенными службами и контролируйте ACL объекта компьютера."]},"ESC1_TEMPLATE":{"description":"Шаблон сертификата может позволять заявителю задавать имя субъекта или альтернативные имена, а выданный сертификат — использоваться для проверки подлинности клиента.","impact":["При доступной регистрации возможно получение сертификата для чужой учётной записи."],"remediation":["Ограничьте права регистрации и изменение имени субъекта; проверьте EKU, требования одобрения и полномочия владельцев шаблона."]},"ESC2_TEMPLATE":{"description":"Шаблон AD CS допускает сертификаты для широкого набора назначений, включая Any Purpose или SubCA, при потенциально небезопасных правах регистрации.","impact":["Возможна выдача сертификатов с чрезмерно широкими возможностями использования."],"remediation":["Сузьте EKU и права регистрации; выдавайте такие сертификаты только после административного одобрения."]},"ESC3_TEMPLATE":{"description":"Шаблон выдаёт сертификаты агента запросов, позволяющие подавать запросы от имени других пользователей при наличии соответствующей конфигурации.","impact":["Ошибки прав на агентский шаблон могут привести к выдаче чужих удостоверений."],"remediation":["Ограничьте регистрацию сертификатов агента и настройте политики уполномоченных агентов."]},"ESC4_TEMPLATE":{"description":"На шаблоне AD CS присутствуют разрешения, позволяющие неподходящим субъектам изменять его параметры или список управления доступом.","impact":["Изменение шаблона может создать опасный сценарий регистрации сертификата."],"remediation":["Удалите избыточные WriteDACL, WriteOwner, GenericAll и права изменения параметров шаблона."]},"ESC5_PKI_CONTAINER_ACL":{"description":"Контейнеры PKI в Active Directory имеют опасные разрешения на изменение доверенной инфраструктуры.","impact":["Изменение критических объектов PKI может повлиять на доверие к сертификатам."],"remediation":["Разрешите управление контейнерами PKI только специально уполномоченным администраторам."]},"ESC8_WEB_ENROLLMENT":{"description":"Веб-службы регистрации сертификатов потенциально допускают ретрансляцию NTLM при недостаточной защите канала проверки подлинности.","impact":["В определённых условиях возможна выдача сертификата от имени другого субъекта."],"remediation":["Включите EPA, настройте HTTPS и ограничения NTLM; отключите ненужные службы веб-регистрации."]},"LDAP_SIGNING_NOT_REQUIRED":{"description":"Контроллер домена не требует обязательной подписи LDAP-запросов. Это снижает защиту от подмены и ретрансляции аутентификации.","impact":["Повышается риск атак на целостность LDAP-сеансов и NTLM Relay при наличии других условий."],"remediation":["Включите обязательную подпись LDAP на контроллерах и проверьте совместимость приложений."]},"LDAP_CHANNEL_BINDING_NOT_REQUIRED":{"description":"Для LDAPS не обеспечивается обязательная привязка канала TLS (LDAP Channel Binding).","impact":["При определённых схемах проверки подлинности возможны атаки ретрансляции."],"remediation":["Настройте LDAP Channel Binding на контроллерах домена и проверьте журналы совместимости клиентов."]},"LDAP_ANONYMOUS_BINDING_ALLOWED":{"description":"Некоторые операции LDAP доступны без проверки подлинности.","impact":["Анонимный доступ может раскрывать сведения о структуре домена и учётных записях."],"remediation":["Ограничьте анонимные LDAP-запросы, если они не требуются подтверждённым приложениям."]},"DANGEROUS_ACL_GENERICALL":{"description":"Субъекту предоставлен полный доступ GenericAll к чувствительному объекту каталога.","impact":["Возможны изменение объекта, его разрешений или использование полномочий для повышения привилегий."],"remediation":["Удалите ненужные разрешения GenericAll и делегируйте только конкретные необходимые операции."]},"DANGEROUS_ACL_WRITEDACL":{"description":"Субъект может менять список управления доступом (DACL) чувствительного объекта.","impact":["Право WriteDACL позволяет выдавать себе или другим дополнительные разрешения."],"remediation":["Ограничьте право WriteDACL доверенными администраторами и контролируйте изменения ACL."]},"DANGEROUS_ACL_WRITEOWNER":{"description":"Субъект может изменить владельца чувствительного объекта Active Directory.","impact":["Новый владелец в ряде случаев может изменить DACL и получить дополнительные права."],"remediation":["Ограничьте WriteOwner и пересмотрите нестандартное владение объектом."]},"DANGEROUS_ACL_DCSYNC":{"description":"Обнаружены права репликации, потенциально достаточные для DCSync — получения секретов каталога без входа на контроллер домена.","impact":["Возможна компрометация хешей и секретов учётных записей домена."],"remediation":["Ограничьте DS-Replication-Get-Changes и DS-Replication-Get-Changes-All контроллерами домена и доверенными службами."]},"DANGEROUS_ACL_DCSYNC_BROAD":{"description":"Права DCSync назначены группе с широким составом участников.","impact":["Члены группы могут получить доступ к реплицируемым секретам при наличии необходимых прав."],"remediation":["Отзовите полномочия репликации у широких групп и проверьте фактический состав через вложенные группы."]},"OU_PERM_PASSWORD_RESET":{"description":"На уровне организационной единицы делегировано право сбрасывать пароли учётных записей.","impact":["Неоправданно широкое делегирование позволяет захватить учётные записи в области действия."],"remediation":["Оставьте право сброса паролей только уполномоченным операторам и исключите привилегированные записи."]},"OU_PERM_SPN_WRITE":{"description":"Субъект может изменять servicePrincipalName у объектов в OU.","impact":["Изменение SPN может создать условия для злоупотребления Kerberos и атаки Kerberoasting."],"remediation":["Пересмотрите делегирование WriteProperty на servicePrincipalName и права наследования OU."]},"OU_PERM_KEYCREDENTIALLINK_WRITE":{"description":"Субъект может изменять msDS-KeyCredentialLink у объектов Active Directory.","impact":["Неправомерная запись ключевых учётных данных может позволить альтернативную аутентификацию от имени объекта."],"remediation":["Ограничьте запись msDS-KeyCredentialLink и контролируйте изменения атрибута."]},"PASSWORD_NOT_REQUIRED":{"description":"У учётной записи установлен флаг PASSWD_NOTREQD, который снимает требование наличия пароля на уровне атрибута userAccountControl.","impact":["При дополнительных небезопасных условиях запись может иметь слабую защиту."],"remediation":["Снимите флаг PASSWD_NOTREQD, если он не обоснован, и проверьте фактические параметры пароля."]},"PASSWORD_NEVER_EXPIRES":{"description":"Для учётной записи установлен запрет истечения срока действия пароля.","impact":["При компрометации длительно неизменяемый пароль расширяет период возможного злоупотребления."],"remediation":["Проверьте необходимость исключения и внедрите управляемую ротацию паролей, особенно для служебных записей."]},"GPO_DANGEROUS_PERMISSIONS":{"description":"Обнаружены разрешения на изменение объекта групповой политики, предоставленные субъектам вне ожидаемого административного круга.","impact":["Изменение GPO может затронуть пользователей и компьютеры в области её действия."],"remediation":["Пересмотрите права изменения GPO и связанные разрешения на каталог SYSVOL."]},"GPO_SYSVOL_WRITABLE":{"description":"Папка групповой политики в SYSVOL доступна на запись субъекту вне доверенного административного круга.","impact":["Изменённые сценарии и параметры политики могут выполниться на компьютерах и пользователях."],"remediation":["Ограничьте права NTFS и разрешения общего ресурса на папки политик SYSVOL."]},"GPO_SYSVOL_GPT_MISSING":{"description":"У объекта групповой политики отсутствует соответствующая папка SYSVOL или файл gpt.ini.","impact":["Политика может применяться неполностью или некорректно."],"remediation":["Проверьте репликацию SYSVOL и согласованность данных AD и файлов групповой политики."]},"GPO_NON_DEFAULT_OWNER":{"description":"У объекта GPO назначен владелец, отличный от ожидаемого.","impact":["Владелец может влиять на разрешения объекта даже без явного права изменения его настроек."],"remediation":["Проверьте происхождение владельца и восстановите штатное владение при отсутствии обоснования."]},"LAPS_NOT_DEPLOYED":{"description":"Для части инфраструктуры не обнаружено управление паролями локальных администраторов с помощью LAPS.","impact":["Повторяющиеся или неизменяемые локальные пароли повышают риск бокового перемещения."],"remediation":["Внедрите Windows LAPS и проверьте политику хранения, прав чтения и ротации паролей."]},"LAPS_PASSWORD_READABLE":{"description":"Текущему субъекту или указанной группе доступны пароли локальных администраторов, сохраняемые LAPS.","impact":["Обладатель разрешения может получить административный доступ к соответствующему компьютеру."],"remediation":["Ограничьте чтение атрибутов LAPS и регулярно проверяйте делегирование на OU."]},"BITLOCKER_KEY_READABLE":{"description":"Обнаружен доступ к сведениям восстановления BitLocker в Active Directory.","impact":["Доступ к ключу восстановления может позволить расшифровать защищённый том."],"remediation":["Ограничьте чтение данных восстановления BitLocker уполномоченным администраторам и журналируйте доступ."]},"SMB_SIGNING_DISABLED":{"description":"Цифровая подпись SMB не является обязательной для соответствующей системы или политики.","impact":["При наличии других условий возможны ретрансляция учётных данных и подмена SMB-трафика."],"remediation":["Включите требование подписи SMB на серверах и клиентах с учётом совместимости."]},"REVERSIBLE_ENCRYPTION":{"description":"Пароль учётной записи хранится с использованием обратимого шифрования.","impact":["Такая настройка ослабляет защиту парольных данных при компрометации хранилища."],"remediation":["Отключите обратимое шифрование и измените пароль после корректировки параметра."]},"CREDENTIAL_IN_DESCRIPTION":{"description":"В свободно заполняемом атрибуте объекта обнаружено содержимое, похожее на учётные данные.","impact":["Читающий атрибут субъект может получить доступ к секрету."],"remediation":["Удалите секрет из атрибута, смените затронутые учётные данные и используйте защищённое хранилище."]},"CREDENTIAL_GPP_PASSWORD":{"description":"В предпочтениях групповой политики обнаружены параметры, потенциально раскрывающие пароль.","impact":["Чтение файлов GPP может позволить восстановить секрет и скомпрометировать учётную запись."],"remediation":["Удалите сохранённые секреты из GPP, смените пароли и применяйте современные механизмы управления учётными данными."]},"CREDENTIAL_SCRIPT_PASSWORD":{"description":"В содержимом доступного сценария обнаружен пароль или похожий секрет.","impact":["Субъект с правом чтения файла может использовать обнаруженные учётные данные."],"remediation":["Удалите секрет из сценария и переместите его в защищённое хранилище; смените обнаруженный пароль."]},"RBCD_CONFIGURED":{"description":"Для объекта настроено ограниченное делегирование Kerberos на основе ресурса (RBCD).","impact":["Настройка безопасна только при корректно ограниченном перечне доверенных субъектов."],"remediation":["Проверьте msDS-AllowedToActOnBehalfOfOtherIdentity и соответствие настроек реальной архитектуре."]},"TRUST_SID_FILTERING_DISABLED":{"description":"На доверительных отношениях отключена фильтрация SID.","impact":["SID из внешних областей доверия могут влиять на вычисление прав в ресурсном домене."],"remediation":["Включите подходящие режимы SID Filtering и согласуйте исключения с архитектурой доверия."]},"WEAK_PASSWORD_POLICY":{"description":"Доменная политика паролей не соответствует рекомендуемым параметрам стойкости или защите от перебора.","impact":["Слабые пароли повышают риск несанкционированного доступа."],"remediation":["Пересмотрите длину, историю, сложность и блокировку учётных записей с учётом современных рекомендаций Microsoft."]},"NO_ACCOUNT_LOCKOUT":{"description":"Политика блокировки учётных записей отсутствует либо её параметры допускают слишком большое число попыток.","impact":["Повышается риск атак перебором и распылением паролей."],"remediation":["Настройте порог и длительность блокировки с учётом риска отказа в обслуживании и политики организации."]},"WEAK_FGPP":{"description":"Тонкая политика паролей задаёт менее строгие параметры, чем доменная политика по умолчанию.","impact":["Затронутые пользователи и группы могут иметь более слабые пароли или защиту от перебора."],"remediation":["Сопоставьте приоритеты FGPP, область применения и требования безопасности; скорректируйте ослабленные параметры."]},"INACTIVE_PRIVILEGED_ACCOUNT":{"description":"Привилегированная учётная запись не использовалась дольше установленного порога.","impact":["Неиспользуемые административные учётные записи создают лишнюю поверхность атаки."],"remediation":["Подтвердите владельца и назначение записи, отключите ненужные записи, пересмотрите членство в группах."]},"LAPS_GPO_DISABLED":{"description":"Групповая политика отключает или не активирует механизмы управления локальными паролями LAPS.","impact":["Локальный административный пароль может оставаться неизменным."],"remediation":["Исправьте политику Windows LAPS и проверьте фактическое применение на целевых компьютерах."]},"SYSVOL_FRS_REPLICATION":{"description":"Репликация SYSVOL всё ещё использует устаревшую службу FRS.","impact":["FRS усложняет поддержку и обновление контроллеров домена; возможны проблемы согласованности политик."],"remediation":["Проведите подготовленную миграцию репликации SYSVOL на DFSR согласно документации Microsoft."]},"OLD_FUNCTIONAL_LEVEL":{"description":"Функциональный уровень домена или леса устарел.","impact":["Могут быть недоступны современные возможности и механизмы защиты AD."],"remediation":["Проверьте совместимость всех контроллеров и приложений, после чего рассмотрите повышение функционального уровня."]},"AD_RECYCLE_BIN_DISABLED":{"description":"Корзина Active Directory для леса не включена.","impact":["Восстановление удалённых объектов с сохранением атрибутов и членства в группах затруднено."],"remediation":["Оцените возможность включения корзины AD на поддерживаемом функциональном уровне леса."]},"GPO_POINTANDPRINT_EXPLOITABLE":{"description":"Параметры Point and Print позволяют устанавливать драйверы принтеров без необходимого административного подтверждения.","impact":["При определённых условиях возможен запуск кода с повышенными привилегиями (семейство PrintNightmare)."],"remediation":["Ограничьте серверы печати, требуйте повышение привилегий и примените современные параметры защиты Point and Print."]},"REGISTRY_WDIGEST":{"description":"Политика допускает сохранение учётных данных WDigest в памяти в открытом виде.","impact":["Компрометация компьютера может раскрыть пароли вошедших пользователей."],"remediation":["Отключите хранение паролей WDigest в открытом виде и проверьте соответствующий параметр реестра."]},"REGISTRY_LLMNR_ON":{"description":"Многоадресное разрешение имён LLMNR разрешено политикой.","impact":["LLMNR может упрощать перехват или ретрансляцию аутентификации в локальной сети."],"remediation":["Отключите LLMNR там, где он не требуется, и обеспечьте корректное разрешение имён DNS."]},"REGISTRY_RDP_NLA":{"description":"Политика отключает проверку подлинности на уровне сети для RDP.","impact":["Служба RDP становится доступна до полноценной проверки подлинности пользователя."],"remediation":["Включите Network Level Authentication для RDP и ограничьте сетевой доступ к службе."]},"REGISTRY_SMB1_SERVER":{"description":"На сервере включён устаревший протокол SMBv1.","impact":["Устаревший протокол повышает риск эксплуатации известных уязвимостей и ошибок безопасности."],"remediation":["Отключите SMBv1 после проверки совместимости зависимых систем."]},"REGISTRY_FIREWALL_DISABLED":{"description":"Групповая политика отключает брандмауэр Windows.","impact":["Сетевые службы могут оказаться доступнее, чем предусмотрено политикой безопасности."],"remediation":["Включите профиль брандмауэра и настройте необходимые правила разрешения трафика."]},"REGISTRY_CREDGUARD":{"description":"Через групповую политику явно отключена защита Credential Guard.","impact":["Снижается защищённость секретов проверок подлинности на конечном устройстве."],"remediation":["Проверьте совместимость оборудования и включите Credential Guard для соответствующих систем."]},"GUEST_ACCOUNT_DISABLED":{"description":"Встроенная учётная запись «Гость» (RID 501) отключена. Это сокращает возможности несанкционированного входа с использованием общей учётной записи.","impact":["Отсутствует дополнительная точка входа через стандартную гостевую учётную запись."],"remediation":["Сохраняйте учётную запись отключённой и контролируйте её состояние через утверждённые политики."]},"UNCONSTRAINED_DELEGATION_DC":{"description":"Контроллер домена использует неограниченное делегирование Kerberos, что является особым штатным случаем для функций домена. Само по себе это не эквивалентно ошибке делегирования на обычном сервере.","impact":["Компрометация контроллера домена затрагивает критическую инфраструктуру аутентификации; вывод необходимо интерпретировать с учётом роли DC."],"remediation":["Не отключайте делегирование на DC без проверки зависимостей; обеспечьте защиту контроллеров домена как систем Tier 0."]},"GPO_NOT_CURRENTLY_EFFECTIVE":{"description":"Обнаруженная настройка содержится в объекте групповой политики, но в момент аудита не считается действующей для соответствующей области.","impact":["Неактивная настройка не обязательно влияет на текущие компьютеры или пользователей, однако может вступить в силу при изменении привязок GPO."],"remediation":["Проверьте привязку, состояние GPO, наследование и фильтры безопасности; контролируйте изменения области применения."]},"PRIVILEGED_ACCOUNT_AFFECTED":{"description":"Обнаруженный параметр затрагивает привилегированную учётную запись, права которой могут распространяться на критические объекты Active Directory.","impact":["Риск выше, чем для обычной записи, поскольку её компрометация может затронуть контроллеры домена и конфигурацию леса."],"remediation":["Определите фактические роли и доступ записи; применяйте изоляцию Tier 0, MFA и принцип минимально необходимых полномочий."]},"ROASTABLE_PRIVILEGED_ACCOUNT":{"description":"Привилегированная учётная запись имеет настройки, позволяющие получить материал Kerberos для автономного подбора пароля.","impact":["Подбор пароля может открыть доступ к административным полномочиям."],"remediation":["Исключите ненужные SPN и отсутствие предварительной проверки подлинности; применяйте gMSA и длинные случайные пароли."]},"CONSTRAINED_DELEGATION_TO_DC":{"description":"Указанной службе разрешено ограниченное делегирование Kerberos к службе на контроллере домена.","impact":["Компрометация делегирующей записи может затронуть защищённые операции, выполняемые от имени пользователя на DC."],"remediation":["Проверьте msDS-AllowedToDelegateTo, необходимость делегирования и защиту учётной записи службы."]},"CONSTRAINED_DELEGATION_TRANSITION_NO_TARGET":{"description":"У службы обнаружен признак перехода протокола Kerberos, но явная цель ограниченного делегирования не определена.","impact":["Сам признак не доказывает возможность доступа к другому сервису; он требует проверки совместно с другими настройками делегирования."],"remediation":["Сверьте userAccountControl и msDS-AllowedToDelegateTo с фактическим сценарием аутентификации."]},"ESC_ENROLLMENT_RIGHTS_UNREAD":{"description":"Права регистрации сертификатов для шаблона AD CS не удалось прочитать с учётными данными аудита.","impact":["Нельзя достоверно заключить, безопасен ли шаблон или кто может запросить сертификат."],"remediation":["Повторите чтение с учётной записью с разрешённым доступом и проверьте ACL шаблона и центра сертификации."]},"ESC3_TARGET_TEMPLATE":{"description":"Шаблон может участвовать в сценарии регистрации сертификата от имени другого субъекта, если разрешено использование агента запросов и отсутствуют достаточные ограничения.","impact":["Неправильное сочетание шаблонов агента и конечного сертификата создаёт риск выдачи сертификата для чужой учётной записи."],"remediation":["Ограничьте EKU Certificate Request Agent, права регистрации, требования одобрения и допустимые целевые шаблоны."]},"ADCS_HTTP_AVAILABLE":{"description":"Веб-интерфейс регистрации сертификатов доступен по HTTP. При отсутствии дополнительных защит запросы могут передаваться без TLS.","impact":["В некоторых конфигурациях возможны перехват данных или атаки ретрансляции NTLM к веб-регистрации AD CS."],"remediation":["По возможности используйте HTTPS, Extended Protection for Authentication и ограничение NTLM; проверьте IIS и настройки AD CS."]},"ADCS_NONPRIV_ENROLLMENT":{"description":"Право регистрации сертификатов предоставлено непривилегированным пользователям или группам.","impact":["Риск зависит от EKU, возможности указания имени субъекта, одобрения заявки и дополнительных разрешений шаблона."],"remediation":["Ограничьте регистрацию действительно необходимыми группами и проверьте сочетания настроек шаблона, создающие ESC-риски."]},"ADCS_CLIENT_AUTH_EKU":{"description":"Шаблон допускает расширенное назначение ключа Client Authentication (EKU). Это само по себе не является уязвимостью.","impact":["При неверных правах регистрации и настройках имени субъекта сертификат может использоваться для нежелательной проверки подлинности."],"remediation":["Проверьте EKU совместно с правами Enroll/Autoenroll, требованиями согласования и ограничениями имени субъекта."]},"ADCS_SMARTCARD_LOGON_EKU":{"description":"Шаблон допускает EKU Smart Card Logon, позволяющий применять сертификаты для доменной проверки подлинности при соответствующих условиях.","impact":["Опасность возникает в сочетании с широкими правами регистрации или возможностью указать чужую идентичность."],"remediation":["Проверьте соответствие выдачи сертификатов политике удостоверения личности и права регистрации."]},"DANGEROUS_ACL_GENERICWRITE":{"description":"Субъекту предоставлено право GenericWrite на важном объекте Active Directory. Оно позволяет менять некоторые свойства объекта в пределах выданных прав.","impact":["Изменяемые атрибуты могут использоваться для вмешательства в работу объекта или цепочки повышения привилегий."],"remediation":["Сопоставьте ACE с владельцем процесса и объёмом задач; уберите избыточные разрешения и проверьте наследование."]},"DANGEROUS_ACL_GPO_WRITEPROPERTY":{"description":"Субъект имеет право WriteProperty на объекте GPO, что может давать возможность изменять атрибуты групповой политики.","impact":["Изменение критичных атрибутов GPO иногда приводит к распространению нежелательных настроек на компьютеры и пользователей."],"remediation":["Проверьте конкретные GUID и свойства, на которые распространяется ACE, и ограничьте право доверенными администраторами GPO."]},"DANGEROUS_ACL_GPO_WRITEPROPERTY_SCOPED":{"description":"Право WriteProperty ограничено определённым атрибутом GPO, который сам по себе не управляет применяемым содержимым политики.","impact":["Такое разрешение нельзя приравнивать к полному контролю GPO; значимость зависит от конкретного атрибута."],"remediation":["Сохраните точный ObjectType ACE в аудите и оцените, требуется ли делегировать запись этого свойства."]},"DANGEROUS_ACL_GPO_DELETE":{"description":"Субъект может удалить объект групповой политики Active Directory при наличии соответствующего разрешения.","impact":["Удаление может нарушить применение настроек безопасности и доступность политик."],"remediation":["Ограничьте Delete/DeleteTree доверенными администраторами, контролируйте изменения и резервные копии GPO."]},"DANGEROUS_ACL_GPO_EXTENDED":{"description":"На объект GPO назначено разрешение Self либо ExtendedRight. Его фактическое действие зависит от ограничений ACE и конкретного объекта.","impact":["Без анализа GUID прав нельзя считать разрешение равным полному контролю над GPO."],"remediation":["Проверьте ObjectType, область действия и необходимость делегирования конкретной операции."]},"GPO_SYSVOL_FOLDER_ORPHANED":{"description":"В SYSVOL обнаружена папка групповой политики, которой не соответствует актуальный объект GPO в каталоге.","impact":["Осиротевшая папка может содержать устаревшие сценарии, настройки или лишние доступные файлы."],"remediation":["Сопоставьте GUID папки с объектами GPO, проверьте репликацию SYSVOL и удаляйте содержимое только после резервного копирования."]},"GPO_UNLINKED_BROAD_WRITE":{"description":"Непривязанный объект GPO допускает изменение со стороны широкой группы пользователей.","impact":["Хотя GPO не применяется сейчас, его последующая привязка может распространить изменённые настройки."],"remediation":["Ограничьте запись на объект и папку SYSVOL; учитывайте будущие изменения привязок."]},"DOMAIN_ROOT_GPLINK_WRITE":{"description":"Субъект может изменять атрибут gPLink корня домена, задающий связи групповых политик.","impact":["Право позволяет влиять на набор применяемых к домену GPO и потенциально на параметры множества компьютеров."],"remediation":["Ограничьте право изменения gPLink утверждёнными администраторами домена и контролируйте изменения."]},"DOMAIN_ROOT_SID_HISTORY_WRITE":{"description":"На объекте домена делегировано право, связанное с переносом SIDHistory.","impact":["При сочетании с другими необходимыми условиями некорректное делегирование может ослаблять границы доверия учётных записей."],"remediation":["Проверьте разрешения, процедуры миграции и аудирование изменений sIDHistory."]},"DOMAIN_ROOT_REPLICA_INSTALL":{"description":"Предоставлено право DS-Install-Replica, применяемое при установке дополнительных реплик каталога.","impact":["Неверное делегирование этого права требует оценки вместе с другими разрешениями на установку DC."],"remediation":["Ограничьте право доверенными административными ролями и проверьте необходимость."]},"CRITICAL_OBJECT_CONTROL":{"description":"Обнаружены права изменения критических объектов конфигурации AD, схемы, разделов, ролей или сайтов.","impact":["Неправомерное изменение этих объектов может затронуть весь лес или несколько доменов."],"remediation":["Сопоставьте ACL с моделью Tier 0; разрешайте запись только установленным административным ролям."]},"RODC_PRIVILEGED_PASSWORD_ALLOWED":{"description":"Политика репликации паролей контроллера домена только для чтения допускает кэширование паролей привилегированных субъектов.","impact":["При компрометации RODC кэшированные секреты могут быть раскрыты."],"remediation":["Запретите репликацию секретов административных групп и проверьте фактическую политику PRP."]},"RODC_PRIVILEGED_PASSWORD_REVEALED":{"description":"На RODC уже кэшированы секреты субъектов с повышенными полномочиями.","impact":["Компрометация этого контроллера может раскрыть данные, требующие замены учётных данных."],"remediation":["Проверьте Revealed List, запретите дальнейшее кэширование и выполните реагирование по процедуре для затронутых записей."]},"RODC_DENIED_GROUP_MISSING":{"description":"Ожидаемая группа защищаемых субъектов отсутствует в списке запрета кэширования паролей RODC.","impact":["Секреты этих субъектов могут оказаться разрешёнными к кэшированию при других условиях PRP."],"remediation":["Проверьте Denied RODC Password Replication Group и итоговые разрешения репликации."]},"DOMAIN_ROOT_MAQ_WRITE":{"description":"Субъект имеет право изменять атрибут ms-DS-MachineAccountQuota, задающий лимит создания компьютеров обычными пользователями.","impact":["Изменение квоты может расширить возможность создавать компьютерные учётные записи и использовать их в цепочках атак."],"remediation":["Ограничьте запись на атрибут и согласуйте допустимую квоту с моделью управления компьютерами."]},"DOMAIN_ROOT_NON_DEFAULT_OWNER":{"description":"Владельцем корневого объекта домена указан субъект, отличный от ожидаемого администратора или защищённой группы.","impact":["Владение объектом обычно позволяет изменять его DACL, поэтому отклонение требует проверки."],"remediation":["Установите происхождение владельца и при необходимости восстановите утверждённого владельца после резервного копирования."]},"OU_NON_DEFAULT_OWNER":{"description":"Организационная единица AD имеет владельца, отличающегося от обычной модели владения.","impact":["Владелец может обладать возможностью изменения разрешений на OU независимо от отдельных ACE."],"remediation":["Проверьте назначение владения, делегирование и необходимость изменения владельца."]},"DANGEROUS_ACL_REPLICATION_NO_SECRETS":{"description":"Обнаружено разрешение на репликацию отдельных данных каталога, не дающее само по себе репликацию секретных атрибутов.","impact":["Наличие одного такого разрешения нельзя автоматически считать полноценным DCSync."],"remediation":["Проверьте сочетание DS-Replication-Get-Changes, DS-Replication-Get-Changes-All и при необходимости In-Filtered-Set."]},"DANGEROUS_ACL_REPLICATION_INERT_HALF":{"description":"Назначена лишь часть набора разрешений на репликацию Active Directory, необходимого для соответствующего сценария.","impact":["Неполный набор сам по себе может не позволять DCSync, но расширение прав впоследствии изменит риск."],"remediation":["Проверьте совокупные разрешения субъекта с учётом вложенных групп и наследования."]},"DANGEROUS_ACL_BROAD_GROUP":{"description":"Опасные разрешения на объект AD предоставлены группе с широким составом участников.","impact":["Любой действующий участник группы может получить соответствующие полномочия в зависимости от ACL и области действия."],"remediation":["Замените широкую группу специальной группой делегирования с минимальным членством."]},"GPO_SCOPE_DOMAIN_WIDE":{"description":"Объект GPO привязан к корню домена и потенциально распространяется на большую часть доменных объектов.","impact":["Ошибочная настройка или компрометация редактора GPO может иметь доменный масштаб."],"remediation":["Проверьте связи, фильтрацию, наследование, административных редакторов и область фактического применения."]},"SID_HISTORY_INJECTION":{"description":"В атрибуте sIDHistory содержится привилегированный SID, который требует подтверждения законности происхождения.","impact":["При ошибках фильтрации SID или доверительных отношений такой SID может давать нежелательные права."],"remediation":["Сверьте SID с историей миграции, настройками доверий и выполненными административными операциями."]},"SID_HISTORY_FOREIGN_PRIVILEGED":{"description":"В атрибуте sIDHistory содержится привилегированный SID из другого домена.","impact":["При неправильной настройке доверий и фильтрации SID он может влиять на авторизацию."],"remediation":["Проверьте доверительные отношения, SID filtering и документированное происхождение sIDHistory."]},"SID_HISTORY_ORPHANED":{"description":"В sIDHistory присутствует SID, который не удаётся сопоставить с ожидаемым доверенным источником.","impact":["Неопознанный SID затрудняет аудит прав и может указывать на ошибочную миграцию или нетипичное изменение."],"remediation":["Проверьте источник SID, доверия и журналы миграции, прежде чем удалять значения."]},"BITLOCKER_RECOVERY_DELEGATED":{"description":"Права чтения объектов с данными восстановления BitLocker делегированы дополнительному субъекту.","impact":["Такой доступ позволяет получить ключи восстановления дисков затронутых компьютеров."],"remediation":["Ограничьте чтение доверенным администраторам восстановления, включите аудит и контролируйте членство групп."]},"EXCHANGE_GROUP_LOW_PRIV_MEMBER":{"description":"В административной группе Exchange обнаружен участник с недостаточно обоснованными повышенными полномочиями.","impact":["Назначения Exchange и связанные с ними ACL AD могут расширять возможности управления каталога."],"remediation":["Проверьте ролевую модель Exchange, вложенные группы и реальную необходимость членства."]},"PRIVILEGED_GROUP_MEMBERSHIP":{"description":"Учётная запись состоит в привилегированной группе Active Directory.","impact":["Полученные через группу полномочия могут давать управление защищёнными объектами и контроллерами домена."],"remediation":["Подтвердите служебную необходимость членства, обеспечьте отдельные административные записи и периодическую переаттестацию."]},"OPERATOR_GROUP_MEMBERSHIP":{"description":"Учётная запись состоит в операторской группе Windows или иной группе с расширенными системными полномочиями.","impact":["В зависимости от роли группы возможен доступ к критическим службам и конфигурациям."],"remediation":["Проверьте эффективные разрешения, вложенность и назначение членства."]},"OU_PERM_WRITEPROPERTY_ALL":{"description":"На объектах в организационной единице обнаружено разрешение изменять все свойства объектов в области действия OU. Важны конкретные ObjectType ACE, наследование и фактический состав субъектов.","impact":["При неверном делегировании возможно неавторизованное изменение атрибутов пользователей или компьютеров."],"remediation":["Ограничьте WriteProperty набором действительно изменяемых атрибутов и соответствующих групп."]},"OU_PERM_USERACCOUNTCONTROL":{"description":"На объектах в организационной единице обнаружено право изменять userAccountControl у объектов в OU. Важны конкретные ObjectType ACE, наследование и фактический состав субъектов.","impact":["При неверном делегировании возможно смену состояния учётных записей или отдельных параметров аутентификации."],"remediation":["Проверьте наследуемые ACE и ограничьте запись userAccountControl."]},"OU_PERM_GROUP_MEMBERSHIP":{"description":"На объектах в организационной единице обнаружено право изменять атрибут member у групп в OU. Важны конкретные ObjectType ACE, наследование и фактический состав субъектов.","impact":["При неверном делегировании возможно добавление нежелательных участников в группы, на которые распространяется разрешение."],"remediation":["Ограничьте изменение членства доверенными владельцами групп и отслеживайте события."]},"OU_PERM_SCRIPTPATH":{"description":"На объектах в организационной единице обнаружено право изменять scriptPath. Важны конкретные ObjectType ACE, наследование и фактический состав субъектов.","impact":["При неверном делегировании возможно подмену выполняемого при входе сценария при наличии доступа к его расположению."],"remediation":["Ограничьте изменение scriptPath и контролируйте ACL хранилища сценариев."]},"OU_PERM_CONSTRAINED_DELEGATION":{"description":"На объектах в организационной единице обнаружено право изменять msDS-AllowedToDelegateTo. Важны конкретные ObjectType ACE, наследование и фактический состав субъектов.","impact":["При неверном делегировании возможно расширение списка служб, к которым разрешено делегирование Kerberos."],"remediation":["Ограничьте изменение целей делегирования и проверьте переход протокола."]},"OU_PERM_RBCD":{"description":"На объектах в организационной единице обнаружено право изменять msDS-AllowedToActOnBehalfOfOtherIdentity. Важны конкретные ObjectType ACE, наследование и фактический состав субъектов.","impact":["При неверном делегировании возможно нежелательное предоставление делегирования Kerberos на основе ресурса (RBCD)."],"remediation":["Ограничьте запись RBCD только доверенными администраторами объекта."]},"OU_PERM_LAPS_READ":{"description":"На объектах в организационной единице обнаружено право чтения паролей LAPS у компьютеров в OU. Важны конкретные ObjectType ACE, наследование и фактический состав субъектов.","impact":["При неверном делегировании возможно получение локальных административных секретов при действительном доступе."],"remediation":["Проверьте ACL LAPS, конфиденциальные атрибуты и право расшифрования Windows LAPS."]},"OU_PERM_GPLINK":{"description":"На объектах в организационной единице обнаружено право изменять gPLink в OU. Важны конкретные ObjectType ACE, наследование и фактический состав субъектов.","impact":["При неверном делегировании возможно подключение или отключение групповых политик для объектов OU."],"remediation":["Ограничьте делегирование gPLink администраторам групповых политик."]},"OU_PERM_CREATE_CHILD":{"description":"На объектах в организационной единице обнаружено право создавать объекты в пределах OU. Важны конкретные ObjectType ACE, наследование и фактический состав субъектов.","impact":["При неверном делегировании возможно создание нежелательных пользователей, групп или компьютеров в зависимости от ObjectType ACE."],"remediation":["Уточните допустимые классы объектов в ACE и полномочия делегированной группы."]},"OU_PERM_GPOPTIONS":{"description":"На объектах в организационной единице обнаружено право изменять gPOptions в OU. Важны конкретные ObjectType ACE, наследование и фактический состав субъектов.","impact":["При неверном делегировании возможно изменение блокирования наследования групповых политик."],"remediation":["Ограничьте запись gPOptions доверенным администраторам OU."]},"OU_PERM_GENERICWRITE":{"description":"На объектах в организационной единице обнаружено право GenericWrite в области OU. Важны конкретные ObjectType ACE, наследование и фактический состав субъектов.","impact":["При неверном делегировании возможно несанкционированное изменение ряда свойств защищаемых объектов."],"remediation":["Проверьте объём ACE, наследование и минимальную достаточность разрешения."]},"OU_PERM_READALL":{"description":"На объектах в организационной единице обнаружено право чтения всех свойств объектов в OU. Важны конкретные ObjectType ACE, наследование и фактический состав субъектов.","impact":["При неверном делегировании возможно раскрытие данных, для которых атрибуты не имеют отдельных ограничений конфиденциальности."],"remediation":["Проверьте необходимость широкого чтения; отдельные конфиденциальные атрибуты могут требовать специальных прав."]},"GPO_USERRIGHT_SEDEBUG":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право «Отладка программ» (SeDebugPrivilege) назначено через GPO сверх стандартных значений». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_SETCB":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право «Работа в режиме операционной системы» (SeTcbPrivilege) назначено через GPO». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_SECREATETOKEN":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право «Создание объекта токена» (SeCreateTokenPrivilege) назначено через GPO». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_SEIMPERSONATE":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право «Имитация клиента после проверки подлинности» (SeImpersonatePrivilege) выдано через GPO». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_SEASSIGNPRIMARYTOKEN":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право «Замена токена уровня процесса» (SeAssignPrimaryTokenPrivilege) выдано через GPO». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_SELOADDRIVER":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право «Загрузка и выгрузка драйверов устройств» (SeLoadDriverPrivilege) выдано через GPO». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_SEBACKUP":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право «Архивирование файлов и каталогов» (SeBackupPrivilege) выдано через GPO». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_SERESTORE":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право «Восстановление файлов и каталогов» (SeRestorePrivilege) выдано через GPO». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_SETAKEOWNERSHIP":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право «Смена владельцев файлов и других объектов» (SeTakeOwnershipPrivilege) выдано через GPO». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_SEENABLEDELEGATION":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право доверия учётных записей для делегирования (SeEnableDelegationPrivilege) выдано через GPO». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_SESYNCAGENT":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право «Синхронизация данных службы каталогов» (SeSyncAgentPrivilege) выдано через GPO». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_SEMANAGEVOLUME":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право обслуживания томов (SeManageVolumePrivilege) выдано через GPO». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_SESECURITY":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право управления аудитом и журналом безопасности (SeSecurityPrivilege) выдано через GPO». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_SERELABEL":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право изменения метки объекта (SeRelabelPrivilege) выдано через GPO». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_SETRUSTEDCREDMANACCESS":{"description":"Одна или несколько групповых политик назначают право пользователя: «Доступ к диспетчеру учётных данных как доверенного вызывающего (SeTrustedCredManAccessPrivilege)». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_SEREMOTEINTERACTIVELOGON":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право входа через службы удалённых рабочих столов (SeRemoteInteractiveLogonRight) расширено через GPO». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_SEINTERACTIVELOGON":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право локального входа (SeInteractiveLogonRight) расширено через GPO». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_SEBATCHLOGON":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право пакетного входа (SeBatchLogonRight) расширено через GPO». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_SESERVICELOGON":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право входа в качестве службы (SeServiceLogonRight) назначено через GPO». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_SESYSTEMTIME":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право изменения системного времени (SeSystemtimePrivilege) расширено через GPO». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_SEREMOTESHUTDOWN":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право принудительного удалённого завершения работы (SeRemoteShutdownPrivilege) расширено через GPO». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_SESHUTDOWN":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право завершения работы системы (SeShutdownPrivilege) расширено через GPO». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_SECREATESYMBOLICLINK":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право создания символических ссылок (SeCreateSymbolicLinkPrivilege) расширено через GPO». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_SEDELEGATESESSIONUSERIMPERSONATE":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право получения токена другого пользователя в сеансе (SeDelegateSessionUserImpersonatePrivilege) выдано через GPO». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_SEAUDIT":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право формирования аудита безопасности (SeAuditPrivilege) расширено через GPO». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_SESYSTEMENVIRONMENT":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право изменения параметров среды микропрограммы (SeSystemEnvironmentPrivilege) расширено через GPO». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_SECREATEGLOBAL":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право создания глобальных объектов (SeCreateGlobalPrivilege) расширено через GPO». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_SEPROFILESINGLEPROCESS":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право профилирования отдельного процесса (SeProfileSingleProcessPrivilege) расширено через GPO». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_SESYSTEMPROFILE":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право профилирования производительности системы (SeSystemProfilePrivilege) расширено через GPO». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_DEFAULT_REMOVED":{"description":"Одна или несколько групповых политик назначают право пользователя: «Групповая политика исключает стандартного владельца права пользователя». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]}};
        const ruFullFindingTechnical = {"LDAP_CHANNEL_BINDING_NOT_REQUIRED":{"description":"В GPO не задано требование LDAP Channel Binding — привязки аутентификации LDAP к защищённому каналу TLS. Состояние «Не настроено» в GPO само по себе не доказывает уязвимость: настройка может быть включена непосредственно на контроллере домена через реестр либо действовать по умолчанию в ОС (начиная с Windows Server 2025 защита применяется по умолчанию). Для единообразного управления всеми DC рекомендуется явно задавать требование через GPO.","impact":["Без обязательного Channel Binding возможно перенаправление некоторых сеансов LDAPS.","Увеличивается поверхность атаки для ретрансляции аутентификации NTLM.","Ослабляется защита LDAP-соединений в инфраструктуре домена."],"attack":["1. Злоумышленник организует ретрансляцию LDAP-аутентификации через TLS.","2. Если привязка к TLS-каналу не требуется, ретрансляция может завершиться успешно.","3. Полученный контекст может использоваться для привилегированных операций LDAP."],"remediation":["Включите LDAP Channel Binding на контроллерах домена после проверки совместимости клиентов.","Параметр реестра: HKEY_LOCAL_MACHINE\\System\\CurrentControlSet\\Services\\NTDS\\Parameters\\LdapEnforceChannelBinding = 2.","Для единообразия настройте параметр через Group Policy Preferences (GPO).","Сначала используйте значение 1 («Если поддерживается»): токен CBT потребуется от клиентов, объявляющих его поддержку. Это позволяет выявить несовместимых клиентов, не отключая сразу их соединения. После завершения аудита переходите к значению 2 («Всегда»).","Для проверки установите 16 LDAP Interface Events = 2 и изучайте журнал Directory Service: событие 3039 показывает проблемного клиента, а 3040 и 3041 формируют суточные сводки. Указанные клиенты могут перестать работать после включения режима 2.","LDAP Simple Bind через LDAPS не передаёт токен CBT и не затрагивается этой настройкой. CBT требуется для SASL-подключений (Negotiate, Kerberos, NTLM) поверх TLS. Windows-клиенты с обновлениями марта 2020 года обычно поддерживают CBT; отдельно проверьте сторонние библиотеки LDAP и прошивки оборудования."]},"LDAP_SIGNING_NOT_REQUIRED":{"description":"В GPO не настроено обязательное подписание LDAP. Статус «Не настроено» не обязательно означает, что защита отсутствует: подписание может требоваться локальной конфигурацией DC либо политикой ОС (в Windows Server 2025+ это требование включено по умолчанию). Для согласованной защиты всех контроллеров домена рекомендуется закреплять требование в GPO.","impact":["Трафик LDAP без подписи может быть перехвачен или изменён.","Возможны атаки ретрансляции NTLM на службы LDAP.","Передаваемые сведения, включая учётные данные при небезопасном связывании, могут быть раскрыты или подменены.","Ретрансляция NTLM к LDAP может позволить изменение групп и других объектов AD от имени жертвы."],"attack":["1. Злоумышленник занимает положение посредника между клиентом и DC.","2. Провоцирует аутентификацию клиента (например, PetitPotam или PrinterBug).","3. Ретранслирует NTLM-аутентификацию в LDAP на контроллере домена.","4. При наличии полномочий выполняет изменения LDAP, например RBCD или членства в группах."],"remediation":["Включите параметр «Контроллер домена: требования к подписи LDAP-сервера» = «Требовать подпись».","Путь GPO: Конфигурация компьютера → Политики → Параметры Windows → Параметры безопасности → Локальные политики → Параметры безопасности.","Для стабильного применения управляйте обязательной подписью через GPO, а не разрозненными локальными настройками.","Сначала соберите фактические сведения о клиентах: задайте 16 LDAP Interface Events = 2 на DC и изучите журнал Directory Service. События 2886 и 2887 напоминают о настройке и отражают суточную статистику; событие 2889 указывает адрес и учётную запись клиента, выполняющего неподписанное или незашифрованное связывание. Именно такие клиенты могут перестать работать после принудительного включения подписи.","Типичные несовместимые клиенты: принтеры и сканеры с Simple Bind на порту 389, VPN-шлюзы, балансировщики, NAS, старые агенты мониторинга и резервного копирования, Linux-клиенты с nss/pam/sssd и ldap:// без TLS, самописные приложения без явно заданного метода аутентификации.","Исправляйте клиентские подключения: используйте LDAPS или StartTLS либо SASL Bind с подписью. Не оставляйте контроллер домена небезопасным только ради устаревшего клиента."]},"UNCONSTRAINED_DELEGATION":{"description":"Для компьютера или пользователя включено неограниченное делегирование Kerberos (TRUSTED_FOR_DELEGATION). При аутентификации клиентов система может получать и хранить делегированные билеты TGT, позволяя действовать от их имени при обращении к другим службам домена.","impact":["На системе могут кэшироваться делегированные TGT пользователей, которые к ней подключались.","Компрометация сервера может привести к краже TGT привилегированных субъектов.","Украденные билеты позволяют действовать от имени пользователей перед другими службами домена.","Аутентификацию контроллера домена иногда можно инициировать через службу печати (PrinterBug).","При сочетании нескольких условий возможна компрометация всего домена."],"attack":["1. Злоумышленник получает контроль над системой с неограниченным делегированием.","2. Инициирует аутентификацию контроллера домена к этой системе, например через PrinterBug или PetitPotam.","3. При успешном делегировании получает TGT контроллера домена из памяти.","4. Использует полномочия билета для DCSync и получения секретов домена.","5. После получения ключей домена может сформировать Golden Ticket для сохранения доступа."],"remediation":["По возможности замените неограниченное делегирование ограниченным делегированием Kerberos или RBCD.","Для пользователей с критическими правами рассмотрите группу Protected Users после проверки совместимости.","У привилегированных учётных записей включите «Учётная запись является конфиденциальной и не подлежит делегированию».","Отключите службу диспетчера печати на DC там, где она не нужна.","Контролируйте запросы TGT и необычную аутентификацию к системам с делегированием."]},"DANGEROUS_ACL_GENERICALL":{"description":"Пользователь или группа обладает разрешением GenericAll («Полный доступ») к важному объекту Active Directory. Такое право позволяет изменять его атрибуты, сбрасывать пароли, менять состав групп и фактически управлять объектом.","impact":["Возможен сброс паролей целевых учётных записей без знания текущего пароля.","Можно добавлять участников в группы, включая Domain Admins при наличии права на соответствующий объект.","Можно изменять свойства, включая servicePrincipalName, и создавать условия для Kerberoasting.","В некоторых условиях можно настроить делегирование Kerberos на основе ресурса (RBCD).","Владелец разрешения получает практически полный контроль над затронутым объектом."],"attack":["Пользователь: сбросить пароль и получить контроль над учётной записью.","Группа: добавить контролируемую учётную запись в состав группы.","Компьютер: настроить RBCD для дальнейшего перемещения по инфраструктуре.","GPO: изменить параметры политики для запуска нежелательного кода или распространения учётных данных."],"remediation":["Проверьте необходимость GenericAll и удалите избыточные разрешения.","Следуйте принципу минимально необходимых привилегий.","Используйте управление правами на основе ролей (RBAC).","Включите аудит изменений ACL для чувствительных объектов AD."]},"ASREP_ROASTABLE":{"description":"Для учётной записи отключена предварительная проверка подлинности Kerberos (флаг DONT_REQUIRE_PREAUTH). Злоумышленник может запросить ответ AS-REP без знания пароля и затем проверять кандидаты пароля автономно.","impact":["Материал для проверки пароля может быть получен без предварительной аутентификации.","Автономный подбор не создаёт событий о неудачных попытках входа в домен.","После получения AS-REP подбор можно продолжать независимо от доступности DC.","Компрометация записи может привести к первоначальному доступу или повышению привилегий."],"attack":["1. Найти учётные записи с флагом DONT_REQUIRE_PREAUTH.","2. Отправить AS-REQ для выбранной записи в KDC.","3. Получить AS-REP, зашифрованный ключом на основе пароля этой записи.","4. Проверять варианты пароля автономно, например в Hashcat или John the Ripper.","5. При успешном подборе пройти проверку подлинности от имени записи."],"remediation":["Включите обязательную предварительную проверку Kerberos для учётных записей.","Выясните, почему она была отключена, и устраните исходную зависимость.","Если исключение временно необходимо, используйте длинные случайные пароли.","Отслеживайте запросы AS-REQ без предварительной проверки Kerberos."]},"KERBEROASTABLE_SPN":{"description":"У пользовательской учётной записи назначен Service Principal Name (SPN), поэтому она может быть целью Kerberoasting. Любой прошедший аутентификацию пользователь домена способен запросить билет службы TGS, защищённый ключом этой записи, и затем проверять пароль автономно.","impact":["Получение материала TGS для автономной проверки пароля обычно не вызывает блокировку учётной записи.","Подбор пароля может продолжаться вне домена.","При слабом пароле компрометация возможна за ограниченное время.","Служебные учётные записи нередко обладают расширенными правами, поэтому их взлом открывает пути перемещения и повышения привилегий."],"attack":["1. Пройти аутентификацию в домене от имени обычного пользователя.","2. Запросить TGS для SPN целевой службы.","3. Извлечь зашифрованный материал билета, связанный с ключом служебной записи.","4. Автономно проверять пароли через Hashcat или John the Ripper.","5. При успешном подборе использовать учётную запись службы."],"remediation":["По возможности используйте gMSA вместо обычных пользовательских служебных записей.","Назначайте служебным записям длинные случайные пароли — не менее 25 символов.","Предпочитайте AES для Kerberos, предварительно проверив совместимость.","Регулярно ротируйте пароли служб.","Контролируйте запросы TGS к служебным SPN из необычных источников."]},"ESC9_CT_NO_SECURITY_EXTENSION":{"description":"Шаблон сертификата не включает расширение безопасности szOID_NTDS_CA_SECURITY_EXT с SID заявителя. Из-за этого сопоставление сертификата с учётной записью может зависеть от UPN. Эксплуатируемость также зависит от параметра StrongCertificateBindingEnforcement на контроллерах домена: значения 0 или 1 допускают ослабленный режим. С февраля 2025 года значение 2 (строгое сопоставление) применяется по умолчанию. При значении 2 обнаруженная настройка шаблона — потенциальный, а не непосредственно доступный путь; риск появится при ослаблении политики или развёртывании DC со старой конфигурацией.","impact":["В сертификатах может отсутствовать криптографическая привязка к SID заявителя.","Украденный сертификат представляет риск компрометации соответствующей идентичности.","При ослабленном сопоставлении сертификатов проверка SID может не выполняться.","В некоторых конфигурациях это облегчает атаки с использованием сертификатов."],"attack":["1. Злоумышленник получает сертификат, например из файла или при компрометации.","2. Сертификат не содержит обязательной привязки к SID исходного заявителя.","3. При небезопасных настройках сопоставления злоумышленник использует сертификат для аутентификации.","4. Без строгой проверки SID различить нелегитимное сопоставление сложнее."],"remediation":["На контроллерах домена обеспечьте StrongCertificateBindingEnforcement = 2 и проверьте отсутствие ослабляющих GPO.","Используйте шаблоны, выдающие расширение szOID_NTDS_CA_SECURITY_EXT.","Отслеживайте аномалии проверки подлинности по сертификатам."]},"EXCHANGE_SMTP_OPEN_RELAY":{"description":"Дескриптор безопасности принимающего SMTP-соединителя Exchange предоставляет право ms-Exch-SMTP-Accept-Any-Recipient неаутентифицированному субъекту (Anonymous Logon или Everyone). Поэтому клиент без учётных данных может передать письмо для доставки в любой домен. Часто причиной служит слишком широкий диапазон удалённых IP-адресов у соединителя, первоначально созданного для отдельного приложения.","impact":["Сервер может отправлять почту за любого клиента, имеющего доступ к порту соединителя.","При этом используются IP-репутация и почтовая инфраструктура организации.","Попадание исходящего адреса в чёрные списки затронет и легитимную почту.","В сочетании с подменой внутреннего отправителя возможно убедительное внутреннее фишинговое письмо."],"attack":["1. Подключиться к порту SMTP-соединителя из разрешённого IP-диапазона.","2. Открыть SMTP-сеанс без аутентификации.","3. Указать внутренний адрес в MAIL FROM и внешний домен в RCPT TO.","4. Сообщение будет доставлено за пределы организации как исходящая почта с её сервера."],"remediation":["Ограничьте RemoteIPRanges только адресами систем, действительно нуждающихся в пересылке.","Уберите ms-Exch-SMTP-Accept-Any-Recipient у Anonymous Logon, если анонимная ретрансляция не нужна.","По возможности используйте соединитель с обязательной проверкой подлинности."]},"REGISTRY_WINRM_BASIC":{"description":"GPO включает Basic Authentication для службы WinRM или клиента WinRM (AllowBasic = 1). В этом методе имя пользователя и пароль кодируются Base64, что не является шифрованием. При передаче по HTTP данные могут быть прочитаны в сети; защищённый транспорт HTTPS снижает этот риск.","impact":["Пароли администраторов, подключающихся по HTTP, могут быть раскрыты при перехвате трафика.","На стороне службы возможно использование пароля локальной учётной записи вне механизмов Kerberos."],"attack":[],"remediation":["Отключите параметр «Разрешить обычную (Basic) проверку подлинности» для WinRM Server и WinRM Client, если он не требуется."]},"REGISTRY_KERBEROS_WEAK_ETYPES":{"description":"GPO разрешает слабые типы шифрования Kerberos: DES-CBC-CRC (0x1), DES-CBC-MD5 (0x2) либо RC4-HMAC (0x4). DES криптографически устарел, а ключ RC4 для учётной записи связан с её NT-хешем. Такие билеты легче подбирать автономно; NT-хеш может также использоваться в сценариях Overpass-the-Hash. Значение настройки — битовая маска; например, 2147483640 (0x7FFFFFF8) разрешает AES и будущие типы без слабых алгоритмов.","impact":["Билеты служб Kerberos с RC4 поддаются автономной проверке паролей быстрее, чем билеты с AES.","Использование DES делает защиту особенно слабой и требует устранения."],"attack":[],"remediation":["Разрешите AES128_HMAC_SHA1, AES256_HMAC_SHA1 и поддерживаемые будущие типы шифрования, предварительно проверив, что все учётные записи и службы имеют ключи AES."]},"REGISTRY_LDAP_CLIENT_SIGNING_OFF":{"description":"GPO устанавливает «Сетевая безопасность: требования подписи LDAP-клиента» в значение None (LDAPClientIntegrity = 0). Компьютеры в области действия больше не запрашивают подписание LDAP-соединений, хотя стандартное значение Negotiate signing предусматривает согласование подписи. Это создаёт риск чтения и изменения трафика посредником.","impact":["Неоподписанный LDAP-трафик затронутых компьютеров может быть перехвачен и изменён в пути."],"attack":[],"remediation":["Задайте «Согласовывать подпись» (Negotiate signing) либо «Требовать подпись» (Require signing) после проверки совместимости клиентов."]},"REGISTRY_ESC10_KDC_BINDING":{"description":"GPO задаёт StrongCertificateBindingEnforcement = 0 в ветке реестра KDC. Расширение SID в сертификате привязывает его к конкретной учётной записи. При значении 0 контроллер домена игнорирует это расширение даже при его наличии и сопоставляет сертификат только по UPN. Значение 2 включает строгую проверку, а 1 проверяет расширение только при его наличии и рассматривается KB5014754 как переходный режим.","impact":["Сертификат может использоваться для входа от имени учётной записи, UPN которой указан в SAN.","Субъект с правом изменения userPrincipalName может временно назначить своей записи UPN жертвы, получить сертификат и аутентифицироваться от её имени.","Дополнительная ошибка шаблона сертификата не требуется: сопоставление ослаблено на уровне домена."],"attack":["1. Временно изменить UPN контролируемой записи на UPN целевой записи.","2. Зарегистрировать сертификат с EKU для аутентификации.","3. Вернуть исходное значение UPN.","4. Использовать выданный сертификат для входа от имени цели."],"remediation":["Установите StrongCertificateBindingEnforcement = 2 на каждом DC.","До перехода на режим 2 перевыпустите сертификаты, выданные до появления расширения SID.","Ограничьте право изменения userPrincipalName."]},"REGISTRY_ESC10_KDC_BINDING_COMPAT":{"description":"GPO задаёт StrongCertificateBindingEnforcement = 1 в KDC. В режиме совместимости SID проверяется только при наличии расширения в сертификате; без него используется сопоставление по UPN. Шаблон с CT_FLAG_NO_SECURITY_EXTENSION специально выдаёт такие сертификаты — это ошибка ESC9. Значение 1 выполняет вторую предпосылку соответствующей атаки; с февраля 2025 года стандартным является строгий режим 2.","impact":["Сертификат без расширения SID сопоставляется с учётной записью только по UPN.","Шаблон ESC9 позволяет получить такой сертификат субъектам с правом регистрации.","Субъект с записью userPrincipalName может получить сертификат с UPN жертвы и аутентифицироваться от её имени.","Старые сертификаты до обновлений мая 2022 года также могут не содержать расширения."],"attack":["1. Найти шаблон CT_FLAG_NO_SECURITY_EXTENSION, допускающий клиентскую аутентификацию; такие шаблоны отмечены как ESC9.","2. Назначить контролируемой записи UPN целевой записи.","3. Получить по этому шаблону сертификат без расширения SID.","4. Восстановить исходный UPN и войти с сертификатом от имени цели."],"remediation":["Установите StrongCertificateBindingEnforcement = 2 на всех DC; значение 1 предназначалось для миграции.","До перехода перевыпустите или выведите из использования старые сертификаты без SID.","Уберите CT_FLAG_NO_SECURITY_EXTENSION у соответствующих шаблонов.","Ограничьте изменение userPrincipalName."]},"REGISTRY_ESC10_SCHANNEL_UPN":{"description":"GPO включает бит 0x4 параметра CertificateMappingMethods в конфигурации Schannel. Это вновь разрешает сопоставлять сертификат с учётной записью только по UPN из SAN для служб, использующих Schannel вместо Kerberos, в том числе LDAPS и других TLS-служб с клиентскими сертификатами.","impact":["При LDAPS сертификат может аутентифицировать субъекта с UPN, указанным в SAN.","Усиление KDC само по себе не устраняет эту уязвимость, поскольку используется Schannel.","Другие биты (0x1, 0x2, 0x8) не относятся к данной находке: опасное значение — именно 0x4."],"attack":[],"remediation":["Уберите бит 0x4 из CertificateMappingMethods на всех контроллерах домена.","Используйте сопоставление сертификатов с Kerberos при обязательной проверке расширения SID."]},"REGISTRY_LMCOMPAT":{"description":"GPO задаёт LmCompatibilityLevel не выше 2, разрешая сетевую аутентификацию LM и/или NTLMv1. Их ответы основаны на устаревшем DES и поддаются подбору, что облегчает перехват хешей и ретрансляцию NTLM.","impact":["Ответы LM/NTLMv1 могут позволить восстановить NT-хеш.","Упрощаются автономный подбор и атаки ретрансляции NTLM.","Защита аутентификации ослабляется на всех затронутых компьютерах."],"attack":["1. Спровоцировать либо перехватить сеанс LM/NTLMv1.","2. Подобрать слабый DES-ответ автономно.","3. Использовать полученный NT-хеш в атаке Pass-the-Hash."],"remediation":["Установите LmCompatibilityLevel = 5: использовать NTLMv2 и отклонять LM/NTLM.","Перед внедрением выявите устройства без поддержки NTLMv2 (МФУ, NAS, встроенные системы, старые Samba). Изменяйте настройку поэтапно; иначе совместимость может быть нарушена и политику придётся откатить."]},"REGISTRY_ALWAYSINSTALLELEVATED":{"description":"GPO устанавливает AlwaysInstallElevated = 1 одновременно в HKLM и HKCU. В этом случае обычный пользователь может установить MSI-пакет Windows Installer с полномочиями SYSTEM. adPEAS помечает находку только при наличии обоих параметров — именно такое сочетание делает ошибку эксплуатируемой.","impact":["Обычный пользователь может запускать установку MSI от имени SYSTEM.","Возможно прямое локальное повышение привилегий до SYSTEM.","Риск распространяется на все компьютеры в области действия GPO."],"attack":["1. Подготовить специально созданный MSI-пакет.","2. Запустить его через msiexec от имени обычного пользователя.","3. Получить исполнение с правами SYSTEM."],"remediation":["Установите AlwaysInstallElevated = 0 одновременно в HKLM и HKCU либо удалите соответствующие параметры политики."]},"REGISTRY_ENABLELUA":{"description":"GPO задаёт EnableLUA = 0 и полностью отключает UAC. Без фильтрации токена локальные административные записи могут давать полный токен при удалённой аутентификации; запросы подтверждения повышения прав также исчезают.","impact":["На затронутых компьютерах отключена фильтрация токенов UAC.","Локальные администраторы могут использоваться для удалённых атак Pass-the-Hash.","Вредоносный код может получать повышенные права без подтверждающего окна."],"attack":["1. Получить пароль либо хеш учётной записи локального администратора.","2. Пройти удалённую аутентификацию с полным токеном.","3. Выполнять команды с повышенными правами и перемещаться между компьютерами."],"remediation":["Верните EnableLUA = 1 и оставьте UAC включённым."]},"REGISTRY_SMB1_CLIENT":{"description":"GPO задаёт драйверу SMBv1-клиента mrxsmb10 тип запуска «Автоматически» или «Вручную». Значение 4 отключает его. Компьютеры с включённым SMBv1 по-прежнему могут договариваться об использовании устаревшего протокола с настоящим или подставным сервером без улучшенной защиты SMB 2/3.","impact":["Подставной SMB-сервер может ограничить взаимодействие клиента протоколом SMBv1 без современных механизмов защиты.","Остаются доступными устаревшие пути обработки SMBv1, заменённые в SMB 2/3."],"attack":["1. Злоумышленник выдаёт себя за SMB-сервер или располагается между клиентом и сервером.","2. При согласовании предлагает только SMBv1.","3. Перехватывает или изменяет данные при наличии условий для атаки."],"remediation":["Установите mrxsmb10 Start = 4 и удалите MRxSmb10 из DependOnService у LanmanWorkstation согласно документации Microsoft.","Обновите или замените сервер, для которого ещё требуется SMBv1."]},"REGISTRY_DSRM_ADMIN_LOGON":{"description":"GPO устанавливает DsrmAdminLogonBehavior = 2 в Control\\Lsa. На DC это позволяет локальной записи администратора режима восстановления каталога (DSRM) входить при работающей службе каталогов, а не только после загрузки в режим восстановления. Microsoft не рекомендует такой режим: пароль DSRM не регулируется обычной доменной политикой и часто не меняется после повышения сервера до DC.","impact":["Учётная запись DSRM может входить на работающий DC как локальный администратор, в том числе по сети с использованием NT-хеша.","Однажды раскрытый или давно неизменяемый пароль DSRM остаётся отдельным путём доступа к DC.","Смена доменных паролей, в том числе krbtgt, не изменяет секрет DSRM в локальной SAM."],"attack":["1. Получить хеш DSRM из SAM при административном доступе либо изменить пароль DSRM.","2. Убедиться, что DsrmAdminLogonBehavior = 2 действует на DC.","3. Даже после смены доменных паролей пройти аутентификацию с сохранённым секретом DSRM.","4. Локальные права администратора DC дают доступ к критическим секретам каталога."],"remediation":["Удалите параметр из GPO и реестра DC либо установите его в 0: вход DSRM будет ограничен режимом восстановления.","Смените пароль DSRM на всех затронутых DC либо настройте его управление через Windows LAPS (BackupDsrmPassword).","Контролируйте событие 4794 и изменения DsrmAdminLogonBehavior."]},"REGISTRY_WSUS_HTTP":{"description":"GPO направляет клиентов к серверу WSUS по незашифрованному HTTP (WUServer=http://...). Трафик обновлений в локальной сети может быть перехвачен и изменён. В уязвимых сценариях это создаёт предпосылки к доставке вредоносных команд, выполняемых с правами SYSTEM.","impact":["Обмен с WSUS по HTTP не защищён TLS.","При соответствующих условиях атака посредника позволяет подменять части процесса обновления.","Угроза может затронуть сразу множество клиентов WSUS в области действия GPO."],"attack":["1. Перехватить HTTP-трафик между клиентом и WSUS.","2. При использовании уязвимого механизма доставки подменить данные обновления или команду запуска.","3. Добиться выполнения кода на клиенте с высокими полномочиями."],"remediation":["Перенастройте WSUS на HTTPS (WUServer=https://...).","Включите TLS с корректной проверкой сертификатов и оцените целостность процесса установки обновлений."]},"REGISTRY_DEFENDER_DISABLED":{"description":"GPO отключает Microsoft Defender Antivirus либо его защиту в реальном времени (DisableAntiSpyware = 1 или DisableRealtimeMonitoring = 1). Так устраняется важный уровень обнаружения вредоносной активности на всех затронутых компьютерах. Однако в Windows 10 версии 1903+ Tamper Protection может препятствовать применению такого параметра.","impact":["Централизованно отключается антивирусная защита или мониторинг в реальном времени.","Вредоносные программы и средства кражи учётных данных могут действовать с меньшей вероятностью обнаружения."],"attack":["1. Получить доступ к компьютеру с отключённым Defender.","2. Использовать инструменты, которые в обычных условиях блокировались бы антивирусом."],"remediation":["Удалите политику, отключающую Defender, и включите Tamper Protection."]},"REGISTRY_RUNASPPL":{"description":"GPO явно задаёт RunAsPPL = 0 и отключает защиту LSA. В результате LSASS не работает как защищённый процесс PPL, что упрощает извлечение учётных данных из его памяти.","impact":["LSASS не защищён PPL от части операций доступа к памяти и внедрения кода.","Упрощается извлечение учётных данных средствами вроде Mimikatz или comsvcs.dll."],"attack":["1. Получить административный доступ на затронутом компьютере.","2. Извлечь содержимое LSASS без обхода ограничений PPL."],"remediation":["Включите защиту LSA параметром RunAsPPL = 1 после проверки совместимости."]},"REGISTRY_CREDSSP_ORACLE":{"description":"GPO устанавливает AllowEncryptionOracle = 2 («Уязвимо»), разрешая CredSSP взаимодействовать с клиентами и серверами без необходимых обновлений. Это может вновь открыть путь эксплуатации CVE-2018-0886, включая атаку посредника при использовании RDP/CredSSP.","impact":["CredSSP принимает неподдерживающие исправления узлы.","При соответствующих условиях злоумышленник-посредник может добиться удалённого выполнения кода через RDP."],"attack":["1. Перехватить сеанс CredSSP/RDP.","2. Использовать CVE-2018-0886 против уязвимого участника соединения."],"remediation":["Установите AllowEncryptionOracle = 0 («Требовать обновлённых клиентов»)."]},"REGISTRY_WINRM_UNENCRYPTED":{"description":"GPO разрешает незашифрованный трафик WinRM у службы или клиента (AllowUnencryptedTraffic = 1). Сеансы удалённого администрирования, включая PowerShell Remoting, могут передаваться по HTTP без шифрования сообщений. При Kerberos или NTLM сама аутентификация остаётся защищённой, но команды, вывод и переданные секреты после неё могут быть доступны в сети; при одновременном разрешении Basic Authentication раскрывается также пароль.","impact":["Команды и ответы удалённого администрирования могут передаваться в читаемом виде.","При использовании Basic Authentication дополнительно могут раскрываться имена пользователей и пароли."],"attack":[],"remediation":["Отключите «Разрешить незашифрованный трафик» для WinRM Server и WinRM Client.","Используйте WinRM через HTTPS там, где Kerberos недоступен."]},"REGISTRY_CREDSSP_DELEGATE_ANY":{"description":"GPO разрешает делегирование учётных данных по умолчанию через CredSSP (либо его вариант с NTLM) на серверы, подходящие под слишком широкую маску, например \u0027*\u0027 или \u0027TERMSRV/*\u0027. Тогда удалённый сервер получает пригодные для повторного входа учётные данные пользователя. Под такую маску могут попасть и контролируемые злоумышленником узлы.","impact":["Учётные данные пользователя передаются каждому серверу, к которому он подключается через CredSSP, в том числе по RDP и PowerShell Remoting.","Один скомпрометированный или подставной сервер способен собрать повторно используемые учётные данные, включая административные."],"attack":["1. Создать или захватить сервер, подходящий под маску; для TERMSRV/* это любой RDP-хост.","2. Побудить пользователя затронутого компьютера подключиться к нему.","3. Получить делегированные учётные данные с этого сервера."],"remediation":["Вместо масок \u0027*\u0027 и \u0027TERMSRV/*\u0027 перечислите поимённо только серверы, которым действительно требуется делегирование.","Для RDP по возможности используйте Remote Credential Guard или Restricted Admin вместо передачи учётных данных."]},"REGISTRY_UAC_NO_PROMPT":{"description":"GPO задаёт «Контроль учётных записей: поведение запроса повышения прав для администраторов» = «Повышать без запроса» (ConsentPromptBehaviorAdmin = 0). Программы администратора первоначально запускаются с ограниченным токеном, но запрошенное повышение выдаётся без согласия и повторной аутентификации. Microsoft допускает этот режим только в строго контролируемой среде. Стандартное значение 5 требует согласия для программ не из состава Windows.","impact":["Вредоносная программа, запущенная администратором из файла, документа или ссылки, может повысить права без заметного подтверждения.","На затронутых компьютерах отпадает необходимость в ряде обходов механизма UAC."],"attack":[],"remediation":["Верните «Запрос согласия для приложений не из Windows» (5) либо более строгий вариант «Запрос согласия на защищённом рабочем столе» (2)."]},"ACCOUNT_DISABLED":{"description":"Для записи установлен флаг ACCOUNTDISABLE в userAccountControl; обычный вход в домен с этой записью запрещён. Это ожидаемая мера для выведенных из эксплуатации учётных записей.","impact":["Отключённая запись не может использоваться для обычной аутентификации.","Снижается риск злоупотребления устаревшими полномочиями."],"attack":["При отключённой учётной записи нарушитель не может:","— проходить аутентификацию с учётными данными этой записи;","— использовать эту запись для бокового перемещения;","— пользоваться делегированными полномочиями этой записи."],"remediation":["Сохраняйте запись отключённой, пока она не требуется.","Проверяйте необходимость хранения и удаляйте ненужные записи по утверждённой процедуре."]},"ADMINSDHOLDER_PROPAGATED_RIGHT":{"description":"На CN=AdminSDHolder обнаружено нестандартное право. SDProp периодически копирует его DACL на защищённые группы и административные записи. Такое разрешение распространяется на все защищённые объекты и может восстанавливаться после удаления с отдельной записи.","impact":["Можно изменять членство защищённых групп, сбрасывать пароли или изменять чувствительные атрибуты в пределах предоставленного права.","Нестандартный ACE может сохраняться благодаря повторному применению SDProp."],"attack":["1. Нарушитель использует право на одном из защищённых объектов — SDProp уже скопировал на него разрешения AdminSDHolder.","2. Если это право изменения member, добавляет себя в Domain Admins; если право на запись, захватывает учётную запись администратора.","3. Сохраняет доступ: следующий запуск SDProp возвращает ACE, даже если его убрали только с дочернего объекта."],"remediation":["Удалите неутверждённый ACE непосредственно с AdminSDHolder, а не только с защищённых записей.","Проверьте результаты очередного SDProp и владельца AdminSDHolder.","Расследуйте происхождение нестандартного разрешения."]},"AGING_OS":{"description":"На компьютере используется ОС, приближающаяся к окончанию расширенной поддержки. Необходимо заблаговременно планировать миграцию, даже если сейчас установлены все доступные обновления.","impact":["Для Windows Server 2016 расширенная поддержка заканчивается в январе 2027 года; для Windows 10 действуют отдельные сроки поддержки и программы ESU.","Устаревшие системы могут не иметь новых защитных механизмов."],"attack":[],"remediation":["Проверьте текущий статус поддержки и наличие ESU, если применимо.","Подготовьте переход на поддерживаемые версии и контролируйте бюллетени безопасности."]},"ANONYMOUS_SID_NAME_TRANSLATION_ALLOWED":{"description":"GPO разрешает анонимное сопоставление SID и имени через LSAAnonymousNameLookup. Неаутентифицированный клиент может узнать переименованную встроенную запись администратора по известному RID 500. Это настройка LSA/SMB, а не LDAP.","impact":["Без учётных данных возможно получение имён пользователей и групп по SID.","Упрощается прицельная атака на встроенную административную запись."],"attack":["1. Нарушитель запрашивает у контроллера домена преобразование SID вида \u003cSID домена\u003e-500.","2. Получает актуальное имя встроенной учётной записи Administrator.","3. Использует полученное имя в атаке с распылением паролей."],"remediation":["Отключите параметр «Сетевой доступ: разрешить анонимное сопоставление SID и имени».","Проверьте устаревшие зависимости от этой функции."]},"COMPUTER_CONTAINER_CREATE_PERMISSIONS":{"description":"В контейнере Computers или OU явно делегировано непривилегированным субъектам создание объектов компьютеров. Такое разрешение может действовать независимо от ms-DS-MachineAccountQuota.","impact":["Возможно создание дополнительных машинных записей.","Они могут участвовать в атаках на делегирование RBCD и ретрансляцию при наличии других условий."],"attack":["1. Нарушитель выявляет явные разрешения создания объектов в контейнере.","2. Используя это разрешение, создаёт собственную машинную учётную запись.","3. Применяет её для атак с RBCD либо ретрансляцией аутентификации.","4. При выполнении дополнительных условий повышает привилегии."],"remediation":["Проверьте ACL контейнеров Computers и OU.","Удалите ненужное Create Computer; используйте специализированное делегирование и предварительное создание записей."]},"GPO_LINK_REACHES_DC":{"description":"Эта связь GPO достигает хотя бы одного контроллера домена через корень, OU, родительский контейнер или сайт AD. Учитываются наследование и фильтрация безопасности; WMI-фильтры и состояние компьютерной части требуют отдельной оценки.","impact":["Настройки и сценарии политики могут действовать на контроллере домена уровня Tier 0."],"attack":["Это не отдельный вектор атаки, а указание на область применения: вредоносное изменение данной политики потенциально затронет контроллер домена."],"remediation":["Привязывайте политики обычных серверов и рабочих станций только к их OU.","Проверяйте фактическую область действия критичных GPO, WMI-фильтры и делегированные права."]},"GPO_SEMACHINEACCOUNTPRIVILEGE_BROAD":{"description":"Через GPO назначено пользовательское право SeMachineAccountPrivilege — добавление компьютеров в домен. Оно дополняет механизм ms-DS-MachineAccountQuota.","impact":["Широкое назначение позволяет создавать нежелательные машинные записи.","Такие записи при дополнительных условиях участвуют в RBCD и атаках с ретрансляцией."],"attack":["1. Нарушитель выявляет чрезмерно широкое назначение SeMachineAccountPrivilege.","2. Присоединяет к домену контролируемую им систему.","3. Использует её машинную учётную запись для последующих действий.","4. При дополнительных условиях применяет RBCD, ретрансляцию либо принуждение к аутентификации."],"remediation":["Оставьте право только утверждённым группам администрирования.","Не назначайте его широким группам Authenticated Users или Everyone.","Отслеживайте появление компьютерных записей."]},"GPO_WIDE_IMPACT":{"description":"Обнаруженная проблема GPO влияет на большое количество компьютеров. Широкая область применения увеличивает масштаб последствий изменения настроек или злоупотребления правами.","impact":["Одна опасная настройка способна затронуть сразу множество узлов.","Приоритет возрастает, если среди них есть критичные серверы или контроллеры домена."],"attack":[],"remediation":["Пересмотрите область действия и связи GPO.","Ограничьте рискованные настройки и разделяйте политики по административным границам."]},"INACTIVE_ACCOUNT":{"description":"По отметкам входа запись давно не использовалась. Неактивные записи могут сохранять старые секреты и неактуальные полномочия, а их применение может остаться незамеченным.","impact":["Повышается риск использования осиротевших записей.","Старые пароли и недостаточный мониторинг увеличивают поверхность атаки."],"attack":[],"remediation":["Проверьте фактическую активность с учётом репликации и разных DC.","Отключите ненужные записи или удалите их по утверждённому процессу.","Отслеживайте неожиданные входы неактивных пользователей."]},"LDAP_ANONYMOUS_BINDING_RESTRICTED":{"description":"Анонимное подключение к LDAP ограничено. Не прошедшие аутентификацию клиенты не могут свободно перечислять объекты Active Directory.","impact":["Уменьшается раскрытие имён пользователей, групп и структуры каталога без учётных данных."],"attack":["При ограниченном анонимном LDAP-подключении нарушитель не может:","— перечислять пользователей и группы без аутентификации;","— анонимно выяснять организационную структуру каталога;","— определять чувствительные цели без действующих учётных данных;","— выполнять предварительную разведку через анонимные LDAP-запросы."],"remediation":["Это безопасное состояние; поддерживайте его.","Проверяйте исключения и отслеживайте отклонённые анонимные подключения."]},"MACHINE_QUOTA_UNRESTRICTED":{"description":"Значение ms-DS-MachineAccountQuota больше нуля. Одна лишь квота не предоставляет права создать компьютер: требуется также SeMachineAccountPrivilege или эквивалентное разрешение.","impact":["При наличии необходимых прав пользователи способны создавать машинные записи.","Созданные записи могут применяться в цепочках RBCD и ретрансляции."],"attack":["1. Нарушитель создаёт запись компьютера в пределах разрешённой квоты.","2. Использует созданную машинную запись для атаки RBCD на целевой компьютер при дополнительных условиях.","3. Получает возможность выдавать себя за выбранного пользователя перед целевой машиной.","4. При успешной цепочке получает права локального администратора на цели."],"remediation":["Рассмотрите значение квоты 0.","Выделите уполномоченные группы для создания компьютеров и проверяйте SeMachineAccountPrivilege."]},"OPERATOR_GROUP_MEMBERS":{"description":"В операторской группе Account Operators, Backup Operators, Print Operators или Server Operators есть участники. Эти встроенные группы обладают расширенными правами, которые требуют отдельной оценки.","impact":["Backup Operators могут получать доступ к резервным копиям важных данных.","Другие операторские группы могут управлять службами, объектами или параметрами контроллеров домена."],"attack":[],"remediation":["Пересмотрите каждого участника и его реальную задачу.","Предпочитайте узкое делегирование широкому членству.","Отслеживайте изменения составов групп."]},"PASSWORD_COMPLEXITY_ENABLED":{"description":"В доменной политике включены требования сложности пароля. Это ограничивает использование некоторых слишком простых паролей, но не гарантирует стойкости без достаточной длины и защиты от известных утечек.","impact":["Снижается вероятность использования очевидных комбинаций.","Общая устойчивость зависит также от длины, MFA и блокировки распространённых паролей."],"attack":["При включённых требованиях сложности нарушитель не может рассчитывать на то, что пользователь без ограничений установит:","— простой пароль, состоящий из одного словарного слова;","— некоторые распространённые комбинации, например password123, если они нарушают действующие правила сложности."],"remediation":["Сохраните требования сложности и дополните их достаточной минимальной длиной.","Применяйте проверку слабых паролей и MFA."]},"PREWIN2000_DEFAULT_MEMBER":{"description":"Группа Pre-Windows 2000 Compatible Access предоставляет своим участникам права чтения значительной части сведений об учётных записях и группах. Широкое членство облегчает перечисление каталога.","impact":["Повышается доступность сведений об именах и групповых членствах.","Эти сведения помогают выбирать цели следующих атак."],"attack":["1. Нарушитель проходит аутентификацию любой, даже непривилегированной, учётной записью.","2. Перечисляет пользователей, группы и связи членства в домене.","3. Выбирает цели по полученным данным, не обращаясь к привилегированным объектам напрямую."],"remediation":["Пересмотрите состав группы и необходимость широких участников.","Удаляйте избыточные членства после проверки совместимости зависимых приложений."]},"PRIVILEGED_GROUP_ACL":{"description":"Субъект может изменить привилегированную группу, не защищаемую AdminSDHolder. SDProp не сбрасывает её DACL, поэтому лишнее делегирование сохраняется и может дать контроль над её участниками.","impact":["Право на member позволяет добавлять участников и передавать им права группы.","Вложенное членство расширяет последствия такого изменения."],"attack":["1. Обладатель разрешения добавляет контролируемую учётную запись в группу посредством LDAP-записи атрибута member.","2. Повторно входит в систему, чтобы новое членство появилось в токене.","3. Использует права группы. Например, DnsAdmins может настроить подключаемую DLL службы DNS через dnscmd /config /serverlevelplugindll; служба загружает её от SYSTEM при следующем запуске."],"remediation":["Уберите ненужные ACE и проверьте наследование от родительских контейнеров.","Размещайте критичные группы в защищённых OU.","Контролируйте события изменения членства."]},"SMB_SIGNING_REQUIRED":{"description":"Обязательная цифровая подпись SMB защищает целостность обмена и мешает ретрансляции NTLM на SMB-службу, требующую подпись. Подпись сама по себе не означает шифрование трафика.","impact":["Снижается риск модификации SMB-сообщений и атак NTLM Relay на защищаемые службы."],"attack":["При обязательной подписи SMB нарушитель не может использовать этот путь для:","— ретрансляции NTLM к SMB ради исполнения кода;","— незаметного перехвата и изменения SMB-сообщений в транзите;","— применения PsExec/WMI через ретранслированные учётные данные;","— использования принуждения к аутентификации (PetitPotam, PrinterBug) для SMB Relay на защищаемую службу."],"remediation":["Сохраняйте требования подписи для клиентов и серверов.","Контролируйте попытки ослабления политики и документируйте настройку."]},"STALE_PASSWORD":{"description":"Пароль не менялся более пяти лет. Это признак повышенного риска, но не самостоятельное доказательство утечки или слабости секрета.","impact":["Пароль мог присутствовать в старых копиях или утечках.","При статическом секрете сохраняется длительное окно возможного злоупотребления."],"attack":["1. Нарушитель выявляет записи с очень давним pwdLastSet.","2. Пробует распространённые либо старые пароли через password spraying.","3. Для служебных записей Kerberoasting может дать материал для длительного автономного подбора.","4. Старые пароли могут совпадать с шаблонами из прежних утечек.","5. Компрометация записи позволяет длительно сохранять доступ."],"remediation":["Приоритетно пересмотрите пароль и смените его с учётом зависимостей.","Для подходящих служб используйте gMSA и длинные случайные пароли."]},"STALE_PASSWORD_MEDIUM":{"description":"Пароль не менялся от одного до пяти лет. Такая ситуация требует оценки парольной практики, хотя сама по себе не доказывает компрометацию.","impact":["Долговременное использование секрета увеличивает период потенциального злоупотребления.","Служебные записи требуют отдельной оценки риска."],"attack":["1. Нарушитель определяет записи с давней сменой пароля по pwdLastSet.","2. Пробует распространённые либо старые пароли через password spraying.","3. Для служб со SPN Kerberoasting позволяет получить материал для автономного подбора пароля.","4. Пароли могут соответствовать шаблонам, известным по предыдущим утечкам."],"remediation":["Проверьте необходимость длительного использования секрета.","Используйте сильные уникальные пароли, gMSA для подходящих служб и мониторинг pwdLastSet."]},"TIER0_NOT_IN_PROTECTED_USERS":{"description":"Пользователь уровня Tier 0 не входит в Protected Users. Для подходящих пользовательских записей эта группа ограничивает NTLM, CredSSP, Digest, RC4, делегирование и кэширование учётных данных.","impact":["Вне Protected Users материал NTLM-аутентификации этой записи может оставаться доступным на машинах входа и при компрометации извлекаться из LSASS.","Полученный NTLM-хеш при подходящих условиях может использоваться для pass-the-hash на доверяющих машинах.","TGT такой записи может делегироваться службам, что создаёт риск действий от её имени при компрометации службы.","RC4 может оставаться доступным для служебных билетов, повышая риск автономного подбора пароля при наличии соответствующих условий.","Обычный срок жизни TGT около десяти часов позволяет украденному билету использоваться значительную часть рабочего дня."],"attack":["1. Нарушитель получает возможность выполнять код на сервере, где входила эта административная запись.","2. Извлекает доступные учётные данные или билет Kerberos из LSASS.","3. Повторно использует их для доступа к контроллеру домена без знания пароля.","4. Если скомпрометированная запись относится к Tier 0, последствия могут охватить весь домен."],"remediation":["После проверки совместимости добавляйте в Protected Users именно ПОЛЬЗОВАТЕЛЬСКИЕ записи Tier 0. Для членов группы отключаются NTLM, CredSSP, Digest, RC4, делегирование и кэширование соответствующего материала учётных данных.","Не добавляйте компьютеры или gMSA в Protected Users: Microsoft не рекомендует это делать, и ожидаемые ограничения для них не действуют.","Для служебных записей, которым группа не подходит, включите «Account is sensitive and cannot be delegated» и ограничьте msDS-SupportedEncryptionTypes алгоритмами AES.","Используйте отдельные административные записи, чтобы их ограничения в Protected Users не нарушали повседневную работу обычного пользователя."]},"KRBTGT_PASSWORD_OLD":{"description":"Пароль встроенной учётной записи krbtgt давно не менялся. Ключи krbtgt используются KDC для защиты билетов TGT. При компрометации такого ключа возможна подделка билетов Golden Ticket.","impact":["Получив хеш krbtgt, нарушитель может подделывать билеты Kerberos.","Golden Ticket позволяет сохранять привилегированный доступ и способен привести к полной компрометации домена.","Поддельный билет может описывать несуществующего пользователя и произвольные членства в группах.","Обычная смена пользовательских паролей не делает уже созданные Golden Ticket недействительными.","Для восстановления доверия необходимо дважды сменить пароль krbtgt с правильным интервалом."],"attack":["1. Нарушитель получает хеш пароля krbtgt (например, через DCSync либо извлечение NTDS.dit).","2. Создаёт Golden Ticket с произвольными SID пользователя и групп.","3. Использует билет для доступа к ресурсам домена.","4. Билет может сохранять пригодность, пока пароль krbtgt не будет сменён дважды с необходимой репликацией и интервалом."],"remediation":["Планово меняйте пароль krbtgt не реже одного раза в 180 дней, если такая периодичность согласована с требованиями инфраструктуры.","При подозрении на компрометацию выполняйте две смены пароля с интервалом не менее 10 часов и с контролем репликации всех контроллеров домена.","Отслеживайте аномалии билетов Kerberos: необычно долгий срок действия и нетипичные алгоритмы шифрования.","Используйте многоуровневое администрирование для защиты доступа к ключам krbtgt."]},"PRIVILEGED_GROUP_MEMBERSHIP":{"description":"Учётная запись входит в особо привилегированные группы AD — ресурсы уровня Tier 0 или другие группы с расширенными полномочиями. Фактический риск определяется конкретной группой и её правами.","impact":["Domain Admins и Enterprise Admins дают широкий контроль над доменом или лесом.","Вход Tier 0 на менее защищённых узлах может привести к краже его секретов."],"attack":["1. Нарушитель компрометирует запись Tier 0 (фишинг, кража секрета либо нарушение административных границ).","2. Использует её права для доступа к контроллерам домена.","3. Извлекает учётные данные через DCSync, дамп LSASS или NTDS.dit.","4. Создаёт Golden Ticket для длительного доступа. Фактический охват других доменов леса зависит от доверия и полученных полномочий."],"remediation":["Минимизируйте административные членства и используйте отдельные записи.","Для подходящих пользователей применяйте Protected Users после тестирования; для компьютеров и gMSA эта группа не подходит.","Используйте PAW, MFA и контроль нарушений границ Tier."]},"DANGEROUS_ACL_DCSYNC":{"description":"Субъект получил DS-Replication-Get-Changes и DS-Replication-Get-Changes-All на корневом объекте домена. Совместное наличие этих прав может позволять DCSync — чтение реплицируемых секретов без интерактивного входа на контроллер.","impact":["Сочетание прав репликации позволяет извлекать хеши паролей учётных записей домена.","Среди получаемых секретов может быть ключ krbtgt, применяемый для Golden Ticket.","Возможна полная компрометация домена без интерактивного входа на контроллер домена.","Похищенные учётные данные могут обеспечить длительное сохранение доступа."],"attack":["1. Нарушитель компрометирует учётную запись с разрешениями репликации каталога.","2. С помощью DCSync запрашивает у контроллера домена хеши паролей.","3. Получает хеши NTLM и ключи Kerberos.","4. Использует ключ krbtgt для создания поддельных билетов Golden Ticket."],"remediation":["Прежде чем удалять права, определите назначение записи. Они штатно нужны средствам синхронизации каталогов (например, Entra Connect/MSOL_*), а также некоторым решениям резервного копирования и восстановления. Необдуманное удаление способно нарушить гибридный вход всей организации; такую запись следует защищать как Tier 0, поскольку её полномочия сопоставимы с DC.","Удалите репликационные права у остальных субъектов, которым они не требуются.","Отслеживайте операции DCSync по событиям 4662 с соответствующими GUID прав.","Используйте средства расширенного обнаружения угроз (Advanced Threat Protection или аналоги) для выявления DCSync."]},"DANGEROUS_ACL_GENERICWRITE":{"description":"GenericWrite позволяет изменять многие незащищённые атрибуты чувствительного объекта AD. Последствия зависят от класса объекта и конкретных доступных атрибутов.","impact":["На пользователях возможно изменение SPN или сценария входа.","На компьютерах возможны рискованные изменения делегирования и ключей.","На группах изменение member может дать дополнительные права."],"attack":["Для пользователя: добавить SPN и применить Kerberoasting либо задать сценарий входа для выполнения кода.","Для компьютера: настроить RBCD, чтобы получать доступ к целевой машине от имени другого пользователя.","Для группы: добавить контролируемую запись в состав и получить её групповые полномочия.","Для GPO: добавить запланированные задания, сценарии запуска либо настройки реестра, действующие на связанные OU."],"remediation":["Уберите избыточный GenericWrite и выдавайте узкие права на нужные атрибуты.","Контролируйте изменения объектов, в том числе событие 5136."]},"GPO_SYSVOL_WRITABLE":{"description":"Субъект, не уполномоченный управлять групповой политикой, имеет право записи в её каталог \\\\\u003cдомен\u003e\\SYSVOL\\\u003cдомен\u003e\\Policies\\{GUID}\\. Здесь располагаются фактические данные политики — Registry.pol, GptTmpl.inf, папка Scripts, ScheduledTasks.xml и GPT.ini. Право записи в SYSVOL позволяет изменить применяемую политику независимо от разрешений на объект GPO в AD.","impact":["Подмена Registry.pol или GptTmpl.inf изменяет настройки, применяемые машинами в области действия GPO при очередном обновлении.","Запись в Scripts\\Startup или Scripts\\Shutdown позволяет выполнять код от SYSTEM на машинах, куда распространяется компьютерная часть политики.","Файлы запланированных заданий и Group Policy Preferences применяются с правами, заданными конкретным механизмом политики.","Увеличение версии в GPT.ini может заставить клиентов считать политику обновлённой и применить её повторно, не дожидаясь обычного цикла.","Эта уязвимость не видна во вкладке делегирования GPO, если там показаны только разрешения объекта каталога."],"attack":["1. Выявляет политику с доступным для записи каталогом SYSVOL; область действия GPO определяет потенциальный масштаб.","2. Записывает в каталог вредоносный сценарий запуска, запланированное задание или Registry.pol.","3. Увеличивает версию в GPT.ini и versionNumber объекта GPO либо ожидает следующего обновления политики.","4. Код выполняется на машинах, связанных с GPO, с правами конкретного механизма: например, сценарий запуска компьютера выполняется от SYSTEM."],"remediation":["Уберите избыточную запись в каталог GPO через свойства безопасности `\\\\\u003cдомен\u003e\\SYSVOL\\\u003cдомен\u003e\\Policies\\{GUID}\\` либо команду icacls для этого же пути.","Если ACE унаследован, исправьте исходный родительский каталог: удаление унаследованного разрешения только на дочернем объекте не устранит причину.","Сверьте ACL с ожидаемой моделью: SYSTEM, Administrators, Domain Admins, Enterprise Admins и CREATOR OWNER — полный доступ; Authenticated Users и ENTERPRISE DOMAIN CONTROLLERS — чтение и выполнение, если применимо к данной среде.","Не запускайте dcgpofix как обычный способ исправления: это крайняя мера, сбрасывающая Default Domain Policy и Default Domain Controllers Policy с потерей их изменённых настроек.","В дальнейшем проверяйте вместе обе части GPO: объект в AD и файловый каталог в SYSVOL."]},"PASSWORD_NOT_REQUIRED":{"description":"В userAccountControl установлен флаг PASSWD_NOTREQD. Он допускает отсутствие обязательного непустого пароля, но сам по себе не доказывает, что пароль фактически пуст.","impact":["При сочетании флага с пустым или слабым паролем растёт риск несанкционированного входа."],"attack":["1. Нарушитель выявляет записи с флагом PASSWD_NOTREQD.","2. Пробует пройти аутентификацию с пустым паролем.","3. Если вход действительно допускается, получает доступ к учётной записи."],"remediation":["Уточните назначение записи и состояние пароля.","Удалите PASSWD_NOTREQD там, где он не нужен, сохранив работу штатных сценариев создания компьютеров."]},"GPO_UNLINKED_BROAD_WRITE":{"description":"Эта GPO сейчас не применяется, но широкая группа может изменять её содержимое или разрешения. Политика может быть привязана позднее, поэтому риск сохраняется.","impact":["Опасное содержимое способно начать действовать после восстановления связей."],"attack":[],"remediation":["Удалите ненужную GPO либо ограничьте право редактирования.","Перед повторным использованием проверяйте содержимое и ACL."]},"DANGEROUS_ACL_WRITEDACL":{"description":"WriteDACL позволяет изменять DACL чувствительного объекта AD и выдавать новые разрешения.","impact":["Возможно назначение себе GenericAll или иных опасных прав на объект."],"attack":["1. Нарушитель через WriteDACL выдаёт собственной записи GenericAll на целевой объект.","2. Использует GenericAll для дальнейшего захвата объекта, как описано в соответствующей находке."],"remediation":["Уберите ненужный WriteDACL; проверьте наследование и владельца.","Контролируйте изменения безопасности объекта."]},"DANGEROUS_ACL_WRITEOWNER":{"description":"WriteOwner позволяет сменить владельца объекта. Владелец обычно может менять DACL и тем самым назначать себе другие полномочия.","impact":["Возможен непрямой захват управления объектом без изначального GenericAll."],"attack":["1. Нарушитель назначает себя владельцем объекта.","2. Как владелец, изменяет DACL и предоставляет себе GenericAll.","3. Использует GenericAll для полного управления объектом."],"remediation":["Отзовите избыточный WriteOwner и проверьте нестандартное владение."]},"DOMAIN_ROOT_NON_DEFAULT_OWNER":{"description":"Корневой объект домена имеет нестандартного владельца. Владение объектом предоставляет специальные возможности управления разрешениями и должно соответствовать административной модели.","impact":["Нестандартный владелец может получить путь к изменению DACL домена.","Это затрагивает критичные права, включая репликацию."],"attack":["1. Нарушитель управляет субъектом, которому принадлежит корневой объект домена.","2. Добавляет в DACL разрешения на оба расширенных репликационных права.","3. Выполняет DCSync и получает учётные данные домена.","4. При желании восстанавливает DACL, оставляя владение объектом как путь повторного доступа."],"remediation":["Установите причину изменения владельца и при необходимости восстановите ожидаемое состояние.","Проверьте ACE корня домена."]},"PASSWORD_NEVER_EXPIRES":{"description":"Для записи включён флаг «Срок действия пароля не ограничен». Такой режим иногда используется для служб, но увеличивает время действия украденного секрета.","impact":["Неизменный пароль после утечки может оставаться пригодным неограниченно долго."],"attack":["1. Нарушитель получает пароль через фишинг, утечку или подбор.","2. Пароль без ограничения срока действия остаётся пригодным до ручной смены или блокировки записи.","3. Нарушитель может длительно сохранять доступ."],"remediation":["Пересмотрите необходимость бессрочного пароля.","Для подходящих служб используйте gMSA и контролируемую ротацию."]},"SMB_SIGNING_DISABLED":{"description":"В GPO не задано обязательное требование подписи SMB. «Не настроено» не доказывает её отключение: действуют также локальные параметры и умолчания конкретной версии Windows.","impact":["Если SMB-служба не требует подписи, возможны атаки с ретрансляцией NTLM и модификацией сообщений."],"attack":["1. Нарушитель располагается в сети для атаки «человек посередине».","2. Принуждает целевой узел к аутентификации (например, PetitPotam или PrinterBug).","3. Ретранслирует NTLM-аутентификацию к системе, не требующей подписи SMB.","4. Выполняет команды либо читает файлы с правами ретранслированной записи при дополнительных условиях."],"remediation":["Проверьте фактические настройки клиентских и серверных машин.","Поэтапно включайте обязательную подпись через GPO с проверкой старых NAS, МФУ и устройств резервного копирования."]},"AD_RECYCLE_BIN_DISABLED":{"description":"Корзина Active Directory не включена, хотя функциональный уровень леса это допускает. Без неё удалённый объект теряет большую часть атрибутов и членств, усложняя восстановление.","impact":["После удаления могут требоваться резервная копия и авторитетное восстановление.","Снижается информативность следов удалённых объектов."],"attack":["1. Нарушитель с достаточными правами удаляет пользователей, группы или OU, нарушая работу домена либо скрывая следы.","2. Без AD Recycle Bin удалённые объекты теряют атрибуты и членства.","3. Восстановление зависит от актуальной резервной копии и процедуры авторитетного восстановления."],"remediation":["Рассмотрите включение AD Recycle Bin после согласования.","Изменение необратимо и действует для последующих удалений.","Поддерживайте резервное копирование."]},"NO_ACCOUNT_LOCKOUT":{"description":"Не установлена эффективная блокировка учётных записей при неуспешных попытках входа либо порог слишком мягкий.","impact":["Становится проще многократно проверять пароли без временной блокировки."],"attack":["1. Нарушитель определяет учётные записи для подбора.","2. Выполняет неограниченное количество попыток ввода пароля.","3. Блокировка не срабатывает и не замедляет атаку.","4. В результате может подобрать правильный пароль."],"remediation":["Настройте порог блокировки с учётом риска отказа в обслуживании.","Включите аудит входов, MFA и защиту от известных слабых паролей."]},"WEAK_PASSWORD_POLICY":{"description":"В доменной политике допускаются недостаточно стойкие пароли, например из-за малого минимального количества символов или отсутствия иных защитных требований.","impact":["Растёт вероятность успешного password spraying и угадывания простых паролей."],"attack":["1. Нарушитель выполняет password spraying с распространёнными паролями.","2. Слабая политика допускает простые варианты вроде Summer2024.","3. Компрометирует несколько учётных записей.","4. Использует полученные записи для повышения привилегий."],"remediation":["Увеличьте минимальную длину и проверяйте запрещённые пароли.","Используйте MFA, историю паролей и при необходимости FGPP."]},"DANGEROUS_ACL_GPO_DELETE":{"description":"У субъекта есть Delete, DeleteTree, DeleteChild или CreateChild на объекте GPO либо контейнере политик. Эти права не меняют содержимое политики напрямую, но позволяют влиять на её существование, что создаёт риск отказа в обслуживании и отключения защитных настроек.","impact":["Delete/DeleteTree могут удалить GPO со всеми применяемыми настройками; воссоздание под прежним именем не возвращает её исходный GUID, связи и делегирование.","CreateChild/DeleteChild на контейнере Group Policy Objects позволяют управлять созданием и удалением GPO в домене."],"attack":["1. Нарушитель выбирает GPO с защитной настройкой, которую хочет устранить (сценарий входа, ограничение, настройка усиления защиты).","2. Удаляет политику либо удаляет и создаёт новую с тем же отображаемым именем, но уже без прежних разрешений и содержимого.","3. Защитная настройка перестаёт применяться на всех машинах области действия; отсутствие отдельного мониторинга удаления GPO может скрыть изменение."],"remediation":["Удалите ненужные Delete/DeleteTree/DeleteChild/CreateChild с GPO и родительского контейнера.","Учитывайте унаследованные ACE и возможность владельца изменить ACL.","Контролируйте создание и удаление GPO (в частности, событие 5141).","Поддерживайте резервные копии через Backup-GPO."]},"DANGEROUS_ACL_GPO_WRITEPROPERTY":{"description":"WriteProperty на объекте GPO позволяет изменять критичные атрибуты политики, прежде всего gPCFileSysPath (путь к файлам SYSVOL), gPCMachineExtensionNames и gPCUserExtensionNames (расширения обработки), а также versionNumber. Это не равнозначно обычному WriteProperty на пользовательской записи.","impact":["Перенаправление gPCFileSysPath заставляет клиентов читать файлы политики из другого UNC-пути.","Изменение ExtensionNames может подключить обработчики Scripts или Group Policy Preferences.","Изменение versionNumber ускоряет повторную обработку обновлённой политики."],"attack":["1. Нарушитель размещает вредоносный файл Registry.pol, Scripts или Group Policy Preferences в подконтрольном каталоге SYSVOL.","2. Изменяет gPCFileSysPath объекта GPO, указывая новый путь.","3. Увеличивает versionNumber, чтобы клиенты считали политику изменённой и применили её на следующем цикле.","4. Содержимое выполняется на всех связанных с GPO компьютерах с полномочиями, заданными соответствующим механизмом политики."],"remediation":["Ограничьте WriteProperty и используйте штатное делегирование через GPMC.","Если ACE унаследован, устраните его источник в контейнере CN=Policies,CN=System.","Проверьте владельца GPO.","Отслеживайте изменения gPCFileSysPath и ExtensionNames (событие 5136)."]},"DANGEROUS_ACL_REPLICATION_INERT_HALF":{"description":"Субъект имеет DS-Replication-Get-Changes-All или вариант для отфильтрованного набора без DS-Replication-Get-Changes. Без Get-Changes такая комбинация не позволяет выполнить репликацию, но недостающее право может быть добавлено отдельным ACE.","impact":["Самостоятельно найденное право не обеспечивает DCSync.","Добавление DS-Replication-Get-Changes к этой записи может создать опасную комбинацию полномочий."],"attack":["1. Нарушитель обнаруживает субъект, обладающий только DS-Replication-Get-Changes-All.","2. Ищет возможность добавить ему DS-Replication-Get-Changes либо перейти к субъекту с недостающим правом.","3. Дополняет пару разрешений одним ACE.","4. Выполняет полный DCSync."],"remediation":["Удалите невостребованное частичное право и установите причину его назначения.","Проверьте связанные ACE и субъектов, способных изменять DACL домена.","Не считайте неполную комбинацию безусловно безопасной."]},"DANGEROUS_ACL_REPLICATION_NO_SECRETS":{"description":"DS-Replication-Get-Changes без DS-Replication-Get-Changes-All даёт возможность репликации обычных атрибутов каталога, но не секретных значений, защищённых вторым правом. Это не полноценный DCSync, однако раскрывается значительная часть каталога, включая дескрипторы безопасности.","impact":["Можно реплицировать несекретные атрибуты всех объектов и сведения об ACL.","Некоторые приложения ошибочно сохраняют пароли в обычных атрибутах, которые могут быть доступны.","Дополнительное право Get-Changes-All превращает эту комбинацию в DCSync."],"attack":["1. Нарушитель управляет субъектом, имеющим только DS-Replication-Get-Changes.","2. Реплицирует раздел каталога и получает все несекретные атрибуты и дескрипторы безопасности.","3. Анализирует дескрипторы автономно, ища путь к получению второго репликационного права.","4. Добавляет DS-Replication-Get-Changes-All либо находит субъект с ним, после чего выполняет полный DCSync."],"remediation":["Оставьте Get-Changes только контроллерам домена и уполномоченным средствам синхронизации.","Проверьте, кто может изменять DACL корня домена.","Не рассматривайте частичное разрешение как безвредное."]},"DOMAIN_ROOT_GPLINK_WRITE":{"description":"Субъект может изменять атрибут gPLink корневого объекта домена. Он задаёт связи GPO с доменом и позволяет влиять на политики всех машин, включая контроллеры домена.","impact":["Можно добавить или удалить доменную связь GPO, изменить порядок и принудительное применение.","Небезопасная политика, привязанная к корню, может затронуть контроллеры домена и обычные компьютеры."],"attack":["1. Нарушитель создаёт GPO; по умолчанию это доступно аутентифицированным участникам Group Policy Creator Owners.","2. Добавляет в политику немедленное запланированное задание либо сценарий запуска.","3. Записывает путь к созданной GPO в gPLink корневого объекта домена.","4. Ожидает обновления политики или инициирует его, после чего код исполняется на машинах в области её действия."],"remediation":["Ограничьте изменение gPLink корня домена субъектами Tier 0.","Проверьте существующие доменные связи.","Контролируйте изменения gPLink, в том числе событие 5136."]},"GPO_SCOPE_DOMAIN_WIDE":{"description":"GPO связана непосредственно с корнем домена, поэтому потенциально действует на всех пользователей и компьютерах, включая контроллеры домена. Реальная применимость также зависит от фильтрации безопасности, WMI и состояния частей политики.","impact":["Ошибка в такой GPO способна повлиять на весь домен.","Вредоносное изменение критичной политики может затронуть Tier 0."],"attack":["1. Нарушитель находит GPO, связанную со всем доменом и имеющую слабые разрешения.","2. Изменяет политику, добавляя запланированное задание или сценарий запуска.","3. При обычном интервале обновления примерно 90 минут вредоносное содержимое применяется к компьютерам домена в области действия политики.","4. Если она действует также на контроллеры домена, возможна немедленная компрометация домена."],"remediation":["Минимизируйте число GPO у корня домена.","Делегируйте редактирование только утверждённым администраторам.","Используйте связи с конкретными OU и фильтрацию безопасности; соблюдайте требования чтения GPO клиентами.","Контролируйте изменение связей."]},"GPO_USERRIGHT_SEASSIGNPRIMARYTOKEN":{"description":"GPO назначает SeAssignPrimaryTokenPrivilege субъекту сверх штатного набора LOCAL SERVICE и NETWORK SERVICE. Право позволяет запускать процесс с первичным токеном другой личности, если субъект уже располагает пригодным токеном олицетворения.","impact":["В сочетании с SeImpersonatePrivilege или ранее полученным токеном возможен запуск процесса от имени другой записи.","Угроза возникает только при наличии дополнительного доступного токена."],"attack":["1. Получить токен олицетворения привилегированной личности (обычно через SeImpersonatePrivilege).","2. Вызвать CreateProcessAsUser либо CreateProcessWithTokenW с этим токеном.","3. Новый процесс запускается с полным набором привилегий первичного токена целевой личности."],"remediation":["Уберите назначение, если запись не является утверждённой службой, действительно запускающей процессы с чужими токенами.","Проверьте область действия GPO."]},"GPO_USERRIGHT_SEAUDIT":{"description":"GPO выдаёт SeAuditPrivilege субъекту помимо LOCAL SERVICE и NETWORK SERVICE. Разрешение позволяет создавать записи аудита в журнале Security и при злоупотреблении заполнять его посторонними событиями.","impact":["Может вытеснять реальные события при циклической перезаписи Security.","При настройке остановки системы при невозможности аудита заполнение журнала способно вызвать отказ.","Поддельные записи затрудняют расследование."],"attack":["1. Получить учётные данные обладателя права и сеанс на целевой машине.","2. Создать большой поток записей аудита безопасности.","3. События вторжения вытесняются из журнала при перезаписи либо машина останавливается при переполнении журнала в соответствующей конфигурации."],"remediation":["Ограничьте право штатными служебными субъектами.","Передавайте события Security на независимый коллектор, недоступный для локального удаления."]},"GPO_USERRIGHT_SEBACKUP":{"description":"SeBackupPrivilege назначен сверх штатных Administrators и Backup Operators (на DC также могут быть Server Operators). Право позволяет читать защищённые файлы с обходом обычных ACL, в том числе чувствительные системные данные.","impact":["На обычном компьютере могут стать доступны SAM и SYSTEM.","На контроллере домена возможен доступ к файлам базы AD, в частности NTDS.dit.","Ограничения NTFS сами по себе не защищают от уполномоченного режима резервного копирования."],"attack":["Получить доступ к компьютеру с данным правом.","Считать защищённые файлы через предусмотренный режим резервного копирования.","При наличии соответствующих данных извлечь секреты в отдельной среде."],"remediation":["Оставляйте SeBackupPrivilege только утверждённым и контролируемым решениям резервного копирования.","Считайте обладателей этого права на DC субъектами уровня Tier 0."]},"GPO_USERRIGHT_SEBATCHLOGON":{"description":"Политика назначает SeBatchLogonRight («Вход в качестве пакетного задания») дополнительному субъекту. Это разрешает запуск запланированного задания от имени соответствующей записи без интерактивного сеанса.","impact":["Возможен автоматический запуск кода с правами этой записи.","При компрометации запись может использоваться для закрепления через задачи."],"attack":["1. Получить учётные данные обладателя права.","2. Зарегистрировать запланированное задание с запуском от имени этой записи (например, schtasks.exe /Create /RU).","3. Задание выполняется по расписанию или немедленно с полномочиями обладателя."],"remediation":["Оставьте право только учётным записям служб и автоматизации, действительно нуждающимся в таком запуске.","Проверяйте запланированные задания и область применения GPO."]},"GPO_USERRIGHT_SEDEBUG":{"description":"SeDebugPrivilege назначен субъекту помимо штатных Administrators. Это право позволяет открывать процессы с расширенными полномочиями, включая LSASS, и может обходить обычные проверки разрешений на процесс.","impact":["Возможно чтение памяти чувствительных процессов и получение материала аутентификации.","Раскрываются процессы других пользователей и служб, вплоть до критических системных компонентов."],"attack":["1. Пройти аутентификацию от имени обладателя права на компьютере в области действия GPO.","2. Открыть дескриптор lsass.exe; SeDebugPrivilege позволяет обойти обычную проверку ACL процесса.","3. Получить дамп процесса (например, comsvcs.dll MiniDump, Task Manager или специализированное средство).","4. Извлечь учётные данные из дампа автономно."],"remediation":["Удалите право у лишних субъектов; оставьте его утверждённым администраторам.","Для мониторинговых служб строго ограничивайте целевые компьютеры и проверяйте необходимость полномочия."]},"GPO_USERRIGHT_SEENABLEDELEGATION":{"description":"SeEnableDelegationPrivilege позволяет настраивать делегирование Kerberos для учётных записей. На контроллере домена это критичное полномочие, штатно предназначенное администраторам; на обычных компьютерах такое назначение не имеет того же значения.","impact":["Можно разрешить делегирование для контролируемой службы и создать условия подмены контекста пользователей.","Неограниченное делегирование способно раскрыть TGT подключающихся пользователей при дополнительных условиях."],"attack":["1. Пройти проверку подлинности от имени обладателя права на контроллере домена.","2. Задать msDS-AllowedToDelegateTo (ограниченное делегирование) либо TRUSTED_FOR_DELEGATION (неограниченное) на контролируемой или целевой записи.","3. Вызвать аутентификацию привилегированного субъекта к службе этой записи.","4. Получить и повторно использовать выданный в результате билет."],"remediation":["Ограничьте право штатными администраторами контроллеров домена.","Дополнительно помечайте критичные учётные записи как конфиденциальные, не допускающие делегирования."]},"GPO_USERRIGHT_SEINTERACTIVELOGON":{"description":"GPO предоставляет SeInteractiveLogonRight («Локальный вход») субъекту сверх ожидаемой модели. На контроллере домена такой вход особенно чувствителен.","impact":["Обладатель может создавать локальный сеанс на затронутых компьютерах.","Неожиданный вход на DC увеличивает риск компрометации Tier 0."],"attack":["Получить учётные данные субъекта.","Войти в локальную консоль целевой машины или консоль гипервизора.","Использовать права записи в этом сеансе."],"remediation":["На DC разрешайте локальный вход строго утверждённым администраторам домена.","На обычных компьютерах оставьте право только тем, кому оно необходимо."]},"GPO_USERRIGHT_SELOADDRIVER":{"description":"SeLoadDriverPrivilege назначен субъекту помимо стандартных администраторов и соответствующих операторов печати на DC. Право позволяет загружать драйвер в ядро Windows.","impact":["Уязвимый подписанный драйвер может дать доступ к памяти ядра.","При успешной эксплуатации угрожает защитным механизмам ОС; на DC последствия критичны для домена."],"attack":["1. С использованием права загрузить подписанный драйвер с известной уязвимостью (например, из перечней loldrivers.io).","2. Злоупотребить уязвимым IOCTL драйвера для чтения или записи памяти ядра.","3. Отключить защитные механизмы (например, EDR callbacks, LSA Protection) либо повысить полномочия непосредственно до SYSTEM."],"remediation":["Удалите лишние назначения.","Применяйте блокировку известных уязвимых драйверов, HVCI и WDAC как дополнительную защиту."]},"GPO_USERRIGHT_SEPROFILESINGLEPROCESS":{"description":"GPO назначает SeProfileSingleProcessPrivilege сверх штатных Administrators. Право позволяет собирать сведения о производительности отдельных процессов и облегчает изучение работающих приложений.","impact":["Можно выявлять критичные процессы, активные сеансы и некоторые средства защиты.","Это повышает информированность нарушителя о целевой машине."],"attack":["Получить сеанс на машине с правом.","Исследовать процессы и выбрать дальнейшие цели."],"remediation":["Оставьте право только утверждённым средствам мониторинга и администраторам.","Ограничьте GPO машинами, где оно действительно необходимо."]},"GPO_USERRIGHT_SEREMOTESHUTDOWN":{"description":"SeRemoteShutdownPrivilege через GPO дан дополнительному субъекту. Оно позволяет инициировать удалённое выключение или перезагрузку компьютеров в области действия политики.","impact":["Можно вызвать отказ в обслуживании сразу нескольких узлов.","Принудительная перезагрузка может уничтожить часть временных свидетельств инцидента."],"attack":["1. Получить учётные данные обладателя права.","2. Инициировать удалённое выключение либо перезагрузку целевой машины (например, shutdown.exe /r /m).","3. Компьютер становится недоступным; повторяющиеся воздействия превращаются в отказ в обслуживании."],"remediation":["Ограничьте право администраторами и уполномоченной эксплуатацией.","Особенно тщательно контролируйте назначение на контроллерах домена."]},"GPO_USERRIGHT_SERESTORE":{"description":"SeRestorePrivilege назначен сверх штатных Administrators и Backup Operators. Право позволяет записывать защищённые файлы в обход обычных ACL и менять владельца; это одна из наиболее чувствительных привилегий.","impact":["Возможна замена файлов, загружаемых привилегированными процессами.","Может изменяться содержимое чувствительных системных файлов и их владение."],"attack":["Получить сеанс с соответствующим правом.","Подменить файл, который позднее загрузит системный компонент.","Вызвать его перезапуск или обычное применение файла."],"remediation":["Оставьте право только утверждённым и наблюдаемым средствам восстановления.","Обладателя права на DC рассматривайте как Tier 0."]},"GPO_USERRIGHT_SESECURITY":{"description":"GPO назначает SeSecurityPrivilege дополнительному субъекту. Разрешение позволяет читать и очищать журнал Security, а также управлять частью параметров аудита.","impact":["Возможно сокрытие следов действий путём очистки журнала или изменения политики аудита.","Субъект может исследовать SACL и контролируемые операции."],"attack":["1. После действий, которые требуется скрыть, пройти аутентификацию от имени обладателя права на целевой машине.","2. Очистить журнал событий Security (например, wevtutil cl Security) либо заранее отключить соответствующие категории аудита.","3. Хронологию вторжения становится невозможно полностью восстановить только по локальным журналам этого компьютера."],"remediation":["Оставьте право только штатным администраторам.","Отправляйте события Security в независимый SIEM или коллектор."]},"GPO_USERRIGHT_SESHUTDOWN":{"description":"SeShutdownPrivilege предоставлен через GPO дополнительному субъекту. Право позволяет выключать или перезагружать целевой компьютер из локального сеанса.","impact":["Возможен отказ в обслуживании.","При остановке DC клиенты перейдут к другому контроллеру, что может быть важно для атак на сетевой маршрут."],"attack":["1. Получить учётные данные обладателя права и сеанс на целевой машине.","2. Завершить работу компьютера через shutdown.exe или интерфейс Windows.","3. Если остановлен контроллер домена, предназначавшийся ему трафик аутентификации переключается на другие контроллеры."],"remediation":["Ограничьте право администраторами и штатными операторами.","Особенно проверяйте контроллеры домена."]},"GPO_USERRIGHT_SESYSTEMENVIRONMENT":{"description":"GPO назначает SeSystemEnvironmentPrivilege сверх стандартных Administrators. Право позволяет менять переменные окружения встроенного ПО, включая значения UEFI NVRAM, связанные с загрузкой.","impact":["Возможно изменение параметров загрузки или работы аппаратных компонентов.","Некорректные параметры способны вызвать недоступность системы либо повреждение данных."],"attack":["1. Получить учётные данные обладателя права и сеанс на целевой машине.","2. Изменить переменные окружения встроенного ПО (firmware).","3. Компьютер загружается с другой конфигурацией либо один из компонентов перестаёт работать."],"remediation":["Сохраните право у Administrators, убрав неутверждённые назначения.","Не удаляйте автоматически штатных Administrators: это может нарушить функции вроде BitLocker."]},"GPO_USERRIGHT_SESYSTEMPROFILE":{"description":"SeSystemProfilePrivilege назначен сверх Administrators и NT SERVICE\\WdiServiceHost. Право позволяет анализировать производительность системных процессов и облегчает разведку на узле.","impact":["Можно получить сведения об активных системных службах и средствах защиты."],"attack":["Получить сеанс на машине.","Изучить производительность системных процессов для выбора цели."],"remediation":["Ограничьте право штатными Administrators и NT SERVICE\\WdiServiceHost, если нет утверждённых дополнительных зависимостей."]},"GPO_USERRIGHT_SESYSTEMTIME":{"description":"SeSystemtimePrivilege назначен дополнительному субъекту. Время машины важно для Kerberos: билеты за пределами допустимого расхождения часов (обычно около пяти минут) отклоняются.","impact":["Изменение времени может нарушить аутентификацию Kerberos.","Неверные часы затрудняют корреляцию журналов и работу временных проверок."],"attack":["Получить сеанс с правом.","Изменить системное время за пределы допуска Kerberos.","Вызвать отказы входа до восстановления синхронизации."],"remediation":["Разрешайте изменение времени только администраторам и службам синхронизации.","Проверяйте службу времени и политику NTP."]},"GPO_USERRIGHT_SETAKEOWNERSHIP":{"description":"SeTakeOwnershipPrivilege назначен сверх штатных Administrators. Право позволяет становиться владельцем объектов, после чего обычно можно изменять их DACL и получать дополнительные разрешения.","impact":["Возможен захват файлов, ключей реестра и иных объектов независимо от исходных ACL.","Смена владельца создаёт путь к изменению защищённых конфигураций."],"attack":["1. Пройти аутентификацию от имени обладателя права.","2. Назначить себя владельцем целевого объекта (через takeown.exe либо Windows API).","3. После получения владения выдать себе полный доступ через icacls.","4. Изменить объект — например, исполняемый файл службы или чувствительный конфигурационный файл — для повышения привилегий."],"remediation":["Оставьте право только утверждённым администраторам.","Контролируйте нестандартные смены владельцев."]},"INACTIVE_PRIVILEGED_ACCOUNT":{"description":"Привилегированная учётная запись долго не использовалась, но остаётся участником административных групп. Такая запись увеличивает поверхность атаки, не принося ожидаемой операционной пользы.","impact":["Старый секрет может оказаться раскрытым, а незаконный вход — долго не замечаться.","Компрометация даёт немедленные административные права."],"attack":["1. Нарушитель выявляет давно не использовавшиеся привилегированные записи.","2. Применяет к ним распыление паролей (password spraying) или проверку утекших паролей (credential stuffing).","3. Полученные учётные данные немедленно дают административный доступ.","4. Атака может остаться незамеченной из-за отсутствия обычной активности этих записей."],"remediation":["Подтвердите необходимость записи и её членства.","Неиспользуемые записи отключайте по утверждённой процедуре и пересматривайте доступ.","Контролируйте попытки входа."]},"OPERATOR_GROUP_MEMBERSHIP":{"description":"Учётная запись входит в группу операторского уровня или с расширенным доступом, например Account Operators, Backup Operators, Print Operators или Cert Publishers. Права этих групп зависят от роли и версии Windows.","impact":["Возможно управление частью записей, резервными копиями, службами либо другими чувствительными компонентами.","При определённой конфигурации существует путь повышения привилегий."],"attack":[],"remediation":["Проверьте необходимость конкретного членства и область предоставляемых прав.","По возможности заменяйте широкие группы точечным делегированием.","Отслеживайте изменения состава."]},"OU_PERM_CREATE_CHILD":{"description":"Субъект может создавать дочерние объекты в OU. Особый риск представляет создание компьютеров: такие записи могут использоваться при RBCD. На DC с Windows Server 2025 право создания All Objects также охватывает делегируемые управляемые учётные записи dMSA.","impact":["Возможно создание пользователей, компьютеров и групп.","Созданные объекты могут наследовать широкие разрешения.","При дополнительных условиях dMSA или RBCD позволяют расширить доступ."],"attack":["1. Нарушитель создаёт компьютерную учётную запись в OU.","2. Использует машинную запись для RBCD-атаки на другой ресурс при дополнительных условиях.","3. Либо создаёт пользовательскую запись для закрепления доступа."],"remediation":["Удалите избыточный CreateChild или ограничьте его нужными классами.","Контролируйте создание объектов.","Если ACE унаследован, устраняйте источник на родительском контейнере, учитывая последствия отключения наследования."]},"OU_PERM_GPLINK":{"description":"Субъект может изменять gPLink данной OU — список связей групповых политик. Это позволяет подключать выбранные GPO к объектам в области действия OU.","impact":["Изменённая связь может применить сценарии, параметры безопасности и другие настройки ко всем компьютерам и пользователям OU."],"attack":["1. Нарушитель создаёт GPO с вредоносным содержимым или изменяет существующую.","2. Изменяя gPLink, привязывает её к целевой OU.","3. Политика применяется при следующем обновлении групповых политик.","4. Выполняются вредоносные сценарии либо изменяются настройки в области действия."],"remediation":["Ограничьте изменение gPLink администраторами групповой политики.","Контролируйте изменения связей и их источников наследования."]},"OU_PERM_GPOPTIONS":{"description":"Субъект может изменять gPOptions OU — атрибут блокировки наследования GPO. При установленном Block Inheritance политики, связанные выше OU, перестают применяться, если их связи не принудительные (Enforced).","impact":["Можно отключить наследуемые защитные политики для всего содержимого OU без изменения самих GPO."],"attack":["1. Нарушитель включает Block Inheritance для OU (gPOptions = 1).","2. Политики, связанные с родительскими контейнерами без принудительного применения, перестают действовать после обновления.","3. Компьютеры внутри OU теряют часть базовой защиты, и нарушитель использует возникший пробел."],"remediation":["Уберите лишнее право записи gPOptions.","Для необходимых базовых политик оцените Enforced.","Проверьте унаследованные ACE и эффект возможного разрыва наследования."]},"OU_PERM_GROUP_MEMBERSHIP":{"description":"Делегированное право позволяет изменять атрибут member групп в OU. Это может дать возможность добавлять или удалять участников, в том числе чувствительных групп, если они входят в область действия.","impact":["Нежелательное добавление участника может передать полномочия группы.","Удаление штатных участников может нарушить работу."],"attack":["1. Нарушитель выявляет привилегированные группы в целевой OU.","2. Добавляет контролируемую учётную запись в выбранную группу.","3. Получает полномочия, предоставляемые членством в ней.","4. При необходимости позже удаляет своё членство, пытаясь скрыть следы."],"remediation":["Уберите право member у неуполномоченных субъектов.","Размещайте критичные группы в защищённых OU.","Отслеживайте события 4728, 4732, 4756 и наследование разрешений."]},"OU_PERM_KEYCREDENTIALLINK_WRITE":{"description":"Субъект может изменять msDS-KeyCredentialLink у записей пользователей или компьютеров в OU. Это создаёт возможность Shadow Credentials: добавить собственный ключ и использовать PKINIT для аутентификации без знания пароля. Для атаки требуются соответствующие условия PKINIT.","impact":["Возможна аутентификация от имени пользователей и компьютеров внутри OU без знания и изменения их пароля.","На объекте компьютера это может дать билет машинной записи; при соответствующих условиях S4U2Self создаёт путь к административному доступу к машине.","Добавленный ключ сохраняет доступ через обычные сбросы пароля, поскольку представляет отдельный материал аутентификации.","Для PKINIT требуется контроллер домена с подходящим сертификатом — как обычно в средах AD CS или Windows Hello for Business."],"attack":["1. Нарушитель добавляет собственный ключ в msDS-KeyCredentialLink целевой записи (например, Whisker, pyWhisker, Certipy shadow).","2. С помощью закрытого ключа запрашивает TGT для цели через PKINIT.","3. Использует билет напрямую либо при соответствующих условиях восстанавливает NT-хеш из PAC (UnPAC-the-hash).","4. При необходимости оставляет ключ как отдельный скрытый способ дальнейшего входа."],"remediation":["Удалите избыточную запись msDS-KeyCredentialLink для субъектов, не относящихся к штатным Key Admins, Enterprise Key Admins и допустимым владельцам соответствующей записи.","Проверьте msDS-KeyCredentialLink пользователей и компьютеров в этой OU на необъяснимые ключи.","Отслеживайте изменения msDS-KeyCredentialLink (событие 5136).","Если находка указывает наследуемый ACE, исправьте источник разрешения на родительском объекте. Альтернатива SetAccessRuleProtection разрывает наследование сразу всех ACE OU и требует анализа последствий для остальных делегирований."]},"OU_PERM_PASSWORD_RESET":{"description":"На OU делегировано расширенное право User-Force-Change-Password («Сброс пароля»). Оно позволяет назначать новый пароль учётным записям в области действия без знания прежнего значения.","impact":["Возможен захват пользовательских записей.","Если затронуты административные записи, последствия могут распространяться на Tier 0."],"attack":["1. Нарушитель выявляет субъект с разрешением сброса пароля.","2. Меняет пароль целевого пользователя, например участника Domain Admins.","3. Выполняет вход от имени цели с новым паролем.","4. Использует полученные полномочия для повышения привилегий."],"remediation":["Оставьте право уполномоченным операторам поддержки и отделите привилегированные записи.","Проверяйте унаследованные права, AdminSDHolder и события сброса пароля 4724."]},"KERBEROAST_WITHOUT_PREAUTH":{"description":"При наличии записи без предварительной проверки подлинности злоумышленник может запросить билеты служб других учётных записей с SPN без собственных доменных учётных данных.","impact":["Все доступные для Kerberoasting служебные записи оказываются под повышенным риском."],"attack":["1. Нарушитель узнаёт имя записи без предварительной проверки Kerberos и имена записей со SPN.","2. Отправляет AS-REQ от имени первой записи с указанием в sname одной из записей со SPN (например, Rubeus kerberoast /nopreauth или impacket GetUserSPNs -no-preauth).","3. Подбирает пароль по полученному служебному билету автономно, как при обычном Kerberoasting."],"remediation":["Включите предварительную проверку подлинности для всех записей и применяйте gMSA или длинные случайные пароли для служб."]},"KERBEROS_HASH_CRACKABLE":{"description":"Выделенный из билета Kerberos материал допускает автономную проверку вариантов пароля без новых обращений к контроллеру домена.","impact":["Подобранный пароль может дать доступ от имени соответствующей учётной записи."],"attack":["1. Сохраняет полученный хеш в файл (например, hash.txt).","2. Определяет тип хеша: Kerberoast — режимы 13100/18200/19600/19700; AS-REP — режим 18200.","3. Запускает Hashcat со словарём и правилами подбора.","4. Дожидается результата автономного подбора пароля.","5. Использует восстановленный пароль для входа от имени служебной записи."],"remediation":["Смените слабые пароли, применяйте AES и управляемые учётные записи служб."]},"GUEST_ACCOUNT_ENABLED":{"description":"Встроенная запись «Гость» (RID 501) активна и может предоставлять ненужную возможность доступа.","impact":["Дополнительная точка входа и риск анонимного или слабоконтролируемого доступа."],"attack":[],"remediation":["Отключите встроенную запись «Гость» и проверьте членство в группах и явные разрешения."]},"UNCONSTRAINED_DELEGATION_EXPOSED_ACCOUNTS":{"description":"Привилегированные учётные записи могут передавать билеты TGT компьютерам с неограниченным делегированием.","impact":["Компрометация такого компьютера создаёт риск захвата привилегированных сеансов."],"attack":["1. Нарушитель получает административный контроль над узлом с неограниченным делегированием.","2. Ожидает или инициирует Kerberos-вход одной из перечисленных записей на этот узел.","3. Извлекает пересланный TGT из памяти (например, Rubeus monitor или Mimikatz sekurlsa::tickets).","4. Использует TGT для действий от имени этой записи."],"remediation":["Ограничьте делегирование и пометьте критические записи как конфиденциальные, не допускающие делегирования."]},"CONSTRAINED_DELEGATION_PROTOCOL_TRANSITION":{"description":"Разрешено ограниченное делегирование с переходом протокола (S4U). При неверных границах доверия это может позволить выдавать себя за других пользователей при доступе к разрешённым службам.","impact":["Возможна подмена контекста пользователя на службе назначения."],"attack":["1. Нарушитель компрометирует запись службы с разрешённым переходом протокола.","2. Через S4U2Self получает служебный билет от имени выбранного пользователя.","3. Через S4U2Proxy получает доступ к настроенным целевым службам от имени этого пользователя.","4. Если среди целей есть LDAP, выполняет доступные привилегированные операции в AD."],"remediation":["Проверьте список служб msDS-AllowedToDelegateTo, учётную запись службы и необходимость перехода протокола."]},"RBCD_DANGEROUS_PRINCIPALS":{"description":"Разрешения на ограниченное делегирование на основе ресурса (RBCD) предоставлены субъектам, не соответствующим ожидаемой модели доверия.","impact":["Субъект с соответствующими полномочиями может получать доступ к ресурсу от имени других пользователей."],"attack":["1. Нарушитель находит компьютеры с ошибочной настройкой делегирования RBCD.","2. Компрометирует субъект из списка разрешённых или создаёт контролируемый субъект, получающий такое разрешение.","3. Использует S4U2Self и S4U2Proxy для получения служебного билета от имени выбранного пользователя.","4. Применяет билет для доступа к целевому компьютеру от имени администратора домена."],"remediation":["Ограничьте значения msDS-AllowedToActOnBehalfOfOtherIdentity только доверенными службами и контролируйте ACL объекта компьютера."]},"ESC1_TEMPLATE":{"description":"Шаблон сертификата позволяет заявителю самостоятельно указать Subject Alternative Name (SAN) и разрешает EKU Client Authentication. При доступном праве регистрации и соответствующих условиях проверки сертификата заявитель может запросить сертификат на чужое имя, в том числе участника Domain Admins. Следует оценивать оба флага задания Subject и SAN, а также фактические требования ЦС.","impact":["Пользователь с правом регистрации при уязвимой конфигурации способен выдать себя за другого пользователя домена.","Возможно быстрое повышение привилегий вплоть до Domain Admins.","Сертификат действует в течение срока, установленного шаблоном (нередко один-два года).","Пароль целевой записи не требуется: сертификатная аутентификация не зависит от её парольной политики."],"attack":["1. Нарушитель запрашивает сертификат по уязвимому шаблону.","2. Указывает UPN участника Domain Admins в поле Subject Alternative Name (SAN).","3. Использует полученный сертификат для аутентификации PKINIT от имени администратора домена.","4. Выполняет операции с привилегиями этого администратора в домене."],"remediation":["Отключите оба флага задания имени заявителем: CT_FLAG_ENROLLEE_SUPPLIES_SUBJECT (0x1) и CT_FLAG_ENROLLEE_SUPPLIES_SUBJECT_ALT_NAME (0x10000). Даже второй флаг сам по себе позволяет задать чужой UPN в SAN — ключевое условие ESC1.","Учитывайте совместимость: изменение сломает процессы, где клиент сам задаёт Subject или SAN, прежде всего выдачу серверных веб-сертификатов. Подготовьте заменяющий шаблон до отключения флагов.","Требуйте одобрения заявок администратором центра сертификации (CA Manager Approval).","Ограничьте разрешения на регистрацию сертификата конкретными необходимыми группами.","Допускайте параметр «Supply in the request» только при обоснованной необходимости и дополнительных ограничениях."]},"ESC2_TEMPLATE":{"description":"Шаблон AD CS допускает сертификаты для широкого набора назначений, включая Any Purpose или SubCA, при потенциально небезопасных правах регистрации.","impact":["Возможна выдача сертификатов с чрезмерно широкими возможностями использования."],"attack":["1. Нарушитель запрашивает сертификат по шаблону Any Purpose или SubCA.","2. Для SubCA: выпускает сертификаты от имени произвольных пользователей.","3. Для Any Purpose: использует сертификат для проверки подлинности клиента от имени целевого пользователя.","4. Обходит предусмотренные ограничения доступа, основанные на сертификатах."],"remediation":["Сузьте EKU и права регистрации; выдавайте такие сертификаты только после административного одобрения."]},"ESC3_TEMPLATE":{"description":"Шаблон выдаёт сертификаты агента запросов, позволяющие подавать запросы от имени других пользователей при наличии соответствующей конфигурации.","impact":["Ошибки прав на агентский шаблон могут привести к выдаче чужих удостоверений."],"attack":["1. Нарушитель запрашивает сертификат агента запросов (Certificate Request Agent).","2. Использует сертификат агента для подачи заявок на сертификаты от имени других пользователей.","3. Получает сертификат для участника Domain Admins либо другой привилегированной записи.","4. Проходит проверку подлинности с полученным сертификатом."],"remediation":["Ограничьте регистрацию сертификатов агента и настройте политики уполномоченных агентов."]},"ESC4_TEMPLATE":{"description":"На шаблоне AD CS присутствуют разрешения, позволяющие неподходящим субъектам изменять его параметры или список управления доступом.","impact":["Изменение шаблона может создать опасный сценарий регистрации сертификата."],"attack":["1. Нарушитель находит шаблон сертификата с разрешениями на его изменение.","2. Изменяет шаблон, разрешая ENROLLEE_SUPPLIES_SUBJECT.","3. При необходимости добавляет EKU Client Authentication.","4. Запрашивает сертификат с SAN административной учётной записи домена.","5. Проходит аутентификацию от имени администратора домена."],"remediation":["Удалите избыточные WriteDACL, WriteOwner, GenericAll и права изменения параметров шаблона."]},"ESC5_PKI_CONTAINER_ACL":{"description":"Контейнеры PKI в Active Directory имеют опасные разрешения на изменение доверенной инфраструктуры.","impact":["Нарушитель с нужными правами может создать новый шаблон с условиями ESC1.","Может сделать существующий безопасный шаблон уязвимым, изменив его настройки.","Может назначить себе право регистрации сертификатов по произвольному шаблону, которым способен управлять.","Может изменить хранилище NTAuth и добавить доверие к постороннему ЦС при наличии соответствующих прав.","В крайнем случае возникает риск полного контроля над инфраструктурой PKI."],"attack":["1. Нарушитель выявляет опасные права (GenericAll, WriteDACL, WriteOwner) на контейнерах PKI.","2. Создаёт шаблон сертификата с уязвимыми условиями ESC1.","3. Выдаёт право регистрации сертификатов контролируемой учётной записи.","4. Запрашивает сертификат с произвольным SAN, например UPN администратора домена.","5. Применяет сертификат для аутентификации и повышения привилегий."],"remediation":["Проверьте ACL всех объектов контейнеров PKI в Active Directory.","Отзовите GenericAll, WriteDACL и WriteOwner у непривилегированных субъектов.","Оставьте права записи только соответствующим администраторам домена/леса и специализированным администраторам PKI.","Ключевые контейнеры для проверки:","— CN=Public Key Services,CN=Services,CN=Configuration,DC=...","— CN=Certificate Templates,CN=Public Key Services,...","— CN=Enrollment Services,CN=Public Key Services,...","— CN=NTAuthCertificates,CN=Public Key Services,...","— CN=OID,CN=Public Key Services,...","Проверьте существующие шаблоны на несанкционированные изменения."]},"ESC8_WEB_ENROLLMENT":{"description":"На центре сертификации включена веб-регистрация сертификатов без подтверждённой защиты EPA (Extended Protection for Authentication). При реально отсутствующей EPA возможна ретрансляция NTLM на веб-интерфейс ЦС и выпуск сертификата от имени переданной учётной записи. Важно: статус [EPA: Undetermined] означает, что проверочный запрос adPEAS со случайными учётными данными был отклонён; это происходит как при включённой, так и при отключённой EPA. До вывода о возможности ретрансляции необходимо проверить параметр IIS tokenChecking.","impact":["NTLM-аутентификация может ретранслироваться к службе регистрации сертификатов при отсутствии требуемой EPA.","Ретранслированная аутентификация машинной записи контроллера домена может привести к получению сертификата DC.","При дополнительных условиях сертификат контроллера домена способен создать путь к DCSync и компрометации домена.","Для ретрансляции не обязательно знать пароль: достаточно соответствующего сетевого положения и возможности инициировать аутентификацию."],"attack":["1. Нарушитель вызывает аутентификацию контроллера домена (например, через PetitPotam или PrinterBug).","2. Ретранслирует NTLM-аутентификацию контроллера на веб-службу регистрации сертификатов ЦС.","3. Запрашивает сертификат машинной учётной записи контроллера домена.","4. Использует сертификат для выполнения DCSync.","5. Получает учётные данные домена."],"remediation":["Включите Extended Protection for Authentication (EPA) на IIS и подтвердите параметр tokenChecking.","Отключите NTLM-аутентификацию на веб-регистрации ЦС, если это совместимо с используемыми клиентами.","По возможности требуйте аутентификацию Kerberos для регистрации сертификатов.","Отключите веб-регистрацию сертификатов, если она не используется.","Включите обязательную подпись LDAP и LDAP Channel Binding на контроллерах домена."]},"LDAP_ANONYMOUS_BINDING_ALLOWED":{"description":"Некоторые операции LDAP доступны без проверки подлинности.","impact":["Анонимный доступ может раскрывать сведения о структуре домена и учётных записях."],"attack":[],"remediation":["Ограничьте анонимные LDAP-запросы, если они не требуются подтверждённым приложениям."]},"DANGEROUS_ACL_DCSYNC_BROAD":{"description":"Права DCSync назначены группе с широким составом участников.","impact":["Члены группы могут получить доступ к реплицируемым секретам при наличии необходимых прав."],"attack":["1. Нарушитель аутентифицируется как любой, даже непривилегированный пользователь домена.","2. Обнаруживает права репликации, предоставленные группе, в которую его запись уже входит.","3. Выполняет DCSync на контроллере домена и получает все хеши, включая krbtgt.","4. Подделывает Golden Ticket; простой сброс остальных паролей не отменит его без двух смен пароля krbtgt."],"remediation":["Отзовите полномочия репликации у широких групп и проверьте фактический состав через вложенные группы."]},"OU_PERM_SPN_WRITE":{"description":"Субъект может изменять servicePrincipalName у объектов в OU.","impact":["Изменение SPN может создать условия для злоупотребления Kerberos и атаки Kerberoasting."],"attack":["1. Нарушитель добавляет SPN привилегированной учётной записи целевого пользователя.","2. Запрашивает билет TGS для нового SPN (Kerberoasting).","3. Получает билет, зашифрованный ключом, производным от пароля пользователя.","4. Подбирает пароль автономно.","5. При необходимости удаляет SPN, чтобы скрыть следы."],"remediation":["Пересмотрите делегирование WriteProperty на servicePrincipalName и права наследования OU."]},"GPO_DANGEROUS_PERMISSIONS":{"description":"Обнаружены разрешения на изменение объекта групповой политики, предоставленные субъектам вне ожидаемого административного круга.","impact":["Изменение GPO может затронуть пользователей и компьютеры в области её действия."],"attack":["1. Нарушитель выявляет GPO с разрешением на запись.","2. Изменяет GPO, добавляя вредоносное запланированное задание либо сценарий запуска.","3. Ожидает обновления групповых политик (либо инициирует его через gpupdate).","4. Вредоносный код исполняется на всех затронутых компьютерах.","5. Если среди целей есть контроллеры домена, возможен захват домена."],"remediation":["Пересмотрите права изменения GPO и связанные разрешения на каталог SYSVOL."]},"GPO_SYSVOL_GPT_MISSING":{"description":"У объекта групповой политики отсутствует соответствующая папка SYSVOL или файл gpt.ini.","impact":["Политика может применяться неполностью или некорректно."],"attack":[],"remediation":["Проверьте репликацию SYSVOL и согласованность данных AD и файлов групповой политики."]},"GPO_NON_DEFAULT_OWNER":{"description":"У объекта GPO назначен владелец, отличный от ожидаемого.","impact":["Владелец может влиять на разрешения объекта даже без явного права изменения его настроек."],"attack":["1. Выявляет GPO, владелец которой уже контролируется нарушителем или может быть им скомпрометирован.","2. Как владелец добавляет ACE с полным доступом; отдельное уже существующее разрешение для этого не требуется.","3. Изменяет содержимое политики: сценарии, запланированные задания, Group Policy Preferences или реестр.","4. При следующем обновлении полезная нагрузка выполняется на всех компьютерах в области GPO."],"remediation":["Проверьте происхождение владельца и восстановите штатное владение при отсутствии обоснования."]},"LAPS_NOT_DEPLOYED":{"description":"Для части инфраструктуры не обнаружено управление паролями локальных администраторов с помощью LAPS.","impact":["Повторяющиеся или неизменяемые локальные пароли повышают риск бокового перемещения."],"attack":[],"remediation":["Внедрите Windows LAPS и проверьте политику хранения, прав чтения и ротации паролей."]},"LAPS_PASSWORD_READABLE":{"description":"Текущему субъекту или указанной группе доступны пароли локальных администраторов, сохраняемые LAPS.","impact":["Обладатель разрешения может получить административный доступ к соответствующему компьютеру."],"attack":["1. Нарушитель определяет компьютеры, для которых ему разрешено читать пароль LAPS.","2. Читает атрибут ms-Mcs-AdmPwd или msLAPS-Password.","3. Использует пароль для получения доступа локального администратора.","4. Извлекает учётные данные из памяти для последующих атак."],"remediation":["Ограничьте чтение атрибутов LAPS и регулярно проверяйте делегирование на OU."]},"BITLOCKER_KEY_READABLE":{"description":"Обнаружен доступ к сведениям восстановления BitLocker в Active Directory.","impact":["Доступ к ключу восстановления может позволить расшифровать защищённый том."],"attack":["1. Проверяет, каким субъектам разрешено читать msFVE-RecoveryPassword объектов компьютеров.","2. Обладатель 48-значного ключа может разблокировать BitLocker при физическом доступе к устройству либо к образу диска.","3. Подтверждает, что право чтения ограничено утверждёнными субъектами восстановления и технической поддержки."],"remediation":["Ограничьте чтение данных восстановления BitLocker уполномоченным администраторам и журналируйте доступ."]},"REVERSIBLE_ENCRYPTION":{"description":"Пароль учётной записи хранится с использованием обратимого шифрования.","impact":["Такая настройка ослабляет защиту парольных данных при компрометации хранилища."],"attack":["1. Нарушитель выполняет DCSync либо получает базу NTDS.dit.","2. С помощью DSInternals расшифровывает пароли, сохранённые с обратимым шифрованием.","3. Получает фактический пароль в открытом виде.","4. Использует пароль для аутентификации или следующих атак."],"remediation":["Отключите обратимое шифрование и измените пароль после корректировки параметра."]},"CREDENTIAL_IN_DESCRIPTION":{"description":"В свободно заполняемом атрибуте объекта обнаружено содержимое, похожее на учётные данные.","impact":["Читающий атрибут субъект может получить доступ к секрету."],"attack":["1. Нарушитель запрашивает в AD объекты с непустыми атрибутами description/info.","2. Ищет в них шаблоны указания пароля (pass=, pwd:, password и подобные).","3. Проверяет обнаруженные учётные данные на учётных записях.","4. Применяет действительные данные для доступа либо повышения привилегий."],"remediation":["Удалите секрет из атрибута, смените затронутые учётные данные и используйте защищённое хранилище."]},"CREDENTIAL_GPP_PASSWORD":{"description":"В предпочтениях групповой политики обнаружены параметры, потенциально раскрывающие пароль.","impact":["Чтение файлов GPP может позволить восстановить секрет и скомпрометировать учётную запись."],"attack":["1. Нарушитель читает SYSVOL, доступный обычным пользователям домена, либо общую папку с копией GPO, например резервной.","2. Ищет файлы Groups.xml, ScheduledTasks.xml, Services.xml и аналогичные.","3. Извлекает из XML атрибут cpassword.","4. Расшифровывает пароль с помощью публично известного ключа AES.","5. Использует учётные данные для бокового перемещения или повышения привилегий."],"remediation":["Удалите сохранённые секреты из GPP, смените пароли и применяйте современные механизмы управления учётными данными."]},"CREDENTIAL_SCRIPT_PASSWORD":{"description":"В содержимом доступного сценария обнаружен пароль или похожий секрет.","impact":["Субъект с правом чтения файла может использовать обнаруженные учётные данные."],"attack":["1. Нарушитель ищет типовые шаблоны паролей в SYSVOL, NETLOGON и доступных для чтения общих ресурсах.","2. Анализирует сценарии на наличие встроенных учётных данных.","3. Выясняет их назначение: база данных, служба или администратор.","4. Использует найденные данные для доступа к ресурсу либо системе."],"remediation":["Удалите секрет из сценария и переместите его в защищённое хранилище; смените обнаруженный пароль."]},"RBCD_CONFIGURED":{"description":"Для объекта настроено ограниченное делегирование Kerberos на основе ресурса (RBCD).","impact":["Настройка безопасна только при корректно ограниченном перечне доверенных субъектов."],"attack":["1. Нарушитель получает управление субъектом, указанным в дескрипторе RBCD, либо право записи этого атрибута, которым располагает владелец объекта.","2. Запрашивает служебный билет к ресурсу от имени выбранной записи (S4U2Self, затем S4U2Proxy).","3. Использует билет для доступа к ресурсу от имени этой записи."],"remediation":["Проверьте msDS-AllowedToActOnBehalfOfOtherIdentity и соответствие настроек реальной архитектуре."]},"TRUST_SID_FILTERING_DISABLED":{"description":"На доверительных отношениях отключена фильтрация SID.","impact":["SID из внешних областей доверия могут влиять на вычисление прав в ресурсном домене."],"attack":["1. Нарушитель компрометирует запись в доверенном домене.","2. Добавляет SID группы Domain Admins доверяющего домена в sIDHistory контролируемой записи.","3. Проходит аутентификацию через доверительные отношения с добавленным SID.","4. Получает полномочия Domain Admins в доверяющем домене."],"remediation":["Включите подходящие режимы SID Filtering и согласуйте исключения с архитектурой доверия."]},"WEAK_FGPP":{"description":"Тонкая политика паролей задаёт менее строгие параметры, чем доменная политика по умолчанию.","impact":["Затронутые пользователи и группы могут иметь более слабые пароли или защиту от перебора."],"attack":[],"remediation":["Сопоставьте приоритеты FGPP, область применения и требования безопасности; скорректируйте ослабленные параметры."]},"LAPS_GPO_DISABLED":{"description":"Групповая политика отключает или не активирует механизмы управления локальными паролями LAPS.","impact":["Локальный административный пароль может оставаться неизменным."],"attack":[],"remediation":["Исправьте политику Windows LAPS и проверьте фактическое применение на целевых компьютерах."]},"SYSVOL_FRS_REPLICATION":{"description":"Репликация SYSVOL всё ещё использует устаревшую службу FRS.","impact":["FRS усложняет поддержку и обновление контроллеров домена; возможны проблемы согласованности политик."],"attack":[],"remediation":["Проведите подготовленную миграцию репликации SYSVOL на DFSR согласно документации Microsoft."]},"OLD_FUNCTIONAL_LEVEL":{"description":"Функциональный уровень домена или леса устарел.","impact":["Могут быть недоступны современные возможности и механизмы защиты AD."],"attack":[],"remediation":["Проверьте совместимость всех контроллеров и приложений, после чего рассмотрите повышение функционального уровня."]},"GPO_POINTANDPRINT_EXPLOITABLE":{"description":"Параметры Point and Print позволяют устанавливать драйверы принтеров без необходимого административного подтверждения.","impact":["При определённых условиях возможен запуск кода с повышенными привилегиями (семейство PrintNightmare)."],"attack":["1. Разворачивает сервер печати с вредоносным драйвером принтера.","2. Добивается подключения компьютера из области действия политики к общему принтеру (Point and Print).","3. Драйвер устанавливается без запроса, а его код выполняется от SYSTEM."],"remediation":["Ограничьте серверы печати, требуйте повышение привилегий и примените современные параметры защиты Point and Print."]},"REGISTRY_WDIGEST":{"description":"Политика допускает сохранение учётных данных WDigest в памяти в открытом виде.","impact":["Компрометация компьютера может раскрыть пароли вошедших пользователей."],"attack":[],"remediation":["Отключите хранение паролей WDigest в открытом виде и проверьте соответствующий параметр реестра."]},"REGISTRY_LLMNR_ON":{"description":"Многоадресное разрешение имён LLMNR разрешено политикой.","impact":["LLMNR может упрощать перехват или ретрансляцию аутентификации в локальной сети."],"attack":[],"remediation":["Отключите LLMNR там, где он не требуется, и обеспечьте корректное разрешение имён DNS."]},"REGISTRY_RDP_NLA":{"description":"Политика отключает проверку подлинности на уровне сети для RDP.","impact":["Служба RDP становится доступна до полноценной проверки подлинности пользователя."],"attack":[],"remediation":["Включите Network Level Authentication для RDP и ограничьте сетевой доступ к службе."]},"REGISTRY_SMB1_SERVER":{"description":"На сервере включён устаревший протокол SMBv1.","impact":["Устаревший протокол повышает риск эксплуатации известных уязвимостей и ошибок безопасности."],"attack":[],"remediation":["Отключите SMBv1 после проверки совместимости зависимых систем."]},"REGISTRY_FIREWALL_DISABLED":{"description":"Групповая политика отключает брандмауэр Windows.","impact":["Сетевые службы могут оказаться доступнее, чем предусмотрено политикой безопасности."],"attack":[],"remediation":["Включите профиль брандмауэра и настройте необходимые правила разрешения трафика."]},"REGISTRY_CREDGUARD":{"description":"Через групповую политику явно отключена защита Credential Guard.","impact":["Снижается защищённость секретов проверок подлинности на конечном устройстве."],"attack":[],"remediation":["Проверьте совместимость оборудования и включите Credential Guard для соответствующих систем."]},"GUEST_ACCOUNT_DISABLED":{"description":"Встроенная учётная запись «Гость» (RID 501) отключена. Это сокращает возможности несанкционированного входа с использованием общей учётной записи.","impact":["Отсутствует дополнительная точка входа через стандартную гостевую учётную запись."],"attack":[],"remediation":["Сохраняйте учётную запись отключённой и контролируйте её состояние через утверждённые политики."]},"UNCONSTRAINED_DELEGATION_DC":{"description":"Контроллер домена использует неограниченное делегирование Kerberos, что является особым штатным случаем для функций домена. Само по себе это не эквивалентно ошибке делегирования на обычном сервере.","impact":["Компрометация контроллера домена затрагивает критическую инфраструктуру аутентификации; вывод необходимо интерпретировать с учётом роли DC."],"attack":[],"remediation":["Не отключайте делегирование на DC без проверки зависимостей; обеспечьте защиту контроллеров домена как систем Tier 0."]},"GPO_NOT_CURRENTLY_EFFECTIVE":{"description":"Обнаруженная настройка содержится в объекте групповой политики, но в момент аудита не считается действующей для соответствующей области.","impact":["Неактивная настройка не обязательно влияет на текущие компьютеры или пользователей, однако может вступить в силу при изменении привязок GPO."],"attack":["1. Настройка остаётся неактивной и о ней забывают.","2. Кто-то по другой причине привязывает GPO либо повторно включает отключённую часть.","3. Настройка начинает действовать на всех компьютерах в области политики, хотя никто не проверял её последствия."],"remediation":["Проверьте привязку, состояние GPO, наследование и фильтры безопасности; контролируйте изменения области применения."]},"PRIVILEGED_ACCOUNT_AFFECTED":{"description":"Обнаруженный параметр затрагивает привилегированную учётную запись, права которой могут распространяться на критические объекты Active Directory.","impact":["Риск выше, чем для обычной записи, поскольку её компрометация может затронуть контроллеры домена и конфигурацию леса."],"attack":[],"remediation":["Определите фактические роли и доступ записи; применяйте изоляцию Tier 0, MFA и принцип минимально необходимых полномочий."]},"ROASTABLE_PRIVILEGED_ACCOUNT":{"description":"Привилегированная учётная запись имеет настройки, позволяющие получить материал Kerberos для автономного подбора пароля.","impact":["Подбор пароля может открыть доступ к административным полномочиям."],"attack":[],"remediation":["Исключите ненужные SPN и отсутствие предварительной проверки подлинности; применяйте gMSA и длинные случайные пароли."]},"CONSTRAINED_DELEGATION_TO_DC":{"description":"Указанной службе разрешено ограниченное делегирование Kerberos к службе на контроллере домена.","impact":["Компрометация делегирующей записи может затронуть защищённые операции, выполняемые от имени пользователя на DC."],"attack":["1. Нарушитель компрометирует учётную запись либо получает хеш её пароля.","2. Через S4U2Self получает билет для привилегированного пользователя; при разрешённом переходе протокола билет может быть перенаправляемым.","3. Через S4U2Proxy обменивает его на служебный билет к настроенному SPN контроллера домена.","4. Переписывает класс службы в билете на необходимый, например ldap или cifs.","5. Использует изменённый билет против контроллера домена, например для DCSync."],"remediation":["Проверьте msDS-AllowedToDelegateTo, необходимость делегирования и защиту учётной записи службы."]},"CONSTRAINED_DELEGATION_TRANSITION_NO_TARGET":{"description":"У службы обнаружен признак перехода протокола Kerberos, но явная цель ограниченного делегирования не определена.","impact":["Сам признак не доказывает возможность доступа к другому сервису; он требует проверки совместно с другими настройками делегирования."],"attack":["1. Нарушитель компрометирует учётную запись.","2. Через S4U2Self получает перенаправляемый билет, выдавая себя за привилегированного пользователя.","3. Предъявляет билет службе, которую размещает сама эта учётная запись.","4. При наличии права записи msDS-AllowedToDelegateTo добавляет любую выбранную целевую службу."],"remediation":["Сверьте userAccountControl и msDS-AllowedToDelegateTo с фактическим сценарием аутентификации."]},"ESC_ENROLLMENT_RIGHTS_UNREAD":{"description":"Права регистрации сертификатов для шаблона AD CS не удалось прочитать с учётными данными аудита.","impact":["Нельзя достоверно заключить, безопасен ли шаблон или кто может запросить сертификат."],"attack":["1. Само по себе это не атака: находка указывает на пробел в данных сканирования.","2. Это важно учитывать: нарушитель, уже контролирующий шаблон, может создать именно такое состояние, записав ACE с GENERIC_ALL.","3. Но и защищённый шаблон может дать такой результат — поэтому это подсказка (Hint), а не подтверждённая уязвимость."],"remediation":["Повторите чтение с учётной записью с разрешённым доступом и проверьте ACL шаблона и центра сертификации."]},"ESC3_TARGET_TEMPLATE":{"description":"Шаблон может участвовать в сценарии регистрации сертификата от имени другого субъекта, если разрешено использование агента запросов и отсутствуют достаточные ограничения.","impact":["Неправильное сочетание шаблонов агента и конечного сертификата создаёт риск выдачи сертификата для чужой учётной записи."],"attack":["1. Нарушитель получает сертификат агента регистрации (шаблон с условием ESC3 №1, украденный ключ либо законно выданный агентский сертификат).","2. Формирует запрос по этому шаблону, указывая привилегированную запись как субъект сертификата.","3. Дополнительно подписывает запрос сертификатом агента регистрации (полный запрос CMC PKI).","4. Центр сертификации выдаёт сертификат клиентской аутентификации для указанной записи.","5. Нарушитель аутентифицируется как эта запись через PKINIT."],"remediation":["Ограничьте EKU Certificate Request Agent, права регистрации, требования одобрения и допустимые целевые шаблоны."]},"ADCS_HTTP_AVAILABLE":{"description":"Веб-интерфейс регистрации сертификатов доступен по HTTP. При отсутствии дополнительных защит запросы могут передаваться без TLS.","impact":["В некоторых конфигурациях возможны перехват данных или атаки ретрансляции NTLM к веб-регистрации AD CS."],"attack":[],"remediation":["По возможности используйте HTTPS, Extended Protection for Authentication и ограничение NTLM; проверьте IIS и настройки AD CS."]},"ADCS_NONPRIV_ENROLLMENT":{"description":"Право регистрации сертификатов предоставлено непривилегированным пользователям или группам.","impact":["Риск зависит от EKU, возможности указания имени субъекта, одобрения заявки и дополнительных разрешений шаблона."],"attack":[],"remediation":["Ограничьте регистрацию действительно необходимыми группами и проверьте сочетания настроек шаблона, создающие ESC-риски."]},"ADCS_CLIENT_AUTH_EKU":{"description":"Шаблон допускает расширенное назначение ключа Client Authentication (EKU). Это само по себе не является уязвимостью.","impact":["При неверных правах регистрации и настройках имени субъекта сертификат может использоваться для нежелательной проверки подлинности."],"attack":[],"remediation":["Проверьте EKU совместно с правами Enroll/Autoenroll, требованиями согласования и ограничениями имени субъекта."]},"ADCS_SMARTCARD_LOGON_EKU":{"description":"Шаблон допускает EKU Smart Card Logon, позволяющий применять сертификаты для доменной проверки подлинности при соответствующих условиях.","impact":["Опасность возникает в сочетании с широкими правами регистрации или возможностью указать чужую идентичность."],"attack":[],"remediation":["Проверьте соответствие выдачи сертификатов политике удостоверения личности и права регистрации."]},"DANGEROUS_ACL_GPO_WRITEPROPERTY_SCOPED":{"description":"Право WriteProperty ограничено определённым атрибутом GPO, который сам по себе не управляет применяемым содержимым политики.","impact":["Такое разрешение нельзя приравнивать к полному контролю GPO; значимость зависит от конкретного атрибута."],"attack":["1. Прочитать, на какой атрибут распространяется ACE: его имя указано в находке.","2. Оценить, чем управляет этот отдельный атрибут объекта groupPolicyContainer.","3. Если это gPCWQLFilter, привязать GPO к WMI-фильтру, возвращающему FALSE на компьютерах, которые нарушитель хочет исключить из области политики."],"remediation":["Сохраните точный ObjectType ACE в аудите и оцените, требуется ли делегировать запись этого свойства."]},"DANGEROUS_ACL_GPO_EXTENDED":{"description":"На объект GPO назначено разрешение Self либо ExtendedRight. Его фактическое действие зависит от ограничений ACE и конкретного объекта.","impact":["Без анализа GUID прав нельзя считать разрешение равным полному контролю над GPO."],"attack":["Непосредственно прочитать GUID ObjectType у ACE, определить, какое конкретно право проверенной записи или расширенное право предоставлено, и отдельно оценить последствия именно этого разрешения."],"remediation":["Проверьте ObjectType, область действия и необходимость делегирования конкретной операции."]},"GPO_SYSVOL_FOLDER_ORPHANED":{"description":"В SYSVOL обнаружена папка групповой политики, которой не соответствует актуальный объект GPO в каталоге.","impact":["Осиротевшая папка может содержать устаревшие сценарии, настройки или лишние доступные файлы."],"attack":[],"remediation":["Сопоставьте GUID папки с объектами GPO, проверьте репликацию SYSVOL и удаляйте содержимое только после резервного копирования."]},"DOMAIN_ROOT_SID_HISTORY_WRITE":{"description":"На объекте домена делегировано право, связанное с переносом SIDHistory.","impact":["При сочетании с другими необходимыми условиями некорректное делегирование может ослаблять границы доверия учётных записей."],"attack":["1. Нарушитель располагает правом Migrate-SID-History на объекте домена.","2. Создаёт контролируемую запись либо использует имеющуюся.","3. Записывает SID группы Domain Admins или записи Administrator в её sIDHistory.","4. Проходит вход и получает соответствующие привилегии без прямого членства в группе."],"remediation":["Проверьте разрешения, процедуры миграции и аудирование изменений sIDHistory."]},"DOMAIN_ROOT_REPLICA_INSTALL":{"description":"Предоставлено право DS-Install-Replica, применяемое при установке дополнительных реплик каталога.","impact":["Неверное делегирование этого права требует оценки вместе с другими разрешениями на установку DC."],"attack":["1. Нарушитель располагает правом DS-Install-Replica на объекте домена.","2. Повышает управляемую машину до реплики домена.","3. Получает раздел каталога с секретами без необходимости в отдельном праве DCSync.","4. Выводит реплику из эксплуатации; остаётся внешне обычное событие репликации."],"remediation":["Ограничьте право доверенными административными ролями и проверьте необходимость."]},"CRITICAL_OBJECT_CONTROL":{"description":"Обнаружены права изменения критических объектов конфигурации AD, схемы, разделов, ролей или сайтов.","impact":["Неправомерное изменение этих объектов может затронуть весь лес или несколько доменов."],"attack":["1. Нарушитель получает контроль над указанным субъектом.","2. Использует его право на объект: изменяет DACL, схему либо fSMORoleOwner с соответствующим правом передачи роли.","3. Сохраняет изменение, пока кто-либо не сравнит объект с его исходным состоянием."],"remediation":["Сопоставьте ACL с моделью Tier 0; разрешайте запись только установленным административным ролям."]},"RODC_PRIVILEGED_PASSWORD_ALLOWED":{"description":"Политика репликации паролей контроллера домена только для чтения допускает кэширование паролей привилегированных субъектов.","impact":["При компрометации RODC кэшированные секреты могут быть раскрыты."],"attack":[],"remediation":["Запретите репликацию секретов административных групп и проверьте фактическую политику PRP."]},"RODC_PRIVILEGED_PASSWORD_REVEALED":{"description":"На RODC уже кэшированы секреты субъектов с повышенными полномочиями.","impact":["Компрометация этого контроллера может раскрыть данные, требующие замены учётных данных."],"attack":[],"remediation":["Проверьте Revealed List, запретите дальнейшее кэширование и выполните реагирование по процедуре для затронутых записей."]},"RODC_DENIED_GROUP_MISSING":{"description":"Ожидаемая группа защищаемых субъектов отсутствует в списке запрета кэширования паролей RODC.","impact":["Секреты этих субъектов могут оказаться разрешёнными к кэшированию при других условиях PRP."],"attack":[],"remediation":["Проверьте Denied RODC Password Replication Group и итоговые разрешения репликации."]},"DOMAIN_ROOT_MAQ_WRITE":{"description":"Субъект имеет право изменять атрибут ms-DS-MachineAccountQuota, задающий лимит создания компьютеров обычными пользователями.","impact":["Изменение квоты может расширить возможность создавать компьютерные учётные записи и использовать их в цепочках атак."],"attack":["1. Нарушитель имеет право изменять ms-DS-MachineAccountQuota в объекте домена.","2. Увеличивает значение с 0 до ненулевого.","3. Создаёт учётную запись компьютера и контролирует её учётные данные.","4. Использует её как источник делегирования для RBCD против цели, на которую у него есть право записи."],"remediation":["Ограничьте запись на атрибут и согласуйте допустимую квоту с моделью управления компьютерами."]},"OU_NON_DEFAULT_OWNER":{"description":"Организационная единица AD имеет владельца, отличающегося от обычной модели владения.","impact":["Владелец может обладать возможностью изменения разрешений на OU независимо от отдельных ACE."],"attack":[],"remediation":["Проверьте назначение владения, делегирование и необходимость изменения владельца."]},"DANGEROUS_ACL_BROAD_GROUP":{"description":"Опасные разрешения на объект AD предоставлены группе с широким составом участников.","impact":["Любой действующий участник группы может получить соответствующие полномочия в зависимости от ACL и области действия."],"attack":["1. Нарушитель проходит аутентификацию как любой пользователь домена.","2. Прямо использует предоставленное право, поскольку группа, которой оно назначено, уже включает эту учётную запись.","3. Если право — WriteDacl или WriteOwner, добавляет себе необходимые разрешения.","4. Затем может захватить домен."],"remediation":["Замените широкую группу специальной группой делегирования с минимальным членством."]},"SID_HISTORY_INJECTION":{"description":"В атрибуте sIDHistory содержится привилегированный SID, который требует подтверждения законности происхождения.","impact":["При ошибках фильтрации SID или доверительных отношений такой SID может давать нежелательные права."],"attack":[],"remediation":["Сверьте SID с историей миграции, настройками доверий и выполненными административными операциями."]},"SID_HISTORY_FOREIGN_PRIVILEGED":{"description":"В атрибуте sIDHistory содержится привилегированный SID из другого домена.","impact":["При неправильной настройке доверий и фильтрации SID он может влиять на авторизацию."],"attack":[],"remediation":["Проверьте доверительные отношения, SID filtering и документированное происхождение sIDHistory."]},"SID_HISTORY_ORPHANED":{"description":"В sIDHistory присутствует SID, который не удаётся сопоставить с ожидаемым доверенным источником.","impact":["Неопознанный SID затрудняет аудит прав и может указывать на ошибочную миграцию или нетипичное изменение."],"attack":[],"remediation":["Проверьте источник SID, доверия и журналы миграции, прежде чем удалять значения."]},"BITLOCKER_RECOVERY_DELEGATED":{"description":"Права чтения объектов с данными восстановления BitLocker делегированы дополнительному субъекту.","impact":["Такой доступ позволяет получить ключи восстановления дисков затронутых компьютеров."],"attack":["1. От имени субъекта с делегированным правом считывает msFVE-RecoveryPassword из объектов msFVE-RecoveryInformation под соответствующими компьютерами.","2. Получает диск одного из этих компьютеров либо образ диска.","3. Разблокирует том 48-значным паролем восстановления (manage-bde -unlock -RecoveryPassword либо dislocker).","4. Читает том автономно: секреты SAM и LSA, материал DPAPI, а на контроллере домена — ntds.dit."],"remediation":["Ограничьте чтение доверенным администраторам восстановления, включите аудит и контролируйте членство групп."]},"EXCHANGE_GROUP_LOW_PRIV_MEMBER":{"description":"В административной группе Exchange обнаружен участник с недостаточно обоснованными повышенными полномочиями.","impact":["Назначения Exchange и связанные с ними ACL AD могут расширять возможности управления каталога."],"attack":["1. Нарушитель компрометирует низкопривилегированную учётную запись.","2. Эта запись уже входит в служебную группу Exchange — ошибочная конфигурация.","3. Нарушитель использует разрешения группы Exchange для повышения привилегий.","4. Потенциально может сбрасывать пароли администраторов или изменять чувствительные атрибуты."],"remediation":["Проверьте ролевую модель Exchange, вложенные группы и реальную необходимость членства."]},"OU_PERM_WRITEPROPERTY_ALL":{"description":"На объектах в организационной единице обнаружено разрешение изменять все свойства объектов в области действия OU. Важны конкретные ObjectType ACE, наследование и фактический состав субъектов.","impact":["При неверном делегировании возможно неавторизованное изменение атрибутов пользователей или компьютеров."],"attack":[],"remediation":["Ограничьте WriteProperty набором действительно изменяемых атрибутов и соответствующих групп."]},"OU_PERM_USERACCOUNTCONTROL":{"description":"На объектах в организационной единице обнаружено право изменять userAccountControl у объектов в OU. Важны конкретные ObjectType ACE, наследование и фактический состав субъектов.","impact":["При неверном делегировании возможно смену состояния учётных записей или отдельных параметров аутентификации."],"attack":[],"remediation":["Проверьте наследуемые ACE и ограничьте запись userAccountControl."]},"OU_PERM_SCRIPTPATH":{"description":"На объектах в организационной единице обнаружено право изменять scriptPath. Важны конкретные ObjectType ACE, наследование и фактический состав субъектов.","impact":["При неверном делегировании возможно подмену выполняемого при входе сценария при наличии доступа к его расположению."],"attack":[],"remediation":["Ограничьте изменение scriptPath и контролируйте ACL хранилища сценариев."]},"OU_PERM_CONSTRAINED_DELEGATION":{"description":"На объектах в организационной единице обнаружено право изменять msDS-AllowedToDelegateTo. Важны конкретные ObjectType ACE, наследование и фактический состав субъектов.","impact":["При неверном делегировании возможно расширение списка служб, к которым разрешено делегирование Kerberos."],"attack":[],"remediation":["Ограничьте изменение целей делегирования и проверьте переход протокола."]},"OU_PERM_RBCD":{"description":"На объектах в организационной единице обнаружено право изменять msDS-AllowedToActOnBehalfOfOtherIdentity. Важны конкретные ObjectType ACE, наследование и фактический состав субъектов.","impact":["При неверном делегировании возможно нежелательное предоставление делегирования Kerberos на основе ресурса (RBCD)."],"attack":["1. Нарушитель создаёт контролируемую машинную запись либо получает доступ к существующей.","2. Изменяет атрибут msDS-AllowedToActOnBehalfOfOtherIdentity целевого объекта.","3. Добавляет управляемую запись в настройки RBCD.","4. Через S4U2Self/S4U2Proxy получает билет от имени администратора к целевому ресурсу.","5. Получает полный контроль над целевым ресурсом."],"remediation":["Ограничьте запись RBCD только доверенными администраторами объекта."]},"OU_PERM_LAPS_READ":{"description":"На объектах в организационной единице обнаружено право чтения паролей LAPS у компьютеров в OU. Важны конкретные ObjectType ACE, наследование и фактический состав субъектов.","impact":["При неверном делегировании возможно получение локальных административных секретов при действительном доступе."],"attack":["1. Нарушитель читает пароль LAPS из объекта компьютера.","2. Использует полученный пароль для локальной аутентификации на машине.","3. Получает полномочия локального администратора.","4. Может перейти на другие системы либо извлечь дополнительные учётные данные."],"remediation":["Проверьте ACL LAPS, конфиденциальные атрибуты и право расшифрования Windows LAPS."]},"OU_PERM_GENERICWRITE":{"description":"На объектах в организационной единице обнаружено право GenericWrite в области OU. Важны конкретные ObjectType ACE, наследование и фактический состав субъектов.","impact":["При неверном делегировании возможно несанкционированное изменение ряда свойств защищаемых объектов."],"attack":[],"remediation":["Проверьте объём ACE, наследование и минимальную достаточность разрешения."]},"OU_PERM_READALL":{"description":"На объектах в организационной единице обнаружено право чтения всех свойств объектов в OU. Важны конкретные ObjectType ACE, наследование и фактический состав субъектов.","impact":["При неверном делегировании возможно раскрытие данных, для которых атрибуты не имеют отдельных ограничений конфиденциальности."],"attack":[],"remediation":["Проверьте необходимость широкого чтения; отдельные конфиденциальные атрибуты могут требовать специальных прав."]},"GPO_USERRIGHT_SETCB":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право «Работа в режиме операционной системы» (SeTcbPrivilege) назначено через GPO». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Привилегия может позволить сформировать токен любой записи, включая участника Domain Admins, без знания её пароля или хеша.","Возможна выдача себя за SYSTEM либо другую локальную или доменную запись.","Последующие решения контроля доступа полагаются на предъявленный токен, поэтому злоупотребление привилегией нарушает фундаментальную границу доверия Windows."],"attack":["1. Проходит проверку подлинности от имени субъекта, которому выдано право.","2. Создаёт токен для целевой личности (например, посредством Incognito или Mimikatz).","3. Применяет токен в текущем процессе либо создаёт процесс с этим токеном."],"remediation":["Немедленно отзовите это право у неутверждённого субъекта: Windows по умолчанию не назначает SeTcbPrivilege никому, а дополнительное назначение чрезвычайно опасно.","Проверьте, по какой причине существует соответствующая GPO: правомерные основания назначения SeTcbPrivilege встречаются крайне редко."]},"GPO_USERRIGHT_SECREATETOKEN":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право «Создание объекта токена» (SeCreateTokenPrivilege) назначено через GPO». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"attack":["1. Проходит аутентификацию от имени владельца права.","2. Формирует токен с желаемым SID записи и SID групп (NtCreateToken).","3. Назначает токен новому или уже существующему процессу."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_SEIMPERSONATE":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право «Имитация клиента после проверки подлинности» (SeImpersonatePrivilege) выдано через GPO». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"attack":["1. Компрометирует запись, обладающую этим правом на целевой машине, либо уже управляет ею.","2. Побуждает клиент уровня SYSTEM подключиться (например, через подставной OXID Resolver или именованный канал).","3. Олицетворяет полученный токен и запускает процесс от имени SYSTEM."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_SESYNCAGENT":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право «Синхронизация данных службы каталогов» (SeSyncAgentPrivilege) выдано через GPO». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"attack":["1. Проходит проверку подлинности от имени обладателя права.","2. Запрашивает синхронизацию атрибутов целевого объекта каталога, включая значения, производные от пароля.","3. Извлекает полученный хеш-материал для автономного анализа."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_SEMANAGEVOLUME":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право обслуживания томов (SeManageVolumePrivilege) выдано через GPO». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"attack":["1. Проходит аутентификацию от имени обладателя права.","2. Открывает прямой доступ к тому с использованием предоставленной привилегии.","3. Читает физические секторы целевого файла, обходя блокировки и ACL, которые обычно применяет файловая система."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_SERELABEL":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право изменения метки объекта (SeRelabelPrivilege) выдано через GPO». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"attack":["1. Проходит проверку подлинности от имени обладателя права.","2. Изменяет метку уровня целостности в SACL целевого объекта с помощью этой привилегии.","3. Процесс, ранее ограниченный уровнем целостности, получает возможность чтения или записи объекта с изменённой меткой."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_SETRUSTEDCREDMANACCESS":{"description":"Одна или несколько групповых политик назначают право пользователя: «Доступ к диспетчеру учётных данных как доверенного вызывающего (SeTrustedCredManAccessPrivilege)». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"attack":["1. Проходит аутентификацию от имени обладателя привилегии.","2. Вызывает API резервного копирования Credential Manager с правом доверенного вызывающего.","3. Читает расшифрованное содержимое хранилища учётных данных."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_SEREMOTEINTERACTIVELOGON":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право входа через службы удалённых рабочих столов (SeRemoteInteractiveLogonRight) расширено через GPO». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"attack":["1. Получает учётные данные обладателя права (фишинг, распыление паролей или повторное использование).","2. Подключается по RDP к одной из машин, на которые распространяется GPO.","3. Работает в интерактивном сеансе от имени этой записи."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_SESERVICELOGON":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право входа в качестве службы (SeServiceLogonRight) назначено через GPO». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"attack":["1. Получает учётные данные обладателя права либо создаёт службу, настроенную на запуск от имени этой записи.","2. Регистрирует службу (например, sc.exe create или PsExec -r) для выполнения в данном контексте.","3. Запускает службу; она выполняется от имени указанной записи без интерактивного входа."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_SECREATESYMBOLICLINK":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право создания символических ссылок (SeCreateSymbolicLinkPrivilege) расширено через GPO». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"attack":["1. Получает учётные данные обладателя права и сеанс на целевой машине.","2. Находит привилегированный процесс, записывающий или удаляющий файлы в каталоге, где можно создать ссылку.","3. Создаёт там символическую ссылку на защищённый файл.","4. Привилегированный процесс выполняет операцию с файлом, на который указывает ссылка."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_SEDELEGATESESSIONUSERIMPERSONATE":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право получения токена другого пользователя в сеансе (SeDelegateSessionUserImpersonatePrivilege) выдано через GPO». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"attack":["1. Получает учётные данные обладателя права и сеанс на целевой машине.","2. Получает токен олицетворения другого пользователя в том же сеансе.","3. Выполняет действия от имени этого пользователя."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_SECREATEGLOBAL":{"description":"Одна или несколько групповых политик назначают право пользователя: «Право создания глобальных объектов (SeCreateGlobalPrivilege) расширено через GPO». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"attack":["1. Получает учётные данные обладателя права и сеанс на целевой машине.","2. Создаёт глобальный объект до того, как его откроет привилегированная служба.","3. Служба читает подготовленные субъектом данные либо переходит по созданной им ссылке."],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"GPO_USERRIGHT_DEFAULT_REMOVED":{"description":"Одна или несколько групповых политик назначают право пользователя: «Групповая политика исключает стандартного владельца права пользователя». Аудит сопоставляет назначенных субъектов и стандартные параметры Windows.","impact":["Чрезмерное назначение может расширять административные возможности или поверхность атаки; значимость зависит от конкретного права и системы назначения."],"attack":[],"remediation":["Проверьте действующую GPO и область применения, сопоставьте группы с базовой политикой безопасности Microsoft, уберите неутверждённые назначения."]},"UNREGISTERED_DOMAIN_CONTROLLER":{"description":"У компьютера присутствуют признаки роли контроллера домена, но соответствующий объект не подтверждён в перечне контроллеров домена Active Directory. Такое расхождение требует проверки регистрации и состояния машины.","impact":["Возможны ошибки инвентаризации, репликации либо следы нештатного развёртывания контроллера."],"attack":[],"remediation":["Сопоставьте объект компьютера с NTDS Settings, DNS-записями SRV и реальными контроллерами. Проверьте журнал развёртывания AD DS."]},"DOMAIN_ROOT_REANIMATE_TOMBSTONES":{"description":"На корневом объекте домена делегировано расширенное право Reanimate-Tombstones. Оно разрешает реанимировать удалённые объекты в пределах допустимого сценария восстановления.","impact":["Субъект может восстанавливать удалённые объекты и изменять ожидаемое состояние каталога при наличии дополнительных прав."],"attack":["1. Нарушитель обладает правом Reanimate-Tombstones на объекте домена.","2. Перечисляет удалённые объекты и выбирает доступный ему для записи объект с ценными SID, членствами или паролем.","3. Восстанавливает его в контейнер, где разрешено создавать объекты этого класса: одним изменением снимает isDeleted и задаёт новый DN.","4. Использует запись со старым паролем либо сбрасывает пароль, если это допускает её ACL."],"remediation":["Ограничьте разрешение администраторами восстановления и проверяйте операции реанимации удалённых объектов."]},"DOMAIN_ROOT_FSMO_TRANSFER":{"description":"Обнаружено делегированное право передачи роли PDC Emulator на корне домена. Такая операция меняет владельца критичной роли FSMO.","impact":["Неправомерная передача роли способна нарушить работу времени, обработку паролей и операции, зависящие от PDC."],"attack":["1. Нарушитель обладает правом Change-PDC на объекте домена.","2. Передаёт роль эмулятора PDC выбранному контроллеру домена.","3. Синхронизация времени и репликация изменений паролей ухудшаются в масштабе домена.","4. Причина может выглядеть как сбой репликации, а не умышленное действие."],"remediation":["Ограничьте управление FSMO доверенными администраторами и контролируйте изменения владельцев ролей."]},"OU_PERM_USER_ACCOUNT_RESTRICTIONS":{"description":"Субъект может изменять набор свойств User-Account-Restrictions у записей в OU. В набор входят чувствительные параметры учётных записей и делегирования.","impact":["Можно ослабить ограничения входа или изменить параметры учётной записи в рамках разрешённых атрибутов."],"attack":[],"remediation":["Проверьте фактические ACE и ограничьте делегирование только необходимыми операциями."]},"OU_PERM_SELF_ALL_VALIDATED":{"description":"В OU назначен широкий набор проверяемых операций записи Validated Writes. Это не полный WriteProperty: сервер проверяет специальные ограничения для каждого атрибута.","impact":["При определённых классах объектов права позволяют изменять SPN, DNS-имя и иные чувствительные данные."],"attack":[],"remediation":["Назначайте отдельные валидируемые операции только уполномоченным службам. Проверьте классы дочерних объектов и наследование ACE."]},"OU_PERM_SELF_MEMBERSHIP":{"description":"Субъекту разрешена проверяемая операция самостоятельного изменения членства в группе. Это не равнозначно праву произвольно менять состав группы.","impact":["В зависимости от условий субъект может добавить собственную запись в группу и получить предоставленные ей полномочия."],"attack":[],"remediation":["Ограничьте Self-Membership в чувствительных группах и проверяйте наследование разрешения."]},"OU_PERM_VALIDATED_SPN":{"description":"Назначено право Validated-SPN, позволяющее изменять servicePrincipalName с проверкой допустимых значений сервером каталога.","impact":["При дополнительных условиях изменение SPN может повлиять на Kerberos и доступность служб."],"attack":[],"remediation":["Оставляйте право только доверенным средствам управления компьютерами и службами; отслеживайте изменения SPN."]},"OU_PERM_DNSHOSTNAME_WRITE":{"description":"Субъект может записывать атрибут dNSHostName у объектов компьютеров в OU.","impact":["Подмена DNS-имени способна повлиять на разрешение имён служб и соответствие идентификатора машине."],"attack":[],"remediation":["Удалите ненужные WriteProperty для dNSHostName, проверьте наследование и отслеживайте изменения атрибута."]},"OU_PERM_DNS_HOST_NAME_ATTRIBUTES":{"description":"Назначено право изменения набора свойств DNS-Host-Name-Attributes для объектов в OU.","impact":["Изменение DNS-атрибутов может нарушить связность записей компьютеров, служб и имён."],"attack":[],"remediation":["Ограничьте делегирование специализированными операторами и контролируйте фактические атрибуты в составе набора."]},"OU_PERM_VALIDATED_DNS":{"description":"Субъект получил право Validated-DNS-Host-Name — проверяемое изменение DNS-имени компьютера.","impact":["Потенциально возможны некорректные изменения DNS-имён в пределах ограничений каталога."],"attack":[],"remediation":["Оставьте право штатным механизмам присоединения и управления компьютерами; проверьте унаследованные ACE."]},"OU_PERM_CREATE_DMSA":{"description":"В OU разрешено создавать делегированные управляемые учётные записи службы dMSA. Эта возможность чувствительна при миграции существующих служб, особенно привилегированных.","impact":["Контролируемая dMSA при небезопасной конфигурации миграции может получить доступ к секретам и сервисным полномочиям предшественника."],"attack":[],"remediation":["Разрешайте создание dMSA только доверенным администраторам. Контролируйте связанные объекты миграции и права их использования."]},"PRECREATED_COMPUTER_ACCOUNT":{"description":"В AD создана учётная запись компьютера, которая ещё не использовалась для обычного присоединения машины к домену.","impact":["Предварительная запись может быть законной, но забытые объекты осложняют контроль делегированных прав и владельцев."],"attack":[],"remediation":["Проверьте владельца, сроки и назначение заготовленной записи; удаляйте неиспользуемые объекты по регламенту."]},"INTERDOMAIN_TRUST_ACCOUNT":{"description":"Найдена специальная учётная запись типа INTERDOMAIN_TRUST_ACCOUNT, участвующая в междоменных доверительных отношениях.","impact":["Обычные политики управления пользовательскими паролями не всегда применимы к такой записи; некорректное изменение может разорвать доверие."],"attack":[],"remediation":["Проверяйте запись вместе с конфигурацией доверия и состоянием его секрета; не отключайте её как обычную устаревшую запись."]},"ESX_ADMINS_MEMBER":{"description":"Субъект включён в группу ESX Admins, которая в определённых конфигурациях VMware ESXi может предоставлять административный доступ к гипервизорам.","impact":["Компрометация такого субъекта может дать управление виртуальными машинами и инфраструктурой виртуализации."],"attack":["1. Нарушитель становится участником ESX Admins либо, если группы нет, создаёт группу с таким именем или переименовывает существующую.","2. Входит на присоединённый к домену узел ESXi с доменными учётными данными и становится его администратором.","3. Копирует виртуальный диск контроллера домена либо шифрует виртуальные машины."],"remediation":["Проверьте фактическую настройку ESXi и необходимость членства. Уберите избыточных участников и контролируйте изменение группы."]},"EXCHANGE_GROUP_PERMISSIONS":{"description":"Выявлены разрешения служебной группы Microsoft Exchange на объекты каталога. Часть этих ACE предусмотрена архитектурой Exchange и не должна удаляться автоматически.","impact":["Необдуманное изменение штатных прав может остановить почтовые службы; избыточные права расширяют поверхность атаки."],"attack":["Нарушители могут атаковать серверы Exchange, чтобы получить доступ к этим привилегированным группам.","Уязвимости Exchange, например ProxyLogon и ProxyShell, могут предоставить такой доступ.","После компрометации Exchange нарушитель может использовать соответствующие разрешения."],"remediation":["Сопоставьте права с используемой моделью Exchange и документированным штатным составом. Проверяйте исключения до изменения ACL."]},"DSHEURISTICS_ANONYMOUS_NSPI":{"description":"Параметр dsHeuristics разрешает анонимный доступ NSPI, который используется для адресных запросов к каталогу.","impact":["Анонимным пользователям могут открываться сведения адресной книги, полезные для разведки."],"attack":["1. Нарушитель без учётных данных достигает RPC-интерфейса контроллера домена.","2. Выполняет анонимную привязку к интерфейсу NSPI.","3. Читает записи адресной книги, которые каталог показывает анонимному клиенту.","4. Использует имена и адреса для распыления паролей либо фишинга."],"remediation":["Отключите анонимный NSPI, если он не требуется совместимости; проверьте конфигурацию dsHeuristics."]},"DSHEURISTICS_ADMINSDHOLDER_EXCLUSION":{"description":"Параметр dsHeuristics исключает некоторые операторские группы из защиты AdminSDHolder/SDProp. Их DACL могут перестать регулярно восстанавливаться по защищённому шаблону.","impact":["Нестандартное делегирование на исключённые группы способно сохраняться и расширять контроль над их участниками."],"attack":["1. Нарушитель контролирует запись с делегированным правом на участника исключённой группы — обычно это делегирование службе поддержки.","2. Сбрасывает пароль участника либо добавляет запись в группу; SDProp больше не удаляет позволившее это право.","3. Использует полномочия группы на контроллере домена, например создаёт резервную копию базы каталога как участник Backup Operators."],"remediation":["Проверьте значение dsHeuristics и обоснованность исключений. Восстановите защиту операторских групп, если нет документированного исключения."]},"DSHEURISTICS_UNIQUENESS_DISABLED":{"description":"Через dsHeuristics ослаблена проверка уникальности UPN или SPN в Active Directory.","impact":["Дублирующиеся имена могут вызвать неоднозначность разрешения субъектов и служб Kerberos."],"attack":["1. Нарушитель контролирует учётную запись с правом изменить UPN или SPN другой записи — через делегирование либо GenericWrite на компьютере.","2. Записывает имя, уже назначенное другой записи, или псевдоним вроде cifs/server рядом с HOST/server этого сервера; контроллер домена принимает изменение.","3. При псевдониме клиенты получают билеты службы для записи нарушителя, компьютер которой выдаёт себя за сервер; при дубликате входы и выдача билетов по этому имени нарушаются."],"remediation":["Верните штатный контроль уникальности, предварительно выявив дубликаты и проверив совместимость приложений."]},"SID_HISTORY_OWN_DOMAIN":{"description":"В sIDHistory учётной записи содержится SID текущего домена. Это требует проверки происхождения миграции и соответствия исходных разрешений.","impact":["Наследуемые через sIDHistory привилегии могут не совпадать с текущим членством в группах."],"attack":[],"remediation":["Уточните назначение sIDHistory и удалите несанкционированные значения после анализа влияния на доступ."]},"LAPS_ENCRYPTED_READ_NO_DECRYPTOR":{"description":"Субъект может прочитать зашифрованный пароль Windows LAPS из AD, но не входит в набор субъектов, способных его расшифровать.","impact":["Само чтение шифротекста не эквивалентно знанию пароля; остаётся доступ к метаданным и зашифрованным данным."],"attack":[],"remediation":["Проверьте ACL чтения, получателей шифрования и документируйте необходимые исключения."]},"LAPS_PASSWORD_READ_ACCESS":{"description":"На OU компьютеров обнаружены разрешения, позволяющие читать атрибуты паролей LAPS при выполнении условий конфиденциальности и доступа.","impact":["Уполномоченный субъект может получить пароль локального администратора управляемой машины."],"attack":[],"remediation":["Ограничьте чтение паролей LAPS доверенными администраторами и средствами поддержки; включите аудит доступа."]},"LAPS_READ_BLOCKED_BY_CONFIDENTIAL":{"description":"Право чтения всех свойств обнаружено, но конфиденциальный флаг атрибута LAPS блокирует чтение пароля без дополнительного необходимого разрешения.","impact":["Широкое ReadProperty само по себе не означает раскрытия пароля при действующей защите конфиденциальных атрибутов."],"attack":[],"remediation":["Сохраняйте конфиденциальность атрибутов и дополнительно проверяйте наличие All Extended Rights у субъектов."]},"DELETED_OBJECT_CREDENTIAL":{"description":"В удалённом объекте Active Directory остались атрибуты, похожие на учётные данные. Такие сведения могут сохраняться до удаления объекта из хранилища Deleted Objects.","impact":["Секрет может оставаться доступным субъектам с правами чтения удалённых объектов."],"attack":["1. Перечисляет контейнер Deleted Objects с управляющим элементом show-deleted (Get-ADObject -IncludeDeletedObjects).","2. Читает свободные текстовые и парольные атрибуты удалённых записей.","3. Пробует пароль на других записях, где он мог повторно использоваться, либо на самой записи после восстановления."],"remediation":["Смените раскрытый секрет и пересмотрите хранение паролей в текстовых атрибутах; проверьте ACL Deleted Objects."]},"DELETED_OBJECTS_READ_DELEGATED":{"description":"Субъект вне Tier 0 может читать контейнер Deleted Objects и доступные атрибуты удалённых записей.","impact":["Можно получить исторические сведения об учётных записях, а иногда и ошибочно сохранённые секреты."],"attack":["1. От имени субъекта с делегированным правом ищет в контейнере Deleted Objects с управляющим элементом show-deleted.","2. Читает удалённые объекты: описания, info, расширенные атрибуты и парольные атрибуты Unix.","3. Использует эти сведения либо выбирает удалённую запись, восстановление которой представляет интерес."],"remediation":["Ограничьте чтение Deleted Objects субъектами с подтверждённой административной задачей."]},"DELETED_OBJECTS_READ_BROAD":{"description":"Широкая группа имеет возможность читать удалённые объекты каталога.","impact":["Расширяется доступ к историческим сведениям и возможным секретам, которые не должны быть доступны обычным пользователям."],"attack":["1. Как любой пользователь домена ищет в контейнере Deleted Objects с управляющим элементом show-deleted.","2. Читает атрибуты удалённых объектов.","3. Использует содержащиеся в них сведения."],"remediation":["Удалите избыточные делегированные права и проверьте влияние на средства резервного копирования и восстановления."]},"CREDENTIAL_AUTOADMINLOGON":{"description":"В конфигурации AutoAdminLogon, распространяемой через GPO, может присутствовать пароль автоматического входа.","impact":["Доступ к соответствующему ключу реестра способен раскрыть учётные данные, используемые для входа на компьютеры."],"attack":["1. Нарушитель читает SYSVOL (доступен любому пользователю домена) либо ресурс с копией политики, например резервной копией GPO.","2. Ищет Registry.xml со значением Winlogon DefaultPassword.","3. Извлекает DefaultUserName, DefaultPassword и DefaultDomainName.","4. Использует учётные данные напрямую — расшифровка не требуется.","5. Входит на системы, где настроен AutoAdminLogon."],"remediation":["Уберите AutoAdminLogon с паролем и смените раскрытый секрет; используйте более безопасные механизмы автоматизации."]},"GPO_REGISTRY_PASSWORD":{"description":"В параметре реестра, развёрнутом через групповую политику, обнаружен текст, похожий на пароль или иной секрет.","impact":["Политика и её файлы могут быть прочитаны широким кругом доменных пользователей."],"attack":[],"remediation":["Проверьте совпадение вручную, исключите секрет из GPO и смените его при подтверждении раскрытия."]},"CREDENTIAL_UNATTEND_PASSWORD":{"description":"В файле ответов автоматической установки Windows обнаружен пароль или поле с учётными данными.","impact":["Unattend-файлы могут сохраняться на диске и быть доступны субъектам с обычными правами чтения."],"attack":["1. Читает файл автоматической установки (answer file) из общего ресурса.","2. Декодирует скрытое значение: Base64, затем UTF-16LE, после чего удаляет суффикс AdministratorPassword или Password.","3. Входит как локальный администратор на компьютеры, установленные с этого файла, либо использует доменную запись присоединения к домену."],"remediation":["Удалите пароль из доступных файлов, смените раскрытый секрет и используйте защищённое хранилище для развёртывания."]},"CREDENTIAL_VNC_PASSWORD":{"description":"В реестре либо файлах конфигурации обнаружено значение пароля удалённого доступа VNC.","impact":["Пароль может использоваться для несанкционированного подключения к управляемому рабочему месту."],"attack":["1. Читает из общего ресурса файл .vnc, файл .ini либо политику.","2. Расшифровывает 16 шестнадцатеричных символов фиксированным ключом DES для VNC.","3. Подключается к указанному в файле узлу или другому VNC-серверу с тем же паролем."],"remediation":["Смените секрет VNC, ограничьте доступ к конфигурации и предпочтительно используйте проверку подлинности с управлением доступом."]},"CREDENTIAL_NET_USE":{"description":"В сценарии обнаружена команда net use с паролем, указанным явно в аргументах.","impact":["Любой читатель сценария может получить пароль и воспользоваться назначенным ему доступом."],"attack":["1. Нарушитель читает сценарии из SYSVOL, NETLOGON или общего файлового ресурса.","2. Ищет в сценариях входа команды net use с параметром /user:.","3. Извлекает имя пользователя и пароль из команды.","4. Использует их для доступа к целевому ресурсу.","5. Возможно, переходит к другим системам, где используются те же учётные данные."],"remediation":["Удалите пароль из команды, смените секрет и используйте управляемый контекст запуска без хранения пароля в тексте."]},"CREDENTIAL_CONNECTION_STRING":{"description":"Строка подключения к базе данных содержит данные входа или секрет в явном виде.","impact":["Чтение файла приложения или скрипта может раскрыть доступ к базе данных."],"attack":["1. Нарушитель находит строку подключения в конфигурационном файле или сценарии.","2. Извлекает адрес сервера, базу данных, имя пользователя и пароль.","3. Подключается к серверу БД с раскрытыми учётными данными.","4. Извлекает данные либо повышает привилегии (например, через xp_cmdshell)."],"remediation":["Перенесите секрет в защищённое хранилище, выдайте минимальные права и замените раскрытый пароль."]},"CREDENTIAL_MENTION_REVIEW":{"description":"В файле или параметре обнаружено слово либо шаблон, похожий на учётные данные, но автоматическая проверка не подтверждает, что это действующий секрет.","impact":["Возможна ложноположительная находка; при реальном секрете возникает риск раскрытия."],"attack":["1. Нарушитель ищет в сценариях ключевые слова, связанные с учётными данными.","2. Анализирует контекст, чтобы понять, действительно ли они присутствуют.","3. Если данные обнаружены, извлекает их и использует для доступа."],"remediation":["Проверьте контекст вручную и избегайте публикации строки в открытых отчётах; при подтверждении секрета выполните ротацию."]},"GMSA_PASSWORD_READABLE":{"description":"Субъект имеет возможность получить управляемый пароль gMSA в рамках msDS-GroupMSAMembership.","impact":["Полученный секрет gMSA даёт возможность аутентифицироваться от имени управляемой службы."],"attack":["1. Выявляет записи gMSA, пароли которых ему разрешено читать.","2. Получает атрибут msDS-ManagedPassword.","3. Разбирает BLOB и получает NT-хеш.","4. Использует хеш для Pass-the-Hash либо запросов билетов Kerberos."],"remediation":["Ограничьте получателей пароля только компьютерами и группами, на которых реально работает служба."]},"SHADOW_CREDENTIALS":{"description":"У учётной записи присутствуют ключевые данные в msDS-KeyCredentialLink. Это может быть штатным состоянием для Windows Hello for Business, ключей FIDO2 и гибридного присоединения Microsoft Entra; заполненный атрибут сам по себе информационный признак, а НЕ подтверждённая атака. Для Shadow Credentials необходимо право записи msDS-KeyCredentialLink — его проверяют отдельные находки ACL (на объекте, OU или AdminSDHolder). Для компьютерных записей дополнительно учитывается время появления ключа относительно присоединения: ключ, зарегистрированный спустя дни или недели без обоснования, заслуживает проверки.","impact":["Обладатель закрытого ключа, привязанного к msDS-KeyCredentialLink, может проходить аутентификацию PKINIT без пароля.","Наличие ключа ожидаемо при Windows Hello for Business, FIDO2 или гибридном присоединении компьютера.","Необъяснимый ключ способен стать способом закрепления, сохраняющимся после смены пароля."],"attack":[],"remediation":["Установите происхождение ключей на привилегированных записях; запись администратора, не использующая Windows Hello или FIDO2, обычно не должна иметь посторонних ключей.","Уберите ненужные права записи msDS-KeyCredentialLink у сторонних субъектов по соответствующим находкам ACL.","Контролируйте изменения msDS-KeyCredentialLink (событие 5136)."]},"KERBEROS_TICKET_LIFETIME_EXTENDED":{"description":"Политика Kerberos устанавливает срок действия TGT или служебного билета выше обычного рекомендуемого значения.","impact":["Украденный билет остаётся пригодным дольше, что увеличивает окно повторного использования."],"attack":[],"remediation":["Сопоставьте настройки с требованиями служб и верните разумные сроки жизни билетов."]},"TRUST_USES_RC4":{"description":"Доверительные отношения используют криптографию Kerberos RC4 без достаточной поддержки AES.","impact":["Ослабляется стойкость материала аутентификации и возрастает риск злоупотребления унаследованными алгоритмами."],"attack":[],"remediation":["Проверьте поддержку AES обоими доменами и безопасно обновите настройки шифрования и пароль доверия."]},"TRUST_PASSWORD_STALE":{"description":"Пароль доверительных отношений между доменами давно не менялся.","impact":["Долгое использование секрета увеличивает время потенциальной пригодности скомпрометированного ключа доверия."],"attack":[],"remediation":["Проверьте здоровье доверия и согласуйте восстановление ротации секрета на обеих сторонах."]},"TRUST_BIDIRECTIONAL":{"description":"Найдены двусторонние доверительные отношения: каждый домен доверяет проверке подлинности пользователей другого в установленных границах.","impact":["Компрометация смежного домена может влиять на доступные ресурсы при чрезмерных разрешениях."],"attack":[],"remediation":["Проверьте необходимость двустороннего доверия, фильтрацию SID и права на ресурсах; само наличие доверия не является нарушением."]},"TRUST_TRANSITIVE":{"description":"Доверие является транзитивным и при определённых условиях распространяется через дополнительные домены.","impact":["Расширяется круг областей идентификации, пользователи которых могут получать доступ к ресурсам через цепочку доверия."],"attack":[],"remediation":["Инвентаризируйте цепочки доверия и оцените границы доступа; сохраняйте транзитивность только там, где она необходима."]},"TRUST_SELECTIVE_AUTH":{"description":"Для доверительных отношений включена выборочная проверка подлинности (Selective Authentication). Она требует явного права Allowed to Authenticate на целевом компьютере.","impact":["Это сокращает несанкционированный доступ через доверие, но неправильные ACL могут нарушить работу служб."],"attack":[],"remediation":["Сохраняйте выборочную аутентификацию там, где она необходима, и проверяйте делегированные права Allowed to Authenticate."]},"TRUST_TREAT_AS_EXTERNAL":{"description":"Лесное доверие настроено с поведением TreatAsExternal, которое ослабляет обычные границы фильтрации SID между лесами.","impact":["Определённые SID из другого леса могут получить доступ шире ожидаемого при дополнительных условиях."],"attack":[],"remediation":["Проверьте необходимость флага и настройте ожидаемую фильтрацию SID в рамках согласованных границ доверия."]},"NETWORK_SUBNET_DOMAIN_CONTROLLERS":{"description":"Подсеть содержит один или несколько контроллеров домена; это важный контекст для оценки сетевой сегментации и доступности служб AD.","impact":["Недостаточные сетевые ограничения повышают поверхность атаки на критичную инфраструктуру."],"attack":[],"remediation":["Проверьте сегментацию и маршруты доступа к DC, оставив необходимые порты репликации, Kerberos, LDAP и DNS."]},"OS_EXTENDED_SECURITY_UPDATES_ONLY":{"description":"Операционная система вышла из обычной поддержки; доступность исправлений зависит от участия в программе Extended Security Updates.","impact":["Без ESU и обновлений не устраняются новые известные уязвимости."],"attack":[],"remediation":["Проверьте наличие активной ESU, состояние исправлений и план миграции на поддерживаемый выпуск."]},"OUTDATED_OS":{"description":"Операционная система снята с поддержки и больше не получает стандартные исправления безопасности.","impact":["Известные уязвимости могут оставаться открытыми неограниченно долго."],"attack":[],"remediation":["Изолируйте критичные узлы до замены и перенесите службы на поддерживаемые версии."]},"EXCHANGE_VULNERABLE_VERSION":{"description":"Установленная версия Exchange Server вышла из поддержки либо требует обновлений безопасности.","impact":["Снижается защищённость почтовых данных и сервера; накопившиеся уязвимости могут стать точкой компрометации домена."],"attack":["1. Определяет версию Exchange извне: номер сборки содержится в ответе OWA.","2. Выбирает опубликованную цепочку эксплуатации для этой версии либо ожидает следующую.","3. Получает выполнение кода от SYSTEM на сервере Exchange.","4. Использует собственные права сервера в каталоге или хранящиеся на нём учётные данные для продвижения в Active Directory."],"remediation":["Проверьте точный выпуск, CU и SU Exchange; обновите сервер или выполните миграцию в поддерживаемую среду."]},"EXCHANGE_SHARED_PERMISSIONS_MODEL":{"description":"Для Exchange используется модель общих разрешений, при которой связанные группы могут иметь WriteDACL на корневом объекте домена и другие расширенные полномочия.","impact":["Компрометация соответствующих групп может создать путь к получению прав уровня домена, если опасные ACE действуют."],"attack":["1. Получает контроль над любым субъектом в Exchange Windows Permissions либо ретранслирует машинную аутентификацию сервера Exchange.","2. Добавляет в объект домена ACE, предоставляющий контролируемому субъекту права репликации.","3. Выполняет DCSync против контроллера домена.","4. Подделывает Golden Ticket с хешем krbtgt либо аутентифицируется как любой пользователь."],"remediation":["Сверьте модель с документированными требованиями Exchange. Рассмотрите разделение разрешений при совместимости с архитектурой и не удаляйте штатные ACE без проверки."]},"EXCHANGE_PERMISSIONS_MODEL_CLEAN":{"description":"Проверка не обнаружила действующих опасных прав повышения привилегий Exchange на корне домена.","impact":["Этот конкретный путь повышения привилегий не подтверждён; другие разрешения Exchange требуют отдельного анализа."],"attack":[],"remediation":["Сохраняйте минимально необходимые делегирования и повторяйте проверку после обновлений Exchange."]},"EXCHANGE_AD_SPLIT_PERMISSIONS":{"description":"В Exchange применяется разделённая модель разрешений AD, ограничивающая операции Exchange над объектами каталога.","impact":["Разделение полномочий уменьшает последствия компрометации обычных административных учётных записей Exchange."],"attack":[],"remediation":["Проверьте корректность конфигурации и отдельные ручные делегирования; сама модель не исключает других уязвимостей."]},"EXCHANGE_SMTP_ANONYMOUS_SPOOFING":{"description":"Принимающий соединитель Exchange может принимать письма анонимного отправителя с внутренним адресом From или MAIL FROM без достаточных ограничений.","impact":["Появляется риск подделки внутреннего отправителя, социальной инженерии и обхода некоторых почтовых правил."],"attack":["1. Подключается к соединителю с адреса в разрешённом диапазоне удалённых IP.","2. Открывает SMTP-сеанс без аутентификации.","3. Задаёт MAIL FROM равным внутреннему адресу руководителя, а RCPT TO — адресу целевого сотрудника.","4. Сообщение доставляется как внутренняя почта от этого руководителя."],"remediation":["Проверьте разрешения соединителя, ограничения IP и применимость SPF, DKIM, DMARC; запретите несанкционированную подмену внутренних отправителей."]},"EXCHANGE_SMTP_BROAD_RELAY":{"description":"SMTP-соединитель разрешает ретрансляцию слишком широкой группе прошедших аутентификацию отправителей.","impact":["Любая компрометированная доменная запись может использовать почтовый сервер для внешней отправки с последующим попаданием в блок-листы."],"attack":[],"remediation":["Ограничьте права ретрансляции утверждёнными сервисными записями и IP-адресами, проверяйте журналы SMTP."]},"EXCHANGE_SMTP_ANONYMOUS_AUTHENTICATED":{"description":"Анонимные сообщения обрабатываются соединителем как аутентифицированные из-за небезопасного сочетания разрешений.","impact":["Такие сообщения могут получить льготы, предназначенные только для доверенных отправителей."],"attack":["1. Нарушитель находит соединитель, принимающий анонимные сеансы.","2. Отправляет сообщение в группу рассылки, допускающую только внутренних отправителей.","3. Сообщение считается аутентифицированным и доставляется без внешней маркировки."],"remediation":["Уберите излишние SMTP-разрешения, не помечайте анонимные сообщения как прошедшие аутентификацию и ограничьте доверенные соединители."]},"EXCHANGE_SMTP_ANONYMOUS_BYPASS_ANTISPAM":{"description":"Конфигурация принимающего соединителя разрешает анонимным отправителям обход некоторых антиспам-проверок Exchange.","impact":["Спам и фишинг могут доставляться без ожидающейся серверной фильтрации."],"attack":["1. Находит соединитель, принимающий анонимные сеансы, — порт 25 опубликованного узла.","2. Отправляет сообщение с вредоносным вложением либо фишинговой ссылкой для кражи учётных данных.","3. Из-за права обхода фильтрации сообщение не проверяется.","4. Оно доставляется и выглядит как почта, прошедшая проверку."],"remediation":["Пересмотрите права обхода антиспама и ограничьте их строго доверенными шлюзами с проверенной репутацией."]},"EXCHANGE_SMTP_BROAD_SPOOFING":{"description":"Прошедший аутентификацию доменный пользователь может отправлять почту с внутренним адресом отправителя, не принадлежащим ему.","impact":["Возможны подмена руководства, мошенничество и обход адресных ограничений."],"attack":["1. Аутентифицируется на соединителе под любой доменной учётной записью.","2. Отправляет сообщение, указав внутренний адрес в MAIL FROM и заголовке From.","3. Exchange принимает сообщение как авторитетное, потому что соединитель предоставляет право отправителя.","4. Получатель видит обычное внутреннее письмо от коллеги."],"remediation":["Ограничьте право отправки от чужого имени, проверяйте аутентифицированное письмо и назначения Send As."]},"EXCHANGE_SMTP_CONNECTOR_AUTHENTICATED":{"description":"Принимающий SMTP-соединитель требует проверку подлинности отправителя; анонимный доступ к данному пути не подтверждён.","impact":["Требование аутентификации снижает риск открытой ретрансляции при корректных разрешениях и TLS."],"attack":[],"remediation":["Поддерживайте требование аутентификации; отдельно проверьте полномочия прошедших её пользователей."]},"EXCHANGE_SMTP_CONNECTOR_UNREADABLE":{"description":"Разрешения принимающего SMTP-соединителя не удалось достоверно прочитать, поэтому безопасность его настроек не оценена.","impact":["Неизвестное состояние может скрывать уязвимое разрешение; отсутствие результатов не означает безопасность."],"attack":[],"remediation":["Проверьте права текущего аудитора и повторите чтение конфигурации соединителя со штатными административными полномочиями."]},"EXCHANGE_HYBRID_DEPLOYMENT":{"description":"В гибридной конфигурации Exchange локальные компоненты связаны с Microsoft 365/Exchange Online. Компрометация гибридной связки может затронуть облачные ресурсы.","impact":["Ошибки доверия или утечка секретов синхронизации и приложений расширяют последствия локального инцидента."],"attack":["1. Получает административный доступ к локальному серверу Exchange одним из способов, описанных в отчёте.","2. Использует учётные данные общего субъекта-службы (service principal), чтобы получить токены доступа к Exchange Online.","3. Действует в облачном арендаторе как доверенное приложение первой стороны."],"remediation":["Контролируйте гибридные сертификаты, сервисные записи, права приложений и журналы в обеих средах."]},"EXCHANGE_RBAC_MAILBOX_IMPORT_EXPORT":{"description":"Назначена роль Mailbox Import Export, позволяющая импортировать и экспортировать содержимое почтовых ящиков при соблюдении области назначения RBAC.","impact":["Чрезмерное назначение может дать доступ к конфиденциальной переписке и возможность выгрузки данных."],"attack":["1. Получает контроль над записью, которой назначена роль.","2. Выполняет New-MailboxExportRequest для целевого почтового ящика с сохранением по UNC-пути под контролем нарушителя.","3. Получает PST и читает его автономно."],"remediation":["Ограничьте роль специальными операторами и проверяйте область управления и аудит экспорта."]},"EXCHANGE_RBAC_APPLICATION_IMPERSONATION":{"description":"Назначена роль ApplicationImpersonation, позволяющая приложению или администратору обращаться к почтовым ящикам от имени других пользователей в установленной области.","impact":["При широком назначении компрометация записи даёт массовый доступ к переписке."],"attack":["1. Компрометирует учётную запись или службу с этой ролью — часто интеграционную запись с небольшими правами и постоянным паролем.","2. Подключается к EWS, передавая в заголовке олицетворения целевой почтовый ящик.","3. Произвольно перечисляет и ищет содержимое почтовых ящиков (это автоматизирует MailSniper)."],"remediation":["Ограничьте роль минимальным набором ящиков и сервисных записей; проверьте переход на современные ограниченные механизмы доступа там, где это доступно."]},"EXCHANGE_RBAC_ROLE_MANAGEMENT":{"description":"Роль Role Management назначена вне ожидаемой группы Organization Management. Она позволяет управлять ролевыми назначениями Exchange.","impact":["Обладатель роли может расширить собственные или чужие полномочия в пределах разрешённой модели RBAC."],"attack":["1. Получает контроль над субъектом с ролью Role Management.","2. Через New-ManagementRoleAssignment назначает себе ApplicationImpersonation.","3. Читает все почтовые ящики через EWS."],"remediation":["Пересмотрите назначения и оставьте управление ролями доверенной группе; отслеживайте новые RBAC-назначения."]},"EXCHANGE_RBAC_UNSCOPED_ROLE_MANAGEMENT":{"description":"Найдена роль Unscoped Role Management, позволяющая управлять назначениями и сценариями управления без обычных ограничений области.","impact":["Чрезмерная роль может привести к широким изменениям в инфраструктуре Exchange."],"attack":["1. Получает контроль над субъектом с соответствующей ролью.","2. Через New-ManagementRole -UnScopedTopLevel создаёт роль, оборачивающую предоставленный нарушителем сценарий.","3. Назначает новую роль и вызывает её."],"remediation":["Сведите назначения к необходимому минимуму и контролируйте любые изменения непривязанных к области ролей."]},"EXCHANGE_RBAC_MAILBOX_SEARCH":{"description":"Роль Mailbox Search назначена вне штатной группы Discovery Management. Она позволяет искать сообщения в доступных почтовых ящиках.","impact":["Неограниченный поиск может раскрыть чувствительную информацию и личные данные."],"attack":["1. Получает контроль над субъектом, которому назначена роль.","2. Через New-MailboxSearch выполняет поиск по списку ключевых слов во всех почтовых ящиках.","3. Открывает целевой почтовый ящик обнаружения (discovery mailbox) и читает скопированные элементы."],"remediation":["Ограничьте роль утверждёнными специалистами расследований и включите аудит поисковых операций."]},"EXCHANGE_RBAC_AD_PERMISSIONS":{"description":"Роль Active Directory Permissions назначена вне ожидаемой группы Organization Management. Она позволяет выполнять разрешённые операции управления объектами AD через Exchange.","impact":["При избыточном назначении расширяется возможность менять записи и другие объекты каталога."],"attack":["1. Получает контроль над субъектом, которому назначена роль.","2. Через Add-ADPermission предоставляет себе Send-As на целевой почтовый ящик либо ACE повышения привилегий на объекте каталога.","3. Непосредственно использует предоставленное право."],"remediation":["Пересмотрите RBAC и границы административных полномочий, избегая лишних назначений."]},"EXCHANGE_RBAC_DEFAULT_ASSIGNMENT":{"description":"Критичная роль Exchange назначена встроенной или стандартной группе ролей, что требует проверки её фактического состава.","impact":["Чрезмерное членство расширяет круг субъектов с чувствительными полномочиями."],"attack":[],"remediation":["Сверьте роль, управляющую группу и её участников с регламентом и фактической необходимостью."]},"COMPUTER_OBJECT_EXPLICIT_RIGHT":{"description":"На объекте компьютера имеется явный ACE для субъекта вне ожидаемой модели Tier 0. Фактические последствия определяются разрешённым правом и атрибутом.","impact":["При WriteDACL, GenericAll, RBCD или изменении ключевых атрибутов возможно нарушение доверия к машине."],"attack":["1. Нарушитель получает контроль над указанным субъектом.","2. Записывает RBCD или ключевые учётные данные на объект компьютера, сбрасывает его пароль либо читает пароль LAPS.","3. Получает служебный билет к компьютеру от имени администратора либо входит с паролем локального администратора."],"remediation":["Пересмотрите ACE, владельца и происхождение явного назначения. Разделяйте права обычных машин и контроллеров домена."]},"COMPUTER_PASSWORD_NOT_ROTATED":{"description":"Пароль доменной учётной записи компьютера давно не менялся. Обычно машины обновляют собственный секрет автоматически.","impact":["Статический машинный секрет повышает окно потенциального использования при утечке и может говорить о проблеме безопасного канала."],"attack":["1. Нарушитель однократно извлекает ключ машинной учётной записи узла.","2. Подделывает служебные билеты для служб узла либо аутентифицируется как компьютер.","3. Сохраняет этот доступ, пока пароль компьютера не изменится."],"remediation":["Проверьте доступность машины, состояние защищённого канала и настройки ротации пароля; не сбрасывайте секрет без проверки."]},"DC_PASSWORD_NOT_ROTATED":{"description":"Пароль машинной учётной записи контроллера домена длительное время не обновлялся, несмотря на штатную ротацию.","impact":["Проблема может свидетельствовать о нарушении работы безопасного канала и повышать риски при компрометации машинного секрета DC."],"attack":["1. Нарушитель однажды получает ключ машинной учётной записи контроллера домена из резервной копии, снимка виртуальной машины либо памяти.","2. Использует его для репликации секретов домена через DCSync или подделки служебных билетов контроллера.","3. Сохраняет доступ до смены пароля контроллера домена."],"remediation":["Проверьте репликацию и состояние контроллера, настройки ротации, журналы и последовательность безопасного восстановления."]},"ORPHANED_ADMIN_ACCOUNT":{"description":"У учётной записи сохраняется adminCount=1, но она больше не входит в защищаемую группу. Атрибут не снимается автоматически при исключении из таких групп.","impact":["Наследование разрешений у записи может остаться отключённым, из-за чего делегирование на родительской OU перестаёт действовать."],"attack":[],"remediation":["Проверьте фактические привилегии; при отсутствии причин для защиты восстановите штатное наследование и согласованно очистите adminCount."]},"NO_MAX_PASSWORD_AGE":{"description":"В доменной политике максимальный срок действия пароля не ограничен.","impact":["При компрометации неизменный пароль может оставаться действительным долго; оценка зависит также от MFA и качества паролей."],"attack":[],"remediation":["Определите разумную политику жизненного цикла паролей и отдельные требования к служебным записям."]},"WEAK_LOCKOUT_DURATION":{"description":"Продолжительность блокировки учётной записи слишком мала, что допускает новые попытки входа через короткий промежуток времени.","impact":["Повышается эффективность последовательного перебора и распыления паролей при отсутствии дополнительных ограничений."],"attack":[],"remediation":["Настройте порог, длительность и окно наблюдения блокировки с учётом защиты от отказа в обслуживании."]},"NO_MIN_PASSWORD_AGE":{"description":"Минимальный срок действия пароля не установлен, поэтому пользователь может последовательно менять пароль несколько раз подряд.","impact":["В сочетании с включённой историей паролей это позволяет быстрее вернуться к ранее использованному значению."],"attack":[],"remediation":["Установите минимальный срок с учётом процессов сброса паролей и работоспособности сотрудников."]},"PASSWORD_HISTORY_DISABLED":{"description":"В доменной парольной политике история предыдущих паролей отключена или слишком мала.","impact":["Пользователи могут возвращаться к слабым или ранее раскрытым паролям."],"attack":[],"remediation":["Настройте хранение достаточного числа предыдущих паролей; используйте проверку запрещённых значений и MFA."]},"SCCM_SYSTEM_MANAGEMENT_ACL":{"description":"На контейнере System Management, используемом Configuration Manager, обнаружены нестандартные разрешения.","impact":["Право создания или изменения объектов контейнера может позволить публиковать недоверенные сведения о службах SCCM."],"attack":[],"remediation":["Ограничьте запись утверждёнными серверами сайта и администратором SCCM; проверьте унаследованные ACE."]},"SCOM_PRIVILEGED_SERVICE_ACCOUNT":{"description":"Служебная запись SCOM обладает расширенными доменными полномочиями, превышающими обычную потребность мониторинга.","impact":["Компрометация системы мониторинга может открыть административный доступ к другим объектам."],"attack":[],"remediation":["Используйте минимальные делегированные права, отдельные сервисные учётные записи и контролируйте интерактивный вход."]},"SCCM_SITE_HIERARCHY":{"description":"Обнаружена конфигурация нескольких сайтов SCCM. Иерархия расширяет набор серверов и служб, способных управлять клиентами.","impact":["Ошибки доверия или делегирования между сайтами могут повысить последствия компрометации инфраструктуры управления."],"attack":[],"remediation":["Инвентаризируйте серверы сайтов, их связи, публикацию в AD и административные роли."]},"SCCM_PXE_EXPOSURE":{"description":"В среде обнаружен сервер сетевой загрузки PXE, используемый для развёртывания ОС через SCCM.","impact":["При небезопасной конфигурации сеть PXE способна раскрывать данные развёртывания или позволять запуск неутверждённых образов."],"attack":[],"remediation":["Проверьте аутентификацию PXE, границы VLAN, контроль загрузочных образов и доступ к файлам развёртывания."]},"SCCM_SERVICE_ACCOUNT":{"description":"Учётная запись службы SCCM имеет SPN и участвует в проверке подлинности Kerberos.","impact":["При статическом слабом пароле такая запись может быть привлекательной целью Kerberoasting, особенно при повышенных правах."],"attack":[],"remediation":["Проверьте права службы, шифрование Kerberos, стойкость пароля и возможность применения gMSA."]},"SCCM_GROUP_BROAD_MEMBER":{"description":"Широкая группа пользователей входит в группу, связанную с управлением SCCM или его доступом к клиентам.","impact":["Чрезмерное членство способно дать возможности управления ПО на большом числе компьютеров."],"attack":[],"remediation":["Ограничьте состав административных групп SCCM и проверьте делегированные роли."]},"AZURE_AD_CONNECT_EXPOSED":{"description":"Обнаружены признаки небезопасного доступа к серверу Microsoft Entra Connect или его привилегированным учётным данным.","impact":["Компрометация компонента синхронизации может влиять на локальную и облачную инфраструктуры идентификации."],"attack":["1. Нарушитель компрометирует сервер Azure AD Connect.","2. Извлекает учётные данные записи MSOL.","3. Использует права DCSync для извлечения всех хешей паролей домена.","4. Либо подделывает токены для доступа к Azure AD."],"remediation":["Изолируйте сервер синхронизации, ограничьте администраторов и сервисные привилегии, контролируйте изменения конфигурации."]},"ADFS_DKM_CONTAINER":{"description":"В Active Directory присутствует контейнер DKM AD FS для защиты криптографического материала службы федерации.","impact":["Избыточные права чтения или записи могут создать риск компрометации ключей федерации и подписанных токенов."],"attack":["1. Нарушитель получает административный доступ к серверу AD FS либо к служебной учётной записи AD FS.","2. Считывает ключ DKM из контейнера AD, а зашифрованную конфигурацию — из базы данных AD FS.","3. Расшифровывает сертификат подписи токенов с помощью ключа DKM.","4. Подделывает SAML-токены произвольных пользователей; их принимают доверяющие стороны, в том числе Microsoft 365."],"remediation":["Проверьте ACL контейнера DKM и сервисных записей AD FS; ограничьте доступ доверенными администраторами."]},"MSSQL_SERVICE_ACCOUNT_PRIVILEGED":{"description":"SQL Server использует доменную учётную запись с высокими привилегиями, не необходимыми для обычной работы СУБД.","impact":["Эксплуатация SQL Server или компрометация сервиса может дать доступ к другим системам AD."],"attack":[],"remediation":["Используйте отдельную минимально привилегированную сервисную запись или gMSA, проверив совместимость."]},"LAPS_PASSWORD_NOT_ROTATED":{"description":"Пароль локального администратора, управляемый LAPS, давно не обновлялся относительно заданной политики.","impact":["Старый секрет может оставаться пригодным после ранее раскрытого доступа к компьютеру."],"attack":[],"remediation":["Проверьте состояние агента LAPS, политику истечения и журналы смены пароля; устраните сбои ротации."]},"DSRM_PASSWORD_UNMANAGED":{"description":"Пароль режима восстановления служб каталогов (DSRM) на контроллерах домена не управляется Windows LAPS.","impact":["Устаревший общий или редко меняемый пароль DSRM увеличивает риск локального восстановления доступа к контроллеру."],"attack":[],"remediation":["Настройте управление DSRM через поддерживаемую политику Windows LAPS и проверьте надёжность резервных процедур."]},"NON_DEFAULT_COMPUTER_OWNERS":{"description":"Владельцем компьютерного объекта является нестандартный субъект. Владелец обычно способен изменять DACL объекта.","impact":["При неправомерном владении субъект может делегировать себе дополнительные права на компьютерную запись."],"attack":[],"remediation":["Проверьте происхождение и необходимость владения; восстановите ожидаемого владельца при отклонении."]},"COMPUTER_OWNERSHIP_REASSIGNED":{"description":"Владение объектом компьютера было изменено после создания или отличается от ожидаемого субъекта создания.","impact":["Смена владельца может скрывать делегированный путь к изменению прав на машину."],"attack":["1. Нарушитель получает контроль над субъектом — владельцем объекта компьютера.","2. Использует права владельца, чтобы добавить ACE в DACL с разрешением GenericAll.","3. Устанавливает msDS-AllowedToActOnBehalfOfOtherIdentity на контролируемую запись.","4. Через S4U2Self и S4U2Proxy получает служебный билет к этому компьютеру от имени любого пользователя, включая Domain Admin."],"remediation":["Проверьте журнал смены владельца, актуальные ACE и обоснованность передачи владения."]},"NON_DEFAULT_USER_OWNERS":{"description":"Владельцем пользовательского объекта является нестандартный субъект, что может дать ему полномочия менять разрешения на запись.","impact":["Злоупотребление владением позволяет расширить доступ к пользователю даже при ограниченном явном DACL."],"attack":[],"remediation":["Проверьте владельца и наследование, ограничьте возможности передачи владения."]},"READABLE_UNIX_PASSWORD_ATTRIBUTES":{"description":"В каталоге доступны для чтения парольные атрибуты UNIX/NIS, которые могут содержать чувствительный парольный материал.","impact":["Ненужное раскрытие таких атрибутов облегчает автономный подбор паролей или компрометацию смежных систем."],"attack":[],"remediation":["Ограничьте чтение, исключите хранение действующих секретов в обычных атрибутах и смените раскрытые данные."]},"STANDALONE_MSA_LEGACY":{"description":"Используется автономная управляемая учётная запись службы sMSA, рассчитанная на привязку к одному компьютеру.","impact":["Такая запись может быть штатной, но сложнее переносится между узлами, чем gMSA; требует проверки использования."],"attack":[],"remediation":["Инвентаризируйте зависимые службы и при необходимости планируйте переход на gMSA."]},"GPO_TASK_SYSTEM_UNC_PATH":{"description":"Запланированная задача, развёрнутая через GPO, запускается от SYSTEM или привилегированной записи, а исполняемый файл расположен по UNC-пути.","impact":["Если сетевой ресурс доступен для записи посторонним, подмена файла приведёт к запуску с высокими привилегиями."],"attack":[],"remediation":["Перенесите программу в защищённый локальный путь либо ограничьте запись на сетевом ресурсе; проверяйте цифровую подпись и ACL."]},"GPO_TASK_UNQUOTED_PATH":{"description":"В задаче GPO путь к исполняемому файлу с пробелами не заключён в кавычки.","impact":["При совпадении условий разбора команды Windows может быть запущен другой файл из промежуточного пути."],"attack":[],"remediation":["Укажите полный путь в кавычках, не допускайте записи посторонних в промежуточные каталоги."]},"GPO_TASK_CMD_UNQUOTED_PATH":{"description":"Задача GPO запускает cmd.exe и передаёт путь с пробелами без корректного экранирования.","impact":["Парсер командной строки может интерпретировать ошибочную часть пути как отдельную команду или аргумент."],"attack":[],"remediation":["Исправьте кавычки и экранирование команд cmd.exe, протестируйте выполнение под фактической сервисной записью."]},"ESC15_SCHEMA_V1_ENROLLEE_SUBJECT":{"description":"Шаблон сертификата версии схемы 1 позволяет заявителю задавать имя субъекта в запросе. При некоторых настройках выдачи и назначений сертификата это создаёт риск подмены личности через механизм ESC15.","impact":["Сертификат может содержать данные, позволяющие использовать его для аутентификации не того субъекта, которому предназначено право регистрации."],"attack":["1. Нарушитель запрашивает сертификат по уязвимому шаблону схемы v1 на неисправленном центре сертификации.","2. Добавляет EKU Client Authentication через Application Policies.","3. Указывает UPN администратора домена в Subject Alternative Name.","4. Получает сертификат, который позволяет аутентифицироваться от имени указанной записи.","5. Использует PKINIT для аутентификации от имени администратора домена."],"remediation":["Проверьте права регистрации, назначение шаблона и возможность задать имя субъекта; обновите или выведите небезопасный шаблон из эксплуатации."]},"CREDENTIAL_ROAMING_PRESENT":{"description":"В домене включены механизмы Credential Roaming: материалы DPAPI, закрытые ключи и сертификаты могут храниться в атрибутах Active Directory для переноса между компьютерами.","impact":["При неправильных разрешениях чтения эти чувствительные данные могут оказаться доступны посторонним субъектам."],"attack":["1. Читает msPKIDPAPIMasterKeys и msPKIAccountCredentials в объекте целевого пользователя.","2. Экспортирует доменный резервный ключ с контроллера домена (lsadump::backupkeys /export) либо использует пароль или хеш пользователя.","3. Автономно расшифровывает мастер-ключи (dpapi::masterkey /in:\u003cblob\u003e /pvk:\u003cbackupkey\u003e.pvk).","4. Полученным мастер-ключом расшифровывает закрытый ключ из msPKIAccountCredentials.","5. Аутентифицируется как пользователь с восстановленным сертификатом либо расшифровывает его сохранённые секреты DPAPI."],"remediation":["Проверьте необходимость Credential Roaming и настройку доступа к его атрибутам; учитывайте влияние на приложения и пользователей."]},"CREDENTIAL_ROAMING_READABLE":{"description":"Атрибуты Credential Roaming с потенциально чувствительным криптографическим материалом доступны широкому кругу прошедших аутентификацию пользователей.","impact":["Раскрытие закрытых ключей или связанных данных DPAPI при дополнительных условиях может привести к компрометации записей."],"attack":["1. Как обычный пользователь домена запрашивает msPKIDPAPIMasterKeys и msPKIAccountCredentials всех пользовательских объектов.","2. Сохраняет двоичные данные — для их чтения не требовалось привилегий, и для последующего хранения они также не нужны.","3. Ожидает либо пытается получить хеш целевого пользователя или доменный резервный ключ.","4. Автономно расшифровывает мастер-ключи, затем защищённые ими закрытые ключи.","5. Выдаёт себя за пользователя с помощью перенесённого сертификата аутентификации."],"remediation":["Удалите избыточные ACE чтения и оцените утечку; при подтверждении раскрытия выполняйте ротацию ключевого материала."]},"CREDENTIAL_ROAMING_DELEGATED":{"description":"Чтение атрибутов Credential Roaming делегировано субъекту вне ожидаемой модели административного доступа.","impact":["Делегированное чтение потенциально раскрывает сохранённые криптографические данные, связанные с пользователями."],"attack":["1. От имени субъекта с делегированным доступом читает msPKIDPAPIMasterKeys и msPKIAccountCredentials пользователей в области действия.","2. Получает доменный резервный ключ либо пароль или хеш целевого пользователя.","3. Автономно расшифровывает мастер-ключи, затем защищённые ими закрытые ключи.","4. Аутентифицируется как целевой пользователь с восстановленным сертификатом либо расшифровывает сохранённые секреты DPAPI."],"remediation":["Проверьте необходимость такого делегирования, защиту конфиденциальных атрибутов и фактические права."]},"ESC14_WEAK_EXPLICIT_MAPPING":{"description":"В altSecurityIdentities обнаружено явное сопоставление сертификата с учётной записью, использующее слабый формат привязки. При соответствующей политике KDC это может ослаблять проверку принадлежности сертификата.","impact":["Возможно использование сертификата, не связанного с записью сильным идентификатором, для аутентификации от её имени."],"attack":[],"remediation":["Переведите сопоставления на надёжные форматы и проверьте StrongCertificateBindingEnforcement, режим совместимости и сертификаты."]},"ESC14_WRITABLE_MAPPING":{"description":"Непривилегированный субъект имеет право изменять altSecurityIdentities у привилегированной учётной записи.","impact":["При недостаточно строгом сопоставлении сертификатов изменение атрибута может позволить вход от имени целевой записи."],"attack":[],"remediation":["Удалите лишние права записи altSecurityIdentities, проверьте наследование ACE и строгую привязку сертификатов."]},"ESC13_ISSUANCE_POLICY_GROUP_LINK":{"description":"Политика выдачи сертификата связана с группой AD. Выдача сертификата с соответствующим OID может влиять на членство или предоставляемые полномочия в сценариях ESC13.","impact":["При недостаточном контроле прав регистрации сертификат может дать права, связанные с привилегированной группой."],"attack":[],"remediation":["Проверьте связь OID с группами, права регистрации, EKU и согласование выпуска сертификатов."]},"ADCS_CA_WEAK_SIGNATURE":{"description":"Сертификат центра сертификации подписан алгоритмом, не отвечающим современным требованиям криптографической стойкости.","impact":["Слабый алгоритм ухудшает доверие к цепочке сертификатов и может повышать риск криптографической атаки."],"attack":[],"remediation":["Планируйте перевыпуск сертификатов ЦС со стойким алгоритмом и заранее проверяйте совместимость клиентов и цепочки доверия."]},"ADCS_CA_SHORT_KEY":{"description":"У сертификата центра сертификации недостаточная длина открытого ключа для действующих требований организации.","impact":["Криптографическая стойкость сертификата ЦС и всей цепочки доверия может оказаться ниже допустимой."],"attack":[],"remediation":["Планируйте обновление ключевой пары и сертификата ЦС, соблюдая процедуру миграции и сохранения доверия."]},"ADCS_CA_CERT_EXPIRED":{"description":"Срок действия сертификата центра сертификации истёк. Продолжение доверия к такой цепочке зависит от контекста проверки, времени подписи и политики приложений.","impact":["Новые операции выпуска или проверки сертификатов могут нарушаться; часть цепочек перестанет приниматься клиентами."],"attack":[],"remediation":["Проверьте статус ЦС, цепочки и CRL, организуйте плановый перевыпуск сертификата."]},"ADCS_CA_CROSS_DOMAIN":{"description":"Сервер центра сертификации размещён в другом домене относительно анализируемой области. Это не всегда уязвимость и требует проверки границ доверия.","impact":["Права управления и регистрация сертификатов могут зависеть от другой административной зоны."],"attack":[],"remediation":["Уточните владельцев ЦС, применимость политик выдачи, доверие и делегированные права между доменами."]},"PRIVILEGED_ACCOUNT_ACL":{"description":"На привилегированной учётной записи найдено разрешение, позволяющее стороннему субъекту управлять её безопасностью или чувствительными атрибутами.","impact":["WriteDACL, WriteOwner, GenericAll, сброс пароля или запись чувствительного атрибута могут привести к захвату Tier 0."],"attack":[],"remediation":["Проверьте конкретный ACE, наследование и администраторов защищённой записи; отзовите несанкционированные права."]},"NTAUTH_FOREIGN_ISSUER":{"description":"Хранилище NTAuth содержит издателя сертификатов, не относящегося к ожидаемым корпоративным ЦС данного леса.","impact":["В зависимости от настроек удостоверения от такого издателя могут использоваться для доменной аутентификации."],"attack":[],"remediation":["Проверьте происхождение сертификата, необходимость межлесного доверия и согласованность с политикой выдачи."]},"PKI_WEAK_SIGNATURE_ALGORITHM":{"description":"В обнаруженном сертификате PKI используется устаревший или недостаточно стойкий алгоритм подписи.","impact":["Цепочка доверия может не соответствовать современным требованиям и блокироваться клиентами."],"attack":[],"remediation":["Перевыпустите сертификат со стойким алгоритмом, проверив совместимость приложений и цепочек."]},"PKI_SHORT_KEY_LENGTH":{"description":"Длина ключа сертификата PKI ниже установленного порога стойкости.","impact":["Снижается запас криптографической прочности сертификата в пределах его назначения."],"attack":[],"remediation":["Обновите ключевую пару и сертификат с допустимыми параметрами и согласуйте переход со всеми зависимыми службами."]},"PKI_CERTIFICATE_EXPIRED":{"description":"Сертификат PKI просрочен и может не проходить проверку по времени действия.","impact":["TLS, аутентификация и иные криптографические операции могут завершаться ошибкой."],"attack":[],"remediation":["Перевыпустите сертификат и проверьте полную цепочку доверия и доступность CRL/OCSP."]},"COMPUTER_CONTAINER_CREATE_BROAD":{"description":"Широкая группа пользователей может создавать объекты компьютеров в контейнере или OU.","impact":["Новые машинные записи при дополнительных условиях могут участвовать в атаках с делегированием и ретрансляцией."],"attack":["1. Любой участник группы создаёт учётную запись компьютера в контейнере.","2. Задаёт её пароль и получает контролируемую машинную идентичность.","3. Записывает msDS-AllowedToActOnBehalfOfOtherIdentity на целевом компьютере.","4. Запрашивает служебный билет от имени привилегированного пользователя для этого компьютера."],"remediation":["Ограничьте CreateChild для класса computer и проверяйте ms-DS-MachineAccountQuota и SeMachineAccountPrivilege."]},"BLOODHOUND_COLLECTION_COMPLETE":{"description":"Сбор данных для графового анализа AD завершён. Наличие этого информационного результата не означает обнаружение конкретной уязвимости.","impact":["Собранные связи прав и членства помогают выявлять цепочки повышения привилегий; сами результаты могут содержать чувствительные сведения."],"attack":["BloodHound — защитный инструмент для выявления путей атаки.","Нарушители также используют BloodHound для разведки.","Понимание собственной поверхности атаки помогает определять приоритеты устранения рисков."],"remediation":["Храните выгрузку в защищённом месте и проверяйте выявленные пути повышения привилегий отдельно."]},"LDAP_SIGNING_REQUIRED":{"description":"На контроллерах домена требуется цифровая подпись LDAP, которая защищает целостность сообщений при соответствующих типах связки.","impact":["Снижается риск подмены данных LDAP и части атак с ретрансляцией аутентификации."],"attack":[],"remediation":["Сохраняйте обязательную подпись и контролируйте исключения для устаревших клиентов."]},"LDAP_CHANNEL_BINDING_ALWAYS":{"description":"Для LDAP поверх TLS обязательно проверяется привязка канала (Channel Binding), сопоставляющая аутентификацию с текущим TLS-сеансом.","impact":["Снижается риск ретрансляции аутентификации в LDAPS при корректной поддержке клиентами."],"attack":[],"remediation":["Сохраняйте строгое требование и проверяйте журналы несовместимых LDAP-клиентов."]},"ANONYMOUS_SAM_ENUMERATION_ALLOWED":{"description":"Политика безопасности допускает анонимное перечисление некоторых данных SAM и общих ресурсов.","impact":["Неаутентифицированные субъекты могут получать сведения, полезные для разведки сети."],"attack":["1. Нарушитель открывает анонимный сеанс (null session) с компьютером в области действия политики.","2. Перечисляет локальные учётные записи и общие ресурсы.","3. Использует найденные имена для распыления паролей (password spraying) или поиска доступных общих ресурсов."],"remediation":["Запретите ненужное анонимное перечисление после проверки совместимости старых приложений."]},"ENROLLMENT_REQUIRES_APPROVAL":{"description":"Для регистрации сертификата по шаблону требуется одобрение уполномоченным администратором ЦС.","impact":["Ручная проверка уменьшает риск автоматического выпуска сертификата в опасных сценариях ESC, но не заменяет контроль прав и EKU."],"attack":["Когда включён PEND_ALL_REQUESTS, нарушители не могут:","— автоматически получать сертификаты;","— незаметно использовать уязвимости, связанные с регистрацией сертификатов;","— запрашивать сертификаты без ведома администратора."],"remediation":["Поддерживайте процедуру одобрения, разделение обязанностей и аудит выдачи сертификатов."]},"SMARTCARD_REQUIRED":{"description":"Для интерактивного входа учётной записи требуется смарт-карта; использование обычного пароля для такого входа ограничено соответствующей настройкой.","impact":["Снижается риск входа только по украденному паролю в предусмотренных сценариях; остаются риски ключей, сертификатов и исключений."],"attack":[],"remediation":["Сохраняйте защиту, проверяйте жизненный цикл сертификатов и совместимость приложений и служб."]},"ACCOUNT_NOT_DELEGATED":{"description":"Учётная запись помечена как конфиденциальная и не допускает делегирования Kerberos.","impact":["Снижается риск передачи её пересылаемого билета службам с делегированием."],"attack":["Если установлен флаг NOT_DELEGATED, нарушитель не может:","— выдавать себя за эту учётную запись через серверы с настроенным делегированием;","— применять перехваченные TGT для атак S4U2Self/S4U2Proxy;","— использовать RBCD для доступа к ресурсам от имени этой записи;","— злоупотреблять неограниченным делегированием для кражи TGT этой записи."],"remediation":["Сохраняйте запрет делегирования для привилегированных записей и применяйте дополнительные защитные меры."]},"WEB_ENDPOINT_EPA_ENABLED":{"description":"Для веб-службы включена расширенная защита проверки подлинности (Extended Protection for Authentication, EPA).","impact":["Привязка аутентификации к каналу снижает часть рисков NTLM Relay в защищаемом сценарии."],"attack":[],"remediation":["Сохраняйте EPA и корректный TLS; проверяйте настройки балансировщиков и обратных прокси."]},"PKI_STRONG_SIGNATURE_ALGORITHM":{"description":"В сертификате PKI используется алгоритм подписи, удовлетворяющий установленному порогу криптографической стойкости.","impact":["Недостаточная стойкость алгоритма подписи в этой проверке не выявлена."],"attack":[],"remediation":["Поддерживайте современную криптографию и отслеживайте будущие изменения требований."]},"PKI_STRONG_KEY_LENGTH":{"description":"Длина ключа сертификата PKI соответствует проверяемому порогу стойкости.","impact":["Недостаточная длина ключа в этой проверке не выявлена."],"attack":[],"remediation":["Соблюдайте процедуру ротации ключей и поддерживайте допустимые параметры при перевыпуске."]},"LOCKOUT_DURATION_FOREVER":{"description":"Политика блокировки требует ручной разблокировки учётной записи администратором после достижения порога неудачных входов.","impact":["Это препятствует дальнейшим попыткам входа, но может создавать риск отказа в обслуживании через намеренные блокировки."],"attack":[],"remediation":["Оцените баланс безопасности и доступности, включите мониторинг неудачных входов и регламент разблокировки."]},"PRIMARY_GROUP_IS_DC_GROUP":{"description":"У учётной записи, которая не является штатным контроллером домена, первичная группа соответствует группе контроллеров домена.","impact":["Некорректная primaryGroupID может давать неожиданное членство или указывать на опасное изменение записи."],"attack":[],"remediation":["Проверьте класс объекта, назначение primaryGroupID и происхождение изменения; восстановите штатную группу после расследования."]},"TOMBSTONE_LIFETIME_SHORT":{"description":"Период хранения удалённых объектов в AD меньше 180 дней. Параметр влияет на допустимое время восстановления и работу репликации после длительных простоев DC.","impact":["Слишком короткий срок уменьшает окно восстановления и повышает риск проблем с давно отключёнными контроллерами."],"attack":[],"remediation":["Согласуйте tombstoneLifetime с политикой резервного копирования и восстановления; проверьте репликацию."]},"PREWIN2000_ANONYMOUS_MEMBER":{"description":"В группу Pre-Windows 2000 Compatible Access включён Anonymous Logon.","impact":["Неаутентифицированные субъекты могут получить расширенный доступ к сведениям каталога при соответствующих ACL."],"attack":[],"remediation":["Удалите анонимное членство, если оно не требуется совместимости; проверьте сопутствующие разрешения."]},"PREWIN2000_BROAD_MEMBER":{"description":"В Pre-Windows 2000 Compatible Access присутствует широкая группа пользователей или компьютеров.","impact":["Повышается круг субъектов, способных читать данные каталога, используемые для разведки."],"attack":[],"remediation":["Пересмотрите состав группы и необходимость широких назначений с проверкой влияния на приложения."]},"ANON_LDAP_READABLE_ATTRS":{"description":"Некоторые атрибуты каталога можно читать через анонимный LDAP-запрос.","impact":["Сведения о пользователях или инфраструктуре могут быть раскрыты без учётных данных."],"attack":[],"remediation":["Сузьте права анонимного чтения и проверьте необходимость совместимости с устаревшими приложениями."]},"LAPS_UNPROTECTED_COMPUTERS":{"description":"В домене обнаружены компьютеры, для которых не подтверждено управление паролем локального администратора через LAPS.","impact":["Повторно используемые локальные пароли могут облегчать распространение атаки между машинами."],"attack":[],"remediation":["Обеспечьте охват LAPS, корректность GPO и доступность управляемой учётной записи."]},"LAPS_COVERAGE_NOT_IN_AD":{"description":"По атрибутам Active Directory нельзя однозначно определить, защищён ли компьютер LAPS. Некоторые настройки и состояния требуют проверки на клиенте.","impact":["Отсутствие атрибутов не всегда доказывает отсутствие защиты, поэтому возможна неопределённость оценки."],"attack":[],"remediation":["Сопоставьте данные AD с событиями Windows LAPS и реальными настройками управляемых компьютеров."]},"LAPS_GPO_PASSWORD_LENGTH":{"description":"Политика LAPS задаёт длину локального пароля ниже ожидаемого порога.","impact":["Короткий пароль увеличивает вероятность угадывания и автономного подбора после раскрытия его материала."],"attack":[],"remediation":["Увеличьте длину пароля LAPS и проверьте поддержку выбранных параметров всеми клиентами."]},"LAPS_GPO_PASSWORD_AGE":{"description":"Интервал ротации локального пароля LAPS превышает рекомендованный или стандартный срок.","impact":["Один пароль используется дольше, что увеличивает период потенциальной пригодности раскрытого секрета."],"attack":[],"remediation":["Сократите срок действия и проверьте работоспособность автоматической ротации."]},"LAPS_GPO_NO_POST_AUTH_RESET":{"description":"Windows LAPS не настроен на автоматический сброс локального пароля после применения управляемой учётной записи.","impact":["Полученный административный пароль может оставаться действительным после завершения обслуживания."],"attack":[],"remediation":["Рассмотрите политики сброса после аутентификации, обеспечив совместимость с процедурами техподдержки."]},"GMSA_ROTATION_INTERVAL_LONG":{"description":"У gMSA задан чрезмерно длинный интервал обновления управляемого пароля.","impact":["Раскрытый секрет gMSA может оставаться пригодным дольше обычного."],"attack":["1. Получает msDS-ManagedPassword записи gMSA (см. находки о доступе к управляемому паролю).","2. Выводит ключи Kerberos из BLOB и аутентифицируется как служба.","3. Продолжает это до истечения интервала ротации; при 365 днях — до года."],"remediation":["Пересмотрите интервал ротации с учётом сервисных зависимостей и планового обслуживания."]},"GMSA_MEMBERSHIP_OWNER":{"description":"Владельцем дескриптора разрешений получения пароля gMSA указан субъект вне доверенной административной области.","impact":["Владелец может влиять на DACL доступа к управляемому паролю и расширить список получателей."],"attack":["1. Получает контроль над владельцем msDS-GroupMSAMembership.","2. Изменяет дескриптор, предоставляя себе ReadProperty.","3. Читает msDS-ManagedPassword и выводит ключи Kerberos учётной записи.","4. Аутентифицируется как gMSA, после чего восстанавливает дескриптор."],"remediation":["Проверьте владельца и ACE msDS-GroupMSAMembership, восстановите ожидаемую модель доступа."]},"AUTHN_SILO_NOT_EFFECTIVE":{"description":"Authentication Policy Silo создан, но не содержит эффективного ограничения для нужных записей либо не применяется.","impact":["Предполагаемое разделение административных учётных записей не обеспечивается."],"attack":[],"remediation":["Проверьте назначения пользователей и компьютеров в silo и обязательный режим политик."]},"AUTHN_SILO_INCOMPLETE_ENROLLMENT":{"description":"Назначенная учётная запись не завершила включение в Authentication Policy Silo, поэтому ожидаемые ограничения могут не действовать.","impact":["Вход с незащищённых машин может оставаться возможным вопреки модели Tier."],"attack":[],"remediation":["Проверьте фактическое назначение silo и события KDC; исправьте состав и режим применения."]},"AUTHN_POLICY_EXEMPT_ADMINISTRATOR":{"description":"Встроенная запись Administrator (RID 500) затрагивается политикой проверки подлинности особым образом; её фактическая применимость требует отдельной проверки.","impact":["Неправильное ожидание ограничений для RID 500 может оставить путь административного входа открытым."],"attack":[],"remediation":["Проверьте документированные исключения и реальные события проверки входа для встроенной записи."]},"AUTHN_POLICY_NOT_EFFECTIVE":{"description":"Authentication Policy настроена только на аудит либо не применяется в обязательном режиме.","impact":["Нарушения политики могут регистрироваться, но не блокировать входы."],"attack":[],"remediation":["После проверки совместимости переведите ограничения из аудита в принудительное применение."]},"AUTHN_POLICY_BROAD_CONDITION":{"description":"Условие Authentication Policy допускает слишком широкую группу компьютеров или субъектов для входа.","impact":["Административная запись может пройти аутентификацию на менее защищённом узле."],"attack":[],"remediation":["Ограничьте условие доверенными станциями и серверами нужного уровня безопасности."]},"AUTHN_POLICY_OBJECT_WRITABLE":{"description":"Объект Authentication Policy или Policy Silo доступен для изменения субъекту вне доверенной административной области.","impact":["Нарушитель с таким правом может ослабить ограничения входа для привилегированных записей."],"attack":["1. Использует право записи, чтобы установить msDS-AuthNPolicySiloEnforced (либо msDS-AuthNPolicyEnforced) в FALSE или ослабить условие политики.","2. Дожидается входа учётной записи Tier 0 с компьютера под контролем нарушителя.","3. Похищает её учётные данные на этом компьютере."],"remediation":["Удалите избыточные ACE и владельцев, проверьте наследование и аудит изменений объектов политики."]},"AUTHN_KDC_ARMORING_NOT_SUPPORTED":{"description":"В инфраструктуре не обеспечена поддержка необходимых механизмов Kerberos Armoring и claims на всех контроллерах домена.","impact":["Часть политик аутентификации и защиты FAST может работать неполно или в режиме совместимости."],"attack":[],"remediation":["Проверьте функциональный уровень, версии DC и настройку KDC; тестируйте включение Armoring с учётом клиентов."]},"DMSA_LINK_IRREGULAR":{"description":"Связь исходной служебной записи с dMSA обнаружена вне ожидаемой процедуры миграции.","impact":["Необычное связывание способно создать непредусмотренный доступ к сервисным учётным данным и полномочиям."],"attack":["1. Получает контроль над dMSA: создаёт новую либо имеет право записи на существующую.","2. При наличии права записи целевой записи задаёт обе стороны связи: msDS-ManagedAccountPrecededByLink у dMSA и msDS-SupersededManagedAccountLink у целевой записи.","3. Запрашивает билет для dMSA: он содержит членства замещённой записи в группах, а пакет ключей dMSA содержит её ключи."],"remediation":["Сопоставьте обе записи и разрешения миграции с утверждённой процедурой, изучите историю изменений атрибутов."]},"DMSA_LINK_ONE_SIDED":{"description":"Атрибуты связи между dMSA и предшествующей записью заполнены только в одном направлении.","impact":["Неконсистентность может свидетельствовать о незавершённой миграции или неправомерном изменении и привести к ошибкам службы."],"attack":["1. Управляет dMSA и направляет её msDS-ManagedAccountPrecededByLink на цель — это уже установленная сторона связи.","2. Получает право записи целевой записи и задаёт msDS-SupersededManagedAccountLink на dMSA.","3. Запрашивает билет dMSA: он содержит членства целевой записи в группах, а пакет ключей — её ключи."],"remediation":["Проверьте состояние миграции, соответствующие LDAP-атрибуты и репликацию; устраните расхождение безопасным штатным способом."]},"DMSA_PRIVILEGED_PREDECESSOR":{"description":"У dMSA в качестве предшественника указана привилегированная учётная запись.","impact":["При небезопасной процедуре миграции доступ к dMSA может унаследовать чувствительные полномочия старой записи."],"attack":["1. Захватывает узел, которому разрешено использовать dMSA, либо получает право записи её msDS-GroupMSAMembership.","2. Получает билет для dMSA с членствами предшествующей записи в группах."],"remediation":["Проверьте законность миграции, права исходной записи и круг субъектов, способных использовать dMSA."]},"DMSA_USABLE_BY_NONPRIVILEGED":{"description":"Непривилегированный субъект имеет право использовать dMSA либо получать необходимые для службы секреты.","impact":["Возможна аутентификация в контексте управляемой службы с расширенными правами."],"attack":["1. Аутентифицируется как субъект, указанный в msDS-GroupMSAMembership.","2. Используя собственный билет этого субъекта, запрашивает билет для dMSA.","3. Использует его с членствами в группах той записи, которую заменила dMSA."],"remediation":["Ограничьте получение пароля и использование dMSA только доверенными машинами и соответствующими сервисами."]},"DMSA_MEMBERSHIP_OWNER":{"description":"Владельцем дескриптора доступа к dMSA является непривилегированный субъект.","impact":["Владелец обычно может изменять ACL дескриптора и добавить новых субъектов доступа."],"attack":["1. Получает контроль над владельцем дескриптора msDS-GroupMSAMembership.","2. Изменяет дескриптор, добавляя собственный субъект.","3. Запрашивает билет для dMSA, после чего восстанавливает дескриптор."],"remediation":["Верните штатного владельца и проверьте все ACE, связанные с использованием dMSA."]},"GMSA_MEMBERSHIP_INFO":{"description":"Объект содержит сведения о субъектах, уполномоченных получать пароль gMSA.","impact":["Это информационный контекст для проверки делегирования секретов службы."],"attack":[],"remediation":["Проверяйте перечень доверенных компьютеров и групп получателей, не рассматривая одно наличие записи как нарушение."]},"ACL_INHERITED_FROM":{"description":"Указан родительский контейнер, из которого объект унаследовал ACE.","impact":["Удаление только унаследованного ACE с дочернего объекта может не устранить источник опасного разрешения."],"attack":[],"remediation":["Анализируйте ACL родителя и область наследования до изменения DACL."]},"ADMIN_COUNT_INDICATOR":{"description":"У объекта установлен adminCount=1 без подтверждённого членства в защищённой группе. Значение может остаться после исключения из группы.","impact":["Отключённое наследование и особые DACL могут сохраняться даже после снятия привилегий."],"attack":[],"remediation":["Проверьте реальное членство и, если защита больше не нужна, восстановите согласованное наследование и атрибут adminCount."]},"LAPS_ACCOUNT_INFO":{"description":"Отображается учётная запись локального администратора, управляемая LAPS; статус носит справочный характер.","impact":["Сведения помогают сопоставить политику ротации с фактическим локальным администратором."],"attack":[],"remediation":["Проверьте соответствие имени управляемой записи настройкам LAPS и не публикуйте пароль в отчётах."]},"DANGEROUS_RIGHTS_SEVERITY":{"description":"Поле классифицирует опасность обнаруженных разрешений в зависимости от их типа и контекста объекта.","impact":["Классификация помогает расставить приоритеты, но не является самостоятельной ACL-проверкой."],"attack":[],"remediation":["Сопоставляйте уровень риска с реальной областью действия, наследованием и привилегиями субъекта."]},"DANGEROUS_RIGHTS_AFFECTED_OUS":{"description":"Поле содержит организационные единицы и контейнеры, на которые распространяется найденное опасное разрешение.","impact":["Широкая область действия увеличивает число потенциально затронутых учётных записей."],"attack":[],"remediation":["При устранении учитывайте все OU и контейнеры, включая наследуемые области."]},"ADCS_CLIENT_AUTH_SEVERITY":{"description":"Поле указывает наличие EKU для проверки подлинности клиента и контекст риска шаблона сертификата.","impact":["Такой EKU сам по себе допустим, но при сочетании с небезопасными настройками регистрации возможна подмена личности."],"attack":[],"remediation":["Проверьте права регистрации, одобрение, управление субъектом и связь шаблона с другими условиями ESC."]},"ADCS_MANAGER_APPROVAL":{"description":"Поле описывает необходимость ручного одобрения менеджером ЦС при регистрации сертификата.","impact":["Одобрение снижает вероятность неконтролируемой выдачи, но не заменяет настройку EKU и прав."],"attack":[],"remediation":["Проверяйте уполномоченных утверждающих лиц и журнал выдачи сертификатов."]},"CERT_FLAG_SEVERITY":{"description":"Информационное поле классифицирует влияние флагов шаблона сертификата на безопасность.","impact":["Некоторые флаги допускают заявителю указывать субъекта или влияют на расширения безопасности."],"attack":[],"remediation":["Оценивайте флаги совместно с EKU, правами записи и регистрации."]},"EXCHANGE_WEB_ENDPOINTS":{"description":"Информационный результат описывает защищённость доступных веб-служб Exchange, включая проверки HTTPS и механизмов аутентификации.","impact":["Недостаточная защита веб-служб может позволять утечки или атаки с ретрансляцией при дополнительных условиях."],"attack":["1. Принуждает доменную или машинную запись к аутентификации либо перехватывает такую аутентификацию.","2. Ретранслирует её на конечную точку Exchange, предоставляющую NTLM без привязки к каналу TLS.","3. Действует от имени ретранслированной записи: читает почту через EWS либо вызывает методы другой конечной точки, например MRSProxy.","4. Компрометированный таким образом Exchange даёт доступ ко всем почтовым ящикам, а через права Exchange в каталоге часто и к домену."],"remediation":["Поддерживайте TLS и EPA, отключайте неиспользуемые конечные точки и ограничивайте внешнюю публикацию."]},"CONSTRAINED_DELEGATION":{"description":"Для учётной записи настроено ограниченное делегирование Kerberos к перечисленным службам.","impact":["При правильной настройке оно допустимо, но чрезмерный перечень SPN или переход протокола расширяет поверхность атаки."],"attack":[],"remediation":["Проверьте msDS-AllowedToDelegateTo, флаги protocol transition и необходимость каждого назначения."]},"LAPS_INSTALLED":{"description":"В среде обнаружены признаки установки и использования Windows LAPS.","impact":["Это информационный признак; фактическую защиту определяют политика, охват и успешная ротация пароля."],"attack":[],"remediation":["Проверьте состояние агента на клиентах и назначение GPO, получателей и срок действия паролей."]},"LAPS_LEGACY":{"description":"Используется прежняя реализация Microsoft LAPS либо её атрибуты.","impact":["Старая инфраструктура может оставаться рабочей, но не поддерживает все возможности Windows LAPS."],"attack":[],"remediation":["Проверьте поддержку используемого агента и планируйте согласованный переход на Windows LAPS."]},"META_SEVERITY_PASSTHROUGH":{"description":"Служебное поле передаёт класс опасности находки для отображения.","impact":["Это метаданные отчёта, а не отдельная уязвимость."],"attack":[],"remediation":["Оставьте классификацию неизменной и не интерпретируйте её как новое обнаружение."]},"META_STATUS_INDICATOR":{"description":"Служебное поле отображает состояние проверки или объекта.","impact":["Статус помогает понимать результат, но не создаёт самостоятельной находки."],"attack":[],"remediation":["Сверяйте статус с исходными данными проверки."]},"CREDENTIAL_USERNAME_EXPOSED":{"description":"В найденном фрагменте раскрыто имя пользователя или служебной записи.","impact":["Само имя может не быть секретом, но в сочетании с паролем облегчает злоупотребление."],"attack":[],"remediation":["Проверьте источник и минимизируйте распространение имени вместе с секретом."]},"CREDENTIAL_PASSWORD_EXPOSED":{"description":"В найденном фрагменте обнаружена строка, похожая на пароль в открытом виде.","impact":["При подтверждении действующего секрета субъект с доступом к файлу может использовать его для входа."],"attack":[],"remediation":["Проверьте совпадение безопасным способом, затем удалите раскрытие и смените подтверждённый пароль."]},"CREDENTIAL_MATCHED_LINE":{"description":"Поле показывает строку, в которой обнаружен потенциальный секрет.","impact":["Такая строка сама по себе может раскрывать пароль и требует защищённого обращения с отчётом."],"attack":[],"remediation":["Не публикуйте значение в открытых документах; проверьте источник и выполните ротацию подтверждённых секретов."]},"CREDENTIAL_TYPE_INFO":{"description":"Поле описывает тип обнаруженных учётных данных — пароль, ключ или имя пользователя.","impact":["Классификация помогает определить порядок проверки и устранения."],"attack":[],"remediation":["Подтвердите тип и актуальность секрета перед изменениями."]},"LAPS_ENCRYPTED_PASSWORD":{"description":"В отчёте обнаружен зашифрованный пароль Windows LAPS, но отсутствие права расшифрования не позволяет получить его открытое значение.","impact":["Чтение шифротекста без ключа не означает компрометации локального пароля."],"attack":[],"remediation":["Проверьте доверенных получателей ключей и ACL чтения, не трактуйте шифротекст как открытый пароль."]},"NON_DEFAULT_OWNER":{"description":"У объекта AD установлен владелец, отличный от ожидаемого для данного типа и способа создания.","impact":["Владелец обычно может корректировать DACL и расширять разрешения на объект."],"attack":[],"remediation":["Проверьте историю и обоснованность владения, восстановите штатную модель при отклонении."]},"ENCRYPTION_RC4_ONLY":{"description":"Учётная запись Kerberos поддерживает только RC4 либо фактически не использует более стойкие AES-типы.","impact":["Слабый тип шифрования облегчает автономный подбор пароля по захваченным билетам в некоторых сценариях."],"attack":["1. Запрашивает служебный билет для записи (Kerberoasting); тип шифрования билета определяется этим атрибутом.","2. Извлекает RC4-хеш ($krb5tgs$23$...) и подбирает пароль автономно со скоростью RC4.","3. Получает пароль этой записи и доступ ко всем ресурсам в пределах её полномочий."],"remediation":["Настройте AES после проверки поддержки приложений и смены необходимого ключевого материала."]},"ENCRYPTION_DES_ENABLED":{"description":"Для учётной записи разрешён устаревший алгоритм DES в Kerberos.","impact":["DES имеет недостаточную криптографическую стойкость и не должен использоваться для современной аутентификации."],"attack":["1. Запрашивает и перехватывает билет для учётной записи.","2. Перебирает 56-битный ключ DES — это атака с известным открытым текстом на зашифрованную часть, а не подбор пароля.","3. Расшифровывает билет либо подделывает новый с восстановленным ключом."],"remediation":["Уберите DES, обновите учётные данные и проверьте совместимость служб."]},"ENCRYPTION_NOT_CONFIGURED":{"description":"Типы шифрования у записи с SPN явно не заданы, поэтому KDC использует настройки и умолчания домена и учётной записи.","impact":["Неоднозначность может привести к применению RC4 в зависимости от конфигурации."],"attack":["1. Запрашивает служебный билет для записи с предпочтением RC4 (Rubeus по умолчанию делает это при /rc4opsec).","2. Если KDC выдаёт такой билет, подбирает пароль автономно со скоростью, характерной для RC4."],"remediation":["Проверьте фактические Kerberos-билеты и настройте допустимые AES-типы с учётом совместимости."]},"ENCRYPTION_AES_ONLY":{"description":"Учётная запись Kerberos настроена на использование AES без устаревших RC4/DES в пределах проверяемой конфигурации.","impact":["Снижается риск некоторых атак на слабые криптографические алгоритмы."],"attack":[],"remediation":["Поддерживайте AES и следите за фактически выдаваемыми билетами."]},"KERBEROASTABLE_USER_SPN":{"description":"Пользовательская запись имеет SPN и может получать служебные билеты TGS, шифруемые её ключом.","impact":["При слабом пароле полученный билет подходит для автономного подбора; риск зависит от криптографии и привилегий."],"attack":[],"remediation":["Используйте длинный случайный секрет, AES и gMSA там, где это возможно."]},"DANGEROUS_RIGHTS_CONTEXT":{"description":"Поле поясняет, почему определённый набор ACE или прав считается опасным с учётом объекта и области действия.","impact":["Одно и то же разрешение может быть допустимым для штатного администратора и критичным для постороннего субъекта."],"attack":["1. Нарушитель компрометирует низкопривилегированного пользователя с GenericAll на группе Domain Admins.","2. Через Add-DomainGroupMember добавляет контролируемую запись в Domain Admins.","3. Альтернативно WriteDACL позволяет добавить ACE с полным доступом нарушителя.","4. WriteOwner позволяет завладеть чувствительными объектами, например AdminSDHolder и GPO.","5. ForceChangePassword позволяет сбросить пароль привилегированной учётной записи."],"remediation":["Сверяйте значение с фактическими правами и административными обязанностями."]},"GPO_SCOPE_SEVERITY":{"description":"Поле классифицирует риск параметра или разрешения GPO на основании её области применения.","impact":["Политика, затрагивающая DC и широкий круг компьютеров, имеет более значимые последствия."],"attack":[],"remediation":["Проверяйте связи GPO и фактическую фильтрацию безопасности."]},"GPO_LOCAL_GROUP_RISKY_MEMBER":{"description":"Через GPO широкая группа добавляется в чувствительную локальную группу, например Administrators.","impact":["Многие пользователи могут получить высокие полномочия на машинах области действия."],"attack":["1. Как обычный пользователь домена читает назначение из SYSVOL: GptTmpl.inf либо Groups.xml доступны широкому кругу субъектов.","2. Определяет компьютеры, к которым привязана GPO.","3. Аутентифицируется на одном из них любой доменной записью, которая уже является участником через широкую группу.","4. Использует полученные права: извлекает учётные данные как локальный администратор, читает SAM как оператор резервного копирования либо входит интерактивно."],"remediation":["Уберите широкие назначения и используйте ограниченные группы управления."]},"GPO_LOCAL_GROUP_MEMBER":{"description":"GPO добавляет указанную запись или группу в локальную привилегированную группу компьютеров.","impact":["Такое назначение расширяет административные возможности на целевых узлах."],"attack":["1. Как обычный пользователь домена читает назначение в SYSVOL: GptTmpl.inf и Groups.xml доступны всем для чтения.","2. Определяет компьютеры, к которым привязана GPO.","3. Захватывает указанный субъект: подбирает или выманивает пароль, сбрасывает пароль делегированным правом либо добавляет участника в группу.","4. Входит на компьютеры в области действия с правами этой группы."],"remediation":["Сопоставьте назначение с задачами администратора и минимизируйте состав."]},"GPO_TASK_FIELD_SEVERITY":{"description":"Поле указывает риск отдельных параметров запланированного задания GPO: пути, контекста запуска и доступности файла.","impact":["Опасность зависит от сочетания привилегий и возможности изменить выполняемый файл."],"attack":[],"remediation":["Проверяйте все параметры задания и ACL исполняемого пути."]},"GPO_LINKED_OUS_SEVERITY":{"description":"GPO связана с корнем домена или важной OU, что влияет на классификацию риска.","impact":["Ошибочные настройки могут затронуть контроллеры домена или многие компьютеры."],"attack":[],"remediation":["Уточните область применения и ограничьте редактирование политики."]},"WEB_ENDPOINT_SECURITY":{"description":"Служебное поле описывает состояние безопасности веб-службы по результатам проверок аутентификации и транспорта.","impact":["Недостаточная защита веб-конечной точки может повысить риск перехвата или ретрансляции."],"attack":[],"remediation":["Проверьте HTTPS, EPA и доступность службы; само поле не является отдельной уязвимостью."]},"REGISTRY_ONELOGON":{"description":"Через GPO задано небезопасное значение или список разрешений для защищённого канала Netlogon, связанного с устранением уязвимостей Zerologon/OneLogon.","impact":["Неверная политика может ослабить проверку защищённого канала контроллеров домена."],"attack":[],"remediation":["Сверьте настройку с текущими рекомендациями Microsoft и исправлениями Netlogon; удалите унаследованные исключения."]},"REGISTRY_AUTOLOGON":{"description":"В GPO включён автоматический вход AutoAdminLogon. В зависимости от конфигурации секреты могут храниться в локальном реестре.","impact":["Пароль автоматического входа может быть получен субъектом с доступом к настройкам машины."],"attack":[],"remediation":["Отключите автоматический вход там, где он не требуется, и исключите хранение открытых секретов."]},"REGISTRY_NOLMHASH":{"description":"Политика допускает сохранение устаревших LM-хешей паролей при определённых условиях.","impact":["LM-хеш существенно слабее современного NT-хеша и повышает риск восстановления пароля."],"attack":[],"remediation":["Запретите сохранение LM-хешей и проверьте обновление паролей существующих записей."]},"REGISTRY_REMOTEUAC":{"description":"Через GPO отключена фильтрация локальных административных токенов для удалённых подключений (Remote UAC).","impact":["Локальная административная запись может получать полный административный токен при удалённом доступе."],"attack":[],"remediation":["Верните фильтрацию Remote UAC и используйте индивидуальные административные записи."]},"REGISTRY_RESTRICTEDADMIN":{"description":"Через GPO включён режим RDP Restricted Admin, который позволяет определённые типы входа без передачи пароля удалённому хосту.","impact":["Режим уменьшает экспозицию пароля на целевом хосте, но при определённых условиях может облегчать использование уже украденного NTLM-хеша для RDP."],"attack":[],"remediation":["Оцените необходимость Restricted Admin, ограничьте RDP и используйте современные защитные меры аутентификации."]},"REGISTRY_FILTERADMINTOKEN":{"description":"Групповая политика отключает режим одобрения администратора для встроенной записи Administrator (RID 500), ослабляя механизмы UAC.","impact":["Операции под встроенным администратором могут выполняться без ожидаемого повышения прав и дополнительных подтверждений."],"attack":[],"remediation":["Включите фильтрацию токена для встроенного администратора, проверьте совместимость приложений и используйте отдельные административные записи."]},"REGISTRY_MACHINE_PASSWORD_STATIC":{"description":"Через GPO отключена штатная смена пароля машинной учётной записи компьютера.","impact":["Неизменный машинный секрет повышает окно компрометации и создаёт проблемы с безопасным каналом."],"attack":[],"remediation":["Верните автоматическую ротацию, проверьте состояние защищённого канала и исключения для специальных устройств."]},"REGISTRY_NULL_SESSION":{"description":"Настройки GPO расширяют доступ через анонимные SMB/LSA Null Session соединения.","impact":["Без проверки подлинности может раскрываться перечень пользователей, ресурсов и других сведений, доступных в текущем контексте."],"attack":[],"remediation":["Отключите ненужные анонимные именованные каналы и общие ресурсы, проверив устаревшие зависимости."]},"REGISTRY_RDP_SECURITYLAYER":{"description":"Уровень безопасности RDP, заданный политикой, допускает менее защищённый режим соединения, чем ожидаемый TLS.","impact":["Могут снижаться гарантии защиты канала и проверки подлинности удалённого узла."],"attack":[],"remediation":["Включите безопасный уровень RDP и NLA, проверьте сертификаты и совместимость клиентов."]},"REGISTRY_RDP_ENCRYPTION":{"description":"Через GPO для RDP задан слабый уровень шифрования.","impact":["Снижается конфиденциальность данных удалённого сеанса при несовременной криптографии."],"attack":[],"remediation":["Настройте надёжную защиту транспорта и обновите устаревшие клиенты RDP."]},"REGISTRY_INSECURE_GUEST_AUTH":{"description":"Политика разрешает SMB-клиенту небезопасные гостевые подключения без подтверждения подлинности.","impact":["Повышается риск подключения к поддельному серверу, раскрытия информации и атак на сетевое взаимодействие."],"attack":[],"remediation":["Запретите небезопасный гостевой вход и перейдите на проверки подлинности SMB."]},"REGISTRY_SMB2_SERVER_DISABLED":{"description":"На сервере отключено семейство SMBv2/SMBv3, что может вынуждать использование SMBv1 либо приводить к отказам доступа.","impact":["При зависимости от SMBv1 утрачиваются современные защитные свойства протокола."],"attack":[],"remediation":["Включите актуальные версии SMB и отключите SMBv1 после проверки совместимости."]},"REGISTRY_SMB_UNENCRYPTED_ACCESS":{"description":"SMB-клиент допускает соединение без шифрования даже с ресурсами, для которых предполагалось обязательное шифрование.","impact":["Трафик может передаваться без ожидаемой конфиденциальности в пределах сети."],"attack":[],"remediation":["Восстановите требование шифрования и проверьте фактические возможности SMB-серверов."]},"REGISTRY_PRINT_RPC_PRIVACY":{"description":"Через GPO отключено усиленное требование конфиденциальности RPC при взаимодействии со службой печати.","impact":["При совместимых условиях ослабляется защита RPC-трафика и границы доверия диспетчера печати."],"attack":[],"remediation":["Верните требование конфиденциальности RPC, обновите драйверы и проверяйте клиентов."]},"REGISTRY_WSUS_USER_PROXY":{"description":"Клиент Windows Update/WSUS может использовать прокси-настройки пользователя вместо системного контекста обслуживания.","impact":["Изменённые пользовательские параметры прокси могут повлиять на маршрут и доверие к сервису обновлений."],"attack":[],"remediation":["Проверьте политику прокси WSUS и настройте доверенный управляемый маршрут обновлений."]},"REGISTRY_MACHINE_PASSWORD_AGE":{"description":"Через GPO увеличен максимальный срок действия пароля компьютерной записи свыше штатного интервала.","impact":["Машинный секрет обновляется реже, что увеличивает его срок пригодности при утечке."],"attack":[],"remediation":["Верните разумный интервал смены и проверьте специальные исключения."]},"REGISTRY_SCRIPTBLOCK_LOGGING_OFF":{"description":"Политика отключает журналирование блоков PowerShell Script Block Logging.","impact":["Сокращаются возможности расследования выполнения опасных команд и автоматизации на конечных узлах."],"attack":[],"remediation":["Включите Script Block Logging с учётом защиты журналов, объёмов событий и конфиденциальности."]},"REGISTRY_LEGACY_TLS":{"description":"В политике разрешены устаревшие протоколы SSL 3.0 или TLS 1.0.","impact":["Они не соответствуют современным требованиям и допускают более слабые механизмы защиты соединения."],"attack":[],"remediation":["Отключите устаревшие версии после инвентаризации зависимостей и переходите на TLS 1.2/1.3."]},"REGISTRY_CACHED_LOGONS":{"description":"На компьютере разрешено кэшировать чрезмерное число доменных входов для автономной аутентификации.","impact":["При компрометации локальной машины может увеличиться количество доступных проверочных материалов учётных записей."],"attack":[],"remediation":["Снизьте параметр кэширования в соответствии с требованиями мобильных пользователей и защиты рабочих станций."]},"REGISTRY_REMOTE_ASSISTANCE_OFFER":{"description":"Групповая политика разрешает незапрошенную удалённую помощь (Offer Remote Assistance) определённым субъектам.","impact":["Чрезмерно широкий круг помощников может получать доступ к пользовательским сеансам и данным."],"attack":[],"remediation":["Ограничьте помощников специальными группами и используйте подтверждение пользователя и аудит сеансов."]},"REGISTRY_OFFICE_MACROS_ON":{"description":"Через GPO разрешён запуск макросов Office без ожидающегося предупреждения или ограничений происхождения.","impact":["Макросы могут выполнять вредоносный код при открытии документа и использовать права текущего пользователя."],"attack":[],"remediation":["Запретите неподписанные макросы из Интернета, настройте доверенные издательства и проверьте исключения."]},"GPO_POINTANDPRINT_NONADMIN_INSTALL":{"description":"Настройка Point and Print разрешает непривилегированным пользователям устанавливать драйверы печати без административного подтверждения.","impact":["При небезопасном источнике драйверов возможно выполнение вредоносного кода с повышенными привилегиями."],"attack":[],"remediation":["Требуйте административное подтверждение и используйте утверждённые серверы и подписанные драйверы."]},"GPO_POINTANDPRINT_LATENT":{"description":"В политике отключены предупреждения Point and Print, но другие действующие механизмы Windows сейчас ограничивают небезопасную установку.","impact":["Несогласованная конфигурация может стать опасной после изменения смежных защитных настроек."],"attack":[],"remediation":["Удалите устаревшие ослабляющие параметры, даже если текущая версия ОС блокирует злоупотребление."]},"GPO_POINTANDPRINT_USER_SCOPE":{"description":"Ограничения Point and Print заданы только в пользовательской части GPO, хотя соответствующая защита проверяется системными параметрами компьютера.","impact":["Администраторы могут ошибочно полагать, что ограничение действует, хотя клиент его не применяет."],"attack":[],"remediation":["Перенесите защитные настройки в конфигурацию компьютера и проверяйте эффективные параметры на клиенте."]},"GPO_POINTANDPRINT_DRIVER_SOURCE":{"description":"Политика разрешает получать драйверы принтера с произвольного сервера вместо утверждённого списка источников.","impact":["Поддельный сервер печати может доставить нежелательный драйвер при дополнительных условиях."],"attack":["1. Поднимает сервер печати в любой точке сети, доступной клиенту.","2. Предлагает с него вредоносный драйвер либо использует вариант Point and Print без пакета драйвера.","3. В сочетании с отключёнными запросами подтверждения получает незаметное выполнение кода от SYSTEM."],"remediation":["Ограничьте список доверенных серверов печати и включите требования подписанных драйверов."]},"GPO_PRINT_SPOOLER_RPC":{"description":"Служба диспетчера печати принимает удалённые RPC-подключения из сети, что расширяет поверхность атаки.","impact":["Доступные RPC-вызовы могут способствовать эксплуатации уязвимостей печати при наличии дополнительных условий."],"attack":[],"remediation":["Отключите удалённый диспетчер печати на машинах без необходимости, особенно на контроллерах домена; ограничьте сеть."]},"GPO_PRINT_QUEUE_SPECIFIC_FILES":{"description":"Диспетчер печати настроен на операции с файлами очереди печати, допускающие нежелательные пути или небезопасную обработку данных.","impact":["При определённых разрешениях службы возможны запись посторонних файлов и повышение привилегий."],"attack":[],"remediation":["Примените защитные настройки очереди печати и ограничьте доступ к папкам спулера."]},"GPO_PRINT_DRIVER_HARDENING":{"description":"Политика отключает усиленные ограничения установки и обновления драйверов печати.","impact":["Снижается защита от атак через небезопасные драйверы и Point and Print."],"attack":[],"remediation":["Восстановите требования администратора и подписанных драйверов; проверьте утверждённые серверы печати."]},"LAPS_GPO_ENCRYPTION_DISABLED":{"description":"Windows LAPS хранит пароль локального администратора в Active Directory без дополнительного шифрования секретов Windows LAPS.","impact":["Субъект с правом чтения конфиденциального атрибута получает открытый управляемый пароль."],"attack":[],"remediation":["Включите шифрование Windows LAPS при поддерживаемом функциональном уровне и строго ограничьте права чтения."]},"LAPS_GPO_NO_AD_BACKUP":{"description":"Политика Windows LAPS не предусматривает сохранение управляемого пароля в текущей Active Directory.","impact":["Администраторы могут не иметь ожидаемого способа восстановления локального доступа; пароль может храниться в другом целевом хранилище."],"attack":[],"remediation":["Проверьте назначение резервного копирования и настройте поддерживаемый целевой каталог, если требуется локальная AD."]},"LAPS_GPO_EXPIRATION_PROTECTION_DISABLED":{"description":"Отключена защита Windows LAPS от некорректного или намеренно продлённого срока действия пароля.","impact":["Может увеличиться время использования локального пароля сверх ожидающейся политики."],"attack":[],"remediation":["Включите защиту срока действия, проверьте возможности клиента и заданные ограничения."]},"LAPS_GPO_WEAK_PASSWORD_COMPLEXITY":{"description":"Политика Windows LAPS выбирает недостаточную сложность генерируемых локальных паролей.","impact":["Секрет может иметь предсказуемые свойства и снижать устойчивость к подбору."],"attack":[],"remediation":["Установите достаточную длину, допустимый набор символов и контролируйте фактическую ротацию."]},"LAPS_GPO_NOT_LINKED":{"description":"Настройки Windows LAPS обнаружены в GPO без действующих связей с OU компьютеров.","impact":["Политика может не применяться, поэтому ожидаемая защита локального администратора отсутствует."],"attack":[],"remediation":["Привяжите политику к нужным OU и проверьте результаты gpresult на целевых компьютерах."]},"GPO_SCRIPT_OUTSIDE_POLICY_STORE":{"description":"Сценарий входа или запуска, заданный через GPO, находится вне защищённого каталога политики SYSVOL.","impact":["Если внешний путь доступен для записи менее привилегированным субъектам, скрипт может быть подменён."],"attack":[],"remediation":["Проверьте UNC-путь, права записи и доверие к источнику; используйте защищённые каталоги."]},"LOGON_SCRIPT_WRITABLE":{"description":"Файл сценария входа, назначенного доменным пользователям, доступен для изменения субъекту с избыточными правами.","impact":["Подмена сценария приводит к выполнению кода в контексте пользователей, запускающих вход."],"attack":[],"remediation":["Уберите лишние права записи в файл и родительские каталоги; контролируйте изменения сценария."]},"SCRIPTPATH_HARDCODED":{"description":"В атрибуте scriptPath учётной записи задан прямой путь к сценарию входа.","impact":["Внешний или устаревший путь может создавать зависимость от небезопасного сервера и осложнять централизованное управление."],"attack":[],"remediation":["Проверьте актуальность пути, доверие и ACL; предпочтительно применяйте управляемые GPO."]},"UAC_SEVERITY_OVERRIDE":{"description":"Служебный результат классифицирует риск параметров контроля учётных записей Windows (UAC) с учётом значения политики.","impact":["Это метаданные отчёта; само поле не является отдельной уязвимостью."],"attack":[],"remediation":["Сверяйте итоговую классификацию с конкретной настройкой UAC и её областью действия."]}};
        const ruAttributeLabels = {"Domain":"Домен","Domain Name":"Имя домена","Domain DNS Name":"DNS-имя домена","Domain DN":"Отличительное имя домена (DN)","Domain SID":"SID домена","Forest":"Лес","Forest Name":"Имя леса","Forest Root Domain":"Корневой домен леса","Forest Functional Level":"Функциональный уровень леса","Domain Functional Level":"Функциональный уровень домена","Functional Level":"Функциональный уровень","Domain Controller":"Контроллер домена","Domain Controllers":"Контроллеры домена","Domain Controller Name":"Имя контроллера домена","Domain Controller IP":"IP-адрес контроллера домена","Server":"Сервер","Server Name":"Имя сервера","Site":"Сайт","Site Name":"Имя сайта","Subnet":"Подсеть","IP Address":"IP-адрес","DNS Name":"DNS-имя","DNS Host Name":"DNS-имя узла","Operating System":"Операционная система","Operating System Version":"Версия операционной системы","OS Version":"Версия ОС","OS":"ОС","OS Name":"Название ОС","Version":"Версия","Status":"Состояние","State":"Состояние","Account Status":"Состояние учётной записи","Account":"Учётная запись","Account Name":"Имя учётной записи","User":"Пользователь","Username":"Имя пользователя","User Name":"Имя пользователя","Display Name":"Отображаемое имя","Description":"Описание","Comment":"Комментарий","Computer":"Компьютер","Computer Name":"Имя компьютера","Group":"Группа","Group Name":"Имя группы","Members":"Участники","Member":"Участник","Member Count":"Количество участников","Group Membership":"Членство в группах","Primary Group":"Основная группа","Distinguished Name":"Отличительное имя (DN)","Object DN":"Отличительное имя объекта","Object Name":"Имя объекта","Object Type":"Тип объекта","Object Class":"Класс объекта","Object SID":"SID объекта","Object GUID":"GUID объекта","Object Owner":"Владелец объекта","Owner":"Владелец","Creator":"Создатель","Created":"Создано","Creation Date":"Дата создания","Created On":"Дата создания","Modified":"Изменено","Last Modified":"Последнее изменение","Last Change":"Последнее изменение","Enabled":"Включено","Disabled":"Отключено","Locked":"Заблокировано","Unlocked":"Разблокировано","Active":"Активна","Inactive":"Неактивна","Account Enabled":"Учётная запись включена","Account Disabled":"Учётная запись отключена","Password":"Пароль","Password Age":"Возраст пароля","Password Last Set":"Дата последней смены пароля","Password Changed":"Пароль изменён","Password Expiration":"Истечение срока действия пароля","Password Expires":"Срок действия пароля","Password Never Expires":"Срок действия пароля не ограничен","Password Policy":"Политика паролей","Minimum Password Length":"Минимальная длина пароля","Min Password Length":"Минимальная длина пароля","Maximum Password Age":"Максимальный срок действия пароля","Minimum Password Age":"Минимальный срок действия пароля","Password History":"История паролей","Password History Length":"Длина истории паролей","Password Complexity":"Сложность пароля","Lockout Threshold":"Порог блокировки","Lockout Duration":"Продолжительность блокировки","Lockout Observation Window":"Окно наблюдения блокировки","Bad Password Count":"Число ошибочных попыток ввода пароля","Failed Logons":"Неудачные входы","Last Logon":"Последний вход","Last Logon Date":"Дата последнего входа","Last Login":"Последний вход","Last Seen":"Последняя активность","Last Logon Timestamp":"Отметка времени последнего входа","Logon Count":"Число входов","User Account Control":"Параметры контроля учётной записи","Account Flags":"Флаги учётной записи","Security Identifier":"Идентификатор безопасности (SID)","SID History":"История SID","SID History Count":"Число SID в истории","Privileges":"Привилегии","Privilege":"Привилегия","Permissions":"Разрешения","Permission":"Разрешение","Access Rights":"Права доступа","Effective Permissions":"Действующие разрешения","Explicit Permissions":"Явные разрешения","Inherited Permissions":"Унаследованные разрешения","Inheritance":"Наследование","Inherited From":"Наследуется от","Access Control List":"Список управления доступом (ACL)","Access Control Entry":"Запись управления доступом (ACE)","ACE Count":"Количество записей ACE","ACL":"Список управления доступом (ACL)","Risk":"Риск","Risk Level":"Уровень риска","Severity":"Уровень опасности","Critical":"Критический","High":"Высокий","Medium":"Средний","Low":"Низкий","Finding":"Нарушение","Findings":"Нарушения","Warning":"Предупреждение","Warnings":"Предупреждения","Hint":"Предупреждение","Note":"Примечание","Secure":"Безопасно","Not Applicable":"Неприменимо","N/A":"Н/Д","None":"Нет","Unknown":"Неизвестно","Not Found":"Не найдено","Not Tested":"Не проверено","Not Checked":"Не проверялось","Not Available":"Недоступно","Not Configured":"Не настроено","Not Set":"Не задано","Not Required":"Не требуется","Required":"Обязательно","Allowed":"Разрешено","Denied":"Запрещено","Read":"Чтение","Write":"Запись","Full Control":"Полный доступ","Read Access":"Доступ на чтение","Write Access":"Доступ на запись","Can Read":"Может читать","Can Write":"Может изменять","Read Permissions":"Разрешения на чтение","Write Permissions":"Разрешения на запись","Access":"Доступ","Access Type":"Тип доступа","Principal":"Субъект безопасности","Security Principal":"Субъект безопасности","Trust":"Доверие","Trust Type":"Тип доверия","Trust Direction":"Направление доверия","Trust Transitivity":"Транзитивность доверия","Trusting Domain":"Доверяющий домен","Trusted Domain":"Доверенный домен","Transitive":"Транзитивное","Non-transitive":"Нетранзитивное","Kerberos":"Kerberos","TGT Lifetime":"Срок действия TGT","Ticket Lifetime":"Срок действия билета","Renewal Lifetime":"Срок обновления билета","Encryption Type":"Тип шифрования","Encryption Types":"Типы шифрования","Service Principal Name":"Имя субъекта-службы (SPN)","Service Principal Names":"Имена субъектов-служб (SPN)","SPNs":"Имена SPN","Delegation":"Делегирование","Delegation Type":"Тип делегирования","Unconstrained Delegation":"Неограниченное делегирование","Constrained Delegation":"Ограниченное делегирование","Resource-Based Constrained Delegation":"Ограниченное делегирование на основе ресурса","Certificate":"Сертификат","Certificate Authority":"Центр сертификации","Certificate Authorities":"Центры сертификации","Certificate Template":"Шаблон сертификата","Template Name":"Имя шаблона","Template":"Шаблон","Issuer":"Издатель","Subject":"Субъект","Valid From":"Действует с","Valid To":"Действует до","Not Before":"Начало срока действия","Not After":"Конец срока действия","Expiration Date":"Дата окончания срока действия","Validity Period":"Срок действия","Key Length":"Длина ключа","Key Size":"Размер ключа","Signature Algorithm":"Алгоритм подписи","Enrollment Rights":"Права регистрации","Enrollment":"Регистрация сертификата","Manager Approval":"Одобрение администратором","Enhanced Key Usage":"Расширенное назначение ключа (EKU)","Authentication":"Проверка подлинности","Authentication Method":"Метод проверки подлинности","Authentication Policy":"Политика проверки подлинности","Client Authentication":"Проверка подлинности клиента","Smart Card Logon":"Вход со смарт-картой","GPO":"Объект групповой политики (GPO)","Group Policy Object":"Объект групповой политики","Group Policy Objects":"Объекты групповой политики","GPO Name":"Имя GPO","GPO GUID":"GUID объекта GPO","GPO Status":"Состояние GPO","GPO Link":"Привязка GPO","GPO Links":"Привязки GPO","Linked OUs":"Связанные OU","Linked OUs/Domain":"Привязанные OU и домен","Applied GPOs":"Применённые GPO","Policy":"Политика","Policy Name":"Имя политики","Policy Setting":"Параметр политики","Policy Value":"Значение политики","Effective Policy":"Действующая политика","Scope":"Область действия","Scope of Management":"Область управления","File Path":"Путь к файлу","Path":"Путь","Script Path":"Путь сценария","Logon Script":"Сценарий входа","Task Name":"Имя задачи","Scheduled Tasks":"Запланированные задания","Registry Key":"Раздел реестра","Registry Value":"Значение реестра","Registry Path":"Путь реестра","Shares":"Общие ресурсы","Share Name":"Имя общего ресурса","Share Path":"Путь общего ресурса","UNC Path":"UNC-путь","Readable":"Доступно для чтения","Writable":"Доступно для записи","Read Only":"Только чтение","Number of Objects":"Количество объектов","Object Count":"Количество объектов","Total Objects":"Всего объектов","Total Count":"Общее количество","Count":"Количество","Total":"Всего","Result":"Результат","Results":"Результаты","Value":"Значение","Values":"Значения","Type":"Тип","Name":"Имя","Source":"Источник","Target":"Назначение","Origin":"Происхождение","Reason":"Причина","Details":"Подробности","Recommendation":"Рекомендация","Recommendations":"Рекомендации","Remediation":"Меры по устранению","Impact":"Последствия","Attack Path":"Вектор атаки","Attack Steps":"Этапы атаки","Command":"Команда","Command Line":"Командная строка","References":"Источники","Tools":"Инструменты","Date":"Дата","Time":"Время","Duration":"Продолжительность","Last Updated":"Последнее обновление","Scan Time":"Время аудита","Scan Duration":"Продолжительность аудита","LDAP Queries":"LDAP-запросы","LDAP Statistics":"Статистика LDAP","Queries":"Запросы","Objects":"Объекты","Affected Objects":"Затронутые объекты","Status Code":"Код состояния","GPOName":"Имя групповой политики (GPO)","GPOGUID":"GUID групповой политики","GPOPath":"Путь к GPO в SYSVOL","GPOStatus":"Состояние GPO","GPOOwner":"Владелец GPO","GPODisplayName":"Отображаемое имя GPO","distinguishedName":"Отличительное имя (DN)","objectGUID":"GUID объекта","objectSid":"SID объекта","sAMAccountName":"Имя учётной записи (sAMAccountName)","userPrincipalName":"Основное имя пользователя (UPN)","memberOf":"Членство в группах","DangerousPermissions":"Опасные разрешения","dangerousRights":"Опасные права доступа","dangerousRightsSeverity":"Критичность разрешений","affectedGroups":"Затронутые группы","affectedOUs":"Затронутые OU","LinkedOUs":"OU, связанные с GPO","GPOLinkedOUs":"OU, связанные с GPO","Trustee":"Субъект доступа","TrusteeSID":"SID субъекта доступа","TrusteeName":"Имя субъекта доступа","TrusteeRights":"Права субъекта","Rights":"Права доступа","SysvolPermissions":"Разрешения в SYSVOL","SysvolFolder":"Папка SYSVOL","GPOSysvolPath":"Путь GPO в SYSVOL","OwnerSID":"SID владельца","groupsRead":"Прочитанные группы","groupsNotRead":"Группы, недоступные для чтения","readDespiteAdminCount":"Группы, проверенные несмотря на adminCount","displayName":"Отображаемое имя","NameToCheck":"Проверяемое имя","MemberCount":"Количество участников","ParentGroup":"Родительская группа","RiskScore":"Оценка риска","FindingId":"Идентификатор находки","ObjectType":"Тип объекта","AccountName":"Имя учётной записи","AccountDN":"Отличительное имя учётной записи","AccountEnabled":"Учётная запись активна","PasswordLastSet":"Последняя смена пароля","PasswordNeverExpires":"Срок действия пароля не ограничен","LastLogonDate":"Дата последнего входа","LastSeen":"Последняя активность","whenCreated":"Дата создания","whenChanged":"Дата изменения","UserRightName":"Имя права пользователя Windows","TargetGroup":"Целевая группа","PolicyName":"Имя политики","PolicyDN":"Отличительное имя политики","ReadErrors":"Ошибки чтения","UnreadOUs":"OU, недоступные для чтения","UnresolvedOUs":"OU с неразрешёнными связями","OwnerNonDefault":"Нестандартный владелец","OwnerName":"Имя владельца","OwnerIdentity":"Субъект-владелец","PasswordAgeDays":"Возраст пароля (дней)","InactiveDays":"Период неактивности (дней)","CertificateTemplate":"Шаблон сертификата","TemplateName":"Имя шаблона","CertificateAuthority":"Центр сертификации","EnrollmentRights":"Права регистрации","ExtendedKeyUsage":"Расширенное назначение ключа (EKU)"};
        const ruCheckContext = {"DomainBasicInfo":{"whyItMatters":"Параметры домена влияют на доверие, проверку подлинности и репликацию. Сопоставьте конфигурацию с политикой защиты Active Directory.","whatWeCheck":["Общие сведения о домене Active Directory, лесу, SID и функциональных уровнях.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"","summary":"Общие сведения о домене Active Directory, лесу, SID и функциональных уровнях.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Сведения о домене"},"KerberosPolicy":{"whyItMatters":"Параметры домена влияют на доверие, проверку подлинности и репликацию. Сопоставьте конфигурацию с политикой защиты Active Directory.","whatWeCheck":["Параметры времени действия билетов Kerberos и политики для учётной записи krbtgt.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Проверенные параметры политики Kerberos находятся в ожидаемых пределах: сроки действия билетов не превышают контрольные значения, а пароль krbtgt менялся в течение последних 180 дней.","summary":"Параметры времени действия билетов Kerberos и политики для учётной записи krbtgt.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Политика Kerberos"},"GuestAccount":{"whyItMatters":"Параметры домена влияют на доверие, проверку подлинности и репликацию. Сопоставьте конфигурацию с политикой защиты Active Directory.","whatWeCheck":["Проверка встроенной учётной записи «Гость» (RID 501) и её членства в группах.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Встроенная учётная запись Guest отключена (стандартное безопасное состояние).","summary":"Проверка встроенной учётной записи «Гость» (RID 501) и её членства в группах.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Состояние учётной записи «Гость»"},"DomainControllers":{"whyItMatters":"Параметры домена влияют на доверие, проверку подлинности и репликацию. Сопоставьте конфигурацию с политикой защиты Active Directory.","whatWeCheck":["Список контроллеров домена и распределение ролей FSMO.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"","summary":"Список контроллеров домена и распределение ролей FSMO.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Контроллеры домена и роли FSMO"},"SitesAndSubnets":{"whyItMatters":"Параметры домена влияют на доверие, проверку подлинности и репликацию. Сопоставьте конфигурацию с политикой защиты Active Directory.","whatWeCheck":["Сопоставление сайтов AD, IP-подсетей и контроллеров домена.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"","summary":"Сопоставление сайтов AD, IP-подсетей и контроллеров домена.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Сайты и подсети Active Directory"},"DomainPasswordPolicy":{"whyItMatters":"Параметры домена влияют на доверие, проверку подлинности и репликацию. Сопоставьте конфигурацию с политикой защиты Active Directory.","whatWeCheck":["Проверка параметров парольной политики домена по умолчанию.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Доменная политика паролей соответствует проверяемым требованиям: минимальная длина не менее 14 символов, сложность включена, параметры блокировки настроены.","summary":"Проверка параметров парольной политики домена по умолчанию.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Доменная политика паролей"},"FineGrainedPasswordPolicy":{"whyItMatters":"Параметры домена влияют на доверие, проверку подлинности и репликацию. Сопоставьте конфигурацию с политикой защиты Active Directory.","whatWeCheck":["Анализ тонких политик паролей, переопределяющих доменную политику.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Проверенные тонкие политики паролей (FGPP) задают строгие требования. Ни один PSO не допускает более слабые пароли, чем доменная политика по умолчанию.","summary":"Анализ тонких политик паролей, переопределяющих доменную политику.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Тонкие политики паролей (FGPP)"},"DomainTrust":{"whyItMatters":"Параметры домена влияют на доверие, проверку подлинности и репликацию. Сопоставьте конфигурацию с политикой защиты Active Directory.","whatWeCheck":["Проверка доверительных отношений с доменами и лесами.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Проверенные доверительные отношения домена соответствуют ожидаемой модели: фильтрация SID включена и параметры аутентификации настроены. Опасных или чрезмерно разрешающих настроек доверия проверка не обнаружила.","summary":"Проверка доверительных отношений с доменами и лесами.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Доверительные отношения домена"},"ReadableShare":{"whyItMatters":"Доступ к общим ресурсам и сценариям может раскрывать секреты или позволять изменять выполняемые файлы.","whatWeCheck":["Общие папки компьютеров домена, к которым текущая учётная запись имеет доступ на чтение.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"","summary":"Общие папки компьютеров домена, к которым текущая учётная запись имеет доступ на чтение.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Доступные для чтения общие ресурсы"},"ShareCredential":{"whyItMatters":"Доступ к общим ресурсам и сценариям может раскрывать секреты или позволять изменять выполняемые файлы.","whatWeCheck":["Поиск учётных данных в доступных скриптах и конфигурационных файлах.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"","summary":"Поиск учётных данных в доступных скриптах и конфигурационных файлах.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Учётные данные в общих папках"},"NetworkSubnet":{"whyItMatters":"Настройки компьютеров и их учётных записей влияют на защиту паролей, администрирование и риск бокового перемещения.","whatWeCheck":["Анализ IP-подсетей активных компьютеров домена и их организационных единиц.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"","summary":"Анализ IP-подсетей активных компьютеров домена и их организационных единиц.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Карта сети"},"OpenPorts":{"whyItMatters":"Настройки компьютеров и их учётных записей влияют на защиту паролей, администрирование и риск бокового перемещения.","whatWeCheck":["Список открытых TCP-портов просканированных адресов.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"","summary":"Список открытых TCP-портов просканированных адресов.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Открытые сетевые порты"},"LDAPConfigGPO":{"whyItMatters":"Параметры домена влияют на доверие, проверку подлинности и репликацию. Сопоставьте конфигурацию с политикой защиты Active Directory.","whatWeCheck":["Проверка подписи LDAP и привязки канала TLS по объектам групповой политики.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Через GPO настроены обязательные подпись LDAP и LDAP Channel Binding. Контроллеры домена требуют подпись LDAP и привязку канала, что уменьшает риск NTLM Relay к службам LDAP.","summary":"Проверка подписи LDAP и привязки канала TLS по объектам групповой политики.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Настройки подписи LDAP в GPO"},"NullSessionGPO":{"whyItMatters":"Параметры домена влияют на доверие, проверку подлинности и репликацию. Сопоставьте конфигурацию с политикой защиты Active Directory.","whatWeCheck":["Анализ настроек анонимного перечисления SAM и сопоставления SID с именами.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Действующие на контроллерах домена политики ограничивают анонимное перечисление SAM и анонимное сопоставление SID с именами.","summary":"Анализ настроек анонимного перечисления SAM и сопоставления SID с именами.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Параметры анонимного доступа в GPO"},"DSHeuristics":{"whyItMatters":"Параметры домена влияют на доверие, проверку подлинности и репликацию. Сопоставьте конфигурацию с политикой защиты Active Directory.","whatWeCheck":["Проверка параметров службы каталогов, которые могут ослаблять защиту леса AD.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Параметр dsHeuristics сохраняет проверяемые защитные ограничения: анонимный доступ LDAP и NSPI заблокирован, AdminSDHolder защищает операторские группы, а контроллеры домена проверяют уникальность UPN и SPN.","summary":"Проверка параметров службы каталогов, которые могут ослаблять защиту леса AD.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Параметры dsHeuristics"},"SMBSigning":{"whyItMatters":"Параметры домена влияют на доверие, проверку подлинности и репликацию. Сопоставьте конфигурацию с политикой защиты Active Directory.","whatWeCheck":["Проверка требования цифровой подписи SMB на компьютерах домена.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Через GPO обязательная подпись SMB задана для серверов и клиентов. Это препятствует атакам NTLM Relay на SMB-ресурсы, которым требуется подпись, и снижает риск несанкционированного доступа и бокового перемещения.","summary":"Проверка требования цифровой подписи SMB на компьютерах домена.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Настройки подписи SMB"},"EffectiveLDAPConfig":{"whyItMatters":"Параметры домена влияют на доверие, проверку подлинности и репликацию. Сопоставьте конфигурацию с политикой защиты Active Directory.","whatWeCheck":["Определение фактически применённых настроек подписи LDAP и привязки канала.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Политики, действующие на контроллеры домена, требуют цифровой подписи LDAP и LDAP Channel Binding.","summary":"Определение фактически применённых настроек подписи LDAP и привязки канала.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Действующие настройки LDAP"},"EffectiveNullSession":{"whyItMatters":"Параметры домена влияют на доверие, проверку подлинности и репликацию. Сопоставьте конфигурацию с политикой защиты Active Directory.","whatWeCheck":["Определение действующих ограничений анонимных сеансов.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Политики, действующие на контроллеры домена, ограничивают анонимное перечисление SAM и сопоставление SID с именами.","summary":"Определение действующих ограничений анонимных сеансов.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Действующие параметры анонимного доступа"},"EffectiveSMBSigning":{"whyItMatters":"Параметры домена влияют на доверие, проверку подлинности и репликацию. Сопоставьте конфигурацию с политикой защиты Active Directory.","whatWeCheck":["Определение фактических требований подписи SMB.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Действующие на контроллерах домена политики требуют подписи SMB как на серверной, так и на клиентской стороне.","summary":"Определение фактических требований подписи SMB.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Действующие настройки подписи SMB"},"EffectiveSMBSigningMembers":{"whyItMatters":"Параметры домена влияют на доверие, проверку подлинности и репликацию. Сопоставьте конфигурацию с политикой защиты Active Directory.","whatWeCheck":["Перечень компьютеров, на которые распространяется политика подписи SMB.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Политика, действующая на серверы-участники домена и клиентские компьютеры, требует подписи SMB.","summary":"Перечень компьютеров, на которые распространяется политика подписи SMB.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Подпись SMB: затронутые компьютеры"},"SMBSigningWeakened":{"whyItMatters":"Параметры домена влияют на доверие, проверку подлинности и репликацию. Сопоставьте конфигурацию с политикой защиты Active Directory.","whatWeCheck":["Выявление настроек, снижающих требования цифровой подписи SMB.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Среди привязанных и включённых GPO нет политик, ослабляющих требование подписи SMB.","summary":"Выявление настроек, снижающих требования цифровой подписи SMB.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Ослабление защиты SMB"},"DomainController":{"whyItMatters":"Службы приложений могут обладать высокими правами AD. Применяйте минимальные привилегии и контролируйте служебные записи.","whatWeCheck":["Перечень контроллеров домена и их основные параметры.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"","summary":"Перечень контроллеров домена и их основные параметры.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Контроллеры домена"},"ExchangeServer":{"whyItMatters":"Службы приложений могут обладать высокими правами AD. Применяйте минимальные привилегии и контролируйте служебные записи.","whatWeCheck":["Инвентаризация серверов Microsoft Exchange и их настроек.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Проверенная инфраструктура Exchange использует поддерживаемую версию и ожидаемую конфигурацию безопасности. Веб-службы работают по HTTPS с EPA, а разрешения Exchange соответствуют проверяемой модели.","summary":"Инвентаризация серверов Microsoft Exchange и их настроек.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Серверы Exchange"},"ExchangeServerBasic":{"whyItMatters":"Службы приложений могут обладать высокими правами AD. Применяйте минимальные привилегии и контролируйте служебные записи.","whatWeCheck":["Базовая инвентаризация серверов Microsoft Exchange.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"","summary":"Базовая инвентаризация серверов Microsoft Exchange.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Серверы Exchange: основные сведения"},"ExchangeOrganization":{"whyItMatters":"Службы приложений могут обладать высокими правами AD. Применяйте минимальные привилегии и контролируйте служебные записи.","whatWeCheck":["Анализ объектов организации Microsoft Exchange в Active Directory.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"","summary":"Анализ объектов организации Microsoft Exchange в Active Directory.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Организация Exchange"},"ExchangeConfigServer":{"whyItMatters":"Службы приложений могут обладать высокими правами AD. Применяйте минимальные привилегии и контролируйте служебные записи.","whatWeCheck":["Параметры серверов Exchange в разделе конфигурации AD.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"","summary":"Параметры серверов Exchange в разделе конфигурации AD.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Сервер Exchange в разделе Configuration"},"ExchangeHybridConfiguration":{"whyItMatters":"Службы приложений могут обладать высокими правами AD. Применяйте минимальные привилегии и контролируйте служебные записи.","whatWeCheck":["Проверка конфигурации гибридного взаимодействия Exchange с облачными сервисами.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Признаки гибридной конфигурации Exchange не обнаружены; почтовая инфраструктура выглядит полностью локальной.","summary":"Проверка конфигурации гибридного взаимодействия Exchange с облачными сервисами.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Гибридное развёртывание Exchange"},"ExchangeReceiveConnector":{"whyItMatters":"Службы приложений могут обладать высокими правами AD. Применяйте минимальные привилегии и контролируйте служебные записи.","whatWeCheck":["Проверка принимающих соединителей SMTP и параметров аутентификации.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Ни один проверенный принимающий соединитель Exchange не предоставляет анонимным отправителям права ретрансляции или подмены отправителя.","summary":"Проверка принимающих соединителей SMTP и параметров аутентификации.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Принимающие SMTP-соединители Exchange"},"ExchangePermissionsModel":{"whyItMatters":"Службы приложений могут обладать высокими правами AD. Применяйте минимальные привилегии и контролируйте служебные записи.","whatWeCheck":["Анализ модели разрешений Exchange и связанных прав в Active Directory.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Ни одна группа Exchange не имеет действующих прав, позволяющих повысить привилегии через корневой объект домена.","summary":"Анализ модели разрешений Exchange и связанных прав в Active Directory.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Модель разрешений Exchange"},"ExchangeRoleAssignment":{"whyItMatters":"Службы приложений могут обладать высокими правами AD. Применяйте минимальные привилегии и контролируйте служебные записи.","whatWeCheck":["Проверка назначений ролей RBAC в Exchange.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Ни одна критичная роль Exchange не назначена вне групп ролей, предусмотренных штатной конфигурацией Exchange.","summary":"Проверка назначений ролей RBAC в Exchange.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Назначения ролей управления Exchange"},"MSSQLServer":{"whyItMatters":"Службы приложений могут обладать высокими правами AD. Применяйте минимальные привилегии и контролируйте служебные записи.","whatWeCheck":["Инвентаризация серверов SQL Server и связанных служебных учётных записей.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"","summary":"Инвентаризация серверов SQL Server и связанных служебных учётных записей.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Серверы Microsoft SQL Server"},"SCCMServer":{"whyItMatters":"Службы приложений могут обладать высокими правами AD. Применяйте минимальные привилегии и контролируйте служебные записи.","whatWeCheck":["Проверка инфраструктуры Microsoft Configuration Manager.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Ни один субъект вне серверов сайта SCCM и Management Point не может записывать в контейнер System Management. Этот результат НЕ касается учётных данных: Network Access Accounts хранятся в базе Configuration Manager и клиентских политиках, а не в AD, поэтому данная проверка не устанавливает, раскрыты ли их секреты.","summary":"Проверка инфраструктуры Microsoft Configuration Manager.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Инфраструктура Configuration Manager (SCCM)"},"SCCMServerBasic":{"whyItMatters":"Службы приложений могут обладать высокими правами AD. Применяйте минимальные привилегии и контролируйте служебные записи.","whatWeCheck":["Базовая инвентаризация серверов Microsoft Configuration Manager.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"","summary":"Базовая инвентаризация серверов Microsoft Configuration Manager.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Серверы SCCM: основные сведения"},"SCCMServiceAccount":{"whyItMatters":"Службы приложений могут обладать высокими правами AD. Применяйте минимальные привилегии и контролируйте служебные записи.","whatWeCheck":["Проверка учётных записей служб Configuration Manager.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"","summary":"Проверка учётных записей служб Configuration Manager.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Служебные учётные записи SCCM"},"SCCMGroup":{"whyItMatters":"Службы приложений могут обладать высокими правами AD. Применяйте минимальные привилегии и контролируйте служебные записи.","whatWeCheck":["Анализ групп и их участников в инфраструктуре Configuration Manager.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"","summary":"Анализ групп и их участников в инфраструктуре Configuration Manager.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Группы SCCM"},"SCCMContainerPermission":{"whyItMatters":"Службы приложений могут обладать высокими правами AD. Применяйте минимальные привилегии и контролируйте служебные записи.","whatWeCheck":["Проверка прав доступа к контейнеру System Management в Active Directory.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Запись в контейнер System Management разрешена только серверам сайта SCCM и ожидаемым администраторам. Необоснованного субъекта, который мог бы публиковать сведения о доверенном клиентами Management Point, не обнаружено.","summary":"Проверка прав доступа к контейнеру System Management в Active Directory.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Разрешения контейнера System Management"},"SCCMSite":{"whyItMatters":"Службы приложений могут обладать высокими правами AD. Применяйте минимальные привилегии и контролируйте служебные записи.","whatWeCheck":["Параметры сайтов Microsoft Configuration Manager.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"","summary":"Параметры сайтов Microsoft Configuration Manager.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Сайты SCCM"},"SCCMManagementPoint":{"whyItMatters":"Службы приложений могут обладать высокими правами AD. Применяйте минимальные привилегии и контролируйте служебные записи.","whatWeCheck":["Инвентаризация точек управления Configuration Manager.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"","summary":"Инвентаризация точек управления Configuration Manager.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Точки управления SCCM"},"SCCMPXEServer":{"whyItMatters":"Службы приложений могут обладать высокими правами AD. Применяйте минимальные привилегии и контролируйте служебные записи.","whatWeCheck":["Проверка серверов сетевой загрузки PXE и служб WDS.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"","summary":"Проверка серверов сетевой загрузки PXE и служб WDS.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Серверы загрузки PXE/WDS"},"SCOMServer":{"whyItMatters":"Службы приложений могут обладать высокими правами AD. Применяйте минимальные привилегии и контролируйте служебные записи.","whatWeCheck":["Проверка инфраструктуры Microsoft Operations Manager.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Найденные в каталоге служебные записи SCOM не входят в привилегированные группы AD. Однако права Run As на целевых системах задаются ВНУТРИ SCOM, а не в Active Directory: этот результат ничего не доказывает о минимальности этих прав. Пароли таких записей также хранятся средствами SCOM.","summary":"Проверка инфраструктуры Microsoft Operations Manager.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Инфраструктура Operations Manager (SCOM)"},"SCOMServerBasic":{"whyItMatters":"Службы приложений могут обладать высокими правами AD. Применяйте минимальные привилегии и контролируйте служебные записи.","whatWeCheck":["Инвентаризация серверов Microsoft Operations Manager.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"","summary":"Инвентаризация серверов Microsoft Operations Manager.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Серверы SCOM: основные сведения"},"SCOMServiceAccount":{"whyItMatters":"Службы приложений могут обладать высокими правами AD. Применяйте минимальные привилегии и контролируйте служебные записи.","whatWeCheck":["Проверка прав и настроек учётных записей служб Operations Manager.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"","summary":"Проверка прав и настроек учётных записей служб Operations Manager.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Служебные учётные записи SCOM"},"SCOMGroup":{"whyItMatters":"Службы приложений могут обладать высокими правами AD. Применяйте минимальные привилегии и контролируйте служебные записи.","whatWeCheck":["Проверка групп Microsoft Operations Manager.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"","summary":"Проверка групп Microsoft Operations Manager.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Группы SCOM"},"ADFSServer":{"whyItMatters":"Службы приложений могут обладать высокими правами AD. Применяйте минимальные привилегии и контролируйте служебные записи.","whatWeCheck":["Инвентаризация серверов и конфигурации Active Directory Federation Services.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Развёртывание AD FS в домене не обнаружено. Локальная служба федерации, ключ подписи которой мог бы использоваться для подделки токенов облачного арендатора, отсутствует в проверенных данных.","summary":"Инвентаризация серверов и конфигурации Active Directory Federation Services.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Службы федерации AD FS"},"EntraConnect":{"whyItMatters":"Службы приложений могут обладать высокими правами AD. Применяйте минимальные привилегии и контролируйте служебные записи.","whatWeCheck":["Проверка конфигурации синхронизации идентификаторов Microsoft Entra Connect.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Компоненты Microsoft Entra Connect обнаружены, а проверенные параметры их защиты соответствуют ожидаемой модели. Учётные записи синхронизации имеют предусмотренные разрешения.","summary":"Проверка конфигурации синхронизации идентификаторов Microsoft Entra Connect.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Microsoft Entra Connect"},"ExchangeTrustedSubsystem":{"whyItMatters":"Службы приложений могут обладать высокими правами AD. Применяйте минимальные привилегии и контролируйте служебные записи.","whatWeCheck":["Проверка привилегий группы Exchange Trusted Subsystem.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"В состав Exchange Trusted Subsystem входят только ожидаемые учётные записи компьютеров серверов Exchange.","summary":"Проверка привилегий группы Exchange Trusted Subsystem.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Группа Exchange Trusted Subsystem"},"ExchangeWindowsPermissions":{"whyItMatters":"Службы приложений могут обладать высокими правами AD. Применяйте минимальные привилегии и контролируйте служебные записи.","whatWeCheck":["Анализ полномочий группы Exchange Windows Permissions.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Состав Exchange Windows Permissions соответствует ожидаемой конфигурации: в группе обнаружены только субъекты, связанные с Exchange.","summary":"Анализ полномочий группы Exchange Windows Permissions.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Группа Exchange Windows Permissions"},"ExchangeOrganizationManagement":{"whyItMatters":"Службы приложений могут обладать высокими правами AD. Применяйте минимальные привилегии и контролируйте служебные записи.","whatWeCheck":["Анализ участников административной группы Organization Management в Exchange.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"В группе Organization Management состоят только назначенные администраторы Exchange.","summary":"Анализ участников административной группы Organization Management в Exchange.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Группа Organization Management"},"ExchangeServersGroup":{"whyItMatters":"Службы приложений могут обладать высокими правами AD. Применяйте минимальные привилегии и контролируйте служебные записи.","whatWeCheck":["Проверка состава и полномочий группы Exchange Servers.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"В составе Exchange Servers найдены только компьютерные записи серверов Exchange и группы Exchange.","summary":"Проверка состава и полномочий группы Exchange Servers.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Группа Exchange Servers"},"CertificateAuthority":{"whyItMatters":"Ошибки регистрации сертификатов AD CS могут влиять на проверку подлинности. Проверяйте шаблоны, EKU, разрешения и цепочки доверия.","whatWeCheck":["Инвентаризация центров сертификации Active Directory Certificate Services.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Проверенная конфигурация центра сертификации соответствует заданным защитным условиям: сертификаты ЦС используют стойкие алгоритмы, веб-регистрация работает через HTTPS с EPA, а права ЦС ограничены по принципу минимальных полномочий.","summary":"Инвентаризация центров сертификации Active Directory Certificate Services.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Центры сертификации AD CS"},"CertificateTemplate":{"whyItMatters":"Ошибки регистрации сертификатов AD CS могут влиять на проверку подлинности. Проверяйте шаблоны, EKU, разрешения и цепочки доверия.","whatWeCheck":["Проверка шаблонов сертификатов, параметров выдачи и прав регистрации.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Уязвимых шаблонов сертификатов не обнаружено. Проверенные шаблоны ограничивают регистрацию привилегированными пользователями и не разрешают опасные сочетания параметров, например произвольное задание SAN заявителем.","summary":"Проверка шаблонов сертификатов, параметров выдачи и прав регистрации.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Шаблоны сертификатов AD CS"},"PKIContainer":{"whyItMatters":"Ошибки регистрации сертификатов AD CS могут влиять на проверку подлинности. Проверяйте шаблоны, EKU, разрешения и цепочки доверия.","whatWeCheck":["Проверка списков управления доступом к контейнерам инфраструктуры открытых ключей.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Уязвимостей в разрешениях проверенных контейнеров PKI не выявлено: доступ ограничен уполномоченными администраторами.","summary":"Проверка списков управления доступом к контейнерам инфраструктуры открытых ключей.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Разрешения контейнеров PKI"},"PKIInfrastructure":{"whyItMatters":"Ошибки регистрации сертификатов AD CS могут влиять на проверку подлинности. Проверяйте шаблоны, EKU, разрешения и цепочки доверия.","whatWeCheck":["Анализ компонентов инфраструктуры открытых ключей и цепочек доверия.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Проверенная инфраструктура доверия PKI содержит действительные корневые сертификаты ЦС и ожидаемые записи хранилища NTAuth.","summary":"Анализ компонентов инфраструктуры открытых ключей и цепочек доверия.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Инфраструктура доверия PKI"},"RootCA":{"whyItMatters":"Ошибки регистрации сертификатов AD CS могут влиять на проверку подлинности. Проверяйте шаблоны, EKU, разрешения и цепочки доверия.","whatWeCheck":["Проверка сертификатов доверенных корневых центров сертификации.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Сертификат корневого центра сертификации использует стойкие криптографические алгоритмы и находится в пределах срока действия.","summary":"Проверка сертификатов доверенных корневых центров сертификации.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Доверенные корневые центры сертификации"},"NTAuthCertificate":{"whyItMatters":"Ошибки регистрации сертификатов AD CS могут влиять на проверку подлинности. Проверяйте шаблоны, EKU, разрешения и цепочки доверия.","whatWeCheck":["Проверка сертификатов в хранилище NTAuth леса Active Directory.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"В хранилище NTAuth обнаружены только сертификаты корпоративных центров сертификации данного леса.","summary":"Проверка сертификатов в хранилище NTAuth леса Active Directory.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Хранилище NTAuth"},"AIACA":{"whyItMatters":"Ошибки регистрации сертификатов AD CS могут влиять на проверку подлинности. Проверяйте шаблоны, EKU, разрешения и цепочки доверия.","whatWeCheck":["Проверка опубликованных в Active Directory сертификатов центров сертификации.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Сертификаты AIA CA действительны и корректно настроены для построения цепочки доверия.","summary":"Проверка опубликованных в Active Directory сертификатов центров сертификации.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Центры сертификации в AIA"},"UnconstrainedDelegation":{"whyItMatters":"Ошибки делегирования Kerberos могут позволять действия от имени других пользователей. Проверяйте доверенные службы и субъектов.","whatWeCheck":["Поиск учётных записей и компьютеров с неограниченным делегированием.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Неограниченное делегирование обнаружено только у контроллеров домена. На проверенных серверах-участниках нет условий для хранения пересланных TGT всех подключающихся пользователей через этот механизм. Ограниченное делегирование и RBCD оцениваются в других разделах.","summary":"Поиск учётных записей и компьютеров с неограниченным делегированием.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Неограниченное делегирование Kerberos"},"ConstrainedDelegation":{"whyItMatters":"Ошибки делегирования Kerberos могут позволять действия от имени других пользователей. Проверяйте доверенные службы и субъектов.","whatWeCheck":["Проверка разрешённых служб и параметров ограниченного делегирования.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Опасное ограниченное делегирование не обнаружено. Проверенные записи не делегируют Kerberos-доступ к контроллерам домена и не используют переход протокола без списка целевых служб.","summary":"Проверка разрешённых служб и параметров ограниченного делегирования.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Ограниченное делегирование Kerberos"},"RBCDelegation":{"whyItMatters":"Ошибки делегирования Kerberos могут позволять действия от имени других пользователей. Проверяйте доверенные службы и субъектов.","whatWeCheck":["Анализ разрешений RBCD на целевых компьютерных объектах.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"В домене не найдены учётные записи с настроенным Resource-Based Constrained Delegation (RBCD): атрибут msDS-AllowedToActOnBehalfOfOtherIdentity нигде не задан. Оценивать параметры RBCD было нечего — объектов с такой настройкой нет.","summary":"Анализ разрешений RBCD на целевых компьютерных объектах.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Ограниченное делегирование на основе ресурса (RBCD)"},"PasswordNeverExpires":{"whyItMatters":"Избыточные права и неверные настройки учётных записей создают пути компрометации. Особое внимание уделяйте административным и служебным записям.","whatWeCheck":["Поиск учётных записей с запретом истечения срока действия пароля.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Привилегированных записей с флагом «срок действия пароля не ограничен» не обнаружено. Для административных записей применяются требования доменной политики срока действия пароля.","summary":"Поиск учётных записей с запретом истечения срока действия пароля.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Пароли с неограниченным сроком действия"},"ReversibleEncryption":{"whyItMatters":"Избыточные права и неверные настройки учётных записей создают пути компрометации. Особое внимание уделяйте административным и служебным записям.","whatWeCheck":["Выявление учётных записей с хранением паролей в обратимо зашифрованном виде.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Учётных записей с хранением пароля посредством обратимого шифрования не обнаружено. Через этот механизм нельзя восстановить пароль в открытом виде из проверенных данных Active Directory.","summary":"Выявление учётных записей с хранением паролей в обратимо зашифрованном виде.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Обратимое шифрование паролей"},"ComputerObjectACL":{"whyItMatters":"Настройки компьютеров и их учётных записей влияют на защиту паролей, администрирование и риск бокового перемещения.","whatWeCheck":["Проверка явных разрешений на объекты компьютеров в AD.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"","summary":"Проверка явных разрешений на объекты компьютеров в AD.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Явно назначенные права на компьютеры"},"CriticalObjectACL":{"whyItMatters":"Ошибки делегирования прав на объекты AD могут позволить несанкционированное изменение или повышение привилегий. Проверьте ACL, наследование и вложенные группы.","whatWeCheck":["Анализ ACL схемы, разделов каталога и объектов ролей.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Ни один субъект вне Tier 0 не управляет проверенными критичными объектами: схемой, разделом конфигурации, контейнером разделов, RID Manager, объектом инфраструктуры и сайтами.","summary":"Анализ ACL схемы, разделов каталога и объектов ролей.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Права на критически важные объекты каталога"},"RODCPasswordReplication":{"whyItMatters":"Избыточные права и неверные настройки учётных записей создают пути компрометации. Особое внимание уделяйте административным и служебным записям.","whatWeCheck":["Проверка кэширования и репликации паролей на контроллерах домена только для чтения.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Ни один проверенный RODC не может кэшировать пароли привилегированных записей по политике репликации; ранее закэшированных секретов таких записей также не обнаружено.","summary":"Проверка кэширования и репликации паролей на контроллерах домена только для чтения.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Политика репликации паролей RODC"},"PasswordNotRequired":{"whyItMatters":"Избыточные права и неверные настройки учётных записей создают пути компрометации. Особое внимание уделяйте административным и служебным записям.","whatWeCheck":["Выявление учётных записей с флагом PASSWD_NOTREQD.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Среди включённых пользовательских и компьютерных записей не найдено флага PASSWD_NOTREQD («пароль не требуется»). Для них действуют соответствующие требования парольной политики.","summary":"Выявление учётных записей с флагом PASSWD_NOTREQD.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Учётные записи без обязательного пароля"},"InactiveAdmin":{"whyItMatters":"Избыточные права и неверные настройки учётных записей создают пути компрометации. Особое внимание уделяйте административным и служебным записям.","whatWeCheck":["Поиск длительно неиспользуемых привилегированных учётных записей.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Неактивных привилегированных учётных записей не обнаружено. Административные записи показывают недавнюю активность в проверяемых данных.","summary":"Поиск длительно неиспользуемых привилегированных учётных записей.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Неактивные административные учётные записи"},"gMSA":{"whyItMatters":"Избыточные права и неверные настройки учётных записей создают пути компрометации. Особое внимание уделяйте административным и служебным записям.","whatWeCheck":["Анализ настроек и использования групповых управляемых учётных записей служб.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Права получения управляемых паролей gMSA ограничены привилегированными субъектами. Непривилегированных субъектов, способных получать эти пароли, проверка не обнаружила.","summary":"Анализ настроек и использования групповых управляемых учётных записей служб.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Групповые управляемые учётные записи служб (gMSA)"},"gMSAPassword":{"whyItMatters":"Избыточные права и неверные настройки учётных записей создают пути компрометации. Особое внимание уделяйте административным и служебным записям.","whatWeCheck":["Проверка субъектов, которым разрешено получать управляемые пароли gMSA.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"","summary":"Проверка субъектов, которым разрешено получать управляемые пароли gMSA.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Права чтения паролей gMSA"},"MSA":{"whyItMatters":"Избыточные права и неверные настройки учётных записей создают пути компрометации. Особое внимание уделяйте административным и служебным записям.","whatWeCheck":["Проверка традиционных управляемых учётных записей служб (sMSA).","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Устаревшие автономные управляемые записи служб (sMSA) не обнаружены. Для обнаруженных управляемых служб используется более современная модель gMSA с автоматической ротацией пароля.","summary":"Проверка традиционных управляемых учётных записей служб (sMSA).","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Автономные управляемые учётные записи служб"},"AuthNPolicySilo":{"whyItMatters":"Избыточные права и неверные настройки учётных записей создают пути компрометации. Особое внимание уделяйте административным и служебным записям.","whatWeCheck":["Проверка изолированных групп применения политик проверки подлинности.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Проверенные хранилища политик проверки подлинности работают в обязательном режиме, их участники включены в соответствующие области, а изменять хранилища и политики могут только субъекты Tier 0.","summary":"Проверка изолированных групп применения политик проверки подлинности.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Хранилища политик проверки подлинности"},"AuthNPolicy":{"whyItMatters":"Избыточные права и неверные настройки учётных записей создают пути компрометации. Особое внимание уделяйте административным и служебным записям.","whatWeCheck":["Анализ настроек и назначения политик проверки подлинности.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"","summary":"Анализ настроек и назначения политик проверки подлинности.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Политики проверки подлинности"},"dMSA":{"whyItMatters":"Избыточные права и неверные настройки учётных записей создают пути компрометации. Особое внимание уделяйте административным и служебным записям.","whatWeCheck":["Проверка делегированных управляемых учётных записей служб.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Проверенные dMSA доступны для использования только привилегированным учётным записям и узлам, на которых работают соответствующие службы.","summary":"Проверка делегированных управляемых учётных записей служб.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Делегированные управляемые учётные записи служб (dMSA)"},"dMSALink":{"whyItMatters":"Избыточные права и неверные настройки учётных записей создают пути компрометации. Особое внимание уделяйте административным и служебным записям.","whatWeCheck":["Проверка связей между dMSA и заменяемыми учётными записями.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"","summary":"Проверка связей между dMSA и заменяемыми учётными записями.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Связи делегированных учётных записей dMSA"},"NonDefaultOwner":{"whyItMatters":"Избыточные права и неверные настройки учётных записей создают пути компрометации. Особое внимание уделяйте административным и служебным записям.","whatWeCheck":["Поиск пользовательских объектов, у которых назначен нетипичный владелец.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Владельцы пользовательских объектов соответствуют ожидающейся модели (Domain Admins). Путей повышения привилегий через нестандартное владение объектами не обнаружено.","summary":"Поиск пользовательских объектов, у которых назначен нетипичный владелец.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Нестандартные владельцы учётных записей"},"Tier0Account":{"whyItMatters":"Избыточные права и неверные настройки учётных записей создают пути компрометации. Особое внимание уделяйте административным и служебным записям.","whatWeCheck":["Оценка защиты учётных записей с доступом к критически важной инфраструктуре AD.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Все учётные записи Tier 0 включены в Protected Users. Для административных записей существенно снижены риски кражи учётных данных через NTLM, злоупотребления делегированием и атак с билетами Kerberos.","summary":"Оценка защиты учётных записей с доступом к критически важной инфраструктуре AD.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Защита учётных записей уровня 0 (Tier 0)"},"PrivilegedGroupMember":{"whyItMatters":"Избыточные права и неверные настройки учётных записей создают пути компрометации. Особое внимание уделяйте административным и служебным записям.","whatWeCheck":["Анализ состава административных и других привилегированных групп.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Состав привилегированных групп соответствует принципу минимальных полномочий. Избыточные или неожиданные членства в проверенных критичных группах не обнаружены.","summary":"Анализ состава административных и других привилегированных групп.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Участники привилегированных групп"},"OperatorGroup":{"whyItMatters":"Избыточные права и неверные настройки учётных записей создают пути компрометации. Особое внимание уделяйте административным и служебным записям.","whatWeCheck":["Проверка состава встроенных операторских и широких групп доступа.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Операторские группы пусты либо их участники защищены через Protected Users. Риск похищения учётных данных для операторских записей снижен.","summary":"Проверка состава встроенных операторских и широких групп доступа.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Участники операторских групп"},"SIDHistory":{"whyItMatters":"Избыточные права и неверные настройки учётных записей создают пути компрометации. Особое внимание уделяйте административным и служебным записям.","whatWeCheck":["Проверка атрибута sIDHistory и включённых в него идентификаторов безопасности.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Не обнаружено записей с привилегированным SID в sIDHistory, который НЕ происходит из исходного домена. Значения, оставшиеся после законной миграции, рассматриваются отдельно: их фактическая пригодность для повышения полномочий определяется фильтрацией SID в доверительных отношениях.","summary":"Проверка атрибута sIDHistory и включённых в него идентификаторов безопасности.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Возможное злоупотребление sIDHistory"},"AdminSDHolderACL":{"whyItMatters":"Избыточные права и неверные настройки учётных записей создают пути компрометации. Особое внимание уделяйте административным и служебным записям.","whatWeCheck":["Анализ ACL AdminSDHolder и распространяемых защитных разрешений.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"У контейнера AdminSDHolder только штатные разрешения ACL. Не обнаружены несанкционированные полномочия для повышения привилегий либо закрепления.","summary":"Анализ ACL AdminSDHolder и распространяемых защитных разрешений.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Права на объект AdminSDHolder"},"PrivilegedGroupACL":{"whyItMatters":"Избыточные права и неверные настройки учётных записей создают пути компрометации. Особое внимание уделяйте административным и служебным записям.","whatWeCheck":["Поиск опасных разрешений на группах, не защищённых AdminSDHolder.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Посторонних субъектов, способных изменять привилегированные группы, которые AdminSDHolder не защищает, не обнаружено.","summary":"Поиск опасных разрешений на группах, не защищённых AdminSDHolder.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"ACL привилегированных групп вне AdminSDHolder"},"UnprotectedPrivilegedGroups":{"whyItMatters":"Избыточные права и неверные настройки учётных записей создают пути компрометации. Особое внимание уделяйте административным и служебным записям.","whatWeCheck":["Поиск административных групп за пределами защиты AdminSDHolder.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Все найденные привилегированные группы защищены механизмом AdminSDHolder.","summary":"Поиск административных групп за пределами защиты AdminSDHolder.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Привилегированные группы без защиты AdminSDHolder"},"PrivilegedAccountACL":{"whyItMatters":"Избыточные права и неверные настройки учётных записей создают пути компрометации. Особое внимание уделяйте административным и служебным записям.","whatWeCheck":["Проверка прав изменения и владения административными учётными записями.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"За пределами ожидаемых субъектов не обнаружено лиц, способных захватить привилегированную учётную запись через её разрешения ACL.","summary":"Проверка прав изменения и владения административными учётными записями.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Права управления привилегированными учётными записями"},"PrivilegedAccountsRead":{"whyItMatters":"Избыточные права и неверные настройки учётных записей создают пути компрометации. Особое внимание уделяйте административным и служебным записям.","whatWeCheck":["Проверка разрешений на чтение и управление защищаемыми учётными записями.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Не удалось прочитать ни одной привилегированной пользовательской или служебной учётной записи данного домена. Этот результат НЕ подтверждает отсутствие таких записей.","summary":"Проверка разрешений на чтение и управление защищаемыми учётными записями.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Доступ к объектам привилегированных учётных записей"},"LogonScriptPermission":{"whyItMatters":"Избыточные права и неверные настройки учётных записей создают пути компрометации. Особое внимание уделяйте административным и служебным записям.","whatWeCheck":["Анализ путей сценариев входа и прав их изменения.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Сценарии входа, выполняемые учётными записями, могут изменять только администраторы и привилегированные субъекты.","summary":"Анализ путей сценариев входа и прав их изменения.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Сценарии входа учётных записей"},"PreWindows2000Access":{"whyItMatters":"Избыточные права и неверные настройки учётных записей создают пути компрометации. Особое внимание уделяйте административным и служебным записям.","whatWeCheck":["Проверка состава группы совместимого доступа с Windows 2000 и её полномочий.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Группа Pre-Windows 2000 Compatible Access не содержит опасных широких участников, например Anonymous Logon или Everyone. Через эту группу нельзя выполнять анонимное перечисление домена.","summary":"Проверка состава группы совместимого доступа с Windows 2000 и её полномочий.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Группа Pre-Windows 2000 Compatible Access"},"Kerberoastable":{"whyItMatters":"Обнаруженные секреты и возможность автономного подбора паролей повышают риск компрометации. Ограничьте доступ к результатам аудита.","whatWeCheck":["Поиск учётных записей служб, для которых доступны билеты Kerberos с возможностью автономного подбора пароля.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Среди пользовательских записей не обнаружены SPN (за исключением компьютерных записей и gMSA). Для проверенного набора записей Kerberoasting недоступен.","summary":"Поиск учётных записей служб, для которых доступны билеты Kerberos с возможностью автономного подбора пароля.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Учётные записи, допускающие Kerberoasting"},"ASREPRoastable":{"whyItMatters":"Обнаруженные секреты и возможность автономного подбора паролей повышают риск компрометации. Ограничьте доступ к результатам аудита.","whatWeCheck":["Поиск учётных записей без обязательной предварительной проверки подлинности Kerberos.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Учётные записи с отключённой предварительной проверкой Kerberos не обнаружены. Для проверенной области атака AS-REP Roasting через такие записи недоступна.","summary":"Поиск учётных записей без обязательной предварительной проверки подлинности Kerberos.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Учётные записи, допускающие AS-REP Roasting"},"UnixPassword":{"whyItMatters":"Обнаруженные секреты и возможность автономного подбора паролей повышают риск компрометации. Ограничьте доступ к результатам аудита.","whatWeCheck":["Поиск потенциально чувствительных парольных атрибутов UNIX в AD.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Учётных записей с доступными для чтения парольными атрибутами UNIX не обнаружено. В проверенном каталоге нет старых атрибутов, раскрывающих соответствующие пароли.","summary":"Поиск потенциально чувствительных парольных атрибутов UNIX в AD.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Парольные атрибуты UNIX"},"CredentialRoaming":{"whyItMatters":"Обнаруженные секреты и возможность автономного подбора паролей повышают риск компрометации. Ограничьте доступ к результатам аудита.","whatWeCheck":["Анализ сохранённых в AD данных Credential Roaming.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Объекты пользователей не содержат материала Credential Roaming. Он либо не используется, либо синхронизация ещё не выполнялась; в каталоге не обнаружены соответствующие закрытые ключи и мастер-ключи DPAPI.","summary":"Анализ сохранённых в AD данных Credential Roaming.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Перемещаемые учётные данные"},"CredentialRoamingPermission":{"whyItMatters":"Обнаруженные секреты и возможность автономного подбора паролей повышают риск компрометации. Ограничьте доступ к результатам аудита.","whatWeCheck":["Проверка делегированных разрешений на чтение Credential Roaming.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"В контейнерах, содержащих перенесённый материал Credential Roaming, не найдено субъектов с делегированным правом чтения его атрибутов.","summary":"Проверка делегированных разрешений на чтение Credential Roaming.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Права чтения перемещаемых учётных данных"},"GPPCredential":{"whyItMatters":"Обнаруженные секреты и возможность автономного подбора паролей повышают риск компрометации. Ограничьте доступ к результатам аудита.","whatWeCheck":["Поиск раскрытия паролей и других секретов в Group Policy Preferences (GPP).","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"В проверенных файлах Group Policy Preferences не найдены учётные данные. Хранение паролей GPP через cpassword в домене не обнаружено.","summary":"Поиск раскрытия паролей и других секретов в Group Policy Preferences (GPP).","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Учётные данные в предпочтениях групповой политики"},"SYSVOLCredential":{"whyItMatters":"Обнаруженные секреты и возможность автономного подбора паролей повышают риск компрометации. Ограничьте доступ к результатам аудита.","whatWeCheck":["Поиск паролей и секретов в доступных сценариях SYSVOL.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"В проверенных сценариях и конфигурационных файлах SYSVOL/NETLOGON не обнаружены учётные данные или чувствительная информация.","summary":"Поиск паролей и секретов в доступных сценариях SYSVOL.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Учётные данные в сценариях SYSVOL"},"LAPSCredential":{"whyItMatters":"Обнаруженные секреты и возможность автономного подбора паролей повышают риск компрометации. Ограничьте доступ к результатам аудита.","whatWeCheck":["Проверка разрешений на чтение паролей локальных администраторов из LAPS.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Паролей LAPS, доступных для чтения текущим пользователем, не найдено. Учётная запись, под которой выполняется аудит, не имеет доступа к паролям управляемых локальных администраторов. Это говорит только о правах ТЕКУЩЕЙ записи, а не обо всех возможных получателях.","summary":"Проверка разрешений на чтение паролей локальных администраторов из LAPS.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Доступ к паролям LAPS"},"BitLockerRecoveryKey":{"whyItMatters":"Обнаруженные секреты и возможность автономного подбора паролей повышают риск компрометации. Ограничьте доступ к результатам аудита.","whatWeCheck":["Проверка доступа к ключам и паролям восстановления BitLocker в AD.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Ключи восстановления BitLocker, доступные для чтения, не обнаружены. Учётная запись, выполняющая аудит, не может прочитать ни один сохранённый в AD пароль восстановления. Это ничего не говорит о правах ДРУГИХ субъектов — их делегированный доступ проверяется в следующем разделе.","summary":"Проверка доступа к ключам и паролям восстановления BitLocker в AD.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Доступ к ключам восстановления BitLocker"},"BitLockerRecoveryPermission":{"whyItMatters":"Обнаруженные секреты и возможность автономного подбора паролей повышают риск компрометации. Ограничьте доступ к результатам аудита.","whatWeCheck":["Проверка субъектов с делегированными правами чтения данных восстановления BitLocker.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"В контейнерах с компьютерными объектами не обнаружено субъектов, которым делегировано право читать пароли восстановления BitLocker.","summary":"Проверка субъектов с делегированными правами чтения данных восстановления BitLocker.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Делегированное чтение ключей BitLocker"},"PasswordInDescription":{"whyItMatters":"Обнаруженные секреты и возможность автономного подбора паролей повышают риск компрометации. Ограничьте доступ к результатам аудита.","whatWeCheck":["Поиск учётных данных в полях описания и других свободно заполняемых атрибутах.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"В свободных текстовых атрибутах проверенных объектов не обнаружены учётные данные. В частности, не найдены пароли в description, info, comment, adminDescription, атрибутах ссылок, extensionAttribute1–15 и msDS-cloudExtensionAttribute1–20.","summary":"Поиск учётных данных в полях описания и других свободно заполняемых атрибутах.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Пароли в текстовых атрибутах объектов"},"DeletedObject":{"whyItMatters":"Обнаруженные секреты и возможность автономного подбора паролей повышают риск компрометации. Ограничьте доступ к результатам аудита.","whatWeCheck":["Проверка чтения удалённых объектов и сохранённых атрибутов.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Среди удалённых объектов, доступных для чтения ТЕКУЩЕМУ пользователю, не найдено учётных данных в текстовых или парольных атрибутах.","summary":"Проверка чтения удалённых объектов и сохранённых атрибутов.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Доступные для чтения удалённые объекты"},"DeletedObjectsReader":{"whyItMatters":"Обнаруженные секреты и возможность автономного подбора паролей повышают риск компрометации. Ограничьте доступ к результатам аудита.","whatWeCheck":["Определение субъектов, имеющих право перечислять удалённые объекты.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Перечислять контейнер Deleted Objects могут только субъекты Tier 0 и, при установленном Exchange, предусмотренные служебные группы Exchange.","summary":"Определение субъектов, имеющих право перечислять удалённые объекты.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Права просмотра удалённых объектов"},"DangerousACL":{"whyItMatters":"Ошибки делегирования прав на объекты AD могут позволить несанкционированное изменение или повышение привилегий. Проверьте ACL, наследование и вложенные группы.","whatWeCheck":["Проверка опасных разрешений на корневом объекте домена.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Опасных разрешений ACL на корневом объекте домена не обнаружено. Чувствительные права, включая DCSync и запись, имеют только ожидаемые привилегированные субъекты.","summary":"Проверка опасных разрешений на корневом объекте домена.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Права доступа к корню домена"},"DangerousOUPermission":{"whyItMatters":"Ошибки делегирования прав на объекты AD могут позволить несанкционированное изменение или повышение привилегий. Проверьте ACL, наследование и вложенные группы.","whatWeCheck":["Анализ ACL организационных единиц и возможных путей повышения привилегий.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Опасных разрешений на OU не обнаружено. Проверенные ACL соответствуют ожидаемой модели: запись разрешена только привилегированным субъектам.","summary":"Анализ ACL организационных единиц и возможных путей повышения привилегий.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Опасные разрешения на OU"},"WeakCertificateMapping":{"whyItMatters":"Ошибки регистрации сертификатов AD CS могут влиять на проверку подлинности. Проверяйте шаблоны, EKU, разрешения и цепочки доверия.","whatWeCheck":["Проверка явного сопоставления сертификатов и возможных слабых привязок к учётным записям.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Слабых явных сопоставлений сертификатов не обнаружено. Непривилегированный субъект не может добавить такое сопоставление привилегированной записи.","summary":"Проверка явного сопоставления сертификатов и возможных слабых привязок к учётным записям.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Небезопасное сопоставление сертификатов"},"PasswordResetRight":{"whyItMatters":"Ошибки делегирования прав на объекты AD могут позволить несанкционированное изменение или повышение привилегий. Проверьте ACL, наследование и вложенные группы.","whatWeCheck":["Проверка субъектов с правом сброса паролей других учётных записей.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Опасных делегированных прав сброса пароля не обнаружено. Сбрасывать пароли административных записей могут только ожидаемые привилегированные субъекты.","summary":"Проверка субъектов с правом сброса паролей других учётных записей.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Права сброса паролей"},"AddComputerRight":{"whyItMatters":"Ошибки делегирования прав на объекты AD могут позволить несанкционированное изменение или повышение привилегий. Проверьте ACL, наследование и вложенные группы.","whatWeCheck":["Проверка прав создания объектов компьютеров.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Создание компьютерных объектов ограничено. Значение ms-DS-MachineAccountQuota равно 0, поэтому обычные пользователи не могут создавать компьютеры только за счёт этой квоты.","summary":"Проверка прав создания объектов компьютеров.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Права добавления компьютеров в домен"},"GPOUserRights":{"whyItMatters":"Ошибки делегирования прав на объекты AD могут позволить несанкционированное изменение или повышение привилегий. Проверьте ACL, наследование и вложенные группы.","whatWeCheck":["Поиск отступлений от стандартных настроек прав пользователя Windows в GPO.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Права пользователей, назначаемые через GPO, соответствуют стандартному набору Windows. Политики не расширяют назначения привилегий сверх штатных значений.","summary":"Поиск отступлений от стандартных настроек прав пользователя Windows в GPO.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Назначение прав пользователя через GPO"},"MachineAccountQuota":{"whyItMatters":"Ошибки делегирования прав на объекты AD могут позволить несанкционированное изменение или повышение привилегий. Проверьте ACL, наследование и вложенные группы.","whatWeCheck":["Проверка параметра ms-DS-MachineAccountQuota.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Значение ms-DS-MachineAccountQuota равно 0. Для присоединения компьютеров к домену требуются отдельно делегированные полномочия; обычная пользовательская квота не действует.","summary":"Проверка параметра ms-DS-MachineAccountQuota.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Квота создания компьютерных учётных записей"},"AddComputerGPO":{"whyItMatters":"Ошибки делегирования прав на объекты AD могут позволить несанкционированное изменение или повышение привилегий. Проверьте ACL, наследование и вложенные группы.","whatWeCheck":["Анализ групповых политик, влияющих на право добавлять компьютеры в домен.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"","summary":"Анализ групповых политик, влияющих на право добавлять компьютеры в домен.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Параметры GPO для добавления компьютеров"},"LAPSPermission":{"whyItMatters":"Ошибки делегирования прав на объекты AD могут позволить несанкционированное изменение или повышение привилегий. Проверьте ACL, наследование и вложенные группы.","whatWeCheck":["Анализ ACL, позволяющих читать пароли LAPS.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Чтение паролей LAPS ограничено ожидаемыми субъектами. Непривилегированных записей с правом чтения проверка не обнаружила; принцип минимальных полномочий соблюдён в проверенной области.","summary":"Анализ ACL, позволяющих читать пароли LAPS.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Разрешения на чтение LAPS"},"ComputerPasswordAge":{"whyItMatters":"Настройки компьютеров и их учётных записей влияют на защиту паролей, администрирование и риск бокового перемещения.","whatWeCheck":["Проверка давности изменения паролей компьютеров домена.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Все компьютеры, входившие в домен за последние 30 дней, меняли пароль своей машинной учётной записи в пределах 90 дней.","summary":"Проверка давности изменения паролей компьютеров домена.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Возраст паролей компьютерных учётных записей"},"OutdatedComputer":{"whyItMatters":"Настройки компьютеров и их учётных записей влияют на защиту паролей, администрирование и риск бокового перемещения.","whatWeCheck":["Поиск неподдерживаемых и устаревающих версий Windows.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Среди активных компьютеров не обнаружено систем Microsoft с завершённой поддержкой. Компьютеры, выпуск ОС которых удалось определить по таблице жизненного цикла, используют версии, ещё получающие обновления безопасности.","summary":"Поиск неподдерживаемых и устаревающих версий Windows.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Устаревшие версии Windows на компьютерах"},"NonDefaultComputerOwner":{"whyItMatters":"Настройки компьютеров и их учётных записей влияют на защиту паролей, администрирование и риск бокового перемещения.","whatWeCheck":["Проверка собственников компьютерных объектов в AD.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"У компьютерных объектов ожидаемые стандартные владельцы. Путей атаки RBCD через нестандартное владение объектами проверка не обнаружила.","summary":"Проверка собственников компьютерных объектов в AD.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Нестандартные владельцы объектов компьютеров"},"LAPSConfiguration":{"whyItMatters":"Настройки компьютеров и их учётных записей влияют на защиту паролей, администрирование и риск бокового перемещения.","whatWeCheck":["Проверка политики и параметров Windows LAPS и прежней версии LAPS.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"В домене обнаружено развёртывание LAPS с высоким охватом компьютеров. Пароли локальных администраторов уникальны для управляемых машин, что уменьшает риск бокового перемещения из-за повторного использования пароля.","summary":"Проверка политики и параметров Windows LAPS и прежней версии LAPS.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Конфигурация LAPS"},"LAPSCoverage":{"whyItMatters":"Настройки компьютеров и их учётных записей влияют на защиту паролей, администрирование и риск бокового перемещения.","whatWeCheck":["Оценка доли компьютеров с управлением паролем локального администратора.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"","summary":"Оценка доли компьютеров с управлением паролем локального администратора.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Охват компьютеров защитой LAPS"},"GPOPermission":{"whyItMatters":"Параметры групповой политики действуют на множество компьютеров и пользователей. Оцените область действия, владельцев и права на SYSVOL.","whatWeCheck":["Проверка списков управления доступом к объектам групповой политики.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"На объектах GPO в каталоге не обнаружены опасные разрешения и нестандартные владельцы. Также не найден неожиданный доступ на запись в проверяемые каталоги политик SYSVOL.","summary":"Проверка списков управления доступом к объектам групповой политики.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Разрешения на объекты GPO"},"GPOLocalGroup":{"whyItMatters":"Параметры групповой политики действуют на множество компьютеров и пользователей. Оцените область действия, владельцев и права на SYSVOL.","whatWeCheck":["Анализ добавления учётных записей в локальные группы посредством GPO.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Опасных назначений в локальные группы через GPO не обнаружено. Изменение состава локальных администраторов через политики ограничено в проверяемой области.","summary":"Анализ добавления учётных записей в локальные группы посредством GPO.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Назначение участников локальных групп через GPO"},"GPOSuppressedGroup":{"whyItMatters":"Параметры групповой политики действуют на множество компьютеров и пользователей. Оцените область действия, владельцев и права на SYSVOL.","whatWeCheck":["Перечень результатов, сознательно исключённых согласно условиям проверки.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"","summary":"Перечень результатов, сознательно исключённых согласно условиям проверки.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Объекты, исключённые из этой проверки"},"GPOScheduledTask":{"whyItMatters":"Параметры групповой политики действуют на множество компьютеров и пользователей. Оцените область действия, владельцев и права на SYSVOL.","whatWeCheck":["Проверка задач, создаваемых и настраиваемых групповыми политиками.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Уязвимых заданий, распространяемых через GPO, не обнаружено. Проверенные задания не запускают код по UNC-пути или из каталога, в который обычные пользователи могут записывать по стандартным разрешениям Windows.","summary":"Проверка задач, создаваемых и настраиваемых групповыми политиками.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Запланированные задания в GPO"},"GPOScriptPath":{"whyItMatters":"Параметры групповой политики действуют на множество компьютеров и пользователей. Оцените область действия, владельцев и права на SYSVOL.","whatWeCheck":["Проверка сценариев запуска и входа, заданных через GPO.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Сценарии, распространяемые через GPO, не найдены. В конфигурации групповых политик не обнаружены Logon/Logoff/Startup/Shutdown.","summary":"Проверка сценариев запуска и входа, заданных через GPO.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Пути сценариев в GPO"},"GPORegistrySetting":{"whyItMatters":"Параметры групповой политики действуют на множество компьютеров и пользователей. Оцените область действия, владельцев и права на SYSVOL.","whatWeCheck":["Анализ параметров реестра, устанавливаемых объектами групповой политики.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Известных уязвимых параметров реестра, развёрнутых через GPO, не обнаружено. Ни одна политика не устанавливает известные этой проверке опасные значения. Значения вне перечня учитываются количественно, но НЕ получают оценку безопасности.","summary":"Анализ параметров реестра, устанавливаемых объектами групповой политики.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Параметры реестра в GPO"},"GPORegistryValue":{"whyItMatters":"Параметры групповой политики действуют на множество компьютеров и пользователей. Оцените область действия, владельцев и права на SYSVOL.","whatWeCheck":["Проверка значений реестра, изменяемых групповыми политиками.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Параметров реестра, выходящих за пределы списка этой конкретной проверки, не обнаружено.","summary":"Проверка значений реестра, изменяемых групповыми политиками.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Значения реестра в GPO"},"PointAndPrintPolicy":{"whyItMatters":"Параметры групповой политики действуют на множество компьютеров и пользователей. Оцените область действия, владельцев и права на SYSVOL.","whatWeCheck":["Проверка ограничений Point and Print для установки драйверов принтеров.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"GPO не задают параметры Point and Print или установки драйверов принтеров. Начиная с обновлений Windows за август 2021 года, штатные ограничения требуют административных прав для установки драйверов.","summary":"Проверка ограничений Point and Print для установки драйверов принтеров.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Политики установки драйверов Point and Print"},"LAPSStalePassword":{"whyItMatters":"Настройки компьютеров и их учётных записей влияют на защиту паролей, администрирование и риск бокового перемещения.","whatWeCheck":["Поиск паролей LAPS, не сменявшихся в установленный срок.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Все компьютеры с обнаруженным LAPS меняли пароль по заданному расписанию. В проверенном наборе нет машин, у которых пароль локального администратора просрочил интервал ротации.","summary":"Поиск паролей LAPS, не сменявшихся в установленный срок.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Пароли LAPS, переставшие обновляться"},"LAPSGPOConfig":{"whyItMatters":"Настройки компьютеров и их учётных записей влияют на защиту паролей, администрирование и риск бокового перемещения.","whatWeCheck":["Проверка параметров Windows LAPS, заданных в GPO.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"Настройки LAPS, развёрнутые через групповые политики, не обнаружены. Это результат обнаружения конфигурации, а НЕ подтверждение защищённости паролей.","summary":"Проверка параметров Windows LAPS, заданных в GPO.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Параметры LAPS в групповых политиках"},"BloodHoundCollector":{"whyItMatters":"Граф отношений выявляет возможные цепочки доступа и повышения привилегий. Данные о структуре домена следует защищать.","whatWeCheck":["Сбор графа отношений между объектами, группами и разрешениями AD.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"","summary":"Сбор графа отношений между объектами, группами и разрешениями AD.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Сбор данных BloodHound"},"LDAPStatisticsModule":{"whyItMatters":"Оцените фактические значения и применимость рекомендаций к архитектуре вашего домена.","whatWeCheck":["Количество LDAP-запросов и объём данных по каждому модулю.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"","summary":"Количество LDAP-запросов и объём данных по каждому модулю.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Статистика LDAP по модулям"},"LDAPStatisticsTotal":{"whyItMatters":"Оцените фактические значения и применимость рекомендаций к архитектуре вашего домена.","whatWeCheck":["Сводное количество LDAP-запросов, результатов и переданных данных.","Проверенные параметры и обнаруженные объекты приведены в карточках результатов."],"secureMessage":"","summary":"Сводное количество LDAP-запросов, результатов и переданных данных.","filteringNote":"Некоторые штатные разрешения привилегированных записей скрыты; для их отображения включите -IncludePrivileged.","title":"Общая статистика LDAP"}};
        Object.keys(ruCheckContext).forEach(function(id) {
            const check = checkDescriptions[id];
            const ru = ruCheckContext[id];
            if (!check) return;
            check.originalEnglish = {
                whyItMatters: check.whyItMatters,
                whatWeCheck: check.whatWeCheck,
                secureMessage: check.secureMessage,
                filteringNote: check.filteringNote
            };
            check.title = ru.title;
            check.summary = ru.summary;
            check.whyItMatters = ru.whyItMatters;
            check.whatWeCheck = ru.whatWeCheck;
            if (check.secureMessage) check.secureMessage = ru.secureMessage;
            if (check.filteringNote) check.filteringNote = ru.filteringNote;
        });
        document.addEventListener('DOMContentLoaded', function() {
            // Translate visible finding titles by exact text match. Never modify
            // LDAP/JSON data attributes, IDs, links, or code/command fragments.
            const englishTitleMap = Object.create(null);
            Object.keys(ruFindingTitles).forEach(function(fid) {
                const finding = findingDefinitions[fid];
                if (finding && typeof finding.title === 'string') {
                    englishTitleMap[finding.title.trim()] = ruFindingTitles[fid];
                }
            });
            const auditRoot = document.querySelector('.report-content') ||
                              document.querySelector('main') || document.body;
            const walker = document.createTreeWalker(auditRoot, NodeFilter.SHOW_TEXT);
            let textNode;
            while ((textNode = walker.nextNode())) {
                const parent = textNode.parentElement;
                if (!parent || parent.closest('script,style,pre,code,textarea')) continue;
                const original = textNode.nodeValue;
                const label = original.trim();
                if (Object.prototype.hasOwnProperty.call(englishTitleMap, label)) {
                    const prefix = original.slice(0, original.indexOf(label));
                    const suffix = original.slice(original.indexOf(label) + label.length);
                    textNode.nodeValue = prefix + englishTitleMap[label] + suffix;
                }
            }
            document.querySelectorAll('.attr-name').forEach(function(node) {
                const name = node.textContent.trim();
                const colon = name.endsWith(':') ? ':' : '';
                const key = colon ? name.slice(0,-1).trim() : name;
                if(Object.prototype.hasOwnProperty.call(ruAttributeLabels,key)) {
                    node.textContent = ruAttributeLabels[key] + colon;
                }
            });
            const statuses = {
                'Yes':'Да','No':'Нет','True':'Истина','False':'Ложь',
                'Enabled':'Включено','Disabled':'Отключено',
                'Not Set':'Не задано','Not Configured':'Не настроено',
                'Not Found':'Не найдено','Not Tested':'Не проверено',
                'Unknown':'Неизвестно','None':'Нет','N/A':'Н/Д',
                'Required':'Обязательно','Allowed':'Разрешено','Denied':'Запрещено'
            };
            document.querySelectorAll('.attr-value span').forEach(function(node) {
                if(node.children.length) return;
                const key = node.textContent.trim();
                if(Object.prototype.hasOwnProperty.call(statuses,key)){
                    node.textContent = statuses[key];
                }
            });
        });
        // Russian presentation-only text transformation: no mutation of audit data.
        const ruReportDisplay = {"schema":"adPEAS-RU.ReportDisplay.1","locale":"ru-RU","exact":{"Privileged groups outside AdminSDHolder\u0027s protection:":"Привилегированные группы, не защищённые AdminSDHolder:","WriteProperty on member - may add a member to every protected group":"WriteProperty на member — позволяет добавлять участников во все защищённые группы","Self on member - may add itself to every protected group":"Self на member — позволяет добавлять себя во все защищённые группы","All extended rights - may reset the password of every protected account":"Все расширенные права — позволяют сбрасывать пароли всех защищённых учётных записей","Password reset right - may reset the password of every protected account":"Право сброса пароля — позволяет сбрасывать пароли всех защищённых учётных записей","WriteProperty on msDS-KeyCredentialLink - may add a key credential to every protected account and log on as it":"WriteProperty на msDS-KeyCredentialLink — позволяет добавлять ключи аутентификации защищённым записям и входить от их имени","WriteProperty on servicePrincipalName - may give every protected account an SPN and roast its password":"WriteProperty на servicePrincipalName — позволяет назначать SPN защищённым записям и создавать риск Kerberoasting","WriteProperty on altSecurityIdentities - may map a certificate onto every protected account":"WriteProperty на altSecurityIdentities — позволяет сопоставлять сертификат с защищённой учётной записью","WriteProperty on userAccountControl - may turn off pre-authentication or the password requirement on every protected account":"WriteProperty на userAccountControl — позволяет отключать предварительную проверку Kerberos или требование пароля","WriteProperty on member - may add a member to the group":"WriteProperty на member — позволяет изменять состав группы","Self on member - may add itself to the group":"Self на member — позволяет добавить собственную учётную запись в группу","Owner of the group - may rewrite its DACL":"Владелец группы — может изменять её DACL","All extended rights - may reset the password of the account":"Все расширенные права — позволяют сбросить пароль учётной записи","WriteProperty on member - may add itself to the group":"WriteProperty на member — позволяет добавить себя в группу","WriteDacl on group - may rewrite membership permissions":"WriteDacl группы — позволяет изменять разрешения на членство","GenericAll (Full Control)":"GenericAll (полный доступ)","GenericWrite (Write Properties)":"GenericWrite (изменение свойств)","WriteDacl (Modify Permissions)":"WriteDacl (изменение разрешений)","WriteOwner (Take Ownership)":"WriteOwner (смена владельца)","CreateChild (Create Objects)":"CreateChild (создание объектов)","DeleteChild (Delete Objects)":"DeleteChild (удаление объектов)","DeleteTree (Delete Subtree)":"DeleteTree (удаление поддерева)","Self (Validated Write)":"Self (проверяемая запись)","All Extended Rights":"Все расширенные права","Owner of the OU":"Владелец OU","Owner of the domain object":"Владелец объекта домена","Read / Write":"Чтение / запись","SYSVOL not accessible":"SYSVOL недоступен","No readable share found":"Общие ресурсы, доступные для чтения, не обнаружены","No members found in privileged groups":"Участники привилегированных групп не обнаружены","No dangerous members in Pre-Windows 2000 Compatible Access group":"В группе Pre-Windows 2000 Compatible Access опасных участников не обнаружено","Found 0 accounts with DCSync rights":"Субъекты с правами DCSync не обнаружены","SYSVOL is not accessible - GPO user rights could not be evaluated":"SYSVOL недоступен: не удалось проверить права пользователей из GPO","Only the site servers and the expected administrators can write to the System Management container":"Запись в контейнер System Management разрешена только серверам сайта и утверждённым администраторам","System Management container not found - sites, management points and its permissions were not read":"Контейнер System Management не найден; сайты, точки управления и права доступа не проверены","No hybrid configuration found - this organization appears to be purely on-premises":"Гибридная конфигурация не найдена: организация, вероятно, использует только локальную инфраструктуру Exchange","SCOM infrastructure detected":"Обнаружена инфраструктура SCOM","SCCM/MECM infrastructure detected":"Обнаружена инфраструктура SCCM/MECM","PXE/WDS servers detected":"Обнаружены серверы PXE/WDS","Who can add computers to the domain:":"Субъекты, которым разрешено добавлять компьютеры в домен:","Privileged accounts read:":"Прочитанные привилегированные учётные записи:","Password Never Expires":"Срок действия пароля не ограничен","Trust account":"Учётная запись доверия","Security configuration is properly set":"Проверяемая конфигурация соответствует требованиям безопасности","Error during check":"Ошибка выполнения проверки","No scripts distributed via GPO":"Сценарии, распространяемые через GPO, не обнаружены","No gMSA accounts found in domain":"Учётные записи gMSA в домене не обнаружены","No standalone MSAs found":"Автономные управляемые учётные записи служб (sMSA) не обнаружены","No external domain trusts found (isolated domain)":"Внешние доверительные отношения домена не обнаружены (изолированный домен)","No trusted Root CAs found in AD configuration":"В конфигурации AD не обнаружены доверенные корневые центры сертификации (CA)","No principal uses an explicit certificate mapping":"Учётных записей с явно заданным сопоставлением сертификатов не обнаружено","No non-privileged principal can write altSecurityIdentities on a privileged account":"Непривилегированных субъектов с правом изменения altSecurityIdentities привилегированной учётной записи не обнаружено","No scheduled tasks distributed via GPO":"Задачи, распространяемые через GPO, не обнаружены"},"regex":[["^Found (\\d+) GPO\\(s\\) with dangerous permissions, a writable SYSVOL folder or a non-default owner(?: \\((.*)\\))?$","Обнаружено GPO с опасными разрешениями, доступной для записи папкой SYSVOL или нестандартным владельцем: $1 ($2)"],["^Privileged groups outside AdminSDHolder\u0027s protection:$","Привилегированные группы вне защиты AdminSDHolder:"],["^Account Operators \\((no members|\\d+ member\\(s\\))\\) control (all \\d+|\\d+ of them) - the default of every new group$","Группа Account Operators ($1) по умолчанию управляет $2 незащищёнными группами"],["^Account Operators \\((no members|\\d+ member\\(s\\))\\) control (all \\d+|\\d+ of them) - the default of every new user$","Группа Account Operators ($1) по умолчанию управляет $2 незащищёнными учётными записями"],["^Account Operators \\(no members\\) control all (\\d+) - the default of every new group$","Группа Account Operators (нет участников) по умолчанию имеет права управления для всех $1 незащищённых групп"],["^Found (\\d+) principal\\(s\\) that can take over a privileged group AdminSDHolder does not protect$","Субъекты, способные получить контроль над привилегированными группами вне защиты AdminSDHolder: $1"],["^Found (\\d+) principal\\(s\\) that can take over an operator-level group AdminSDHolder does not protect$","Субъекты, способные получить контроль над операторскими группами вне защиты AdminSDHolder: $1"],["^Found (\\d+) non-Tier-0 principal\\(s\\) with control over an object the forest or the domain runs on$","Субъекты вне Tier 0 с управлением критическими объектами домена или леса: $1"],["^Found (\\d+) non-privileged account\\(s\\) with LAPS read access$","Непривилегированные записи с доступом на чтение LAPS: $1"],["^Found (\\d+) privileged account\\(s\\) with LAPS read access \\(expected\\)$","Привилегированные записи со штатным доступом на чтение LAPS: $1"],["^Found (\\d+) Exchange service group\\(s\\) with LAPS read access \\(by-design, cannot be removed\\)$","Служебные группы Exchange со штатным доступом на чтение LAPS: $1 (проверьте зависимости перед изменением)"],["^Found (\\d+) member\\(s\\) in (.+):$","Участники группы $2: $1"],["^Found (\\d+) SCOM management server\\(s\\)$","Обнаружено серверов управления SCOM: $1"],["^Found (\\d+) privileged group\\(s\\):$","Обнаружено привилегированных групп: $1"],["^Found (\\d+) Fine-Grained Password Polic(?:y|ies):$","Обнаружено детализированных политик паролей (FGPP): $1"],["^Found (\\d+) (?:GPO\\(s\\)|policies) with (.+)$","Обнаружено групповых политик: $1. Признак: $2"],["^No dangerous OU permissions detected in the (.+) analyzed$","В проверенной области $1 опасных разрешений OU не обнаружено"],["^No dangerous password reset rights detected in the (.+) analyzed$","В проверенной области $1 опасных прав сброса пароля не обнаружено"],["^No non-privileged accounts with LAPS read access found in the (.+) analyzed$","В проверенной области $1 нет непривилегированных субъектов с доступом на чтение LAPS"],["^([0-9]+) of them by ownership alone$","Только из-за нестандартного владельца: $1"],["^([0-9]+) with a writable policy folder$","С правами записи в папку GPO: $1"],["^Found ([0-9]+) of ([0-9]+) receive connector\\(s\\) granting SMTP rights to unauthenticated senders$","SMTP-соединители с разрешениями для неаутентифицированных отправителей: $1 из $2"],["^No dangerous permissions, no non-default owner and no unexpected SYSVOL write access on (\\d+) of (\\d+) GPO\\(s\\)$","У $1 из $2 групповых политик не обнаружены опасные разрешения, нестандартные владельцы или неожиданные права записи в SYSVOL"],["^No principal outside Tier-0 controls the schema, the configuration, the partitions, a role object or a site$","Субъекты вне Tier 0 не управляют схемой, конфигурацией, разделами, объектами ролей или сайтами"],["^Account Operators \\(no members\\) control (.*) - the default of every new user$","Группа Account Operators (нет участников) по умолчанию имеет права управления для $1 незащищённых учётных записей"],["^Tier-0 Account: (.*)$","Учётная запись Tier 0: $1"],["^GPO Local Group: (.*)$","Локальная группа в GPO: $1"],["^Scheduled Task: (.*)$","Запланированная задача: $1"],["^Fine-Grained Policy: (.*)$","Детализированная политика паролей: $1"],["^Add Computer Right: (.*)$","Право добавления компьютеров в домен: $1"],["^Trust: (.*)$","Доверительное отношение: $1"],["^Object: (.*)$","Объект: $1"],["^Found (\\d+) user\\(s\\) across (\\d+) privileged group\\(s\\):$","Обнаружено пользователей в привилегированных группах: $1; проверено групп: $2"],["^Found (\\d+) unprotected Tier-0 account\\(s\\) \\((\\d+) of (\\d+) in Protected Users, (\\d+)%\\):$","Учётных записей Tier 0 вне Protected Users: $1; защищено: $2 из $3 ($4%):"],["^(\\d+) further enabled computer account\\(s\\) carry the \u0027Password Not Required\u0027 flag$","Дополнительно обнаружены включённые учётные записи компьютеров с флагом PASSWD_NOTREQD: $1"],["^(\\d+) further privileged account\\(s\\) carry the flag with a password newer than (\\d+) days:$","Привилегированных записей с бессрочным паролем, изменённым менее $2 дней назад: $1"],["^(\\d+) privileged account\\(s\\) have inheritance disabled - a delegation on their OU does not reach them$","Привилегированных записей с отключённым наследованием прав: $1. Делегирование с родительской OU на них не распространяется"],["^OPSEC mode: Skipping user owner enumeration \\(would check all enabled users\\)$","Режим OPSEC: пропущена проверка владельцев учётных записей пользователей"],["^OPSEC mode: Skipping the logon scripts of accounts \\(reading their permissions takes an SMB connection to NETLOGON\\)$","Режим OPSEC: пропущена проверка сценариев входа (требуется SMB-подключение к NETLOGON)"],["^No scheduled tasks distributed via GPO in (\\d+) analyzed GPO\\(s\\)$","Задачи, распространяемые через GPO, не обнаружены; проанализировано политик: $1"],["^No vulnerable GPO local group assignments found in (\\d+) analyzed GPO\\(s\\)$","Небезопасных назначений в локальные группы через GPO не обнаружено; проверено политик: $1"],["^No read-only Domain Controller in this domain - there is no password replication policy to check$","Контроллеры домена только для чтения (RODC) не обнаружены; проверка политики репликации паролей не требуется"],["^Found (disabled|enabled) Guest account$","Обнаружена учётная запись Guest: $1"],["^Domain:\\s*(.+)$","Домен: $1"],["^(\\d+) further registry value\\(s\\) from (\\d+) policies are not on the list of this check - not judged$","Дополнительных значений реестра вне перечня проверки: $1; политик GPO: $2. Оценка не выполнялась"],["^(\\d+) further registry value\\(s\\) from (\\d+) policy are not on the list of this check - not judged$","Дополнительных значений реестра вне перечня проверки: $1; политик GPO: $2. Оценка не выполнялась"],["^(\\d+) OU\\(s\\) and (\\d+) container\\(s\\)$","$1 OU и $2 контейнеров"],["^(\\d+) OU\\(s\\)$","$1 OU"],["^(\\d+) container\\(s\\)$","$1 контейнеров"]]};
        const ruDisplayPatterns = ruReportDisplay.regex.map(function(entry) {
            return [new RegExp(entry[0], 'u'), entry[1]];
        });
        function ruTranslateVisibleText(original) {
            const leading = (original.match(/^\s*/) || [''])[0];
            const trailing = (original.match(/\s*$/) || [''])[0];
            const text = original.slice(leading.length, original.length - trailing.length);
            if (!text) return original;
            if (Object.prototype.hasOwnProperty.call(ruReportDisplay.exact, text)) {
                return leading + ruReportDisplay.exact[text] + trailing;
            }
            for (const entry of ruDisplayPatterns) {
                if (entry[0].test(text)) {
                    return leading + text.replace(entry[0], entry[1]) + trailing;
                }
            }
            return original;
        }
        document.addEventListener('DOMContentLoaded', function() {
            const nodes = document.querySelectorAll(
                '.finding-line, .object-body .attr-value, .object-header > span:first-child, .finding-key'
            );
            let translated = 0, reviewed = 0, englishCandidates = 0;
            const examples = [];
            nodes.forEach(function(root) {
                if (root.closest('pre,code,textarea,script,style,.tooltip-section,.tooltip-content')) return;
                const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
                const textNodes = [];
                let node;
                while ((node = walker.nextNode())) textNodes.push(node);
                textNodes.forEach(function(textNode) {
                    const parent = textNode.parentElement;
                    if (!parent || parent.closest('pre,code,textarea,script,style,.tooltip-section,.tooltip-content')) return;
                    reviewed++;
                    const oldText = textNode.nodeValue;
                    const newText = ruTranslateVisibleText(oldText);
                    if (newText !== oldText) {
                        textNode.nodeValue = newText;
                        translated++;
                    } else {
                        const candidate = oldText.trim();
                        if (candidate.length > 24 &&
                            /(?:\b(?:Found|could not|not read|permissions|privileged|principal|account|group|default|access|Password|will|without|expected)\b)/i.test(candidate) &&
                            !/[А-Яа-яЁё]/.test(candidate)) {
                            englishCandidates++;
                            if (examples.length < 20) examples.push(candidate.slice(0, 180));
                        }
                    }
                });
            });
            // Local, read-only diagnostic for administrators. No network traffic.
            window.adPEASRUReportAudit = Object.freeze({
                reviewed: reviewed, translated: translated,
                englishCandidates: englishCandidates, examples: examples
            });
        });
        // ruPolishReportPresentation: display-only processing of safe text nodes.
        document.addEventListener('DOMContentLoaded', function ruPolishReportPresentation() {
            const sectionNames = {
                'Analyzing Domain Configuration':'Анализ параметров домена',
                'Analyzing Access Permissions':'Анализ прав доступа',
                'Analyzing Delegation Settings':'Анализ делегирования',
                'Analyzing Certificate Services':'Анализ служб сертификатов',
                'Analyzing Privileged Accounts':'Анализ привилегированных учётных записей',
                'Analyzing Group Policy Objects':'Анализ групповых политик'
            };
            document.querySelectorAll('.section-header .section-title').forEach(function(node) {
                const match = node.textContent.trim().match(/^(\[\d+\/\d+\])\s+(.+)$/);
                if(match && sectionNames[match[2]]) node.textContent = match[1] + ' ' + sectionNames[match[2]];
            });
            const labels = {
                'Enabled':'Включено', 'Disabled':'Отключено','Optional':'Необязательно',
                'Required':'Обязательно', 'Not Configured':'Не настроено',
                'Not configured':'Не настроено','Not set':'Не задано',
                'Refused':'Отклонено','Restricted':'Ограничено','Checked':'Проверяется',
                '(none)':'(нет)','None':'Нет', 'No':'Нет', 'Yes':'Да'
            };
            const attributeNames = {
                maxTicketAgeTGT:'Время действия TGT',maxRenewalAge:'Срок продления TGT',
                maxServiceTicketAge:'Срок действия билета службы',maxClockSkew:'Допустимое расхождение часов',
                krbtgtPasswordAge:'Возраст пароля krbtgt',domainControllerTime:'Время контроллера домена',
                minPwdLength:'Минимальная длина пароля',passwordComplexity:'Сложность пароля',
                minPwdAge:'Минимальный срок действия пароля',maxPwdAge:'Максимальный срок действия пароля',
                pwdHistoryLength:'История паролей',reversibleEncryption:'Обратимое шифрование',
                lockoutThreshold:'Порог блокировки',lockoutDuration:'Продолжительность блокировки',
                lockoutObservationWindow:'Окно наблюдения блокировки'
            };
            document.querySelectorAll('.attr-row[data-attr-name]').forEach(function(row) {
                const key = row.getAttribute('data-attr-name');
                const label = row.querySelector('.attr-name');
                if(label && attributeNames[key]) label.textContent = attributeNames[key];
            });
            function textRu(original) {
                const value = original.trim();
                if(Object.prototype.hasOwnProperty.call(labels,value)) return labels[value];
                let match = value.match(/^(\d+) (days|hours|minutes|characters)( \(default\))?$/i);
                if(match){
                    const units={days:'дн.',hours:'ч',minutes:'мин',characters:'символов'};
                    return match[1]+' '+units[match[2].toLowerCase()]+(match[3]?' (по умолчанию)':'');
                }
                match=value.match(/^(\d+) days \(last changed: (\d{4}-\d{2}-\d{2})\)$/);
                if(match) return match[1]+' дн. (последнее изменение: '+match[2]+')';
                match=value.match(/^(\d+) passwords remembered$/);
                if(match) return 'Запоминается паролей: '+match[1];
                return original;
            }
            document.querySelectorAll('.attr-value').forEach(function(root) {
                const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);
                let node;
                while((node=walker.nextNode())){
                    if(node.parentElement && node.parentElement.closest('code,pre,a')) continue;
                    const translated=textRu(node.nodeValue);
                    if(translated !== node.nodeValue) node.nodeValue=translated;
                }
            });
            document.querySelectorAll('.finding-count').forEach(function(node){
                const match=node.textContent.trim().match(/^(\d+) элементов$/);
                if(!match)return;
                const n=parseInt(match[1],10),last=n%10,last2=n%100;
                const word=last2>=11&&last2<=14?'элементов':last===1?'элемент':last>=2&&last<=4?'элемента':'элементов';
                node.textContent=n+' '+word;
            });
            document.querySelectorAll('.object-header > span:first-child').forEach(function(node){
                if(node.textContent.indexOf('Domain: ')===0)node.textContent='Домен: '+node.textContent.slice(8);
                if(/^Domain Controllers \(\d+\)$/.test(node.textContent))node.textContent=node.textContent.replace('Domain Controllers','Контроллеры домена');
            });
            document.querySelectorAll('[aria-label]').forEach(function(node){
                const label=node.getAttribute('aria-label');
                if(/^Filter by Findings: \d+ critical issues$/.test(label))node.setAttribute('aria-label',label.replace(/^Filter by Findings:/,'Фильтр нарушений:').replace(' critical issues',''));
                if(/^Filter by Hints: \d+ items$/.test(label))node.setAttribute('aria-label',label.replace(/^Filter by Hints:/,'Фильтр предупреждений:').replace(' items',''));
                if(/^Filter by Notes: \d+ items$/.test(label))node.setAttribute('aria-label',label.replace(/^Filter by Notes:/,'Фильтр сведений:').replace(' items',''));
                if(/^Filter by Secure: \d+ items$/.test(label))node.setAttribute('aria-label',label.replace(/^Filter by Secure:/,'Фильтр безопасных результатов:').replace(' items',''));
            });
            const a11y={
                'Type to filter findings by text content':'Введите текст для поиска',
                'Toggle to show or hide findings marked as completed':'Показать или скрыть выполненные результаты'
            };
            document.querySelectorAll('.visually-hidden').forEach(function(node){
                const key=node.textContent.trim();
                if(a11y[key])node.textContent=a11y[key];
            });
        });
        // Scoring context data for context-aware risk calculation
        const scoringContext = {{SCORING_CONTEXT_JSON}};

        document.addEventListener('DOMContentLoaded', function() {
            // Favicon: adPEAS logo as 32x32 PNG via Blob URL (works on file:// protocol)
            (function() {
                try {
                    var b64 = 'iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAKVSURBVFhH7dHJS9RhHMfxz0xjOjIzbjluiSaCYqBWmkqOhmmUW7hkOU3u5kxu4zb5y1HDMVxGC/diXDLNykuFWZpgZBch6A+I7gXRpVNB8gm9+YOiDtXl9zo+z5fnDd8HkEgkEsmfKwQQKj78l9IBzAA4AsAVQCKASPHQ35aLE4WzWPvyLmZqndp7b4mNLYd4aNuVSZfoi83u8QDcAIqvd6vsdktvGfFZNto0gjDhmTe+oTZahn2rC0xeMeVWz/AHrzIPTSwdS7bdDQyWR8Uvo6qHpwcfMrR3gUjVb7/eb7EnPOqaDV4vNLs/bhnz2hx54UNhPJDnajzfF1s83hha3DZzjMqD4vYO84B2uMqmYYnViVcd3px46cf2yQBmlaqpb1JvOdZieWs1muUdnt+CQkB9kTONgj+zz4PhYaDPfgVN1w7w+nwQLzTso6nLj2Z7APMvuzGzzJnZVXLqcrGq08FZ3N7ROLo3pXNORcuYB+v7fVnb488yQcvMIg/qzd6st/uxrs+PhkZvhkQoGZuiYYZBy4STGgaHuTLfqGVdbwBNNl+WCB4sqFcyq1LGjHLwVDE+pxSgw2qFTNzdpWMB5sHniq+DKwreWFHSvqRi96KKbTOutN5RsW1KTcGhZuOwiqXtziwSXFjW4coau5pNoyo2jijZMOpEYWYPqwdkzK3BpzQDhiLiEC5u/VRWBeIqbLA3jeN126z8Q+s0vjffBrsW5exbUrD/qYKd92W0zoEDzxQcXHFizxM5W6fBtlkZ2+flNPXhY5oeQxoNDgNwEjd+1/ZfBQZF4mhkEjJjUmGIT8elxGzUxqXDEn8aNl0ebiafxcTxAkwm5cChO4OBqCRUAogAIAd2Vv7rtUskEolE8j/9AG6P+zF32FIuAAAAAElFTkSuQmCC';
                    var byteStr = atob(b64);
                    var bytes = new Uint8Array(byteStr.length);
                    for (var i = 0; i < byteStr.length; i++) bytes[i] = byteStr.charCodeAt(i);
                    var blob = new Blob([bytes], { type: 'image/png' });
                    var url = URL.createObjectURL(blob);
                    var link = document.createElement('link');
                    link.rel = 'icon';
                    link.type = 'image/png';
                    link.href = url;
                    document.head.appendChild(link);
                } catch(e) { /* favicon setup failed, non-critical */ }
            })();

            // Theme: Check system preference first, then localStorage, then default
            let savedTheme = safeGetItem('adpeas-theme');
            if (!savedTheme) {
                // Auto-detect system preference
                if (window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches) {
                    savedTheme = 'light';
                } else {
                    savedTheme = '{{DEFAULT_THEME}}';
                }
            }
            document.documentElement.setAttribute('data-theme', savedTheme);
            updateThemeUI(savedTheme);

            // Listen for system theme changes
            if (window.matchMedia) {
                window.matchMedia('(prefers-color-scheme: light)').addEventListener('change', function(e) {
                    // Only auto-switch if user hasn't manually set a preference
                    if (!safeGetItem('adpeas-theme')) {
                        const newTheme = e.matches ? 'light' : 'dark';
                        document.documentElement.setAttribute('data-theme', newTheme);
                        updateThemeUI(newTheme);
                    }
                });
            }

            // Debounced search input to prevent performance issues on large reports
            let searchDebounceTimer = null;
            document.getElementById('searchInput').addEventListener('input', function(e) {
                clearTimeout(searchDebounceTimer);
                searchDebounceTimer = setTimeout(() => {
                    currentSearchQuery = e.target.value.toLowerCase();
                    applyFilters();
                }, UI_CONSTANTS.SEARCH_DEBOUNCE_DELAY);
            });

            // Initialize finding tooltips
            initFindingTooltips();

            // Initialize check help tooltips
            initCheckTooltips();

            // Initialize score breakdown tooltips
            initScoreTooltips();

            // Initialize draggable tooltips/popups
            initDraggableTooltips();

            // Initialize checkbox system
            initCheckboxSystem();

            // Initialize keyboard shortcuts
            initKeyboardShortcuts();

            // Create shortcut help modal
            createShortcutHelpModal();

            // Generate Top Priority Actions
            generateTopPriorityActions();

            // Populate score badges on finding cards, then sort by score
            populateCardScores();
            sortCardsByScore();

            // Initialize attribute drag & drop reordering
            initAttributeDragAndDrop();

            // Initialize per-card name-column resizing
            initColumnResize();
        });

        let activeTooltip = null;

        function initFindingTooltips() {
            // Create tooltip container
            const tooltipDiv = document.createElement('div');
            tooltipDiv.id = 'findingTooltip';
            tooltipDiv.className = 'finding-tooltip';
            tooltipDiv.setAttribute('role', 'dialog');
            tooltipDiv.setAttribute('aria-modal', 'false');
            tooltipDiv.setAttribute('aria-label', 'Подробности нарушения');
            document.body.appendChild(tooltipDiv);

            // Add event listeners to all finding triggers
            document.querySelectorAll('[data-finding-id]').forEach(trigger => {
                trigger.classList.add('finding-tooltip-trigger');
                trigger.setAttribute('role', 'button');
                trigger.setAttribute('tabindex', '0');
                trigger.setAttribute('aria-haspopup', 'dialog');
                trigger.setAttribute('aria-expanded', 'false');

                // Click handler
                trigger.addEventListener('click', function(e) {
                    e.stopPropagation();
                    showFindingTooltip(this, this.dataset.findingId);
                });

                // Keyboard handler for accessibility
                trigger.addEventListener('keydown', function(e) {
                    if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        e.stopPropagation();
                        showFindingTooltip(this, this.dataset.findingId);
                    }
                });
            });

            // Close tooltip when clicking outside
            document.addEventListener('click', function(e) {
                if (activeTooltip && !e.target.closest('.finding-tooltip') && !e.target.closest('[data-finding-id]')) {
                    hideTooltip();
                }
            });

            // Close on escape key
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape' && activeTooltip) {
                    hideTooltip();
                }
            });
        }

        let activeFindingTrigger = null;

        function showFindingTooltip(trigger, findingId) {
            const tooltip = document.getElementById('findingTooltip');
            const finding = findingDefinitions[findingId];

            if (!finding) {
                console.warn('Finding definition not found:', findingId);
                return;
            }

            // Close any previously open tooltip first
            if (activeFindingTrigger && activeFindingTrigger !== trigger) {
                activeFindingTrigger.setAttribute('aria-expanded', 'false');
            }

            // Get actual severity using hybrid approach (Option C):
            // 1. First: Check the trigger element itself for severity class (e.g., <span class="finding" data-finding-id="...">)
            // 2. Then: Check the attr-value div for severity class
            // 3. Fallback: Use parent card's severity
            // 4. Final fallback: Use static definition severity
            let actualSeverity = null;

            // Check severity class directly on the trigger element (most precise - for multi-value attributes)
            // HTML: <span class="finding" data-finding-id="PRIVILEGED_GROUP_MEMBERSHIP">Domain Admins</span>
            if (trigger.classList.contains('finding')) {
                actualSeverity = 'finding';
            } else if (trigger.classList.contains('hint')) {
                actualSeverity = 'hint';
            } else if (trigger.classList.contains('note')) {
                actualSeverity = 'note';
            } else if (trigger.classList.contains('secure')) {
                actualSeverity = 'secure';
            }

            // Check for attribute-level severity on attr-value div (for single-value attributes)
            if (!actualSeverity) {
                const attrValue = trigger.closest('.attr-value');
                if (attrValue) {
                    if (attrValue.classList.contains('finding')) {
                        actualSeverity = 'finding';
                    } else if (attrValue.classList.contains('hint')) {
                        actualSeverity = 'hint';
                    } else if (attrValue.classList.contains('note')) {
                        actualSeverity = 'note';
                    } else if (attrValue.classList.contains('secure')) {
                        actualSeverity = 'secure';
                    }
                }
            }

            // Fallback to card severity if no attribute severity found
            if (!actualSeverity) {
                const parentCard = trigger.closest('.finding-card');
                actualSeverity = parentCard?.dataset?.severity || null;
            }

            // Build tooltip HTML with actual severity override
            tooltip.innerHTML = buildTooltipHtml(finding, findingId, actualSeverity);

            // Make visible first (but off-screen) so we can measure
            tooltip.style.visibility = 'hidden';
            tooltip.classList.add('visible');

            // Position tooltip (now we can measure correctly)
            positionTooltip(tooltip, trigger);

            // Make fully visible
            tooltip.style.visibility = 'visible';
            activeTooltip = tooltip;
            activeFindingTrigger = trigger;

            // Update ARIA state
            trigger.setAttribute('aria-expanded', 'true');

            // Add section toggle listeners
            tooltip.querySelectorAll('.tooltip-section-title').forEach(title => {
                title.addEventListener('click', function() {
                    this.classList.toggle('collapsed');
                    const content = this.nextElementSibling;
                    content.classList.toggle('collapsed');
                });
            });
        }

        function hideTooltip() {
            const tooltip = document.getElementById('findingTooltip');
            tooltip.classList.remove('visible');
            activeTooltip = null;

            // Reset ARIA expanded state on trigger
            if (activeFindingTrigger) {
                activeFindingTrigger.setAttribute('aria-expanded', 'false');
                activeFindingTrigger = null;
            }
        }

        function positionTooltip(tooltip, trigger) {
            const rect = trigger.getBoundingClientRect();
            const viewportWidth = window.innerWidth;
            const viewportHeight = window.innerHeight;

            // Reset position for measurement
            tooltip.style.left = '0';
            tooltip.style.top = '0';

            // Get tooltip dimensions
            const tooltipRect = tooltip.getBoundingClientRect();

            // Calculate position - prefer below and to the right of trigger
            let left = rect.left;
            let top = rect.bottom + 8;

            // Adjust if too far right
            if (left + tooltipRect.width > viewportWidth - UI_CONSTANTS.VIEWPORT_PADDING) {
                left = viewportWidth - tooltipRect.width - 20;
            }

            // Adjust if too far left
            if (left < UI_CONSTANTS.VIEWPORT_PADDING) {
                left = UI_CONSTANTS.VIEWPORT_PADDING;
            }

            // Adjust if too far down - show above instead
            if (top + tooltipRect.height > viewportHeight - UI_CONSTANTS.VIEWPORT_PADDING) {
                top = rect.top - tooltipRect.height - 8;
            }

            // Ensure top is not negative
            if (top < UI_CONSTANTS.VIEWPORT_PADDING) {
                top = UI_CONSTANTS.VIEWPORT_PADDING;
            }

            tooltip.style.left = left + 'px';
            tooltip.style.top = top + 'px';
        }

        function buildTooltipHtml(finding, findingId, actualSeverity) {
            const ruExtra = ruFindingExplanations[findingId] || {};
            const titleRu = ruFindingTitles[findingId] || finding.title;
            const isSecureRu = actualSeverity === 'secure' ||
                (finding.risk && finding.risk.toLowerCase() === 'secure');
            const descriptionRu = ruExtra.description ||
                ('Краткое русское пояснение: ' + titleRu + '. Для оценки конкретных условий используйте данные карточки и полный технический оригинал EN.');
            const impactRu = ruExtra.impact || (isSecureRu ?
                ['Обнаруженный параметр соответствует ожидаемому безопасному состоянию.'] :
                ['Последствия зависят от полномочий затронутого субъекта и области действия настройки.']);
            const remediationRu = ruExtra.remediation || (isSecureRu ?
                ['Сохраните действующие защитные настройки и проверяйте их после изменений инфраструктуры.'] :
                ['Проверьте необходимость настройки и соответствие принципу минимальных привилегий. Для исправления опирайтесь на документацию Microsoft и действующие политики организации.']);
            const attackRu = ruExtra.attack || [];
            // Map card severity to display label and CSS class
            // actualSeverity comes from parent card's data-severity attribute
            // If provided, it overrides the static finding.risk from definition
            // Maps SeverityClasses (from adPEAS-Types.ps1) to display labels and CSS classes
            // These values are used for tooltip badges and match the central definitions
            const severityMap = {
                'finding': { label: 'НАРУШЕНИЕ', class: 'finding' },
                'hint': { label: 'ПРЕДУПРЕЖДЕНИЕ', class: 'hint' },
                'note': { label: 'СВЕДЕНИЯ', class: 'note' },
                'secure': { label: 'БЕЗОПАСНО', class: 'secure' }  // Blue in CSS
            };

            let riskLabel, riskClass;
            if (actualSeverity && severityMap[actualSeverity]) {
                // Use actual severity from parent card (dynamic)
                riskLabel = severityMap[actualSeverity].label;
                riskClass = severityMap[actualSeverity].class;
            } else {
                // Fallback to static definition
                riskLabel = finding.risk;
                riskClass = finding.risk.toLowerCase();
            }

            let html = `
                <div class="tooltip-header">
                    <div>
                        <div class="tooltip-title">${escapeHtml(ruFindingTitles[findingId] || finding.title)}</div>
                        <span class="tooltip-risk ${riskClass}">${escapeHtml(riskLabel)}</span>
                    </div>
                    <button class="tooltip-close" onclick="hideTooltip()">&times;</button>
                </div>
                <div class="tooltip-body">
            `;

            // Description
            html += `
                <div class="tooltip-section">
                    <div class="tooltip-section-title">
                        <span class="toggle-icon">&#9660;</span> Описание
                    </div>
                    <div class="tooltip-section-content">
                        ${escapeHtml(descriptionRu)}
                    </div>
                </div>
            `;

            // Impact (collapsed by default)
            if (impactRu && impactRu.length > 0) {
                html += `
                    <div class="tooltip-section">
                        <div class="tooltip-section-title collapsed">
                            <span class="toggle-icon">&#9660;</span> Последствия
                        </div>
                        <div class="tooltip-section-content collapsed">
                            <ul>
                                ${impactRu.map(i => `<li>${escapeHtml(i)}</li>`).join('')}
                            </ul>
                        </div>
                    </div>
                `;
            }

            // Attack/Protection section (collapsible by default)
            // For "Secure" findings, this section describes what attacks are prevented
            if (attackRu && attackRu.length > 0) {
                const isSecure = actualSeverity === 'secure' || (finding.risk && finding.risk.toLowerCase() === 'secure');
                const attackSectionTitle = isSecure ? 'Предотвращаемые угрозы' : 'Этапы атаки';
                html += `
                    <div class="tooltip-section">
                        <div class="tooltip-section-title collapsed">
                            <span class="toggle-icon">&#9660;</span> ${attackSectionTitle}
                        </div>
                        <div class="tooltip-section-content collapsed">
                            <ul>
                                ${attackRu.map(a => `<li>${escapeHtml(a)}</li>`).join('')}
                            </ul>
                        </div>
                    </div>
                `;
            }

            // Remediation / Best Practices section
            // For "Secure" findings, this section describes how to maintain the secure configuration
            if (remediationRu && remediationRu.length > 0) {
                const isSecureConfig = actualSeverity === 'secure' || (finding.risk && finding.risk.toLowerCase() === 'secure');
                const remediationTitle = isSecureConfig ? 'Поддержание защиты' : 'Меры по устранению';
                html += `
                    <div class="tooltip-section">
                        <div class="tooltip-section-title collapsed">
                            <span class="toggle-icon">&#9660;</span> ${remediationTitle}
                        </div>
                        <div class="tooltip-section-content collapsed">
                            <ul>
                                ${remediationRu.map(r => `<li>${escapeHtml(r)}</li>`).join('')}
                            </ul>
                        </div>
                    </div>
                `;
            }

            // Remediation Commands (PowerShell with Copy button)
            if (finding.remediationCommands && finding.remediationCommands.length > 0) {
                html += `
                    <div class="tooltip-section">
                        <div class="tooltip-section-title collapsed">
                            <span class="toggle-icon">&#9660;</span> Команды исправления
                        </div>
                        <div class="tooltip-section-content collapsed">
                            <div class="remediation-disclaimer">&#9888; Команды приведены как примеры. Перед применением проверьте их в тестовой среде и адаптируйте к вашей инфраструктуре.</div>
                            ${finding.remediationCommands.map(cmd => `
                                <div class="remediation-command">
                                    <div class="remediation-command-desc">${escapeHtml(cmd.description)}</div>
                                    <div class="remediation-code">
                                        <button class="copy-btn" onclick="copyToClipboard(this, \`${cmd.command.replace(/`/g, '\\`').replace(/\\/g, '\\\\')}\`)">Копировать</button>
                                        <pre>${escapeHtml(cmd.command)}</pre>
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                `;
            }

            // References (collapsible by default)
            if (finding.references && finding.references.length > 0) {
                html += `
                    <div class="tooltip-section">
                        <div class="tooltip-section-title collapsed">
                            <span class="toggle-icon">&#9660;</span> Источники
                        </div>
                        <div class="tooltip-section-content collapsed tooltip-references">
                            ${finding.references.map(r => `<a href="${escapeHtml(r.url)}" target="_blank" rel="noopener">${escapeHtml(r.title)}</a>`).join('')}
                        </div>
                    </div>
                `;
            }

            // Tools (collapsible by default) - supports both string and object format
            if (finding.tools && finding.tools.length > 0) {
                html += `
                    <div class="tooltip-section">
                        <div class="tooltip-section-title collapsed">
                            <span class="toggle-icon">&#9660;</span> Инструменты
                        </div>
                        <div class="tooltip-section-content collapsed tooltip-tools">
                            ${finding.tools.map(t => {
                                // Support both string (legacy) and object format {name, url}
                                if (typeof t === 'object' && t.name) {
                                    if (t.url) {
                                        return `<a href="${escapeHtml(t.url)}" target="_blank" rel="noopener" class="tooltip-tool tooltip-tool-link">${escapeHtml(t.name)}</a>`;
                                    } else {
                                        return `<span class="tooltip-tool">${escapeHtml(t.name)}</span>`;
                                    }
                                } else {
                                    return `<span class="tooltip-tool">${escapeHtml(t)}</span>`;
                                }
                            }).join('')}
                        </div>
                    </div>
                `;
            }

            // Curated Russian description, impact and remediation for every FindingId.
            // Attack is shown only when an individual RU explanation exists.
            // English originals remain available separately for comparison.
            const ruFull = ruFullFindingTechnical[findingId] || null;
            if (ruFull) {
                const addRuList = (label, values) =>
                    values && values.length > 0
                        ? '<strong>' + label + '</strong><ul>' +
                          values.map(value => '<li>' + escapeHtml(value) + '</li>').join('') +
                          '</ul>'
                        : '';
                html += '<details class="tooltip-section" lang="ru">' +
                    '<summary>Подробное техническое описание</summary>' +
                    '<p>' + escapeHtml(ruFull.description) + '</p>' +
                    addRuList('Последствия', ruFull.impact) +
                    addRuList('Сценарий атаки', ruFull.attack) +
                    addRuList('Рекомендации по устранению', ruFull.remediation) +
                    '</details>';
            }
            html += '<details class="tooltip-section" lang="en">' +
                '<summary>Сверить с исходным текстом на английском (EN)</summary>' +
                '<p>' + escapeHtml(finding.description) + '</p>' +
                (finding.impact ? '<p>Impact</p><ul>' + finding.impact.map(i => '<li>' + escapeHtml(i) + '</li>').join('') + '</ul>' : '') +
                (finding.attack ? '<p>Attack</p><ul>' + finding.attack.map(i => '<li>' + escapeHtml(i) + '</li>').join('') + '</ul>' : '') +
                (finding.remediation ? '<p>Remediation</p><ul>' + finding.remediation.map(i => '<li>' + escapeHtml(i) + '</li>').join('') + '</ul>' : '') +
                '</details>';
            // MITRE ATT&CK
            if (finding.mitre) {
                const mitreUrl = `https://attack.mitre.org/techniques/${finding.mitre.replace('.', '/')}/`;
                html += `
                    <div class="tooltip-section">
                        <div class="tooltip-section-content">
                            <span class="tooltip-mitre">
                                <a href="${mitreUrl}" target="_blank" rel="noopener">MITRE ATT&CK: ${escapeHtml(finding.mitre)}</a>
                            </span>
                        </div>
                    </div>
                `;
            }

            html += '</div>';
            return html;
        }

        function escapeHtml(text) {
            if (!text) return '';
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        // Escape JSON for use in HTML data attributes
        // Uses single quotes in HTML attribute, escapes single quotes in JSON
        function escapeJsonForAttr(obj) {
            if (!obj) return '';
            const json = JSON.stringify(obj);
            // Replace single quotes with escaped version for safe embedding
            return json.replace(/'/g, '&#39;');
        }

        // Decode HTML entities in a string (for parsing data attributes)
        function decodeHtmlEntities(str) {
            if (!str) return '';
            const txt = document.createElement('textarea');
            txt.innerHTML = str;
            return txt.value;
        }

        // Check description tooltip functionality
        let activeCheckTooltip = null;

        let activeCheckTrigger = null;

        function initCheckTooltips() {
            // Create check tooltip container
            const tooltipDiv = document.createElement('div');
            tooltipDiv.id = 'checkTooltip';
            tooltipDiv.className = 'check-tooltip';
            tooltipDiv.setAttribute('role', 'dialog');
            tooltipDiv.setAttribute('aria-modal', 'false');
            tooltipDiv.setAttribute('aria-label', 'Описание проверки');
            document.body.appendChild(tooltipDiv);

            // Add event listeners to all check help buttons
            document.querySelectorAll('.check-help-btn').forEach(btn => {
                btn.setAttribute('aria-haspopup', 'dialog');
                btn.setAttribute('aria-expanded', 'false');
                btn.setAttribute('aria-label', 'Описание проверки');

                btn.addEventListener('click', function(e) {
                    e.stopPropagation();
                    // Prefer ObjectType over title for tooltip lookup (more reliable)
                    const objectType = btn.dataset.objectType;
                    const checkTitle = btn.dataset.checkTitle;
                    showCheckTooltip(this, objectType, checkTitle);
                });

                // Keyboard support
                btn.addEventListener('keydown', function(e) {
                    if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        e.stopPropagation();
                        const objectType = btn.dataset.objectType;
                        const checkTitle = btn.dataset.checkTitle;
                        showCheckTooltip(this, objectType, checkTitle);
                    }
                });
            });

            // Close tooltip when clicking outside
            document.addEventListener('click', function(e) {
                if (activeCheckTooltip && !e.target.closest('.check-tooltip') && !e.target.closest('.check-help-btn')) {
                    hideCheckTooltip();
                }
            });

            // Close on escape key (consistent with finding tooltip)
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape' && activeCheckTooltip) {
                    hideCheckTooltip();
                }
            });
        }

        function showCheckTooltip(trigger, objectType, checkTitle) {
            const tooltip = document.getElementById('checkTooltip');

            // Look up check description by ObjectType
            if (!objectType || !checkDescriptions[objectType]) {
                console.warn('Check description not found for ObjectType:', objectType);
                return;
            }

            const check = checkDescriptions[objectType];
            const lookupKey = objectType;

            // Get card severity from parent finding-card element
            const findingCard = trigger.closest('.finding-card');
            const cardSeverity = findingCard ? findingCard.dataset.severity : null;

            // Build tooltip HTML (pass severity for secure message display)
            tooltip.innerHTML = buildCheckTooltipHtml(check, checkTitle, cardSeverity);

            // Make visible first (but off-screen) so we can measure
            tooltip.style.visibility = 'hidden';
            tooltip.classList.add('visible');

            // Position tooltip (now we can measure correctly)
            positionCheckTooltip(tooltip, trigger);

            // Make fully visible
            tooltip.style.visibility = 'visible';
            activeCheckTooltip = tooltip;

            // Close any previous trigger and update ARIA
            if (activeCheckTrigger && activeCheckTrigger !== trigger) {
                activeCheckTrigger.setAttribute('aria-expanded', 'false');
            }
            activeCheckTrigger = trigger;
            trigger.setAttribute('aria-expanded', 'true');
        }

        function hideCheckTooltip() {
            const tooltip = document.getElementById('checkTooltip');
            tooltip.classList.remove('visible');

            // Reset ARIA state
            if (activeCheckTrigger) {
                activeCheckTrigger.setAttribute('aria-expanded', 'false');
                activeCheckTrigger = null;
            }
            activeCheckTooltip = null;
        }

        // Reuse the same positioning function for check tooltips
        function positionCheckTooltip(tooltip, trigger) {
            positionTooltip(tooltip, trigger);
        }

        // ============================================================
        // DRAGGABLE TOOLTIPS/POPUPS
        // ============================================================

        let dragState = {
            isDragging: false,
            tooltip: null,
            offsetX: 0,
            offsetY: 0
        };

        function initDraggableTooltips() {
            // Handle mousedown on tooltip headers
            document.addEventListener('mousedown', function(e) {
                const header = e.target.closest('.tooltip-header, .check-tooltip-header');
                if (!header) return;

                // Don't drag if clicking on close button
                if (e.target.closest('.tooltip-close, .check-tooltip-close')) return;

                const tooltip = header.closest('.finding-tooltip, .check-tooltip');
                if (!tooltip || !tooltip.classList.contains('visible')) return;

                e.preventDefault();
                dragState.isDragging = true;
                dragState.tooltip = tooltip;

                // Get current position (could be from CSS or previous drag)
                const rect = tooltip.getBoundingClientRect();
                dragState.offsetX = e.clientX - rect.left;
                dragState.offsetY = e.clientY - rect.top;

                tooltip.classList.add('dragging');
            });

            document.addEventListener('mousemove', function(e) {
                if (!dragState.isDragging || !dragState.tooltip) return;

                e.preventDefault();

                // Calculate new position
                let newX = e.clientX - dragState.offsetX;
                let newY = e.clientY - dragState.offsetY;

                // Keep within viewport bounds
                const tooltipRect = dragState.tooltip.getBoundingClientRect();
                const maxX = window.innerWidth - tooltipRect.width;
                const maxY = window.innerHeight - tooltipRect.height;

                newX = Math.max(0, Math.min(newX, maxX));
                newY = Math.max(0, Math.min(newY, maxY));

                dragState.tooltip.style.left = newX + 'px';
                dragState.tooltip.style.top = newY + 'px';
            });

            document.addEventListener('mouseup', function() {
                if (dragState.isDragging && dragState.tooltip) {
                    dragState.tooltip.classList.remove('dragging');
                }
                dragState.isDragging = false;
                dragState.tooltip = null;
            });

            // Prevent text selection while dragging
            document.addEventListener('selectstart', function(e) {
                if (dragState.isDragging) {
                    e.preventDefault();
                }
            });
        }

        function buildCheckTooltipHtml(check, checkTitle, cardSeverity) {
            let html = `
                <div class="check-tooltip-header">
                    <span class="check-tooltip-title">Об этой проверке</span>
                    <button class="check-tooltip-close" onclick="hideCheckTooltip()">&times;</button>
                </div>
                <div class="check-tooltip-body">
            `;

            // Summary
            html += `<div class="check-tooltip-summary">${escapeHtml(check.summary)}</div>`;

            // Secure Message (shown when card severity is 'secure')
            if (cardSeverity === 'secure' && check.secureMessage) {
                html += `
                    <div class="check-tooltip-section check-tooltip-secure">
                        <div class="check-tooltip-section-title">Безопасная конфигурация</div>
                        <div class="check-tooltip-section-content">
                            ${escapeHtml(check.secureMessage)}
                        </div>
                    </div>
                `;
            }

            // Why It Matters
            if (check.whyItMatters) {
                html += `
                    <div class="check-tooltip-section">
                        <div class="check-tooltip-section-title">Почему это важно</div>
                        <div class="check-tooltip-section-content">
                            ${escapeHtml(check.whyItMatters)}
                        </div>
                    </div>
                `;
            }

            // What We Check
            if (check.whatWeCheck && check.whatWeCheck.length > 0) {
                html += `
                    <div class="check-tooltip-section">
                        <div class="check-tooltip-section-title">Что проверяется</div>
                        <div class="check-tooltip-section-content">
                            <ul>
                                ${check.whatWeCheck.map(item => `<li>${escapeHtml(item)}</li>`).join('')}
                            </ul>
                        </div>
                    </div>
                `;
            }

            if (check.originalEnglish && check.originalEnglish.whyItMatters) {
                html += '<details class="check-tooltip-section" lang="en">' +
                    '<summary>Подробные критерии проверки (оригинал EN)</summary>' +
                    '<p>' + escapeHtml(check.originalEnglish.whyItMatters) + '</p>' +
                    (check.originalEnglish.whatWeCheck ?
                        '<ul>' + check.originalEnglish.whatWeCheck.map(i => '<li>' + escapeHtml(i) + '</li>').join('') + '</ul>' : '') +
                    '</details>';
            }
            // Filtering Note (documents privilege filtering behavior)
            if (check.filteringNote) {
                html += `
                    <div class="check-tooltip-section check-tooltip-filtering">
                        <div class="check-tooltip-section-title">Фильтрация результатов</div>
                        <div class="check-tooltip-section-content">
                            ${escapeHtml(check.filteringNote)}
                        </div>
                    </div>
                `;
            }

            html += '</div>';
            return html;
        }

        // ============================================================
        // CHECKBOX SYSTEM - Mark findings as completed
        // ============================================================

        let completedFindings = {};
        let reportHash = '';
        let localStorageAvailable = true;
        let localStorageWriteAttempts = 0;
        const MAX_WRITE_FAILURES = 3;

        // Safe localStorage wrapper with differentiated error handling
        // - Security errors (privacy mode): Permanently disable localStorage
        // - Quota errors: Retry up to MAX_WRITE_FAILURES times, then disable writes only
        // - Transient errors: Log and continue
        function safeGetItem(key) {
            if (!localStorageAvailable) return null;
            try {
                return localStorage.getItem(key);
            } catch (e) {
                if (isSecurityError(e)) {
                    console.warn('localStorage blocked (privacy mode):', e.message);
                    localStorageAvailable = false;
                } else {
                    console.warn('localStorage read failed:', e.message);
                }
                return null;
            }
        }

        function safeSetItem(key, value) {
            if (!localStorageAvailable) return false;
            try {
                localStorage.setItem(key, value);
                localStorageWriteAttempts = 0; // Reset on success
                return true;
            } catch (e) {
                if (isSecurityError(e)) {
                    // Privacy mode or security restriction - permanently disable
                    console.warn('localStorage blocked (privacy mode):', e.message);
                    localStorageAvailable = false;
                    return false;
                } else if (isQuotaError(e)) {
                    // Quota exceeded - try to clean up old data
                    localStorageWriteAttempts++;
                    console.warn('localStorage quota exceeded, attempt', localStorageWriteAttempts);
                    if (localStorageWriteAttempts >= MAX_WRITE_FAILURES) {
                        console.warn('localStorage quota exceeded repeatedly, disabling writes');
                        localStorageAvailable = false;
                    }
                    return false;
                } else {
                    // Other transient error - log but don't disable
                    console.warn('localStorage write failed:', e.message);
                    return false;
                }
            }
        }

        function isSecurityError(e) {
            // SecurityError is thrown in privacy mode or when localStorage is blocked
            return e.name === 'SecurityError' ||
                   (e.name === 'Error' && e.message.includes('access'));
        }

        function isQuotaError(e) {
            // QuotaExceededError when storage is full
            return e.name === 'QuotaExceededError' ||
                   e.name === 'NS_ERROR_DOM_QUOTA_REACHED' ||
                   (e.code && e.code === 22);
        }

        function initCheckboxSystem() {
            // Generate a hash from the report content for localStorage key
            reportHash = generateReportHash();

            // Load saved state
            const savedState = safeGetItem('adpeas-completed-' + reportHash);
            if (savedState) {
                try {
                    completedFindings = JSON.parse(savedState);
                } catch (e) {
                    completedFindings = {};
                }
            }

            // Initialize checkboxes on all finding cards (checkbox is already in HTML)
            document.querySelectorAll('.finding-card').forEach((card, index) => {
                // Use existing data-card-id (set by PowerShell) or generate fallback
                const cardId = card.dataset.cardId || ('finding-' + index);
                card.dataset.cardId = cardId;  // Ensure it's set if missing

                // Find existing checkbox and initialize it
                const checkbox = card.querySelector('.finding-checkbox');
                if (checkbox) {
                    checkbox.checked = !!completedFindings[cardId];
                    // Re-bind onclick to ensure proper cardId reference
                    checkbox.onclick = function(e) {
                        e.stopPropagation();
                        toggleCompleted(cardId, this.checked);
                    };
                }

                // Apply initial state
                if (completedFindings[cardId]) {
                    card.classList.add('completed');
                }
            });

            // Update progress bar
            updateProgress();

            // Load hide completed state
            const hideCompleted = safeGetItem('adpeas-hide-completed') === 'true';
            if (hideCompleted) {
                document.getElementById('hideCompletedToggle').checked = true;
                document.body.classList.add('hide-completed');
            }
        }

        function generateReportHash() {
            // Generate hash based on domain, timestamp, and finding titles for uniqueness
            // This ensures different reports don't share completed-state even if same domain/count
            const infoItems = document.querySelectorAll('.info-item');
            let domain = 'unknown';
            let generated = '';

            infoItems.forEach(item => {
                const label = item.querySelector('.label')?.textContent?.trim();
                const value = item.querySelector('.value')?.textContent?.trim();
                if (label === 'Domain') domain = value || 'unknown';
                if (label === 'Generated') generated = value || '';
            });

            // Include first 3 finding titles for additional uniqueness
            const titles = Array.from(document.querySelectorAll('.finding-title'))
                .slice(0, 3)
                .map(t => t.textContent || '')
                .join('');

            const hashInput = domain + generated + titles;
            // Simple hash function
            let hash = 0;
            for (let i = 0; i < hashInput.length; i++) {
                const char = hashInput.charCodeAt(i);
                hash = ((hash << 5) - hash) + char;
                hash = hash & hash; // Convert to 32bit integer
            }
            return domain.replace(/[^a-z0-9]/gi, '') + '-' + Math.abs(hash).toString(36);
        }

        function toggleCompleted(cardId, isCompleted) {
            if (isCompleted) {
                completedFindings[cardId] = true;
            } else {
                delete completedFindings[cardId];
            }

            // Update Card View UI
            const card = document.querySelector(`.finding-card[data-card-id="${cardId}"]`);
            if (card) {
                card.classList.toggle('completed', isCompleted);
            }

            // Save state
            safeSetItem('adpeas-completed-' + reportHash, JSON.stringify(completedFindings));

            // Update progress bar
            updateProgress();

            // Re-apply filters (if hide completed is enabled)
            if (hideCompletedEnabled) {
                applyFilters();
            }
        }

        function updateProgress() {
            // Update sidebar counts to show remaining (non-completed) findings
            updateSidebarCounts();
        }

        function updateSidebarCounts() {
            // Count non-completed cards per severity and category
            const severityCounts = { all: 0, finding: 0, hint: 0, note: 0, secure: 0 };
            const categoryCounts = {};

            document.querySelectorAll('.finding-card').forEach(card => {
                const cardId = card.dataset.cardId;
                const isCompleted = completedFindings[cardId];

                if (!isCompleted) {
                    severityCounts.all++;
                    const severity = card.dataset.severity || 'note';
                    if (severityCounts[severity] !== undefined) {
                        severityCounts[severity]++;
                    }

                    // Count by category
                    const category = card.dataset.category || '';
                    if (category) {
                        categoryCounts[category] = (categoryCounts[category] || 0) + 1;
                    }
                }
            });

            // Update sidebar severity filter counts
            document.querySelectorAll('.severity-filter').forEach(filter => {
                const severity = filter.dataset.severity;
                const countSpan = filter.querySelector('.count');
                if (countSpan && severityCounts[severity] !== undefined) {
                    countSpan.textContent = severityCounts[severity];
                }
            });

            // Update sidebar category filter counts
            document.querySelectorAll('.nav-item[data-category]').forEach(navItem => {
                const category = navItem.dataset.category;
                const countSpan = navItem.querySelector('.count');
                if (countSpan) {
                    if (category === 'all') {
                        countSpan.textContent = severityCounts.all;
                    } else if (categoryCounts[category] !== undefined) {
                        countSpan.textContent = categoryCounts[category];
                    } else {
                        countSpan.textContent = '0';
                    }
                }
            });

            // Update summary cards at the top
            const summaryMapping = {
                'finding': '.summary-card.finding .value',
                'hint': '.summary-card.hint .value',
                'note': '.summary-card.note .value',
                'secure': '.summary-card.secure .value'
            };

            Object.keys(summaryMapping).forEach(severity => {
                const el = document.querySelector(summaryMapping[severity]);
                if (el) {
                    el.textContent = severityCounts[severity];
                }
            });
        }

        function toggleHideCompleted() {
            const isChecked = document.getElementById('hideCompletedToggle').checked;
            hideCompletedEnabled = isChecked;
            document.body.classList.toggle('hide-completed', isChecked);
            safeSetItem('adpeas-hide-completed', isChecked);
            // Re-apply filters
            applyFilters();

            // Announce to screen readers
            const visibleCount = document.querySelectorAll('.finding-card:not([style*="display: none"])').length;
            const message = isChecked
                ? 'Completed findings hidden. ' + visibleCount + ' findings visible.'
                : 'Showing all findings including completed. ' + visibleCount + ' findings visible.';
            announceToScreenReader(message);
        }

        // ============================================================
        // KEYBOARD SHORTCUTS
        // ============================================================

        let currentFocusIndex = -1;
        let visibleCards = [];

        function initKeyboardShortcuts() {
            document.addEventListener('keydown', function(e) {
                // Don't trigger shortcuts when typing in search
                if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') {
                    if (e.key === 'Escape') {
                        // Clear search filter if the search input has a value
                        if (e.target.id === 'searchInput' && e.target.value) {
                            e.target.value = '';
                            currentSearchQuery = '';
                            applyFilters();
                        }
                        e.target.blur();
                        clearKeyboardFocus();
                    }
                    return;
                }

                switch(e.key) {
                    // Navigation: Arrow keys (intuitive)
                    case 'ArrowDown':
                        e.preventDefault();
                        navigateFinding(1);
                        break;
                    case 'ArrowUp':
                        e.preventDefault();
                        navigateFinding(-1);
                        break;

                    // Enter: Expand/Collapse
                    case 'Enter':
                        e.preventDefault();
                        if (currentFocusIndex >= 0) {
                            toggleCurrentFinding();
                        }
                        break;

                    // Toggle completed: Space (standard checkbox behavior)
                    case ' ':
                        e.preventDefault();
                        if (currentFocusIndex >= 0 && visibleCards[currentFocusIndex]) {
                            const card = visibleCards[currentFocusIndex];
                            const checkbox = card.querySelector('.finding-checkbox');
                            if (checkbox) {
                                checkbox.checked = !checkbox.checked;
                                toggleCompleted(card.dataset.cardId, checkbox.checked);
                            }
                        }
                        break;

                    // Search: / (vim-like, common in web apps)
                    case '/':
                        e.preventDefault();
                        document.getElementById('searchInput').focus();
                        break;

                    // Hide completed toggle: h
                    case 'h':
                        e.preventDefault();
                        const toggle = document.getElementById('hideCompletedToggle');
                        toggle.checked = !toggle.checked;
                        toggleHideCompleted();
                        break;

                    // Help: ? or F1
                    case '?':
                        e.preventDefault();
                        toggleShortcutHelp();
                        break;
                    case 'F1':
                        e.preventDefault();
                        toggleShortcutHelp();
                        break;

                    // Close/Cancel: Escape (standard)
                    case 'Escape':
                        hideTooltip();
                        hideCheckTooltip();
                        hideShortcutHelp();
                        clearKeyboardFocus();
                        break;
                }
            });
        }

        function getVisibleCards() {
            return Array.from(document.querySelectorAll('.finding-card')).filter(card => {
                return card.style.display !== 'none' && !card.closest('.section[style*="display: none"]');
            });
        }

        function navigateFinding(direction) {
            visibleCards = getVisibleCards();
            if (visibleCards.length === 0) return;

            // Remove visual focus from previous card (don't reset index)
            document.querySelectorAll('.keyboard-focused').forEach(el => {
                el.classList.remove('keyboard-focused');
            });

            // Calculate new index
            currentFocusIndex += direction;
            if (currentFocusIndex < 0) currentFocusIndex = visibleCards.length - 1;
            if (currentFocusIndex >= visibleCards.length) currentFocusIndex = 0;

            // Apply focus
            const card = visibleCards[currentFocusIndex];
            card.classList.add('keyboard-focused');
            card.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }

        function clearKeyboardFocus() {
            document.querySelectorAll('.keyboard-focused').forEach(el => {
                el.classList.remove('keyboard-focused');
            });
            currentFocusIndex = -1;
        }

        function toggleCurrentFinding() {
            if (currentFocusIndex >= 0 && visibleCards[currentFocusIndex]) {
                visibleCards[currentFocusIndex].classList.toggle('expanded');
            }
        }

        let allExpanded = false;
        function toggleAllFindings() {
            allExpanded = !allExpanded;
            document.querySelectorAll('.finding-card').forEach(card => {
                card.classList.toggle('expanded', allExpanded);
            });
        }

        function createShortcutHelpModal() {
            const backdrop = document.createElement('div');
            backdrop.className = 'shortcut-help-backdrop';
            backdrop.id = 'shortcutBackdrop';
            backdrop.onclick = hideShortcutHelp;
            backdrop.setAttribute('aria-hidden', 'true');
            document.body.appendChild(backdrop);

            const modal = document.createElement('div');
            modal.className = 'shortcut-help';
            modal.id = 'shortcutHelp';
            modal.setAttribute('role', 'dialog');
            modal.setAttribute('aria-modal', 'true');
            modal.setAttribute('aria-labelledby', 'helpModalTitle');
            modal.innerHTML = `
                <div class="help-header">
                    <h2 id="helpModalTitle">Руководство по отчёту</h2>
                    <button class="help-close-btn" onclick="hideShortcutHelp()" aria-label="Закрыть окно справки">&times;</button>
                </div>
                <div class="help-content">
                    <div class="help-section">
                        <h3>Структура отчёта</h3>
                        <p>Отчёт сгруппирован по разделам аудита безопасности: домен, учётные записи, делегирование, права доступа и другие. В каждом разделе может быть несколько проверок, а в каждой проверке — несколько результатов.</p>
                        <div class="help-grid">
                            <div class="help-card">
                                <div class="help-card-title">Сводные карточки</div>
                                <div class="help-card-desc">В верхней части отчёта показано количество результатов по уровням критичности. Нажмите карточку, чтобы отфильтровать результаты.</div>
                            </div>
                            <div class="help-card">
                                <div class="help-card-title">Первоочередные меры</div>
                                <div class="help-card-desc">Обнаруженные проблемы отсортированы по расчётной оценке риска. Начните с нарушений с наивысшим приоритетом.</div>
                            </div>
                            <div class="help-card">
                                <div class="help-card-title">Разделы аудита</div>
                                <div class="help-card-desc">Раскрываемые разделы объединяют тематически связанные проверки безопасности.</div>
                            </div>
                            <div class="help-card">
                                <div class="help-card-title">Карточки результатов</div>
                                <div class="help-card-desc">Каждая карточка содержит подробности обнаруженного результата. Нажмите её, чтобы раскрыть сведения и атрибуты.</div>
                            </div>
                        </div>
                    </div>

                    <div class="help-section">
                        <h3>Уровни критичности</h3>
                        <div class="help-grid">
                            <div class="help-card">
                                <div class="help-card-title"><span class="severity-sample finding"></span> Нарушение (красный)</div>
                                <div class="help-card-desc">Уязвимость или опасная настройка, требующая приоритетной проверки и устранения.</div>
                            </div>
                            <div class="help-card">
                                <div class="help-card-title"><span class="severity-sample hint"></span> Предупреждение (жёлтый)</div>
                                <div class="help-card-desc">Потенциально значимый результат, требующий дополнительного анализа.</div>
                            </div>
                            <div class="help-card">
                                <div class="help-card-title"><span class="severity-sample note"></span> Сведения (синий)</div>
                                <div class="help-card-desc">Справочная информация о конфигурации и состоянии инфраструктуры.</div>
                            </div>
                            <div class="help-card">
                                <div class="help-card-title"><span class="severity-sample secure"></span> Безопасно (зелёный)</div>
                                <div class="help-card-desc">Проверенная настройка соответствует ожидаемому безопасному состоянию; исправление не требуется.</div>
                            </div>
                        </div>
                    </div>

                    <div class="help-section">
                        <h3>Интерактивные возможности</h3>
                        <div class="help-grid">
                            <div class="help-card">
                                <div class="help-card-title">Кнопки справки «?»</div>
                                <div class="help-card-desc">Нажмите кнопку «?» рядом с названием проверки или результатом, чтобы увидеть пояснения, возможные последствия и рекомендации по устранению.</div>
                            </div>
                            <div class="help-card">
                                <div class="help-card-title">Флажки выполнения</div>
                                <div class="help-card-desc">Отмечайте проверенные или устранённые результаты. Отметки сохраняются в браузере и доступны при повторном открытии отчёта.</div>
                            </div>
                            <div class="help-card">
                                <div class="help-card-title">Оценки риска</div>
                                <div class="help-card-desc">У результата отображается расчётная оценка риска. Карточки автоматически сортируются по убыванию этой оценки.</div>
                            </div>
                            <div class="help-card">
                                <div class="help-card-title">Фильтры</div>
                                <div class="help-card-desc">Используйте фильтры по критичности и разделам, чтобы отобрать необходимые результаты проверки.</div>
                            </div>
                        </div>
                    </div>

                    <div class="help-section">
                        <h3>Горячие клавиши</h3>
                        <div class="shortcut-grid">
                            <div class="shortcut-row">
                                <span class="shortcut-key">&uarr; / &darr;</span>
                                <span class="shortcut-desc">Переход между результатами</span>
                            </div>
                            <div class="shortcut-row">
                                <span class="shortcut-key">Enter</span>
                                <span class="shortcut-desc">Развернуть или свернуть</span>
                            </div>
                            <div class="shortcut-row">
                                <span class="shortcut-key">Пробел</span>
                                <span class="shortcut-desc">Отметить выполненным</span>
                            </div>
                            <div class="shortcut-row">
                                <span class="shortcut-key">h</span>
                                <span class="shortcut-desc">Скрыть выполненные</span>
                            </div>
                            <div class="shortcut-row">
                                <span class="shortcut-key">/</span>
                                <span class="shortcut-desc">Поиск</span>
                            </div>
                            <div class="shortcut-row">
                                <span class="shortcut-key">Esc</span>
                                <span class="shortcut-desc">Закрыть окно или очистить поле</span>
                            </div>
                        </div>
                    </div>

                    <div class="help-section">
                        <h3>Советы по работе с отчётом</h3>
                        <p style="margin-bottom: 8px;"><strong>Начните с первоочередных мер.</strong> Результаты ранжируются по оценке возможности эксплуатации и потенциальным последствиям.</p>
                        <p style="margin-bottom: 8px;"><strong>Используйте поиск.</strong> Находите учётные записи, компьютеры и группы по имени.</p>
                        <p style="margin-bottom: 0;"><strong>Отмечайте выполненное.</strong> Устанавливайте флажки после проверки или устранения проблем, чтобы отслеживать ход работы.</p>
                    </div>

                    <div class="help-section data-management-section">
                        <h3>Хранение данных</h3>
                        <p style="margin-bottom: 12px;">Настройки и отметки выполнения сохраняются в локальном хранилище браузера:</p>
                        <div class="data-storage-info">
                            <div class="data-item"><span class="data-icon">&#9745;</span> Отметки выполненных результатов (флажки)</div>
                            <div class="data-item"><span class="data-icon">&#9788;</span> Выбранная тема оформления (тёмная или светлая)</div>
                            <div class="data-item"><span class="data-icon">&#9744;</span> Состояние переключателя «Скрыть выполненные»</div>
                        </div>
                        <p style="margin: 12px 0; color: var(--text-muted); font-size: 12px;">Данные хранятся только в этом браузере и никуда не отправляются. Для каждого отчёта отметки выполнения сохраняются отдельно.</p>
                        <button class="clear-data-btn" onclick="clearAdPEASData()" title="Удалить сохранённые данные adPEAS из браузера">
                            <span class="clear-data-icon">&#128465;</span> Очистить сохранённые данные
                        </button>
                    </div>
                </div>
            `;
            document.body.appendChild(modal);
        }

        // Clear all adPEAS data from localStorage
        function clearAdPEASData() {
            const keys = Object.keys(localStorage).filter(k => k.startsWith('adpeas-'));
            const count = keys.length;

            if (count === 0) {
                announceToScreenReader('No adPEAS data found in storage.');
                alert('No adPEAS data found in browser storage.');
                return;
            }

            const confirmMsg = 'This will remove all adPEAS data from your browser:\n\n' +
                '• Completed findings (checkboxes) for ALL reports\n' +
                '• Theme preference\n\n' +
                'Found ' + count + ' stored item(s).\n\n' +
                'The page will reload after clearing. Continue?';

            if (confirm(confirmMsg)) {
                keys.forEach(k => localStorage.removeItem(k));
                announceToScreenReader('All adPEAS data cleared. Reloading page.');
                location.reload();
            }
        }

        function toggleShortcutHelp() {
            const backdrop = document.getElementById('shortcutBackdrop');
            const modal = document.getElementById('shortcutHelp');
            const isOpening = !modal.classList.contains('visible');

            backdrop.classList.toggle('visible');
            modal.classList.toggle('visible');

            if (isOpening) {
                // Focus trap and announce
                trapFocus(modal);
                announceToScreenReader('Help dialog opened. Press Escape to close.');
            } else {
                restoreFocus();
            }
        }

        function hideShortcutHelp() {
            document.getElementById('shortcutBackdrop').classList.remove('visible');
            document.getElementById('shortcutHelp').classList.remove('visible');
            restoreFocus();
        }

        // ============================================================
        // TOP PRIORITY ACTIONS with Context-Aware Risk Scoring
        // ============================================================

        // ==========================================================================
        // CONTEXT-AWARE SCORING SYSTEM
        // ==========================================================================
        // Score = BASE_SCORE * IMPACT_MODIFIER * EXPLOITABILITY_MODIFIER * SECURITY_MODIFIER + CORRELATION
        //
        // Definitions are maintained centrally in: src/modules/Core/adPEAS-ScoringDefinitions.ps1
        // Documentation: docs/10-Risk-Scoring-System.md
        // ==========================================================================

        // ---- BEGIN AUTO-GENERATED SCORING DEFINITIONS ----
        // Source: adPEAS-ScoringDefinitions.ps1
{{SCORING_DEFINITIONS}}
        // ---- END AUTO-GENERATED SCORING DEFINITIONS ----

        // Exploitability modifiers for cracking-based attacks
        // Uses values from securityModifiers, passwordAgeModifiers, passwordLengthModifiers, etc.
        function getExploitabilityModifier(accountInfo, findingType) {
            let modifier = 1.0;

            // Only apply these modifiers to attacks that require cracking
            const crackingAttacks = ['kerberoast', 'asrep', 'preauth'];
            const isCrackingAttack = crackingAttacks.some(a => findingType.includes(a));

            if (!isCrackingAttack || !accountInfo) {
                return modifier;
            }

            // Get domain password policy for context-aware age evaluation
            const maxPwdAgeDays = scoringContext?.domainInfo?.maxPwdAgeDays || 0;
            const minPwdLength = scoringContext?.domainInfo?.minPwdLength || 0;

            // Password age factor - relative to policy, not absolute
            if (accountInfo.pwdAgeDays !== null && accountInfo.pwdAgeDays > 0) {
                const pwdAge = accountInfo.pwdAgeDays;

                if (maxPwdAgeDays > 0) {
                    // Policy exists - evaluate relative to policy
                    const policyMultiples = pwdAge / maxPwdAgeDays;

                    if (policyMultiples >= 10) {
                        modifier *= passwordAgeModifiers.multiplier_10x;
                    } else if (policyMultiples >= 5) {
                        modifier *= passwordAgeModifiers.multiplier_5x;
                    } else if (policyMultiples >= 3) {
                        modifier *= passwordAgeModifiers.multiplier_3x;
                    } else if (policyMultiples >= 2) {
                        modifier *= passwordAgeModifiers.multiplier_2x;
                    } else if (policyMultiples >= 1) {
                        modifier *= passwordAgeModifiers.multiplier_1x;
                    } else {
                        modifier *= passwordAgeModifiers.within_policy;
                    }
                } else {
                    // No policy (never expires) - use absolute thresholds
                    if (pwdAge > 365 * 5) {
                        modifier *= passwordAgeModifiers.multiplier_5x;
                    } else if (pwdAge > 365 * 2) {
                        modifier *= passwordAgeModifiers.multiplier_2x;
                    } else if (pwdAge > 365) {
                        modifier *= passwordAgeModifiers.multiplier_1x;
                    }
                }
            }

            // Password policy strength affects cracking difficulty
            const complexityEnabled = scoringContext?.domainInfo?.complexityEnabled || false;

            // Password length impact on cracking time
            if (minPwdLength > 0) {
                if (minPwdLength < 8) {
                    modifier *= passwordLengthModifiers.very_weak;
                } else if (minPwdLength < 12) {
                    modifier *= passwordLengthModifiers.weak;
                } else if (minPwdLength < 16) {
                    modifier *= passwordLengthModifiers.standard;
                } else {
                    modifier *= passwordLengthModifiers.strong;
                }
            }

            // Password complexity
            if (!complexityEnabled) {
                modifier *= passwordComplexityModifiers.disabled;
            } else {
                modifier *= passwordComplexityModifiers.enabled;
            }

            // Combined weak policy scenario (short + no complexity)
            if (minPwdLength > 0 && minPwdLength < 10 && !complexityEnabled) {
                modifier *= 1.15;  // Additional penalty for very weak combination
            }

            // Encryption type factor (RC4 = much easier to crack)
            if (accountInfo.encryptionTypes && accountInfo.encryptionTypes.length > 0) {
                const hasRC4Only = accountInfo.encryptionTypes.includes('RC4-HMAC') &&
                                   !accountInfo.encryptionTypes.includes('AES256') &&
                                   !accountInfo.encryptionTypes.includes('AES128');
                const hasAES = accountInfo.encryptionTypes.includes('AES256') ||
                               accountInfo.encryptionTypes.includes('AES128');

                if (hasRC4Only) {
                    modifier *= encryptionTypeModifiers.rc4_only;
                } else if (hasAES && !accountInfo.encryptionTypes.includes('RC4-HMAC')) {
                    modifier *= encryptionTypeModifiers.aes256;
                }
            }

            return modifier;
        }

        // Security configuration modifiers - REDUCE score for secure settings
        // Uses values from securityModifiers object
        function getSecurityModifier(accountInfo, findingType) {
            if (!accountInfo || !accountInfo.uacFlags) {
                return 1.0;
            }

            let modifier = 1.0;
            const flags = accountInfo.uacFlags;
            const isCrackingAttack = ['kerberoast', 'asrep', 'preauth'].some(a => findingType.includes(a));

            // ========================================
            // ACCOUNT STATUS FLAGS (affect ALL attacks)
            // ========================================

            if (flags.includes('ACCOUNTDISABLE') || flags.includes('Disabled')) {
                modifier *= securityModifiers.ACCOUNTDISABLE;
            }

            // No modifier for a locked-out account or an expired password. The DC
            // computes LOCKOUT and PASSWORD_EXPIRED into msDS-User-Account-Control-Computed
            // and never stores them in userAccountControl, where these flags come from -
            // the two modifiers that read them here never fired.

            // ========================================
            // KERBEROS SECURITY FLAGS (affect cracking attacks)
            // ========================================

            if (isCrackingAttack) {
                if (flags.includes('SMARTCARD_REQUIRED') || flags.includes('SmartcardRequired')) {
                    modifier *= securityModifiers.SMARTCARD_REQUIRED;
                }

                if (accountInfo.isProtectedUser) {
                    modifier *= securityModifiers.PROTECTED_USERS;
                }
            }

            // ========================================
            // DELEGATION FLAGS (affect delegation attacks)
            // ========================================
            //
            // Removed, not repaired. The flags here belong to the account the card is
            // about - the host that PERFORMS the delegation - and NOT_DELEGATED
            // ("Account is sensitive and cannot be delegated") protects the identity of
            // THAT account against being delegated by someone else. It has no effect on
            // the delegation this account carries out.
            //
            // So a hardened server whose computer account has the flag set, and which
            // also has unconstrained delegation, had its delegation finding multiplied by
            // 0.3 for a measure that does not touch the attack: the most dangerous
            // delegation object in the domain read as a medium problem. No modifier is
            // better than one that points the wrong way.
            //
            // A correct version would measure the Tier-0 coverage that
            // Get-ProtectedUsersStatus already computes - whether the accounts worth
            // impersonating are protected from delegation - rather than the UAC flags of
            // the delegating host.

            // ========================================
            // ENCRYPTION FLAGS (affect Kerberoast specifically)
            // ========================================

            if (flags.includes('USE_DES_KEY_ONLY') || flags.includes('DESKeyOnly')) {
                modifier *= securityModifiers.USE_DES_KEY_ONLY;
            }

            return modifier;
        }

        // Every account a card describes, in the order the card lists them.
        function getCardAccountInfos(card) {
            if (!scoringContext || !scoringContext.accounts) {
                return [];
            }

            const found = [];
            const seen = new Set();
            const addAccount = function (acct) {
                if (!acct) return;
                const key = acct.sid || acct.dn || acct.name;
                if (key && seen.has(key)) return;
                if (key) seen.add(key);
                found.push(acct);
            };

            const objectDetails = card.querySelectorAll('.object-detail');
            for (const detail of objectDetails) {
                const rows = detail.querySelectorAll('.attr-row');
                for (const row of rows) {
                    const nameEl = row.querySelector('.attr-name');
                    const valueEl = row.querySelector('.attr-value');
                    if (!nameEl || !valueEl) continue;

                    const attrName = nameEl.textContent.trim().toLowerCase();
                    const attrValue = valueEl.textContent.trim();

                    // objectSid first, it is the only identifier that cannot collide
                    if (attrName === 'objectsid' && scoringContext.accounts[attrValue]) {
                        addAccount(scoringContext.accounts[attrValue]);
                        continue;
                    }
                    if (attrName === 'distinguishedname' && scoringContext.accounts[attrValue]) {
                        addAccount(scoringContext.accounts[attrValue]);
                        continue;
                    }
                    if (attrName === 'samaccountname') {
                        for (const [key, acct] of Object.entries(scoringContext.accounts)) {
                            if (acct.name && acct.name.toLowerCase() === attrValue.toLowerCase()) {
                                addAccount(acct);
                                break;
                            }
                        }
                    }
                }
            }
            return found;
        }

        // Get account info from scoring context.
        //
        // One card per check, not per object: a Kerberoastable card lists every roastable
        // account in the domain, and this function used to return at the FIRST match and
        // score the whole card with it. A kerberoastable Domain Admin at position 17 did
        // not raise the card's score at all, and - the same mechanism in the other
        // direction - a disabled account at position 1 multiplied the card by 0.1.
        //
        // The card is scored by the worst of its accounts now, field by field, because
        // "worst" is not the same question for an aggravating and for a mitigating one:
        //
        //   adminTier / isAdmin   the highest tier any of them holds
        //   pwdAgeDays            the oldest password
        //   encryptionTypes       RC4-only if ANY of them is RC4-only, else the union
        //   uacFlags              the INTERSECTION: every flag the scorer reads here is a
        //                         mitigation (disabled, smartcard required),
        //                         so it may only count when it holds for all of them
        //   isProtectedUser       likewise, only when every account is protected
        //
        // Identity fields come from the worst-tier account, which is the one a reader
        // would name, and keeps the correlation bonus pointing at a real account.
        function getAccountInfoFromCard(card) {
            const accounts = getCardAccountInfos(card);
            if (accounts.length === 0) {
                return null;
            }
            if (accounts.length === 1) {
                return accounts[0];
            }

            const tierRank = { none: 0, tier2: 1, tier1: 2, tier0: 3 };
            let worst = accounts[0];
            for (const acct of accounts) {
                if ((tierRank[acct.adminTier] || 0) > (tierRank[worst.adminTier] || 0)) {
                    worst = acct;
                }
            }

            const aggregated = {
                sid: worst.sid,
                name: worst.name,
                dn: worst.dn,
                isAdmin: accounts.some(a => a.isAdmin),
                adminTier: worst.adminTier,
                pwdLastSet: worst.pwdLastSet,
                pwdAgeDays: null,
                encryptionTypes: [],
                uacFlags: [],
                isProtectedUser: accounts.every(a => a.isProtectedUser),
                memberOf: worst.memberOf
            };

            for (const acct of accounts) {
                if (acct.pwdAgeDays !== null && acct.pwdAgeDays !== undefined &&
                    (aggregated.pwdAgeDays === null || acct.pwdAgeDays > aggregated.pwdAgeDays)) {
                    aggregated.pwdAgeDays = acct.pwdAgeDays;
                    aggregated.pwdLastSet = acct.pwdLastSet;
                }
            }

            // An account that permits RC4 and no AES decides the card: the cheapest ticket
            // on it is what an attacker takes. Reporting the union instead would let one
            // AES-only account hide every RC4-only one behind it.
            const rc4Only = accounts.some(function (a) {
                const t = a.encryptionTypes || [];
                return t.includes('RC4-HMAC') && !t.includes('AES256') && !t.includes('AES128');
            });
            if (rc4Only) {
                aggregated.encryptionTypes = ['RC4-HMAC'];
            } else {
                const union = new Set();
                for (const acct of accounts) {
                    for (const t of (acct.encryptionTypes || [])) { union.add(t); }
                }
                aggregated.encryptionTypes = Array.from(union);
            }

            // The intersection, for the reason in the note above. Built from the union
            // rather than from the first account's list: starting there would make the
            // result depend on the order the card happens to list its accounts in, which
            // is the very thing this function exists to stop mattering.
            const allFlags = new Set();
            for (const acct of accounts) {
                for (const flag of (acct.uacFlags || [])) { allFlags.add(flag); }
            }
            aggregated.uacFlags = Array.from(allFlags).filter(function (flag) {
                return accounts.every(a => (a.uacFlags || []).includes(flag));
            });

            return aggregated;
        }

        // Check if account appears in multiple risky findings (correlation bonus)
        // Uses values from correlationBonus object
        // Non-admin accounts get ENHANCED correlation bonus - they represent potential attack paths
        function getCorrelationBonus(accountInfo) {
            if (!scoringContext || !scoringContext.correlations || !accountInfo) {
                return 0;
            }

            // Find correlations for this account
            const accountId = accountInfo.sid || accountInfo.dn || accountInfo.name;
            const correlation = scoringContext.correlations[accountId];

            if (!correlation) {
                return 0;
            }

            // Determine if this is a non-admin account
            const isNonAdmin = !accountInfo.isAdmin && accountInfo.adminTier === 'none';

            let bonus = 0;

            // Dangerous combinations get max bonus
            if (correlation.hasDCSync && (correlation.hasKerberoast || correlation.hasASREP)) {
                bonus = isNonAdmin ? correlationBonus.nonAdminMaxBonus : correlationBonus.maxBonus;
            } else if (correlation.hasDelegation && correlation.hasKerberoast) {
                const perFinding = isNonAdmin ? correlationBonus.nonAdminPerFinding : correlationBonus.perFinding;
                const maxBonus = isNonAdmin ? correlationBonus.nonAdminMaxBonus : correlationBonus.maxBonus;
                bonus = Math.min(perFinding * 2, maxBonus);
            } else if (correlation.count >= 2) {
                // Non-admin with 3+ findings = enhanced bonus (potential privilege escalation path)
                if (isNonAdmin && correlation.count >= correlationBonus.nonAdminThreshold) {
                    // Enhanced correlation for non-admins appearing in multiple findings
                    bonus = Math.min((correlation.count - 1) * correlationBonus.nonAdminPerFinding, correlationBonus.nonAdminMaxBonus);
                } else {
                    // Standard correlation for admins or non-admins below threshold
                    bonus = Math.min((correlation.count - 1) * correlationBonus.perFinding, correlationBonus.maxBonus);
                }
            }

            return bonus;
        }

        // Resolve the BASE score of a card from the finding IDs it actually carries.
        //
        // This replaces a substring match of the card TITLE against the finding IDs, which
        // could never match: titles are prose ("Certificate Templates"), IDs carry
        // underscores ("ESC1_TEMPLATE"). Every red finding therefore fell back to
        // severityBaseScores.finding (35) and the whole per-finding BaseScore table was
        // unreachable - DCSync (100) and ESC1 (90) scored the same as any other finding.
        //
        // Deliberately NOT the same selection as findBestFindingDefinition(): that one
        // returns the card's TOPIC for the tooltip and lets an ObjectType's
        // primaryFindingId win outright, so an incidental attribute trigger cannot
        // relabel the card. The SCORE answers a different question - how urgent is this
        // card - and the answer is its worst finding. So this takes the maximum over all
        // sources instead of the first authoritative one. Badge and tooltip can therefore
        // name different findings on the same card; that is intended.
        function resolveCardBaseScore(meta) {
            let bestKey = null;
            let bestScore = 0;

            const consider = (key) => {
                if (!key || !findingBaseScores.hasOwnProperty(key)) return;
                const score = findingBaseScores[key];
                if (score > bestScore) {
                    bestScore = score;
                    bestKey = key;
                }
            };

            // ObjectType-level primary finding
            if (meta.objectType && typeof checkDescriptions !== 'undefined' && checkDescriptions) {
                consider(checkDescriptions[meta.objectType]?.primaryFindingId);
            }

            // Finding IDs attached by attribute trigger matching
            if (Array.isArray(meta.findingIds)) {
                meta.findingIds.forEach(consider);
            }

            // Vulnerability tags, e.g. "ESC1" -> ESC1_TEMPLATE. A template tagged
            // "ESC1, ESC15" resolves to the higher of the two instead of whichever
            // trigger happened to match first.
            if (Array.isArray(meta.vulnerabilities) && meta.vulnerabilities.length > 0) {
                for (const vulnTag of meta.vulnerabilities) {
                    const vulnLower = String(vulnTag).toLowerCase();
                    if (!vulnLower) continue;
                    // ESC3-TARGET is tagged with a hyphen while its key is
                    // ESC3_TARGET_TEMPLATE, so neither comparison below matched and the
                    // card fell back to the severity base score - half of what the
                    // definition says the finding is worth.
                    const vulnKey = vulnLower.replace(/-/g, '_');
                    for (const key of Object.keys(findingBaseScores)) {
                        const keyLower = key.toLowerCase();
                        if (keyLower === vulnLower || keyLower.startsWith(vulnLower + '_') ||
                            keyLower === vulnKey || keyLower.startsWith(vulnKey + '_')) {
                            consider(key);
                        }
                    }
                }
            }

            return { key: bestKey, score: bestScore };
        }

        // The DOM card carries the same signals as the JSON metadata: its ObjectType as a
        // data attribute, and one data-finding-id per finding row inside it.
        function buildMetaFromCard(card) {
            let findingIds = [];
            try {
                findingIds = Array.from(card.querySelectorAll('[data-finding-id]'))
                    .map(el => el.dataset.findingId)
                    .filter(Boolean);
            } catch (e) {
                findingIds = [];
            }
            return {
                objectType: card.dataset.objectType || null,
                findingIds: Array.from(new Set(findingIds)),
                vulnerabilities: []
            };
        }

        // Calculate score with full breakdown for transparency
        function calculateFindingScoreWithBreakdown(card) {
            const severity = card.dataset.severity || 'note';
            const breakdown = {
                severity: severity,
                baseScore: 0,
                matchedPattern: null,
                impactMod: 1.0,
                impactReason: 'Standard',
                exploitMod: 1.0,
                exploitReasons: [],
                securityMod: 1.0,
                securityReasons: [],
                correlationBonus: 0,
                correlationReason: null,
                finalScore: 0
            };

            // Note and Secure = no security issue
            if (severity === 'note' || severity === 'secure') {
                breakdown.baseScore = 0;
                breakdown.finalScore = 0;
                return breakdown;
            }

            // HINT severity = informational findings
            if (severity === 'hint') {
                breakdown.baseScore = severityBaseScores['hint'] || 15;
                breakdown.finalScore = breakdown.baseScore;
                breakdown.matchedPattern = 'hint (informational)';
                return breakdown;
            }

            // Still needed below: getExploitabilityModifier/getSecurityModifier classify the
            // attack type from the title.
            const title = (card.querySelector('.finding-title')?.textContent || '').toLowerCase();

            // 1. Determine BASE score from the finding IDs on the card, not from its title
            breakdown.baseScore = severityBaseScores[severity] || 5;

            const resolved = resolveCardBaseScore(buildMetaFromCard(card));
            if (resolved.key && resolved.score > breakdown.baseScore) {
                breakdown.baseScore = resolved.score;
                breakdown.matchedPattern = resolved.key;
            }

            // DCSync/Replication Rights are ALWAYS maximum
            if (breakdown.matchedPattern === 'DANGEROUS_ACL_DCSYNC') {
                breakdown.finalScore = 100;
                breakdown.impactReason = 'Maximum (DCSync)';
                return breakdown;
            }

            // 2. Get account context
            const accountInfo = getAccountInfoFromCard(card);

            // 3. Apply IMPACT modifier
            if (accountInfo && accountInfo.adminTier) {
                breakdown.impactMod = impactMultipliers[accountInfo.adminTier] || impactMultipliers.none;
                const tierNames = { tier0: 'Tier 0 (Domain Admin)', tier1: 'Tier 1 (Server Admin)', tier2: 'Tier 2 (Workstation Admin)', none: 'Non-Admin' };
                breakdown.impactReason = tierNames[accountInfo.adminTier] || 'Standard';
            }

            // 4. Apply EXPLOITABILITY modifier with reasons
            breakdown.exploitMod = getExploitabilityModifier(accountInfo, title);
            if (accountInfo) {
                if (accountInfo.pwdAgeDays > 365) {
                    breakdown.exploitReasons.push('Old password (' + Math.round(accountInfo.pwdAgeDays / 365) + 'y)');
                }
                if (accountInfo.encryptionTypes && accountInfo.encryptionTypes.includes('RC4-HMAC') && !accountInfo.encryptionTypes.includes('AES256')) {
                    breakdown.exploitReasons.push('RC4 encryption');
                }
            }
            if (breakdown.exploitReasons.length === 0 && breakdown.exploitMod !== 1.0) {
                breakdown.exploitReasons.push(breakdown.exploitMod > 1 ? 'Easier to exploit' : 'Harder to exploit');
            }

            // 5. Apply SECURITY modifier with reasons
            breakdown.securityMod = getSecurityModifier(accountInfo, title);
            if (accountInfo && accountInfo.uacFlags) {
                const flags = accountInfo.uacFlags;
                if (flags.includes('ACCOUNTDISABLE') || flags.includes('Disabled')) {
                    breakdown.securityReasons.push('Disabled');
                }
                if (flags.includes('SMARTCARD_REQUIRED') || flags.includes('SmartcardRequired')) {
                    breakdown.securityReasons.push('Smartcard required');
                }
                if (accountInfo.isProtectedUser) {
                    breakdown.securityReasons.push('Protected Users');
                }
            }
            if (breakdown.securityReasons.length === 0 && breakdown.securityMod !== 1.0) {
                breakdown.securityReasons.push(breakdown.securityMod < 1 ? 'Mitigated' : 'Vulnerable');
            }

            // 6. Add correlation bonus
            breakdown.correlationBonus = getCorrelationBonus(accountInfo);
            if (breakdown.correlationBonus > 0) {
                breakdown.correlationReason = 'Appears in multiple findings';
            }

            // Calculate final score
            let rawScore = Math.round(breakdown.baseScore * breakdown.impactMod * breakdown.exploitMod * breakdown.securityMod) + breakdown.correlationBonus;
            breakdown.finalScore = Math.min(Math.max(rawScore, 0), 100);

            return breakdown;
        }

        // Simple wrapper for backwards compatibility
        function calculateFindingScore(card) {
            return calculateFindingScoreWithBreakdown(card).finalScore;
        }

        // Format score breakdown as tooltip text
        function formatScoreBreakdown(breakdown) {
            if (breakdown.finalScore === 0) {
                return 'Оценка риска не предусмотрена';
            }

            let lines = [];
            lines.push('Расчёт оценки риска:');
            lines.push('─────────────────');
            lines.push('Base: ' + breakdown.baseScore + (breakdown.matchedPattern ? ' (' + breakdown.matchedPattern + ')' : ''));

            if (breakdown.impactMod !== 1.0) {
                lines.push('Impact: ×' + breakdown.impactMod.toFixed(2) + ' (' + breakdown.impactReason + ')');
            }

            if (breakdown.exploitMod !== 1.0) {
                const reasons = breakdown.exploitReasons.length > 0 ? breakdown.exploitReasons.join(', ') : '';
                lines.push('Exploitability: ×' + breakdown.exploitMod.toFixed(2) + (reasons ? ' (' + reasons + ')' : ''));
            }

            if (breakdown.securityMod !== 1.0) {
                const reasons = breakdown.securityReasons.length > 0 ? breakdown.securityReasons.join(', ') : '';
                lines.push('Security: ×' + breakdown.securityMod.toFixed(2) + (reasons ? ' (' + reasons + ')' : ''));
            }

            if (breakdown.correlationBonus > 0) {
                lines.push('Correlation: +' + breakdown.correlationBonus + (breakdown.correlationReason ? ' (' + breakdown.correlationReason + ')' : ''));
            }

            lines.push('─────────────────');
            lines.push('Final: ' + breakdown.finalScore);

            return lines.join('\n');
        }

        // Format score breakdown as styled HTML tooltip content
        function formatScoreBreakdownHtml(breakdown) {
            if (breakdown.finalScore === 0) {
                return `
                    <div class="score-tooltip-header">
                        <span class="score-tooltip-title">Расчёт оценки риска</span>
                        <span class="score-tooltip-final info">0</span>
                    </div>
                    <div class="score-tooltip-body">
                        <div class="score-tooltip-row">
                            <span class="score-tooltip-label">Оценка риска не предусмотрена</span>
                        </div>
                    </div>
                `;
            }

            const scoreClass = breakdown.finalScore >= scoreThresholds.critical ? 'critical' :
                               breakdown.finalScore >= scoreThresholds.high ? 'high' :
                               breakdown.finalScore >= scoreThresholds.medium ? 'medium' :
                               breakdown.finalScore >= scoreThresholds.low ? 'low' : 'info';

            let rowsHtml = '';

            // Базовая оценка
            rowsHtml += `
                <div class="score-tooltip-row">
                    <span class="score-tooltip-label">Базовая оценка${breakdown.matchedPattern ? `<span class="reason">${escapeHtml(breakdown.matchedPattern)}</span>` : ''}</span>
                    <span class="score-tooltip-value positive">${breakdown.baseScore}</span>
                </div>
            `;

            // Impact Modifier
            if (breakdown.impactMod !== 1.0) {
                rowsHtml += `
                    <div class="score-tooltip-row">
                        <span class="score-tooltip-label">Impact<span class="reason">${escapeHtml(breakdown.impactReason)}</span></span>
                        <span class="score-tooltip-value modifier">×${breakdown.impactMod.toFixed(2)}</span>
                    </div>
                `;
            }

            // Exploitability Modifier
            if (breakdown.exploitMod !== 1.0) {
                const reasons = breakdown.exploitReasons.length > 0 ? breakdown.exploitReasons.join(', ') : '';
                rowsHtml += `
                    <div class="score-tooltip-row">
                        <span class="score-tooltip-label">Возможность эксплуатации${reasons ? `<span class="reason">${escapeHtml(reasons)}</span>` : ''}</span>
                        <span class="score-tooltip-value modifier">×${breakdown.exploitMod.toFixed(2)}</span>
                    </div>
                `;
            }

            // Security Modifier
            if (breakdown.securityMod !== 1.0) {
                const reasons = breakdown.securityReasons.length > 0 ? breakdown.securityReasons.join(', ') : '';
                rowsHtml += `
                    <div class="score-tooltip-row">
                        <span class="score-tooltip-label">Security${reasons ? `<span class="reason">${escapeHtml(reasons)}</span>` : ''}</span>
                        <span class="score-tooltip-value modifier">×${breakdown.securityMod.toFixed(2)}</span>
                    </div>
                `;
            }

            // Correlation Bonus
            if (breakdown.correlationBonus > 0) {
                rowsHtml += `
                    <div class="score-tooltip-row">
                        <span class="score-tooltip-label">Correlation${breakdown.correlationReason ? `<span class="reason">${escapeHtml(breakdown.correlationReason)}</span>` : ''}</span>
                        <span class="score-tooltip-value positive">+${breakdown.correlationBonus}</span>
                    </div>
                `;
            }

            return `
                <div class="score-tooltip-header">
                    <span class="score-tooltip-title">Расчёт оценки риска</span>
                    <span class="score-tooltip-final ${scoreClass}">${breakdown.finalScore}</span>
                </div>
                <div class="score-tooltip-body">
                    ${rowsHtml}
                </div>
            `;
        }

        // Active score tooltip reference
        let activeScoreTooltip = null;

        // Initialize score tooltips for styled display
        function initScoreTooltips() {
            // Create tooltip container
            const tooltipDiv = document.createElement('div');
            tooltipDiv.id = 'scoreTooltip';
            tooltipDiv.className = 'score-tooltip';
            tooltipDiv.setAttribute('role', 'tooltip');
            document.body.appendChild(tooltipDiv);

            // Close tooltip when clicking outside
            document.addEventListener('click', function(e) {
                if (activeScoreTooltip && !e.target.closest('.score-tooltip') && !e.target.closest('[data-score-breakdown]')) {
                    closeScoreTooltip();
                }
            });

            // Close on Escape key
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape' && activeScoreTooltip) {
                    closeScoreTooltip();
                }
            });
        }

        function showScoreTooltip(trigger, breakdown) {
            const tooltip = document.getElementById('scoreTooltip');
            if (!tooltip) return;

            // Close any previously open tooltip first
            if (activeScoreTooltip) {
                closeScoreTooltip();
            }

            // Build tooltip HTML
            tooltip.innerHTML = formatScoreBreakdownHtml(breakdown);

            // Make visible for positioning measurement
            tooltip.style.visibility = 'hidden';
            tooltip.classList.add('visible');

            // Position tooltip
            positionScoreTooltip(tooltip, trigger);

            // Show tooltip
            tooltip.style.visibility = 'visible';
            activeScoreTooltip = tooltip;
        }

        function closeScoreTooltip() {
            const tooltip = document.getElementById('scoreTooltip');
            if (tooltip) {
                tooltip.classList.remove('visible');
            }
            activeScoreTooltip = null;
        }

        function positionScoreTooltip(tooltip, trigger) {
            const triggerRect = trigger.getBoundingClientRect();
            const tooltipRect = tooltip.getBoundingClientRect();
            const viewportWidth = window.innerWidth;
            const viewportHeight = window.innerHeight;
            const padding = UI_CONSTANTS.VIEWPORT_PADDING;

            // Default: position below the trigger, centered
            let left = triggerRect.left + (triggerRect.width / 2) - (tooltipRect.width / 2);
            let top = triggerRect.bottom + 8;

            // Adjust horizontal position if tooltip would overflow
            if (left < padding) {
                left = padding;
            } else if (left + tooltipRect.width > viewportWidth - padding) {
                left = viewportWidth - tooltipRect.width - padding;
            }

            // If tooltip would overflow bottom, position above trigger
            if (top + tooltipRect.height > viewportHeight - padding) {
                top = triggerRect.top - tooltipRect.height - 8;
            }

            // Ensure not above viewport
            if (top < padding) {
                top = padding;
            }

            tooltip.style.left = left + 'px';
            tooltip.style.top = top + 'px';
        }

        // Calculate score from finding metadata (JSON-based, no DOM traversal)
        function calculateScoreFromMetadata(findingMeta) {
            const severity = findingMeta.severity || 'note';
            const breakdown = {
                severity: severity,
                baseScore: 0,
                matchedPattern: null,
                impactMod: 1.0,
                impactReason: 'Standard',
                exploitMod: 1.0,
                exploitReasons: [],
                securityMod: 1.0,
                securityReasons: [],
                correlationBonus: 0,
                correlationReason: null,
                finalScore: 0
            };

            // Note and Secure = no security issue
            if (severity === 'note' || severity === 'secure') {
                return breakdown;
            }

            // HINT severity = informational findings
            if (severity === 'hint') {
                breakdown.baseScore = severityBaseScores['hint'] || 15;
                breakdown.finalScore = breakdown.baseScore;
                breakdown.matchedPattern = 'hint (informational)';
                return breakdown;
            }

            // Still needed below: getExploitabilityModifier/getSecurityModifier classify the
            // attack type from the title.
            const title = (findingMeta.title || '').toLowerCase();

            // 1. Determine BASE score from the finding IDs this card carries, not from its title
            breakdown.baseScore = severityBaseScores[severity] || 5;

            const resolvedMeta = resolveCardBaseScore(findingMeta);
            if (resolvedMeta.key && resolvedMeta.score > breakdown.baseScore) {
                breakdown.baseScore = resolvedMeta.score;
                breakdown.matchedPattern = resolvedMeta.key;
            }

            // The former step 1b - vulnerability tags against findingBaseScores - now lives
            // in resolveCardBaseScore() together with the findingIds and the ObjectType's
            // primaryFindingId, so both score paths resolve a card the same way. The tag
            // route was the only one that ever reached this table; findingIds were never
            // consulted for the base score at all.

            // DCSync/Replication Rights are ALWAYS maximum
            if (breakdown.matchedPattern === 'DANGEROUS_ACL_DCSYNC') {
                breakdown.finalScore = 100;
                breakdown.impactReason = 'Maximum (DCSync)';
                return breakdown;
            }

            // 2. Get account context from scoringContext using accountSID
            const accountInfo = findingMeta.accountSID ? scoringContext?.accounts?.[findingMeta.accountSID] : null;

            // 3. Apply IMPACT modifier
            if (accountInfo && accountInfo.adminTier) {
                breakdown.impactMod = impactMultipliers[accountInfo.adminTier] || impactMultipliers.none;
                const tierNames = { tier0: 'Tier 0 (Domain Admin)', tier1: 'Tier 1 (Server Admin)', tier2: 'Tier 2 (Workstation Admin)', none: 'Non-Admin' };
                breakdown.impactReason = tierNames[accountInfo.adminTier] || 'Standard';
            }

            // 4. Apply EXPLOITABILITY modifier with reasons
            breakdown.exploitMod = getExploitabilityModifier(accountInfo, title);
            if (accountInfo) {
                if (accountInfo.pwdAgeDays > 365) {
                    breakdown.exploitReasons.push('Old password (' + Math.round(accountInfo.pwdAgeDays / 365) + 'y)');
                }
                if (accountInfo.encryptionTypes && accountInfo.encryptionTypes.includes('RC4-HMAC') && !accountInfo.encryptionTypes.includes('AES256')) {
                    breakdown.exploitReasons.push('RC4 encryption');
                }
            }
            if (breakdown.exploitReasons.length === 0 && breakdown.exploitMod !== 1.0) {
                breakdown.exploitReasons.push(breakdown.exploitMod > 1 ? 'Easier to exploit' : 'Harder to exploit');
            }

            // 5. Apply SECURITY modifier with reasons
            breakdown.securityMod = getSecurityModifier(accountInfo, title);
            if (accountInfo && accountInfo.uacFlags) {
                const flags = accountInfo.uacFlags;
                if (flags.includes('ACCOUNTDISABLE') || flags.includes('Disabled')) {
                    breakdown.securityReasons.push('Disabled');
                }
                if (flags.includes('SMARTCARD_REQUIRED') || flags.includes('SmartcardRequired')) {
                    breakdown.securityReasons.push('Smartcard required');
                }
                if (accountInfo.isProtectedUser) {
                    breakdown.securityReasons.push('Protected Users');
                }
            }
            if (breakdown.securityReasons.length === 0 && breakdown.securityMod !== 1.0) {
                breakdown.securityReasons.push(breakdown.securityMod < 1 ? 'Mitigated' : 'Vulnerable');
            }

            // 6. Add correlation bonus
            breakdown.correlationBonus = getCorrelationBonus(accountInfo);
            if (breakdown.correlationBonus > 0) {
                breakdown.correlationReason = 'Appears in multiple findings';
            }

            // Calculate final score
            let rawScore = Math.round(breakdown.baseScore * breakdown.impactMod * breakdown.exploitMod * breakdown.securityMod) + breakdown.correlationBonus;
            breakdown.finalScore = Math.min(Math.max(rawScore, 0), 100);

            return breakdown;
        }

        // Find the best matching findingDefinition for a given finding card metadata
        // Priority: 0) ObjectType primaryFindingId, 1) findingIds from metadata, 2) vulnerability tags, 3) title keyword matching
        function findBestFindingDefinition(meta) {
            if (!findingDefinitions || !meta) return null;
            let bestKey = null;
            let bestScore = 0;

            // 0. ObjectType-level primary finding (highest authority — prevents incidental attribute
            //    triggers from overriding the card's actual topic)
            if (meta.objectType && checkDescriptions) {
                const checkInfo = checkDescriptions[meta.objectType];
                if (checkInfo?.primaryFindingId && findingDefinitions[checkInfo.primaryFindingId]) {
                    return findingDefinitions[checkInfo.primaryFindingId];
                }
            }

            // 1. Direct FindingId lookup (most reliable — from attribute trigger matching)
            if (meta.findingIds && meta.findingIds.length > 0) {
                for (const fid of meta.findingIds) {
                    if (findingDefinitions[fid]) {
                        const score = findingBaseScores[fid] || 0;
                        if (score > bestScore || !bestKey) {
                            bestScore = score;
                            bestKey = fid;
                        }
                    }
                }
            }

            // 2. Vulnerability tags (e.g., "ESC1" → "ESC1_TEMPLATE")
            if (!bestKey && meta.vulnerabilities && meta.vulnerabilities.length > 0) {
                for (const vulnTag of meta.vulnerabilities) {
                    const vulnLower = vulnTag.toLowerCase();
                    // "ESC3-TARGET" against the key ESC3_TARGET_TEMPLATE - see the same
                    // normalisation in resolveCardBaseScore.
                    const vulnKey = vulnLower.replace(/-/g, '_');
                    for (const [key, score] of Object.entries(findingBaseScores)) {
                        if (key.toLowerCase().startsWith(vulnLower + '_') || key.toLowerCase() === vulnLower ||
                            key.toLowerCase().startsWith(vulnKey + '_') || key.toLowerCase() === vulnKey) {
                            if (score > bestScore && findingDefinitions[key]) {
                                bestScore = score;
                                bestKey = key;
                            }
                        }
                    }
                }
            }

            // 3. Fallback: title keyword matching
            if (!bestKey) {
                const titleLower = (meta.title || '').toLowerCase();
                for (const [key, score] of Object.entries(findingBaseScores)) {
                    if (titleLower.includes(key.toLowerCase()) && score > bestScore && findingDefinitions[key]) {
                        bestScore = score;
                        bestKey = key;
                    }
                }
            }

            return bestKey ? findingDefinitions[bestKey] : null;
        }

        function generateTopPriorityActions() {
            const container = document.getElementById('topActionsContainer');
            if (!container) return;

            // ========== OPTIMIZED: Use JSON-based scoring if available ==========
            // This avoids DOM traversal for initial score calculation
            let scoredFindings = [];
            let totalCriticalCount = 0;

            if (scoringContext?.findingCards?.length > 0) {
                // NEW: JSON-based scoring (no DOM traversal needed)
                const criticalFindings = scoringContext.findingCards.filter(f => f.severity === 'finding');
                totalCriticalCount = criticalFindings.length;

                if (criticalFindings.length > 0) {
                    scoredFindings = criticalFindings.map((meta, idx) => {
                        const breakdown = calculateScoreFromMetadata(meta);
                        return {
                            meta: meta,
                            index: idx,
                            score: breakdown.finalScore,
                            breakdown: breakdown,
                            title: meta.title || 'Unknown Finding',
                            section: meta.section || meta.category || 'Unknown'
                        };
                    }).sort((a, b) => b.score - a.score);
                }
            } else {
                // FALLBACK: DOM-based scoring (legacy behavior)
                const allCards = Array.from(document.querySelectorAll('.finding-card'));
                const findingCards = allCards.filter(card => card.dataset.severity === 'finding');
                totalCriticalCount = findingCards.length;

                if (findingCards.length > 0) {
                    scoredFindings = findingCards.map((card, idx) => {
                        const breakdown = calculateFindingScoreWithBreakdown(card);
                        return {
                            card: card,
                            index: idx,
                            score: breakdown.finalScore,
                            breakdown: breakdown,
                            title: card.querySelector('.finding-title')?.textContent || 'Unknown Finding',
                            section: card.closest('.section')?.querySelector('.section-title')?.textContent || 'Unknown'
                        };
                    }).sort((a, b) => b.score - a.score);
                }
            }

            if (totalCriticalCount === 0) {
                // No critical findings - show success message
                container.innerHTML = `
                    <div class="top-actions" style="border-color: var(--note); background: linear-gradient(135deg, var(--note-bg) 0%, var(--bg-card) 100%);">
                        <div class="top-actions-header">
                            <div class="top-actions-title" style="color: var(--note);">
                                <span class="icon">&#10003;</span>
                                Критических нарушений не обнаружено
                            </div>
                        </div>
                        <p style="margin: 0; color: var(--text-muted);">Критические нарушения не выявлены. Проверьте предупреждения и информационные результаты для дальнейшего улучшения защиты.</p>
                    </div>
                `;
                return;
            }

            // Take top 3
            const top3 = scoredFindings.slice(0, 3);

            // Generate HTML
            let actionsHTML = `
                <div class="top-actions">
                    <div class="top-actions-header">
                        <div class="top-actions-title">
                            <span class="icon">&#9889;</span>
                            Первоочередные меры по устранению рисков
                        </div>
                        <div style="display: flex; align-items: center; gap: 12px;">
                            <span style="font-size: 12px; color: var(--text-muted);">${totalCriticalCount} критических нарушений всего</span>
                            <button class="top-actions-toggle" onclick="toggleTopActions()" title="Свернуть или развернуть приоритетные рекомендации">
                                <span class="toggle-icon">&#9660;</span>
                            </button>
                        </div>
                    </div>
                    <div class="top-actions-list">
            `;

            top3.forEach((item, index) => {
                // Resolve objectType and card ID from JSON metadata or DOM
                let cardId = '';
                let objectType = '';
                let checkTitle = item.title;

                if (item.meta) {
                    // JSON-based path: objectType from metadata
                    objectType = item.meta.objectType || '';
                    checkTitle = item.meta.title || item.title;
                } else if (item.card) {
                    // DOM-based fallback
                    cardId = item.card.dataset.cardId || '';
                    const checkHelpBtn = item.card.querySelector('.check-help-btn');
                    objectType = checkHelpBtn?.dataset.objectType || '';
                    checkTitle = checkHelpBtn?.dataset.checkTitle || item.title;
                }

                // Look up check description for professional title and impact text
                const checkInfo = (objectType && checkDescriptions) ? checkDescriptions[objectType] : null;

                // Professional title: checkDescriptions.title > internal check title
                const displayTitle = checkInfo?.title || item.title;

                // Prefer precise Russian security recommendations. Original definitions
                // remain intact for risk scoring and original-language reference.
                const findingDef = findBestFindingDefinition(item.meta || { title: item.title });
                const findingIdRu = findingDef
                    ? Object.keys(findingDefinitions).find(id => findingDefinitions[id] === findingDef)
                    : null;
                const explanationRu = findingIdRu ? (ruFindingExplanations[findingIdRu] || null) : null;
                const impactText = explanationRu?.impact?.[0] || checkInfo?.whyItMatters || '';
                const remediationText = explanationRu?.remediation?.[0] ||
                    'Откройте карточку нарушения, проверьте фактические права и область действия настройки; согласуйте изменение с владельцем системы.';
                const originalEnglishFix = explanationRu?.remediation?.length
                    ? '' : (findingDef?.remediation?.[0] || '');

                // Object count for "N affected" label
                const objectCount = item.meta?.objectCount || 0;

                // Build meta line: "N affected | Section"
                let metaHtml = '';
                if (objectCount > 0) {
                    metaHtml += `<span class="top-action-count">${objectCount} затронуто</span>`;
                }
                const ruModuleNames = {
                    domain:'Домен', accounts:'Учётные записи', rights:'Права доступа',
                    gpo:'Групповые политики', delegation:'Делегирование',
                    adcs:'AD CS', computer:'Компьютеры', creds:'Учётные данные',
                    application:'Приложения', shares:'Общие ресурсы',
                    bloodhound:'BloodHound'
                };
                const ruSection = ruModuleNames[String(item.section || '').toLowerCase()] || item.section;
                metaHtml += `<span class="top-action-section">${escapeHtml(ruSection)}</span>`;

                // Build buttons HTML (info button + score badge)
                let buttonsHtml = '';
                if (checkInfo) {
                    buttonsHtml += `<button class="top-action-info-btn" onclick="event.stopPropagation(); showTopActionInfo(this, '${escapeHtml(objectType)}', '${escapeHtml(checkTitle)}')" data-object-type="${escapeHtml(objectType)}" data-check-title="${escapeHtml(checkTitle)}" title="Подробности проверки">?</button>`;
                }
                const scoreClass = item.score >= scoreThresholds.critical ? 'score-critical' : item.score >= scoreThresholds.high ? 'score-high' : item.score >= scoreThresholds.medium ? 'score-medium' : item.score >= scoreThresholds.low ? 'score-low' : 'score-info';
                const breakdownJson = escapeJsonForAttr(item.breakdown);
                buttonsHtml += `<span class="top-action-score ${scoreClass}" data-score-breakdown='${breakdownJson}' onclick="event.stopPropagation(); showScoreTooltip(this, JSON.parse(this.dataset.scoreBreakdown));" style="cursor: pointer;">${item.score}</span>`;

                // Build detail lines (impact + remediation)
                let detailsHtml = '';
                if (impactText) {
                    detailsHtml += `<div class="top-action-details">${escapeHtml(impactText)}</div>`;
                }
                if (remediationText) {
                    detailsHtml += `<div class="top-action-fix">&rarr; ${escapeHtml(remediationText)}</div>`;
                }
                if (originalEnglishFix) {
                    detailsHtml += `<details class="top-action-original-en" lang="en" onclick="event.stopPropagation()"><summary>Точная рекомендация разработчика (оригинал EN)</summary><div>${escapeHtml(originalEnglishFix)}</div></details>`;
                }

                actionsHTML += `
                    <div class="top-action-item" data-target-card="${cardId}" data-target-title="${escapeHtml(checkTitle)}" data-target-index="${item.index}" onclick="scrollToFindingCard(this)" style="cursor: pointer;">
                        <div class="top-action-rank">${index + 1}</div>
                        <div class="top-action-content">
                            <div class="top-action-title">${escapeHtml(displayTitle)}</div>
                            <div class="top-action-meta">${metaHtml}</div>
                            ${detailsHtml}
                        </div>
                        <div class="top-action-buttons" onclick="event.stopPropagation()">${buttonsHtml}</div>
                    </div>
                `;
            });

            actionsHTML += `
                    </div>
                </div>
            `;

            container.innerHTML = actionsHTML;
        }

        function scrollToFindingCard(element) {
            const cardId = element.dataset.targetCard;
            const targetTitle = element.dataset.targetTitle;
            const targetIndex = parseInt(element.dataset.targetIndex);

            let card = cardId ? document.querySelector('.finding-card[data-card-id="' + cardId + '"]') : null;

            // Second try: find by data-check-title
            if (!card && targetTitle) {
                const allCards = Array.from(document.querySelectorAll('.finding-card'));
                card = allCards.find(c => {
                    const helpBtn = c.querySelector('.check-help-btn');
                    return helpBtn && helpBtn.dataset.checkTitle === targetTitle;
                });
            }

            // Fallback: find by index among finding cards
            if (!card && targetIndex >= 0) {
                const findingCards = Array.from(document.querySelectorAll('.finding-card')).filter(c => c.dataset.severity === 'finding');
                card = findingCards[targetIndex];
            }

            if (!card) return;

            // Reset filters to ensure the card is visible
            currentSeverityFilter = 'all';
            currentCategoryFilter = 'all';
            currentSearchQuery = '';

            // Update filter UI
            document.querySelectorAll('.severity-filter').forEach(f => f.classList.remove('active'));
            document.querySelectorAll('.nav-item[data-category]').forEach(f => f.classList.remove('active'));
            const allSeverityFilter = document.querySelector('.severity-filter[data-severity="all"]');
            const allCategoryFilter = document.querySelector('.nav-item[data-category="all"]');
            if (allSeverityFilter) allSeverityFilter.classList.add('active');
            if (allCategoryFilter) allCategoryFilter.classList.add('active');
            const searchInput = document.getElementById('searchInput');
            if (searchInput) searchInput.value = '';

            // Apply filters to show all cards and sections
            applyFilters();

            // Ensure the card is visible
            card.style.display = '';

            // Collapse all other cards first, then expand only the target card
            document.querySelectorAll('.finding-card.expanded').forEach(c => c.classList.remove('expanded'));
            card.classList.add('expanded');

            // Highlight the category in the sidebar
            highlightCategoryForCard(card);

            // Remove any previous highlight
            document.querySelectorAll('.finding-card.keyboard-focused').forEach(c => c.classList.remove('keyboard-focused'));

            // Use setTimeout to ensure the DOM has fully updated after view switch + filter changes
            setTimeout(() => {
                card.scrollIntoView({ behavior: 'auto', block: 'start' });
                card.classList.add('keyboard-focused');
                setTimeout(() => card.classList.remove('keyboard-focused'), UI_CONSTANTS.KEYBOARD_FOCUS_DURATION);
            }, 150);
        }

        function showTopActionInfo(btn, objectType, checkTitle) {
            // Look up check description by ObjectType
            if (!objectType || !checkDescriptions[objectType]) return;
            const checkInfo = checkDescriptions[objectType];

            // Build tooltip content similar to check tooltip
            let content = '<div class="top-action-tooltip-content">';
            content += '<div class="top-action-tooltip-header">' + escapeHtml(checkTitle) + '</div>';

            if (checkInfo.summary) {
                content += '<div class="top-action-tooltip-section">';
                content += '<div class="top-action-tooltip-label">Краткое описание</div>';
                content += '<div class="top-action-tooltip-text">' + escapeHtml(checkInfo.summary) + '</div>';
                content += '</div>';
            }

            if (checkInfo.whyItMatters) {
                content += '<div class="top-action-tooltip-section">';
                content += '<div class="top-action-tooltip-label">Почему это важно</div>';
                content += '<div class="top-action-tooltip-text">' + escapeHtml(checkInfo.whyItMatters) + '</div>';
                content += '</div>';
            }

            if (checkInfo.whatWeCheck && checkInfo.whatWeCheck.length > 0) {
                content += '<div class="top-action-tooltip-section">';
                content += '<div class="top-action-tooltip-label">Что проверяется</div>';
                content += '<ul class="top-action-tooltip-list">';
                checkInfo.whatWeCheck.forEach(item => {
                    content += '<li>' + escapeHtml(item) + '</li>';
                });
                content += '</ul>';
                content += '</div>';
            }

            if (checkInfo.filteringNote) {
                content += '<div class="top-action-tooltip-section top-action-tooltip-note">';
                content += '<div class="top-action-tooltip-label">Note</div>';
                content += '<div class="top-action-tooltip-text">' + escapeHtml(checkInfo.filteringNote) + '</div>';
                content += '</div>';
            }

            content += '</div>';

            // Show as tooltip near the button
            showTooltipAt(btn, content);
        }

        // Track active floating tooltip and its event listener for cleanup
        let activeFloatingTooltip = null;
        let activeFloatingTooltipListener = null;

        function showTooltipAt(element, content) {
            // Remove any existing tooltip and clean up its event listener
            if (activeFloatingTooltip) {
                activeFloatingTooltip.remove();
                if (activeFloatingTooltipListener) {
                    document.removeEventListener('click', activeFloatingTooltipListener);
                    activeFloatingTooltipListener = null;
                }
                activeFloatingTooltip = null;
            }

            // Create tooltip
            const tooltip = document.createElement('div');
            tooltip.className = 'remediation-floating-tooltip';
            tooltip.innerHTML = content;
            document.body.appendChild(tooltip);
            activeFloatingTooltip = tooltip;

            // Position near element with smart positioning
            const rect = element.getBoundingClientRect();
            const tooltipRect = tooltip.getBoundingClientRect();
            const viewportHeight = window.innerHeight;
            const viewportWidth = window.innerWidth;

            // Calculate vertical position - prefer below, but go above if not enough space
            let top;
            if (rect.bottom + tooltipRect.height + 20 > viewportHeight) {
                // Not enough space below - show above
                top = rect.top + window.scrollY - tooltipRect.height - 8;
            } else {
                // Show below
                top = rect.bottom + window.scrollY + 8;
            }

            // Calculate horizontal position
            let left = rect.left + window.scrollX - 100;
            if (left + tooltipRect.width > viewportWidth - UI_CONSTANTS.VIEWPORT_PADDING) {
                left = viewportWidth - tooltipRect.width - 20;
            }
            if (left < UI_CONSTANTS.VIEWPORT_PADDING) {
                left = UI_CONSTANTS.VIEWPORT_PADDING;
            }

            tooltip.style.top = top + 'px';
            tooltip.style.left = left + 'px';

            // Create named listener for proper cleanup
            activeFloatingTooltipListener = function closeTooltip(e) {
                if (!tooltip.contains(e.target) && e.target !== element) {
                    tooltip.remove();
                    document.removeEventListener('click', closeTooltip);
                    activeFloatingTooltip = null;
                    activeFloatingTooltipListener = null;
                }
            };

            // Close on outside click (with small delay to prevent immediate close)
            setTimeout(() => {
                if (activeFloatingTooltip === tooltip) {
                    document.addEventListener('click', activeFloatingTooltipListener);
                }
            }, UI_CONSTANTS.TOOLTIP_CLOSE_DELAY);
        }

        // ============================================================
        // SCORE SORT STATE
        // ============================================================

        // Populate score badges into finding card headers
        function populateCardScores() {
            const cards = document.querySelectorAll('.finding-card');
            if (!cards.length) return;

            cards.forEach((card, index) => {
                const severity = card.dataset.severity || 'note';

                // Note and Secure cards have no score
                if (severity === 'note' || severity === 'secure') return;

                // Calculate score from JSON metadata (preferred) or DOM fallback
                let breakdown;
                const cardIndex = parseInt(card.dataset.cardIndex);
                if (!isNaN(cardIndex) && scoringContext?.findingCards?.[cardIndex]) {
                    breakdown = calculateScoreFromMetadata(scoringContext.findingCards[cardIndex]);
                } else {
                    breakdown = calculateFindingScoreWithBreakdown(card);
                }

                if (breakdown.finalScore <= 0) return;

                // Determine score class
                const scoreClass = breakdown.finalScore >= scoreThresholds.critical ? 'score-critical' :
                                   breakdown.finalScore >= scoreThresholds.high ? 'score-high' :
                                   breakdown.finalScore >= scoreThresholds.medium ? 'score-medium' :
                                   breakdown.finalScore >= scoreThresholds.low ? 'score-low' : 'score-info';

                // Create score badge element
                const badge = document.createElement('span');
                badge.className = 'score-badge ' + scoreClass;
                badge.textContent = breakdown.finalScore;
                badge.dataset.scoreBreakdown = JSON.stringify(breakdown);
                badge.title = 'Risk Score (click for details)';
                badge.addEventListener('click', function(e) {
                    e.stopPropagation();
                    showScoreTooltip(this, breakdown);
                });

                // Insert badge into finding-meta area (before chevron, after count)
                const meta = card.querySelector('.finding-meta');
                const chevron = meta?.querySelector('.finding-toggle');
                if (meta && chevron) {
                    meta.insertBefore(badge, chevron);
                }

                // Store score on the card element for sorting
                card.dataset.score = breakdown.finalScore;
            });
        }

        // Severity order for sorting (lower = more critical)
        const SEVERITY_ORDER = { 'finding': 0, 'hint': 1, 'note': 2, 'secure': 3 };

        // Sort all finding cards by score (descending), then by severity
        // Called once after populateCardScores() — sections are hidden, cards are flat-sorted
        function sortCardsByScore() {
            const container = document.getElementById('cardViewContainer');
            if (!container) return;

            const allCards = Array.from(container.querySelectorAll('.finding-card'));
            if (allCards.length === 0) return;

            const scoredCards = allCards.map(card => ({
                element: card,
                score: parseInt(card.dataset.score) || 0,
                severity: SEVERITY_ORDER[card.dataset.severity] ?? 99
            }));

            // Sort by score descending, then by severity
            scoredCards.sort((a, b) => {
                if (b.score !== a.score) return b.score - a.score;
                return a.severity - b.severity;
            });

            // Hide all sections (cards are shown flat)
            container.querySelectorAll('.section').forEach(s => s.style.display = 'none');

            // Append sorted cards directly to container
            scoredCards.forEach(item => container.appendChild(item.element));
        }

        function expandAllCards() {
            // Expand all finding cards
            document.querySelectorAll('.finding-card').forEach(card => {
                card.classList.add('expanded');
            });
            // Expand top priority actions
            const topActions = document.querySelector('.top-actions');
            if (topActions) {
                topActions.classList.remove('collapsed');
                updateTopActionsToggleIcon(topActions);
            }
        }

        function collapseAllCards() {
            // Collapse all finding cards
            document.querySelectorAll('.finding-card').forEach(card => {
                card.classList.remove('expanded');
            });
            // Collapse top priority actions
            const topActions = document.querySelector('.top-actions');
            if (topActions) {
                topActions.classList.add('collapsed');
                updateTopActionsToggleIcon(topActions);
            }
        }

        function toggleTopActions() {
            const topActions = document.querySelector('.top-actions');
            if (topActions) {
                topActions.classList.toggle('collapsed');
                updateTopActionsToggleIcon(topActions);
            }
        }

        function updateTopActionsToggleIcon(topActions) {
            const toggleIcon = topActions.querySelector('.toggle-icon');
            if (toggleIcon) {
                toggleIcon.innerHTML = topActions.classList.contains('collapsed') ? '&#9654;' : '&#9660;';
            }
        }

        // ============================================================
        // COPY BUTTON for Remediation
        // ============================================================

        function copyToClipboard(button, text) {
            navigator.clipboard.writeText(text).then(() => {
                button.classList.add('copied');
                const originalText = button.textContent;
                button.textContent = 'Скопировано!';
                setTimeout(() => {
                    button.classList.remove('copied');
                    button.textContent = originalText;
                }, UI_CONSTANTS.COPY_FEEDBACK_DURATION);
            }).catch(err => {
                console.error('Failed to copy:', err);
                button.textContent = 'Failed';
                setTimeout(() => {
                    button.textContent = 'Copy';
                }, UI_CONSTANTS.COPY_FEEDBACK_DURATION);
            });
        }

        // ============================================================
        // Per-card name column resizing (Excel-like, not persisted)
        // ============================================================

        function initColumnResize() {
            const MIN_NAME_W = 120;   // px - keep the name column usable
            const MIN_VALUE_W = 140;  // px - keep the value column usable
            let resizer = null;
            let objectBody = null;
            let startX = 0;
            let startW = 0;
            let maxW = 0;

            document.addEventListener('mousedown', function(e) {
                const r = e.target.closest('.attr-col-resizer');
                if (!r) return;

                objectBody = r.closest('.object-body');
                if (!objectBody) return;

                e.preventDefault();
                resizer = r;

                // Current width from the CSS variable or the rendered name cell
                const nameCell = objectBody.querySelector('.attr-name');
                startW = nameCell ? nameCell.getBoundingClientRect().width : 280;
                startX = e.clientX;
                maxW = Math.max(MIN_NAME_W, objectBody.clientWidth - MIN_VALUE_W);

                resizer.classList.add('resizing');
                document.body.classList.add('col-resizing');
            });

            document.addEventListener('mousemove', function(e) {
                if (!resizer || !objectBody) return;
                e.preventDefault();
                let w = startW + (e.clientX - startX);
                w = Math.max(MIN_NAME_W, Math.min(w, maxW));
                objectBody.style.setProperty('--attr-name-w', w + 'px');
            });

            document.addEventListener('mouseup', function() {
                if (!resizer) return;
                resizer.classList.remove('resizing');
                document.body.classList.remove('col-resizing');
                resizer = null;
                objectBody = null;
            });
        }

        // ============================================================
        // DRAG & DROP Attribute Reordering
        // ============================================================

        function initAttributeDragAndDrop() {
            let draggedElement = null;

            // Only the dedicated drag handle starts a drag, so the rest of the
            // row text stays freely selectable / copyable.
            document.addEventListener('dragstart', function(e) {
                const handle = (e.target.classList && e.target.classList.contains('attr-drag-handle')) ? e.target : null;
                const row = handle ? handle.closest('.attr-row') : null;
                if (row) {
                    draggedElement = row;
                    row.classList.add('dragging');
                    e.dataTransfer.effectAllowed = 'move';
                    e.dataTransfer.setData('text/html', row.innerHTML);
                }
            });

            document.addEventListener('dragend', function() {
                if (draggedElement) {
                    draggedElement.classList.remove('dragging');
                    // Remove all drag-over indicators
                    document.querySelectorAll('.attr-row.drag-over').forEach(el => {
                        el.classList.remove('drag-over');
                    });
                    draggedElement = null;
                }
            });

            document.addEventListener('dragover', function(e) {
                if (!draggedElement) return;

                const target = e.target.closest('.attr-row');
                if (!target || target === draggedElement) return;

                e.preventDefault();
                e.dataTransfer.dropEffect = 'move';

                // Remove previous drag-over indicators
                document.querySelectorAll('.attr-row.drag-over').forEach(el => {
                    if (el !== target) el.classList.remove('drag-over');
                });

                // Add drag-over indicator to current target
                target.classList.add('drag-over');
            });

            document.addEventListener('drop', function(e) {
                if (!draggedElement) return;

                const target = e.target.closest('.attr-row');
                if (!target || target === draggedElement) return;

                e.preventDefault();
                e.stopPropagation();

                // Get target parent container
                const targetParent = target.parentNode;

                // Determine insertion position based on mouse Y position
                const targetRect = target.getBoundingClientRect();
                const midPoint = targetRect.top + (targetRect.height / 2);

                if (e.clientY < midPoint) {
                    // Insert before target
                    targetParent.insertBefore(draggedElement, target);
                } else {
                    // Insert after target
                    if (target.nextSibling) {
                        targetParent.insertBefore(draggedElement, target.nextSibling);
                    } else {
                        targetParent.appendChild(draggedElement);
                    }
                }

                // Remove drag-over indicator
                target.classList.remove('drag-over');

                // Update extended attributes counter after cross-container moves
                updateExtendedAttrCounters(draggedElement);
            });
        }

        // Update the "Show/Hide N more attribute(s)" counter after drag & drop
        function updateExtendedAttrCounters(movedElement) {
            // Find the closest object-body container
            const objectBody = movedElement.closest('.object-body');
            if (!objectBody) return;

            const extSection = objectBody.querySelector('.extended-attrs');
            const toggleBtn = objectBody.querySelector('.extended-attrs-toggle');
            if (!extSection || !toggleBtn) return;

            // Count remaining attr-rows in extended section
            const extCount = extSection.querySelectorAll(':scope > .attr-row').length;
            const textSpan = toggleBtn.querySelector('span:last-child');
            if (!textSpan) return;

            if (extCount === 0) {
                // No more extended attributes — hide toggle and section
                toggleBtn.style.display = 'none';
                extSection.style.display = 'none';
            } else {
                toggleBtn.style.display = '';
                // Update counter text, preserve Show/Hide prefix
                const currentText = textSpan.textContent;
                const prefix = currentText.startsWith('Hide') ? 'Hide' : 'Show';
                textSpan.textContent = prefix + ' ' + extCount + ' more attribute(s)';
            }
        }

        // ============================================================
        //  PRINT / PDF PREPARATION
        //  Ensures all content is expanded and a Table of Contents
        //  is generated before the browser renders the print layout.
        // ============================================================

        // State snapshot to restore after printing
        var printStateSnapshot = null;

        function preparePrint() {
            // Save current state so we can restore after printing
            printStateSnapshot = {
                expandedCards: [],
                collapsedTopActions: false,
                hiddenCompletedState: false
            };

            // Remember which cards were NOT expanded (so we can collapse them back)
            document.querySelectorAll('.finding-card:not(.expanded)').forEach(function(card) {
                printStateSnapshot.expandedCards.push(card);
            });

            // Remember top-actions state
            var topActions = document.querySelector('.top-actions');
            if (topActions && topActions.classList.contains('collapsed')) {
                printStateSnapshot.collapsedTopActions = true;
            }

            // Remember hide-completed state
            var hideToggle = document.getElementById('hideCompletedToggle');
            if (hideToggle && hideToggle.checked) {
                printStateSnapshot.hiddenCompletedState = true;
                hideToggle.checked = false;
                toggleHideCompleted();
            }

            // Expand ALL finding cards for print
            document.querySelectorAll('.finding-card').forEach(function(card) {
                card.classList.add('expanded');
            });

            // Expand top-actions
            if (topActions) {
                topActions.classList.remove('collapsed');
                updateTopActionsToggleIcon(topActions);
            }

            // Build Table of Contents from section headers
            buildPrintTOC();
        }

        function restoreAfterPrint() {
            if (!printStateSnapshot) return;

            // Collapse cards that were not expanded before print
            printStateSnapshot.expandedCards.forEach(function(card) {
                card.classList.remove('expanded');
            });

            // Restore top-actions collapsed state
            if (printStateSnapshot.collapsedTopActions) {
                var topActions = document.querySelector('.top-actions');
                if (topActions) {
                    topActions.classList.add('collapsed');
                    updateTopActionsToggleIcon(topActions);
                }
            }

            // Restore hide-completed state
            if (printStateSnapshot.hiddenCompletedState) {
                var hideToggle = document.getElementById('hideCompletedToggle');
                if (hideToggle) {
                    hideToggle.checked = true;
                    toggleHideCompleted();
                }
            }

            // Remove TOC
            var toc = document.getElementById('printTOC');
            if (toc) toc.remove();

            printStateSnapshot = null;
        }

        function buildPrintTOC() {
            // Remove existing TOC if any
            var existing = document.getElementById('printTOC');
            if (existing) existing.remove();

            var sections = document.querySelectorAll('.section');
            if (sections.length === 0) return;

            var toc = document.createElement('div');
            toc.id = 'printTOC';
            toc.className = 'print-toc';

            var tocTitle = document.createElement('div');
            tocTitle.className = 'print-toc-title';
            tocTitle.textContent = 'Table of Contents';
            toc.appendChild(tocTitle);

            // Build severity matrix table
            var table = document.createElement('table');
            table.className = 'print-toc-table';

            // Table header
            var thead = document.createElement('thead');
            var headerRow = document.createElement('tr');
            ['Section', 'Findings', 'Hints', 'Notes', 'Secure'].forEach(function(label) {
                var th = document.createElement('th');
                th.textContent = label;
                headerRow.appendChild(th);
            });
            thead.appendChild(headerRow);
            table.appendChild(thead);

            // Pre-build severity counts per section using data-category attribute
            // Note: Cards may be sorted flat outside their sections (sortCardsByScore),
            // so we use the card's data-category to map back to section IDs (cat-<category>)
            var sectionCounts = {};
            document.querySelectorAll('.finding-card[data-severity][data-category]').forEach(function(card) {
                var sid = 'cat-' + card.getAttribute('data-category');
                if (!sectionCounts[sid]) sectionCounts[sid] = { finding: 0, hint: 0, note: 0, secure: 0 };
                var sev = card.getAttribute('data-severity');
                if (sectionCounts[sid][sev] !== undefined) sectionCounts[sid][sev]++;
            });

            // Table body
            var tbody = document.createElement('tbody');
            var totals = { finding: 0, hint: 0, note: 0, secure: 0 };

            sections.forEach(function(section, index) {
                var titleEl = section.querySelector('.section-title');
                if (!titleEl) return;

                var sectionTitle = titleEl.textContent.trim();
                // Strip [N/M] prefix for cleaner display
                sectionTitle = sectionTitle.replace(/^\[\d+\/\d+\]\s*/, '');
                var sectionId = section.id;

                // Get pre-computed counts for this section
                var counts = sectionCounts[sectionId] || { finding: 0, hint: 0, note: 0, secure: 0 };

                // Accumulate totals
                totals.finding += counts.finding;
                totals.hint += counts.hint;
                totals.note += counts.note;
                totals.secure += counts.secure;

                // Determine highest severity for left border color
                var severity = counts.finding > 0 ? 'finding' : counts.hint > 0 ? 'hint' : counts.secure > 0 ? 'secure' : 'note';

                var row = document.createElement('tr');
                row.className = 'toc-severity-' + severity;

                // Section name cell with link
                var nameCell = document.createElement('td');
                nameCell.className = 'toc-section-name';
                var link = document.createElement('a');
                link.href = '#' + sectionId;
                link.textContent = (index + 1) + '. ' + sectionTitle;
                nameCell.appendChild(link);
                row.appendChild(nameCell);

                // Severity count cells
                [
                    { key: 'finding', cls: 'toc-cell-finding' },
                    { key: 'hint', cls: 'toc-cell-hint' },
                    { key: 'note', cls: 'toc-cell-note' },
                    { key: 'secure', cls: 'toc-cell-secure' }
                ].forEach(function(col) {
                    var td = document.createElement('td');
                    td.className = col.cls;
                    if (counts[col.key] > 0) {
                        td.textContent = counts[col.key];
                        td.classList.add('has-value');
                    } else {
                        td.textContent = '\u2013'; // en-dash
                        td.classList.add('no-value');
                    }
                    row.appendChild(td);
                });

                tbody.appendChild(row);
            });
            table.appendChild(tbody);

            // Table footer with totals
            var tfoot = document.createElement('tfoot');
            var footerRow = document.createElement('tr');

            var totalLabel = document.createElement('td');
            totalLabel.className = 'toc-section-name toc-total-label';
            totalLabel.textContent = 'Total';
            footerRow.appendChild(totalLabel);

            [
                { key: 'finding', cls: 'toc-cell-finding' },
                { key: 'hint', cls: 'toc-cell-hint' },
                { key: 'note', cls: 'toc-cell-note' },
                { key: 'secure', cls: 'toc-cell-secure' }
            ].forEach(function(col) {
                var td = document.createElement('td');
                td.className = col.cls;
                if (totals[col.key] > 0) {
                    td.textContent = totals[col.key];
                    td.classList.add('has-value');
                } else {
                    td.textContent = '\u2013';
                    td.classList.add('no-value');
                }
                footerRow.appendChild(td);
            });

            tfoot.appendChild(footerRow);
            table.appendChild(tfoot);

            toc.appendChild(table);

            // Insert TOC after info-bar, before card controls
            var infoBar = document.querySelector('.info-bar');
            if (infoBar && infoBar.parentNode) {
                infoBar.parentNode.insertBefore(toc, infoBar.nextSibling);
            }
        }

        // Register print event handlers
        window.addEventListener('beforeprint', preparePrint);
        window.addEventListener('afterprint', restoreAfterPrint);
