﻿function Disconnect-adPEAS {
<#
.SYNOPSIS
    Terminates the current adPEAS session and cleans up resources.

.DESCRIPTION
    Closes the current LDAP connection, disposes connection objects and clears all global session variables and caches.

    This function:
    - Reverts NTLM impersonation if active (RevertToSelf + CloseHandle)
    - Disposes $Script:LdapConnection (System.DirectoryServices.Protocols.LdapConnection)
    - Disposes $Script:GCConnection (Global Catalog connection for cross-domain SID resolution)
    - Clears all session state variables ($Script:LDAPContext, $Script:LDAPCredential, $Script:ConnectionState, etc.)
    - Clears all session caches (SID resolution, privileged check, completion, SMB, LAPS, etc.)
    - Removes hosts file entries added by Connect-adPEAS (requires Admin)

.PARAMETER Force
    Forces disconnect even if errors occur during cleanup.

.EXAMPLE
    Disconnect-adPEAS
    Terminates the current session cleanly.

.EXAMPLE
    Disconnect-adPEAS -Force
    Forces disconnect even with cleanup errors.

.NOTES
    Author: Alexander Sturz (@_61106960_)
#>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$false)]
        [switch]$Force
    )

    begin {
        # Helper: Safe dispose of IDisposable objects (LdapConnection, etc.)
        function Invoke-SafeDispose {
            param(
                [Parameter(Mandatory)]
                [string]$Name,
                [Parameter(Mandatory)]
                [AllowNull()]
                $Object
            )
            if (-not $Object) { return $null }
            try {
                Write-Log "[Disconnect-adPEAS] Disposing $Name..."
                $Object.Dispose()
                Write-Log "[Disconnect-adPEAS] $Name disposed successfully"
                return $null
            }
            catch {
                if ($_.Exception.InnerException -is [System.ObjectDisposedException] -or
                    $_.Exception -is [System.ObjectDisposedException]) {
                    Write-Log "[Disconnect-adPEAS] $Name already disposed - continuing cleanup"
                    return $null
                }
                Write-Log "[Disconnect-adPEAS] Error disposing ${Name}: $_"
                return "$Name disposal failed: $_"
            }
        }
    }

    process {
        try {
            # Check if a real session exists (LDAPContext with Domain set, or active connection)
            $hasSession = ($Script:LDAPContext -and $Script:LDAPContext['Domain']) -or $Script:LdapConnection
            if (-not $hasSession) {
                Show-NoSessionError -Context "Disconnect-adPEAS"
                # Still clean up any partial state (e.g. empty LDAPContext from failed connect)
                if ($Script:LDAPContext) { Clear-SessionState }
                return
            }

            # Display current session before disconnect
            Show-SubHeader "Отключение сеанса..."

            if ($Script:LDAPContext -and $Script:LDAPContext['Domain']) {
                Show-Line "Текущий сеанс:" -Class Hint
                Show-KeyValue "Domain:" $Script:LDAPContext.Domain
                # Display authenticated user
                if ($Script:LDAPContext.AuthenticatedUser) {
                    Show-KeyValue "Authenticated as:" $Script:LDAPContext.AuthenticatedUser
                } elseif ($Script:LDAPContext.Credential) {
                    Show-KeyValue "Authenticated as:" $Script:LDAPContext.Credential.UserName
                } else {
                    Show-KeyValue "Authenticated as:" "$env:USERDOMAIN\$env:USERNAME"
                }

                # Calculate session duration if available
                if ($Script:LDAPContext.SessionStartTime) {
                    $sessionDuration = (Get-Date) - $Script:LDAPContext.SessionStartTime
                    Show-KeyValue "Session Duration:" $sessionDuration.ToString('hh\:mm\:ss')
                }
            }

            $cleanupErrors = @()

            # Step 1: Revert NTLM impersonation (MUST be done BEFORE disposing connections)
            if ($Script:NTLMTokenHandle -and $Script:NTLMTokenHandle -ne [IntPtr]::Zero) {
                Write-Log "[Disconnect-adPEAS] Reverting NTLM impersonation..."
                try {
                    Invoke-RevertToSelf -TokenHandle $Script:NTLMTokenHandle
                    Write-Log "[Disconnect-adPEAS] NTLM impersonation reverted successfully"
                    Show-KeyValue "NTLM Impersonation:" "Reverted to original context"
                }
                catch {
                    $cleanupErrors += "NTLM revert failed: $_"
                    Write-Log "[Disconnect-adPEAS] Error reverting NTLM impersonation: $_"
                    if (-not $Force) {
                        Write-Warning "[Disconnect-adPEAS] Failed to revert NTLM impersonation: $_"
                    }
                }
                $Script:NTLMTokenHandle = [IntPtr]::Zero
            }

            # Step 2: Dispose connections
            $err = Invoke-SafeDispose -Name "LdapConnection" -Object $Script:LdapConnection
            if ($err) { $cleanupErrors += $err }

            $err = Invoke-SafeDispose -Name "GCConnection" -Object $Script:GCConnection
            if ($err) { $cleanupErrors += $err }

            # Step 3: Clean up hosts file entries (if patched during connect)
            if ($Script:LDAPContext -and $Script:LDAPContext['HostsEntries'] -and $Script:LDAPContext['HostsEntries'].Count -gt 0) {
                Write-Log "[Disconnect-adPEAS] Cleaning up hosts file entries..."
                try {
                    $hostsResult = Remove-adPEASHostsEntry
                    if ($hostsResult.Success -and $hostsResult.RemovedCount -gt 0) {
                        Write-Log "[Disconnect-adPEAS] Removed $($hostsResult.RemovedCount) hosts file entries"
                        Show-KeyValue "Hosts File:" "Cleaned ($($hostsResult.RemovedCount) entries removed)"
                    }
                    elseif ($hostsResult.RequiresElevation) {
                        Write-Warning "[Disconnect-adPEAS] Cannot clean hosts file - Administrator privileges required"
                        Write-Warning "[Disconnect-adPEAS] Manually remove adPEAS entries from: $env:SystemRoot\System32\drivers\etc\hosts"
                        Show-KeyValue "Hosts File:" "Cleanup requires Admin (manual removal needed)" -Class Hint
                    }
                }
                catch {
                    $cleanupErrors += "Hosts file cleanup failed: $_"
                    Write-Log "[Disconnect-adPEAS] Error cleaning hosts file: $_"
                    if (-not $Force) {
                        Write-Warning "[Disconnect-adPEAS] Hosts file cleanup failed: $_"
                    }
                }
            }

            # Step 4: Clear all session variables and caches
            Clear-SessionState
            Write-Log "[Disconnect-adPEAS] All session variables and caches cleared"

            # Success output
            Show-EmptyLine
            Show-Line "Очистка:" -Class Hint
            Show-KeyValue "Connection:" "Closed" -Class Note
            Show-KeyValue "Variables:" "Cleared" -Class Note
            Show-EmptyLine

            if ($cleanupErrors.Count -gt 0 -and $Force) {
                Show-Line "Ошибки очистки (принудительное отключение):" -Class Hint
                foreach ($err in $cleanupErrors) {
                    Show-Line "- $err"
                }
            }
        }
        catch {
            # Use centralized error message
            Show-DisconnectError -ErrorMessage $_.Exception.Message

            # If Force is specified, clear variables anyway
            if ($Force) {
                Show-Line "Принудительный режим включён — переменные будут очищены несмотря на ошибки..." -Class Hint
                # Revert NTLM impersonation even in force mode
                if ($Script:NTLMTokenHandle -and $Script:NTLMTokenHandle -ne [IntPtr]::Zero) {
                    try { Invoke-RevertToSelf -TokenHandle $Script:NTLMTokenHandle } catch {}
                    $Script:NTLMTokenHandle = [IntPtr]::Zero
                }
                # Dispose connections silently
                try { if ($Script:LdapConnection) { $Script:LdapConnection.Dispose() } } catch {}
                try { if ($Script:GCConnection) { $Script:GCConnection.Dispose() } } catch {}
                # Clear all state
                Clear-SessionState
                Show-Line "Переменные сеанса и кэши принудительно очищены" -Class Note
            }
        }
    }
}

function Clear-SessionState {
    <#
    .SYNOPSIS
        Clears all session-specific $Script: variables and caches.
    .DESCRIPTION
        Internal helper used by Disconnect-adPEAS (normal and force path).
        Only clears session state - does NOT dispose connections or revert impersonation.
    #>

    # Connection references (already disposed at this point)
    $Script:LdapConnection = $null
    $Script:GCConnection = $null
    # The negative half of the GC cache. Left standing it would survive into the next
    # Connect-adPEAS in the same process and suppress the Global Catalog there - against a
    # different domain, and possibly from a segment where 3268 is open.
    $Script:GCConnectionFailed = $null

    # Core session state
    $Script:LDAPContext = $null
    $Script:LDAPCredential = $null
    $Script:ConnectionState = $null
    $Script:LastLDAPErrorCode = $null
    $Script:LastLDAPErrorDetails = $null
    $Script:AuthInfo = $null
    $Script:NTLMTokenHandle = [IntPtr]::Zero

    # Schema class name cache (Resolve-SchemaClassName). Read from the forest's own schema
    # partition, so it belongs to the session and not to the module: a reconnect to a
    # different forest must not answer out of the previous one's schema.
    $Script:SchemaClassNameCache = $null

    # Anonymous access detection (Connect-LDAP)
    $Script:AnonymousAccessEnabled = $null
    $Script:AnonymousAccessDetails = $null
    $Script:AnonymousAccessTested = $null
    $Script:AnonymousAccessSkipReason = $null

    # License (runtime-provided via -License parameter)
    $Script:RuntimeLicense = $null
    $Script:adPEASDisclaimer = $null

    # Kerberos ticket metadata
    $Script:KirbiMetadata = $null
    $Script:CcacheMetadata = $null

    # SID resolution caches (ConvertFrom-SID / ConvertTo-SID)
    $Script:SIDResolutionCache = @{}
    $Script:SIDVerboseCache = @{}
    $Script:NameToSIDCache = @{}

    # Privileged check cache (Test-IsPrivileged)
    $Script:PrivilegedCheckCache = @{}
    $Script:GroupMembershipCache = @{}

    # Token groups cache (Get-CurrentUserTokenGroups)
    $Script:CurrentUserTokenGroups = $null

    # Foreign domain cache (ConvertFrom-SID)
    $Script:ForeignDomainCache = @{}

    # Collector caches (Invoke-adPEASCollector) - MUST be reset to $null, not @{}.
    # These are lazy-built and their build guards use "if ($cache) { return }". An empty @{} is
    # TRUTHY, so resetting to @{} makes the next collection skip rebuilding and run with an empty
    # cache - group memberships and OU/container children come out empty, and the sibling
    # ParentDNToChildren (previously omitted here entirely) stays $null and crashes Collect-BHOUs
    # with "cannot call a method on a null-valued expression". Reset the full set the collector's
    # end{} block clears, so "null means not built" holds after a disconnect/reconnect.
    $Script:ComputerHostnameCache = $null
    $Script:DNToIdentityCache = $null
    $Script:ParentDNToChildren = $null
    $Script:ConfigContainerGuidCache = $null
    $Script:TemplateCNToOID = $null

    # Tab-completion cache (Register-adPEASCompleters)
    if ($Script:CompletionCache) { Clear-CompletionCache }
    $Script:CompletionCacheAttempted = $null

    # SMB share access cache (Invoke-SMBAccess)
    if ($Script:SMBShareAccessCache -and $Script:SMBShareAccessCache.Count -gt 0) {
        Reset-SMBShareAccessCache
    } else {
        $Script:SMBShareAccessCache = @{}
    }

    # SYSVOL file listing cache
    if ($null -ne $Script:SYSVOLFileCache) {
        Reset-SYSVOLFileCache
    }

    # SYSVOL content cache (on-demand file content, e.g., GptTmpl.inf)
    $Script:SYSVOLContentCache = $null

    # SYSVOL files that could not be read or parsed. Reset-SYSVOLFileCache clears them as
    # well, but only runs when a listing was built - a file can fail without one.
    $Script:SYSVOLFileGaps = $null

    # Whether this directory publishes a certificate issuer trusted for authentication
    # (Get-CertificateTrustAnchor). Per domain, so it must not survive a reconnect.
    $Script:CertificateTrustAnchor = $null

    # Findings collection (adPEAS-Messages / HTML export)
    $Script:adPEAS_FindingsCollection = $null
    $Script:adPEAS_FindingsCollectionEnabled = $false
    # Checks that threw during the last run; named in the Scan Summary
    $Script:adPEAS_IncompleteChecks = $null
    $Script:adPEAS_CurrentCheckContext = $null
    # Whether the import's logo is still the last thing on the console (Show-ScanLogo).
    # Disconnecting prints, so it is not any more.
    $Script:adPEASLogoOnScreen = $false

    # LDAP Statistics tracking (set by Invoke-adPEAS -Statistics)
    $Script:LDAPStatistics = $null

    # Runtime configuration (set by Invoke-adPEAS)
    $Script:DefaultInactiveDays = $null
    $Script:IncludePrivilegedMode = $null
    $Script:adPEAS_OutputColor = $true
    $Script:adPEAS_VerboseLogging = $false
    $Script:ModuleCategoryHeaders = $null

    # Output file (set by Invoke-adPEAS -Outputfile)
    $Script:adPEAS_Outputfile = $null
    $Script:HTMLOutputPath = $null
    $Script:JSONOutputPath = $null

    # ACE Inheritance source cache (parent ACL cache for Get-OUPermissions)
    $Script:InheritanceACLCache = $null

    # Exchange service group check cache (Test-IsExchangeServiceGroup)
    $Script:ExchangeGroupCache = $null

    # OU Permissions result cache (cross-module: DangerousOU, LAPS, PasswordReset)
    $Script:OUPermissionsCache = $null

    # Check module caches
    # The tables below are published per invocation by a check's begin{} block, not at
    # module load, so they are session state and belong here rather than being treated as
    # constant lookup tables.
    $Script:gpoAddComputerFindings = $null
    $Script:gpoAddComputerPrecedenceMap = $null
    $Script:gpoUserRightsSysvolScanned = $null
    $Script:LocalGroupSIDs = $null
    $Script:RiskySIDs = $null
    $Script:GroupSeverityConfig = $null
    $Script:RiskyPaths = $null
    $Script:_uncWriteAccess = $null
    $Script:DangerousGPOAccessRights = $null
    $Script:CriticalGPOAttributes = $null
    $Script:UnscopedGPORights = $null
    $Script:_gpoSysvolRows = $null
    $Script:_gpoSysvolUnread = $null
    $Script:_gpoSysvolScanned = $null
    $Script:_gpoSysvolMissing = $null
    $Script:_gpoSysvolOrphans = $null
    $Script:_gpoSysvolBroadWriters = $null

    $Script:LAPSSchemaInfo = $null
    $Script:CredentialAccountCache = $null
    $Script:PrivilegedAccountFilterCache = $null
    $Script:PrincipalContainerCache = $null
    $Script:PrincipalContainerCache = $null
    $Script:BitLockerSchemaInfo = $null
    $Script:lapsGPOResults = $null
    $Script:AllForeignMembers = $null
    $Script:PrivilegedGroupSIDs = $null
    $Script:PrivilegedGroupRIDs = $null
    $Script:DynamicPrivilegedGroups = $null
    $Script:FilterAccountExpired = $null

    # GPO caches (Get-DomainGPO and Get-GPOLinkage)
    $Script:CachedAllGPOs = $null
    $Script:CachedGPOLinkage = $null
    $Script:DomainControllerGPOContext = $null
    $Script:GPOSecurityFilterMap = $null
    $Script:GPOFilterPrincipalCache = $null
    # The WMI filter and loopback mode of each policy (Get-GPOWmiFilter,
    # Get-GPOLoopbackMode). Per domain, like the security filters above.
    $Script:GPOWmiFilterMap = $null
    $Script:GPOLoopbackMap = $null

    # Kerberoast run state (Invoke-Kerberoast)
    # KerberoastCredParams is a splat table that carries the PSCredential the caller
    # passed - built in begin{}, never torn down. It outlived the session it belonged to,
    # so a disconnect left the credential sitting in session state.
    $Script:KerberoastCredParams = $null
    $Script:UseInMemoryMethod = $null

    # Progress throttling state (Show-Progress)
    $Script:LastProgressUpdate = $null

    # Collector metadata (Invoke-adPEASCollector)
    $Script:CollectorVersion = $null
    $Script:JsonVersion = $null
    $Script:CollectionTimestamp = $null
    $Script:CollectedParts = $null
    $Script:ProgressPadWidth = $null
    $Script:CursorUp = $null
    $Script:CursorDown = $null
    $Script:WriteCollectionStatus = $null
}
