﻿function Get-PrivilegedGroupMembers {
    <#
    .SYNOPSIS
    Enumerates members of all privileged Active Directory groups with nested membership analysis.

    .DESCRIPTION
    This check identifies all members in privileged Active Directory groups including:
    - BUILTIN groups (Administrators, Account/Server/Print/Backup Operators, etc.)
    - Domain groups (Domain/Enterprise/Schema Admins, Group Policy Creator Owners, etc.)
    - Dynamic groups (DNS Admins)

    Features:
    - Distinguishes between direct members and nested group membership
    - Tracks nesting level and depth
    - Identifies high-risk nested groups (large membership)
    - Detects deep nesting (>3 levels)
    - Detects Foreign Security Principals (FSPs) from external domains/forests
    - Analyzes AdminSDHolder ACLs for unauthorized permissions
    - Reads the DACL of the privileged groups AdminSDHolder does not protect
      (Show-UnprotectedGroupACL)
    - Reads the DACL of the privileged users and managed service accounts
      (Show-PrivilegedAccountACL)
    - Checks Pre-Windows 2000 Compatible Access group for dangerous members

    .PARAMETER Domain
    Target domain (optional, uses current domain if not specified)

    .PARAMETER Server
    Domain Controller to query (optional, uses auto-discovery if not specified)

    .PARAMETER Credential
    PSCredential object for authentication (optional, uses current user if not specified)

    .EXAMPLE
    Get-PrivilegedGroupMembers

    .EXAMPLE
    Get-PrivilegedGroupMembers -Domain "contoso.com" -Credential (Get-Credential)

    .NOTES
    Category: Accounts
    Author: Alexander Sturz (@_61106960_)
    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$false)]
        [string]$Domain,

        [Parameter(Mandatory=$false)]
        [string]$Server,

        [Parameter(Mandatory=$false)]
        [System.Management.Automation.PSCredential]$Credential,

        [Parameter(Mandatory=$false)]
        [switch]$IncludePrivileged
    )

    begin {
        Write-Log "[Get-PrivilegedGroupMembers] Starting privileged group enumeration"

        # Built-in privileged groups (well-known SIDs)
        $Script:PrivilegedGroupSIDs = @{
            'S-1-5-32-544' = 'Administrators'
            'S-1-5-32-548' = 'Account Operators'
            'S-1-5-32-549' = 'Server Operators'
            'S-1-5-32-550' = 'Print Operators'
            'S-1-5-32-551' = 'Backup Operators'
            'S-1-5-32-578' = 'Hyper-V Administrators'
            'S-1-5-32-580' = 'Remote Management Users'
        }

        # Domain-specific privileged groups (RIDs)
        $Script:PrivilegedGroupRIDs = @{
            '512' = 'Domain Admins'
            '519' = 'Enterprise Admins'
            '518' = 'Schema Admins'
            '520' = 'Group Policy Creator Owners'
            '526' = 'Key Admins'
            '527' = 'Enterprise Key Admins'
            '517' = 'Cert Publishers'
        }

        # The three domain-controller groups, for the primaryGroupID query ONLY.
        #
        # -516, -521 and -498 are privileged: $Script:PrivilegedRIDSuffixes says so, and
        # $Script:DCSyncPrivilegedRIDSuffixes names -516 and -521 explicitly. This module
        # deliberately does not enumerate them, and that is right - every domain controller
        # is a member of -516, so listing the members would be pages of noise.
        #
        # The interesting case is the other one, and nothing in adPEAS looked for it: a
        # USER account whose primaryGroupID is 516 carries the Domain Controllers SID in its
        # token and therefore every access a DACL grants to domain controllers. It is in no
        # member attribute, it is not a computer, and it survives a review of group
        # memberships untouched.
        $Script:DCPrimaryGroupRIDs = @{
            '516' = 'Domain Controllers'
            '521' = 'Read-only Domain Controllers'
            '498' = 'Enterprise Read-only Domain Controllers'
        }

        # Dynamic groups (no fixed SID - resolve by name)
        #
        # ESX Admins: a VMware ESXi host joined to the domain makes every member of a domain
        # group of that name a full administrator, matched by name alone, so a group created
        # after the join counts as well (CVE-2024-37085). An administrator of the hypervisor
        # owns the virtual machines on it, domain controllers included. The group does not
        # exist by default; where it does, its members and who may change it are reported.
        $Script:DynamicPrivilegedGroups = @(
            'DnsAdmins'
            'ESX Admins'
        )
    }

    process {
        try {
            # Build connection parameters (exclude IncludePrivileged which is not a connection parameter)
            $connectionParams = @{}
            if ($Domain) { $connectionParams['Domain'] = $Domain }
            if ($Server) { $connectionParams['Server'] = $Server }
            if ($Credential) { $connectionParams['Credential'] = $Credential }

            # Ensure LDAP connection (displays error if needed)
            if (-not (Ensure-LDAPConnection @connectionParams)) {
                # Return without output to avoid redundant error display
                return
            }

            $AllGroupData = @()
            $TotalUniqueMembers = @{}
            $MembershipPaths = @{}  # Track all paths per member DN
            $Script:AllForeignMembers = @()
            $DomainSID = $Script:LDAPContext.DomainSID
            $domainDN = $Script:LDAPContext.DomainDN

            # ===== Helper Function: Filter GC multi-domain results =====
            # GC port 3268 can return objects from multiple domain partitions
            # (e.g. BUILTIN groups exist in every domain, DnsAdmins by name in parent+child)
            # Always pick only the group from the current domain.
            function Select-LocalDomainGroup {
                param([object]$GroupResult)

                $groups = @($GroupResult)
                if ($groups.Count -le 1) { return $groups | Select-Object -First 1 }

                # Filter to current domain
                if ($domainDN) {
                    $local = $groups | Where-Object { $_.distinguishedName -like "*,$domainDN" }
                    if ($local) {
                        Write-Log "[Get-PrivilegedGroupMembers] GC returned $($groups.Count) results - filtered to current domain"
                        return $local | Select-Object -First 1
                    }
                }

                # Fallback: first result
                Write-Log "[Get-PrivilegedGroupMembers] GC returned $($groups.Count) results - using first"
                return $groups | Select-Object -First 1
            }

            # ===== Helper Function: Recursive Group Member Resolution =====
            function Get-GroupMembersRecursive {
                param(
                    [string]$GroupDN,
                    [string]$GroupName,
                    [int]$NestingLevel = 0,
                    [hashtable]$Visited = @{},
                    [hashtable]$CredentialParams = @{},
                    [string]$MembershipPath = "Direct Member",
                    [object]$GroupObject = $null  # Pass already-fetched group to avoid duplicate query
                )

                # Prevent infinite loops
                # The guard has to describe the current PATH, not everything visited so far. $Visited is
    # a hashtable and goes into every branch by reference: if group A contains both B and C
    # and both contain D, then D is expanded under B, and under C the entry is already there
    # - so the second branch stops with "circular reference detected" on a group that is not
    # a cycle at all. TotalMemberCount per group then undercounts, and the second route by
    # which an account is a Domain Admin is missing from the display, which is the one thing
    # the "how do I get to Domain Admin" section is for. The entry is removed again on the
    # way out, below.
    if ($Visited.ContainsKey($GroupDN)) {
                    Write-Log "[Get-PrivilegedGroupMembers] Circular reference detected: $GroupDN"
                    return @{
                        DirectMembers = @()
                        NestedGroups = @()
                    }
                }
                $Visited[$GroupDN] = $true

                $DirectMembers = @()
                $NestedGroups = @()

                try {
                    # Use passed group object if available, otherwise fetch it
                    $Group = $GroupObject
                    if (-not $Group) {
                        $Group = @(Get-DomainGroup -Identity $GroupDN @CredentialParams)[0]
                        Write-Log "[Get-PrivilegedGroupMembers] Fetched nested group: $GroupName (DN: $GroupDN)"
                    } else {
                        Write-Log "[Get-PrivilegedGroupMembers] Using pre-fetched group: $GroupName (DN: $GroupDN)"
                    }

                    if (-not $Group) {
                        Write-Log "[Get-PrivilegedGroupMembers] WARNING: Group not found by DN: $GroupDN"
                        return @{ DirectMembers = @(); NestedGroups = @() }
                    }

                    $memberAttr = $Group.member
                    $memberCount = if ($memberAttr) { @($memberAttr).Count } else { 0 }
                    Write-Log "[Get-PrivilegedGroupMembers] Group found: True, Member count: $memberCount"

                    if ($memberAttr) {
                        $MemberDNs = @($Group.member)
                        Write-Log "[Get-PrivilegedGroupMembers] Group '$GroupName' has $($MemberDNs.Count) direct members (Nesting Level: $NestingLevel)"

                        foreach ($MemberDN in $MemberDNs) {
                            # Skip empty/null member DNs (can occur with GC multi-domain results)
                            if ([string]::IsNullOrWhiteSpace($MemberDN)) { continue }

                            # Get member object using Get-DomainObject
                            $Member = @(Get-DomainObject -Identity $MemberDN @CredentialParams)[0]

                            # Cross-domain member resolution: If member not found locally and DN belongs
                            # to a different domain (e.g. parent domain user in child domain group),
                            # try resolving via Global Catalog (port 3268/3269)
                            if (-not $Member -and $domainDN -and -not $MemberDN.EndsWith(",$domainDN")) {
                                Write-Log "[Get-PrivilegedGroupMembers] Cross-domain member detected: $MemberDN - trying GC lookup"
                                try {
                                    $gcConn = Get-GCConnection
                                    if ($gcConn) {
                                        # Use Invoke-LDAPSearch with GC connection for full attribute conversion.
                                        # Escape the member DN (may contain '(' ')' '\,' - e.g. "CN=Doe\, Jane (Contractor),...").
                                        $escapedMemberDN = Escape-LDAPFilterDN -DistinguishedName $MemberDN
                                        $Member = @(Invoke-LDAPSearch -Filter "(&(objectClass=*)(distinguishedName=$escapedMemberDN))" -SizeLimit 1 -LdapConnection $gcConn)[0]
                                        if ($Member) {
                                            Write-Log "[Get-PrivilegedGroupMembers] GC resolved cross-domain member: $($Member.distinguishedName)"
                                        }
                                    }
                                } catch {
                                    Write-Log "[Get-PrivilegedGroupMembers] GC lookup failed for $MemberDN : $_"
                                }
                            }

                            if ($Member) {
                                # Check if member is a group
                                if ($Member.objectClass -icontains "group") {
                                    # Nested group - recurse with updated path
                                    $NewPath = if ($MembershipPath -eq "Direct Member") {
                                        "via $($Member.sAMAccountName)"
                                    } else {
                                        "$MembershipPath -> $($Member.sAMAccountName)"
                                    }

                                    # Pass GC-resolved group object for cross-domain groups to avoid
                                    # local partition lookup failure in recursion
                                    $nestedGroupObj = $null
                                    if ($domainDN -and -not $MemberDN.EndsWith(",$domainDN")) {
                                        $nestedGroupObj = $Member  # GC-resolved object with member attribute
                                    }

                                    $NestedResult = Get-GroupMembersRecursive `
                                        -GroupDN $Member.distinguishedName `
                                        -GroupName $Member.sAMAccountName `
                                        -NestingLevel ($NestingLevel + 1) `
                                        -Visited $Visited `
                                        -CredentialParams $CredentialParams `
                                        -MembershipPath $NewPath `
                                        -GroupObject $nestedGroupObj

                                    # Calculate total member count from nested groups
                                    $NestedTotalCount = $NestedResult.DirectMembers.Count +
                                                        ($NestedResult.NestedGroups | Measure-Object -Property TotalMembers -Sum).Sum

                                    $NestedGroups += [PSCustomObject]@{
                                        GroupName = $Member.sAMAccountName
                                        DistinguishedName = $Member.distinguishedName
                                        NestingLevel = $NestingLevel + 1
                                        DirectMembers = $NestedResult.DirectMembers
                                        NestedGroups = $NestedResult.NestedGroups
                                        TotalMembers = $NestedTotalCount
                                    }
                                } else {
                                    # Direct member (user/computer/FSP)
                                    $IsForeignSecurityPrincipal = $Member.objectClass -icontains 'foreignSecurityPrincipal'

                                    if ($IsForeignSecurityPrincipal) {
                                        # Foreign Security Principal - extract SID from CN
                                        $MemberSID = $null
                                        if ($Member.distinguishedName -match '^CN=([^,]+)') {
                                            $MemberSID = $matches[1]
                                        }

                                        # Resolve SID to account name using central function
                                        $ResolvedName = if ($MemberSID) {
                                            ConvertFrom-SID -SID $MemberSID
                                        } else {
                                            "[FOREIGN - Unknown]"
                                        }

                                        # Check if resolution was successful (not same as SID)
                                        $ResolutionSuccessful = ($ResolvedName -ne $MemberSID)

                                        $MemberInfo = [PSCustomObject]@{
                                            Name = $ResolvedName
                                            SAMAccountName = if ($ResolutionSuccessful) { $ResolvedName.Split('\')[1] } else { "[FOREIGN]" }
                                            ObjectClass = "foreignSecurityPrincipal"
                                            DistinguishedName = $Member.distinguishedName
                                            SID = $MemberSID
                                            ResolvedName = if ($ResolutionSuccessful) { $ResolvedName } else { $null }
                                            NestingLevel = $NestingLevel
                                            IsForeign = $true
                                            MembershipPath = $MembershipPath
                                        }
                                    } else {
                                        # Regular member - determine object type from objectClass array
                                        # Priority: gMSA/sMSA/dMSA > computer > user (most specific first)
                                        $objectClassArray = @($Member.objectClass)
                                        $detectedClass = 'user'  # Default fallback

                                        if ($objectClassArray -icontains 'msDS-GroupManagedServiceAccount') {
                                            $detectedClass = 'msDS-GroupManagedServiceAccount'
                                        }
                                        elseif ($objectClassArray -icontains 'msDS-ManagedServiceAccount') {
                                            $detectedClass = 'msDS-ManagedServiceAccount'
                                        }
                                        # A delegated managed service account derives from
                                        # computer directly. Filed as a computer, it was
                                        # counted as one and left out of the account ACL
                                        # review, where msDS-GroupMSAMembership decides who
                                        # may use it.
                                        elseif ($objectClassArray -icontains 'msDS-DelegatedManagedServiceAccount') {
                                            $detectedClass = 'msDS-DelegatedManagedServiceAccount'
                                        }
                                        elseif ($objectClassArray -icontains 'computer') {
                                            $detectedClass = 'computer'
                                        }
                                        elseif ($objectClassArray -icontains 'user') {
                                            $detectedClass = 'user'
                                        }

                                        # Detect cross-domain members (resolved via GC, DN not in current domain)
                                        $isCrossDomain = ($domainDN -and -not $MemberDN.EndsWith(",$domainDN"))

                                        $MemberInfo = [PSCustomObject]@{
                                            Name = $Member.name
                                            SAMAccountName = $Member.sAMAccountName
                                            ObjectClass = $detectedClass
                                            DistinguishedName = $Member.distinguishedName
                                            SID = $Member.objectSid
                                            NestingLevel = $NestingLevel
                                            IsForeign = $false
                                            IsCrossDomain = $isCrossDomain
                                            GCObject = if ($isCrossDomain) { $Member } else { $null }
                                            MembershipPath = $MembershipPath
                                        }
                                    }

                                    $DirectMembers += $MemberInfo

                                    # Track foreign members for summary
                                    if ($IsForeignSecurityPrincipal) {
                                        $Script:AllForeignMembers += [PSCustomObject]@{
                                            SID = $MemberSID
                                            ResolvedName = $MemberInfo.ResolvedName
                                            PrivilegedGroup = $GroupName
                                            NestingLevel = $NestingLevel
                                        }
                                    }
                                }
                            }
                        }
                    }
                } catch {
                    Write-Log "[Get-PrivilegedGroupMembers] Error resolving members for $GroupDN : $_"
                } finally {
                    # Out of this branch again, so $Visited describes the current path rather
                    # than everything the walk has seen. A real cycle is still caught: an
                    # ancestor of this group is still in the table while we are below it.
                    #
                    # Not memoised on purpose. A group reachable by two routes is expanded
                    # twice now, and the result cannot simply be cached per DN because
                    # NestingLevel and MembershipPath are baked into the objects it returns -
                    # a cache would hand the second route the first route's path, which is
                    # the very thing this fix is about.
                    [void]$Visited.Remove($GroupDN)
                }

                return @{
                    DirectMembers = $DirectMembers
                    NestedGroups = $NestedGroups
                }
            }

            # ===== Helper Function: Collect ALL members including from nested groups =====
            function Get-AllMembersFromResult {
                param(
                    [Parameter(Mandatory)]
                    $Result
                )

                $AllMembers = @()

                # Add direct members
                if ($Result.DirectMembers) {
                    $AllMembers += @($Result.DirectMembers)
                }

                # Recursively add members from nested groups
                if ($Result.NestedGroups) {
                    foreach ($NestedGroup in $Result.NestedGroups) {
                        # Each nested group has DirectMembers and NestedGroups properties
                        if ($NestedGroup.DirectMembers) {
                            $AllMembers += @($NestedGroup.DirectMembers)
                        }
                        if ($NestedGroup.NestedGroups) {
                            # Recurse into deeper nested groups
                            $AllMembers += Get-AllMembersFromResult -Result $NestedGroup
                        }
                    }
                }

                return $AllMembers
            }

            # ===== The groups whose own DACL step 5b reads =====
            # Every privileged group the steps below find, and every group nested into one of
            # them - a nested group passes its membership on, so the right to add a member to
            # it is the right to add one to the group above. Only this domain's partition: the
            # descriptor of a group in another domain is not read over this connection.
            #
            # Roots: the SID of every privileged group a group was reached from, one entry per
            # path ('' where the caller passed none). dsHeuristics can take operator groups out
            # of AdminSDHolder protection, and a group reached only through those is not
            # protected any more, whatever its adminCount says - step 5b needs the paths to
            # tell.
            #
            # Weight: what taking the group over is worth, from the privileged group it was
            # reached from - Get-GroupTakeoverWeight. A nested group carries the weight of the
            # group above it, and of the heaviest one where several paths lead to it.
            $GroupsForACLReview = [ordered]@{}
            function Add-GroupForACLReview {
                param(
                    [string]$DistinguishedName,
                    [string]$Name,
                    [string]$Source,
                    $NestedGroups,
                    [string]$RootSID,
                    [string]$Weight
                )
                if ([string]::IsNullOrWhiteSpace($DistinguishedName)) { return }
                if ($domainDN -and -not $DistinguishedName.EndsWith(",$domainDN", [System.StringComparison]::OrdinalIgnoreCase)) { return }
                if (-not $GroupsForACLReview.Contains($DistinguishedName)) {
                    $GroupsForACLReview[$DistinguishedName] = [PSCustomObject]@{
                        DistinguishedName = $DistinguishedName
                        Name              = $Name
                        Source            = $Source
                        Roots             = New-Object System.Collections.Generic.List[string]
                        Weight            = $Weight
                    }
                } elseif ($Weight -eq 'Finding') {
                    $GroupsForACLReview[$DistinguishedName].Weight = 'Finding'
                }
                $GroupsForACLReview[$DistinguishedName].Roots.Add([string]$RootSID)
                foreach ($nestedGroup in @($NestedGroups)) {
                    if (-not $nestedGroup) { continue }
                    Add-GroupForACLReview -DistinguishedName $nestedGroup.DistinguishedName -Name $nestedGroup.GroupName `
                        -Source "nested in $Name" -NestedGroups $nestedGroup.NestedGroups -RootSID $RootSID -Weight $Weight
                }
            }

            # Members of Account Operators, for step 5b: the group class gives Account
            # Operators full control over every group AdminSDHolder does not protect, and
            # whether that matters today depends on whether anybody is in it. $null = the
            # group was not found.
            $accountOperatorMembers = $null

            # ===== STEP 1: Query Domain-Specific Privileged Groups =====
            Show-SubHeader "Поиск участников привилегированных групп..." -ObjectType "PrivilegedGroupMember"

            # Build credential params for recursive calls (only relevant params)
            $CredParams = @{}
            if ($PSBoundParameters.ContainsKey('Domain')) { $CredParams['Domain'] = $Domain }
            if ($PSBoundParameters.ContainsKey('Server')) { $CredParams['Server'] = $Server }
            if ($PSBoundParameters.ContainsKey('Credential')) { $CredParams['Credential'] = $Credential }

            # ===== Primary group members, which "member" does not list =====
            #
            # An account whose primaryGroupID is 512 is a Domain Admin - the RID is in its
            # token - but Active Directory does not write that relation into the group's
            # member attribute, and the account carries no memberOf pointing back. The
            # recursion below walks member, so it cannot see these accounts at all, and
            # setting the primary group is a known way to hold privilege out of sight of
            # exactly that kind of enumeration.
            #
            # One query for every privileged group rather than one per group: the RIDs are
            # known and primaryGroupID is indexed. 513 for a user and 515 for a computer are
            # the defaults, and neither is a privileged RID, so nothing ordinary matches.
            $PrimaryGroupMembers = @{}
            # DN -> group name, for the display further down. "(direct)" would be true but
            # misleading: you do not remove such an account from the group, because it is
            # not in the member attribute - you change its primaryGroupID.
            $PrimaryGroupOf = @{}
            try {
                $primaryClauses = ($Script:PrivilegedGroupRIDs.Keys | ForEach-Object { "(primaryGroupID=$_)" }) -join ''
                $primaryFilter = "(|$primaryClauses)"

                foreach ($account in @(Get-DomainObject -LDAPFilter $primaryFilter -Properties 'distinguishedName', 'sAMAccountName', 'name', 'objectSid', 'objectClass', 'primaryGroupID' @CredParams)) {
                    $accountRID = "$($account.primaryGroupID)"
                    if (-not $PrimaryGroupMembers.ContainsKey($accountRID)) {
                        $PrimaryGroupMembers[$accountRID] = @()
                    }
                    $PrimaryGroupMembers[$accountRID] += $account
                }

                $primaryTotal = ($PrimaryGroupMembers.Values | ForEach-Object { @($_).Count } | Measure-Object -Sum).Sum
                if (-not $primaryTotal) { $primaryTotal = 0 }
                Write-Log "[Get-PrivilegedGroupMembers] $primaryTotal account(s) hold a privileged group as their primary group"
            } catch {
                # Not fatal: the member-based enumeration below is the main path, and losing
                # this one costs coverage rather than the whole check.
                Write-Log "[Get-PrivilegedGroupMembers] Primary group query failed: $($_.Exception.Message)" -Level Warning
            }

            foreach ($RID in $Script:PrivilegedGroupRIDs.Keys) {
                try {
                    $GroupSID = "$DomainSID-$RID"
                    $GroupNameEN = $Script:PrivilegedGroupRIDs[$RID]

                    Write-Log "[Get-PrivilegedGroupMembers] Checking group: $GroupNameEN (SID: $GroupSID)"

                    # Find group by SID using Get-DomainGroup
                    $Group = Select-LocalDomainGroup (Get-DomainGroup -Identity $GroupSID @CredParams)

                    if ($Group) {
                        # Use actual sAMAccountName from AD (localized, e.g. "Domaenen-Admins" in German)
                        $GroupName = $Group.sAMAccountName
                        Write-Log "[Get-PrivilegedGroupMembers] Found group: $GroupName ($($Group.distinguishedName))"

                        # Each top-level group gets its own Visited hashtable to avoid cross-contamination
                        # Pass the already-fetched group object to avoid duplicate LDAP query
                        $Result = Get-GroupMembersRecursive -GroupDN $Group.distinguishedName -GroupName $GroupName -CredentialParams $CredParams -Visited @{} -GroupObject $Group
                        Add-GroupForACLReview -DistinguishedName $Group.distinguishedName -Name $GroupName -Source 'privileged group' -NestedGroups $Result.NestedGroups -RootSID $GroupSID `
                            -Weight (Get-GroupTakeoverWeight -GroupSID $GroupSID)

                        # Fold in the accounts holding this group as their primary group.
                        # They are direct members in every sense that matters - the RID is in
                        # their token - and the path says "Primary group" rather than "Direct
                        # Member", because the latter would send a reader looking for them in
                        # an attribute that does not list them.
                        #
                        # Only this loop needs it: a primaryGroupID is a RID relative to the
                        # domain, so it can never point at a BUILTIN group, which is what the
                        # two loops below enumerate.
                        foreach ($primaryMember in @($PrimaryGroupMembers["$RID"])) {
                            if (-not $primaryMember) { continue }

                            $primaryDN = if ($primaryMember.distinguishedName -is [array]) {
                                $primaryMember.distinguishedName[0]
                            } else {
                                $primaryMember.distinguishedName
                            }

                            # An account can hold the group as its primary group and be listed
                            # in member as well. Counting it twice would inflate the group and
                            # print the account twice.
                            if (@($Result.DirectMembers | ForEach-Object { $_.DistinguishedName }) -contains $primaryDN) {
                                Write-Log "[Get-PrivilegedGroupMembers] $primaryDN is a listed and a primary-group member of $GroupName"
                                continue
                            }

                            $primaryClassArray = @($primaryMember.objectClass)
                            $primaryClass = 'user'
                            if ($primaryClassArray -icontains 'msDS-GroupManagedServiceAccount') {
                                $primaryClass = 'msDS-GroupManagedServiceAccount'
                            } elseif ($primaryClassArray -icontains 'msDS-ManagedServiceAccount') {
                                $primaryClass = 'msDS-ManagedServiceAccount'
                            } elseif ($primaryClassArray -icontains 'msDS-DelegatedManagedServiceAccount') {
                                $primaryClass = 'msDS-DelegatedManagedServiceAccount'
                            } elseif ($primaryClassArray -icontains 'computer') {
                                $primaryClass = 'computer'
                            }

                            $Result.DirectMembers += [PSCustomObject]@{
                                Name              = $primaryMember.name
                                SAMAccountName    = $primaryMember.sAMAccountName
                                ObjectClass       = $primaryClass
                                DistinguishedName = $primaryDN
                                SID               = $primaryMember.objectSid
                                NestingLevel      = 0
                                IsForeign         = $false
                                IsCrossDomain     = ($domainDN -and $primaryDN -and -not $primaryDN.EndsWith(",$domainDN"))
                                GCObject          = $null
                                MembershipPath    = 'Primary group'
                            }

                            $PrimaryGroupOf[$primaryDN] = $GroupName
                            Write-Log "[Get-PrivilegedGroupMembers] $GroupName - primary group member: $primaryDN"
                        }

                        $DirectMemberCount = @($Result.DirectMembers).Count
                        $NestedGroupCount = @($Result.NestedGroups).Count
                        $NestedSum = ($Result.NestedGroups | Measure-Object -Property TotalMembers -Sum).Sum
                        if ($null -eq $NestedSum) { $NestedSum = 0 }
                        $TotalMemberCount = $DirectMemberCount + $NestedSum

                        Write-Log "[Get-PrivilegedGroupMembers] $GroupName - Direct: $DirectMemberCount, Nested groups: $NestedGroupCount, Total: $TotalMemberCount"

                        # Track unique members and their paths (including nested group members)
                        $AllMembersFromGroup = Get-AllMembersFromResult -Result $Result
                        foreach ($Member in $AllMembersFromGroup) {
                            $TotalUniqueMembers[$Member.DistinguishedName] = $Member

                            # Track membership path for this group
                            if (-not $MembershipPaths.ContainsKey($Member.DistinguishedName)) {
                                $MembershipPaths[$Member.DistinguishedName] = @()
                            }
                            if ($Member.MembershipPath -notin $MembershipPaths[$Member.DistinguishedName]) {
                                $MembershipPaths[$Member.DistinguishedName] += $Member.MembershipPath
                            }
                        }

                        # Add group data if it has any members (direct or nested)
                        if ($TotalMemberCount -gt 0) {
                            $AllGroupData += [PSCustomObject]@{
                                GroupName = $GroupName
                                GroupSID = $GroupSID
                                GroupType = "Domain"
                                DirectMemberCount = $DirectMemberCount
                                NestedGroupCount = $NestedGroupCount
                                TotalMemberCount = $TotalMemberCount
                                DirectMembers = $Result.DirectMembers
                                NestedGroups = $Result.NestedGroups
                            }
                        }
                    } else {
                        Write-Log "[Get-PrivilegedGroupMembers] Group not found: $GroupNameEN (SID: $GroupSID)"
                    }
                } catch {
                    Write-Warning "[Get-PrivilegedGroupMembers] Error checking group $GroupNameEN : $_"
                }
            }

            # ===== STEP 2: Query Built-in Privileged Groups =====
            foreach ($SID in $Script:PrivilegedGroupSIDs.Keys) {
                try {
                    $GroupNameEN = $Script:PrivilegedGroupSIDs[$SID]
                    Write-Log "[Get-PrivilegedGroupMembers] Checking built-in group: $GroupNameEN (SID: $SID)"

                    $Group = Select-LocalDomainGroup (Get-DomainGroup -Identity $SID @CredParams)

                    if ($Group) {
                        # Use actual sAMAccountName from AD (localized, e.g. "Administratoren" in German)
                        $GroupName = $Group.sAMAccountName
                        Write-Log "[Get-PrivilegedGroupMembers] Found built-in group: $GroupName ($($Group.distinguishedName))"

                        # Each top-level group gets its own Visited hashtable to avoid cross-contamination
                        # Pass the already-fetched group object to avoid duplicate LDAP query
                        $Result = Get-GroupMembersRecursive -GroupDN $Group.distinguishedName -GroupName $GroupName -CredentialParams $CredParams -Visited @{} -GroupObject $Group
                        Add-GroupForACLReview -DistinguishedName $Group.distinguishedName -Name $GroupName -Source 'privileged group' -NestedGroups $Result.NestedGroups -RootSID $SID `
                            -Weight (Get-GroupTakeoverWeight -GroupSID $SID)

                        $DirectMemberCount = @($Result.DirectMembers).Count
                        $NestedGroupCount = @($Result.NestedGroups).Count
                        $NestedSum = ($Result.NestedGroups | Measure-Object -Property TotalMembers -Sum).Sum
                        if ($null -eq $NestedSum) { $NestedSum = 0 }
                        $TotalMemberCount = $DirectMemberCount + $NestedSum
                        if ($SID -eq 'S-1-5-32-548') { $accountOperatorMembers = $TotalMemberCount }

                        Write-Log "[Get-PrivilegedGroupMembers] $GroupName - Direct: $DirectMemberCount, Nested groups: $NestedGroupCount, Total: $TotalMemberCount"

                        # Track unique members and their paths (including nested group members)
                        $AllMembersFromGroup = Get-AllMembersFromResult -Result $Result
                        foreach ($Member in $AllMembersFromGroup) {
                            $TotalUniqueMembers[$Member.DistinguishedName] = $Member

                            # Track membership path for this group
                            if (-not $MembershipPaths.ContainsKey($Member.DistinguishedName)) {
                                $MembershipPaths[$Member.DistinguishedName] = @()
                            }
                            if ($Member.MembershipPath -notin $MembershipPaths[$Member.DistinguishedName]) {
                                $MembershipPaths[$Member.DistinguishedName] += $Member.MembershipPath
                            }
                        }

                        if ($TotalMemberCount -gt 0) {
                            $AllGroupData += [PSCustomObject]@{
                                GroupName = $GroupName
                                GroupSID = $SID
                                GroupType = "BUILTIN"
                                DirectMemberCount = $DirectMemberCount
                                NestedGroupCount = $NestedGroupCount
                                TotalMemberCount = $TotalMemberCount
                                DirectMembers = $Result.DirectMembers
                                NestedGroups = $Result.NestedGroups
                            }
                        }
                    } else {
                        Write-Log "[Get-PrivilegedGroupMembers] Built-in group not found: $GroupNameEN (SID: $SID)"
                    }
                } catch {
                    Write-Warning "[Get-PrivilegedGroupMembers] Error checking built-in group $GroupNameEN : $_"
                }
            }

            # ===== STEP 3: Query Dynamic Privileged Groups =====
            $domainDN = $Script:LDAPContext.DomainDN
            foreach ($GroupNameDynamic in $Script:DynamicPrivilegedGroups) {
                try {
                    Write-Log "[Get-PrivilegedGroupMembers] Checking dynamic group: $GroupNameDynamic"

                    $Group = Select-LocalDomainGroup (Get-DomainGroup -Identity $GroupNameDynamic @CredParams)

                    if ($Group) {
                        # Use actual sAMAccountName from AD (dynamic groups may have localized names)
                        $GroupName = $Group.sAMAccountName
                        Write-Log "[Get-PrivilegedGroupMembers] Found dynamic group: $GroupName ($($Group.distinguishedName))"

                        # Each top-level group gets its own Visited hashtable to avoid cross-contamination
                        # Pass the already-fetched group object to avoid duplicate LDAP query
                        $Result = Get-GroupMembersRecursive -GroupDN $Group.distinguishedName -GroupName $GroupName -CredentialParams $CredParams -Visited @{} -GroupObject $Group
                        # DnsAdmins run code as SYSTEM on the domain controllers, ESX Admins own
                        # the hypervisor and the domain controllers on it: the domain's weight.
                        Add-GroupForACLReview -DistinguishedName $Group.distinguishedName -Name $GroupName -Source 'privileged group' -NestedGroups $Result.NestedGroups -Weight 'Finding'

                        $DirectMemberCount = @($Result.DirectMembers).Count
                        $NestedGroupCount = @($Result.NestedGroups).Count
                        $NestedSum = ($Result.NestedGroups | Measure-Object -Property TotalMembers -Sum).Sum
                        if ($null -eq $NestedSum) { $NestedSum = 0 }
                        $TotalMemberCount = $DirectMemberCount + $NestedSum

                        Write-Log "[Get-PrivilegedGroupMembers] $GroupName - Direct: $DirectMemberCount, Nested groups: $NestedGroupCount, Total: $TotalMemberCount"

                        # Track unique members and their paths (including nested group members)
                        $AllMembersFromGroup = Get-AllMembersFromResult -Result $Result
                        foreach ($Member in $AllMembersFromGroup) {
                            $TotalUniqueMembers[$Member.DistinguishedName] = $Member

                            # Track membership path for this group
                            if (-not $MembershipPaths.ContainsKey($Member.DistinguishedName)) {
                                $MembershipPaths[$Member.DistinguishedName] = @()
                            }
                            if ($Member.MembershipPath -notin $MembershipPaths[$Member.DistinguishedName]) {
                                $MembershipPaths[$Member.DistinguishedName] += $Member.MembershipPath
                            }
                        }

                        if ($TotalMemberCount -gt 0) {
                            $AllGroupData += [PSCustomObject]@{
                                GroupName = $GroupName
                                GroupSID = $Group.objectSid
                                GroupType = "Dynamic"
                                DirectMemberCount = $DirectMemberCount
                                NestedGroupCount = $NestedGroupCount
                                TotalMemberCount = $TotalMemberCount
                                DirectMembers = $Result.DirectMembers
                                NestedGroups = $Result.NestedGroups
                            }
                        }
                    } else {
                        Write-Log "[Get-PrivilegedGroupMembers] Dynamic group not found: $GroupNameDynamic"
                    }
                } catch {
                    Write-Warning "[Get-PrivilegedGroupMembers] Error checking dynamic group $GroupNameDynamic : $_"
                }
            }

            # The Exchange groups, for step 5b only. Their members are Get-ExchangeInfrastructure's
            # to report; their own DACL is nobody's, and AdminSDHolder does not protect them.
            # Exchange creates them with fixed English names in one OU, so a group is taken only
            # from there - a group of the same name elsewhere is not one of them.
            foreach ($exchangeGroupName in @('Organization Management', 'Exchange Trusted Subsystem', 'Exchange Windows Permissions')) {
                try {
                    $exchangeGroup = Select-LocalDomainGroup (Get-DomainGroup -Identity $exchangeGroupName @CredParams)
                    if ($exchangeGroup -and [string]$exchangeGroup.distinguishedName -match ',OU=Microsoft Exchange Security Groups,') {
                        # They hold rights on the domain object - the domain's weight.
                        Add-GroupForACLReview -DistinguishedName $exchangeGroup.distinguishedName -Name $exchangeGroup.sAMAccountName -Source 'Exchange group' -Weight 'Finding'
                    }
                } catch {
                    Write-Log "[Get-PrivilegedGroupMembers] Lookup of $exchangeGroupName failed: $_"
                }
            }

            # ===== STEP 4: Build User-Centric View =====
            $TotalGroups = $AllGroupData.Count
            $TotalMembers = $TotalUniqueMembers.Count

            # Count by type for accurate summary message
            $UserCount = 0
            $ComputerCount = 0
            $gMSACount = 0
            $dMSACount = 0
            # Foreign Security Principals get a count of their own. They used to be added to
            # $UserCount, so "Found 7 user(s) across 5 privileged group(s)" could mean six
            # users and one principal from a trusted domain - and if that principal names a
            # group over there, its members are not enumerated either. The number the
            # section opens with has to be a number the reader can trust.
            $ForeignCount = 0
            $totalMembers = @($TotalUniqueMembers.Values).Count
            $currentIndex = 0

            foreach ($memberData in $TotalUniqueMembers.Values) {
                $currentIndex++

                # Progress indicator for large member counts
                if ($totalMembers -gt $Script:ProgressThreshold) {
                    Show-Progress -Activity "Analyzing privileged members" -Current $currentIndex -Total $totalMembers -ObjectName $memberData.SAMAccountName
                }

                $objClass = $memberData.ObjectClass
                $samName = $memberData.SAMAccountName

                Write-Log "[Get-PrivilegedGroupMembers] Counting member: $samName, ObjectClass: '$objClass'"

                # gMSA and sMSA are service accounts (specific objectClass)
                if ($objClass -ieq 'msDS-GroupManagedServiceAccount' -or $objClass -ieq 'msDS-ManagedServiceAccount') {
                    $gMSACount++
                    Write-Log "[Get-PrivilegedGroupMembers]   -> Counted as gMSA"
                }
                elseif ($objClass -ieq 'msDS-DelegatedManagedServiceAccount') {
                    $dMSACount++
                    Write-Log "[Get-PrivilegedGroupMembers]   -> Counted as dMSA"
                }
                # Computer accounts (regular computers and DCs)
                elseif ($objClass -ieq 'computer') {
                    $ComputerCount++
                    Write-Log "[Get-PrivilegedGroupMembers]   -> Counted as Computer"
                }
                # A principal from a trusted domain or forest. Counted apart from the users:
                # adPEAS resolves the SID to a name but cannot read the object behind it, so
                # it does not know whether that SID names a user or a group over there - and
                # if it is a group, the members this report should have listed are on the
                # other side of the trust and were never enumerated.
                elseif ($objClass -ieq 'foreignSecurityPrincipal') {
                    $ForeignCount++
                    Write-Log "[Get-PrivilegedGroupMembers]   -> Counted as foreign principal"
                }
                # User accounts
                elseif ($objClass -ieq 'user') {
                    $UserCount++
                    Write-Log "[Get-PrivilegedGroupMembers]   -> Counted as User"
                }
                # Fallback: Check sAMAccountName for $ suffix (computer/gMSA indicator)
                elseif ($samName -and $samName.EndsWith('$')) {
                    # Could be computer or gMSA - check for gMSA pattern (often has specific naming)
                    $ComputerCount++
                    Write-Log "[Get-PrivilegedGroupMembers]   -> Counted as Computer ($ suffix fallback)"
                }
                else {
                    # Default to user for unknown types
                    $UserCount++
                    Write-Log "[Get-PrivilegedGroupMembers]   -> Counted as User (default fallback, class was: '$objClass')"
                }
            }

            # Clear progress bar
            if ($totalMembers -gt $Script:ProgressThreshold) {
                Show-Progress -Activity "Analyzing privileged members" -Completed
            }

            Write-Log "[Get-PrivilegedGroupMembers] Count summary: Users=$UserCount, gMSAs=$gMSACount, Computers=$ComputerCount, Foreign=$ForeignCount"

            Write-Log "[Get-PrivilegedGroupMembers] AllGroupData contains $TotalGroups groups:"
            foreach ($gd in $AllGroupData) {
                Write-Log "[Get-PrivilegedGroupMembers]   - $($gd.GroupName) (Type: $($gd.GroupType), Members: $($gd.TotalMemberCount))"
            }
            Write-Log "[Get-PrivilegedGroupMembers] TotalUniqueMembers: $TotalMembers"

            # Build per-member group membership tracking
            $MemberGroupMemberships = @{}  # DN -> @{ Groups = @(); DirectGroups = @(); NestedVia = @{} }

            foreach ($GroupData in $AllGroupData) {
                # Helper function to collect all members from nested groups recursively
                function Get-AllMembersWithPaths {
                    param($Members, $NestedGroups, $TopLevelGroup, $ParentPath = $null)

                    $AllMembers = @()

                    # Add direct members
                    foreach ($Member in $Members) {
                        $AllMembers += [PSCustomObject]@{
                            MemberDN = $Member.DistinguishedName
                            MemberInfo = $Member
                            TopLevelGroup = $TopLevelGroup
                            IsDirect = ($null -eq $ParentPath)
                            NestedVia = $ParentPath
                        }
                    }

                    # Recursively add members from nested groups
                    foreach ($NestedGroup in $NestedGroups) {
                        $NewPath = if ($null -eq $ParentPath) {
                            $NestedGroup.GroupName
                        } else {
                            "$ParentPath -> $($NestedGroup.GroupName)"
                        }

                        $NestedMembers = Get-AllMembersWithPaths -Members $NestedGroup.DirectMembers -NestedGroups $NestedGroup.NestedGroups -TopLevelGroup $TopLevelGroup -ParentPath $NewPath
                        $AllMembers += $NestedMembers
                    }

                    return $AllMembers
                }

                # Collect all members for this top-level group
                $AllMembersFlat = Get-AllMembersWithPaths -Members $GroupData.DirectMembers -NestedGroups $GroupData.NestedGroups -TopLevelGroup $GroupData.GroupName

                foreach ($Entry in $AllMembersFlat) {
                    $dn = $Entry.MemberDN
                    if (-not $MemberGroupMemberships.ContainsKey($dn)) {
                        $MemberGroupMemberships[$dn] = @{
                            MemberInfo = $Entry.MemberInfo
                            Groups = @()
                            DirectGroups = @()
                            NestedPaths = @{}
                        }
                    }

                    # Track group membership
                    if ($Entry.TopLevelGroup -notin $MemberGroupMemberships[$dn].Groups) {
                        $MemberGroupMemberships[$dn].Groups += $Entry.TopLevelGroup
                    }

                    if ($Entry.IsDirect) {
                        if ($Entry.TopLevelGroup -notin $MemberGroupMemberships[$dn].DirectGroups) {
                            $MemberGroupMemberships[$dn].DirectGroups += $Entry.TopLevelGroup
                        }
                    } else {
                        if (-not $MemberGroupMemberships[$dn].NestedPaths.ContainsKey($Entry.TopLevelGroup)) {
                            $MemberGroupMemberships[$dn].NestedPaths[$Entry.TopLevelGroup] = @()
                        }
                        if ($Entry.NestedVia -notin $MemberGroupMemberships[$dn].NestedPaths[$Entry.TopLevelGroup]) {
                            $MemberGroupMemberships[$dn].NestedPaths[$Entry.TopLevelGroup] += $Entry.NestedVia
                        }
                    }
                }
            }

            # Show Found message BEFORE user data
            if ($TotalMembers -gt 0) {
                # Build summary message with accurate counts by type
                $summaryParts = @()
                if ($UserCount -gt 0) {
                    $summaryParts += "$UserCount пользователей"
                }
                if ($gMSACount -gt 0) {
                    $summaryParts += "$gMSACount записей gMSA"
                }
                if ($dMSACount -gt 0) {
                    $summaryParts += "$dMSACount записей dMSA"
                }
                if ($ComputerCount -gt 0) {
                    $summaryParts += "$ComputerCount компьютеров"
                }
                if ($ForeignCount -gt 0) {
                    $summaryParts += "$ForeignCount внешних субъектов"
                }
                $summaryText = $summaryParts -join ", "
                Show-Line "Обнаружены участники привилегированных групп: $summaryText; проверено групп: $TotalGroups" -Class Finding
            }

            # What those foreign principals are, said once. $Script:AllForeignMembers was
            # filled in the recursion under the comment "Track foreign members for summary"
            # and then read nowhere - the summary it was collected for did not exist. A SID
            # from across a trust can name a group as easily as a user, and in that case the
            # members this section is about are on the other side and were not enumerated.
            # Grouped by SID, not one row per collected entry. The recursion appends to
            # $Script:AllForeignMembers once per path it reaches the principal on, so a
            # principal that is a member of two privileged groups - or of one group through
            # two routes - was in there twice, and the count above it said two where
            # $ForeignCount, which counts unique members, said one. One line per principal,
            # naming every group it reaches.
            if (@($Script:AllForeignMembers).Count -gt 0) {
                $foreignBySID = @{}
                foreach ($foreign in $Script:AllForeignMembers) {
                    $foreignSID = [string]$foreign.SID
                    if (-not $foreignSID) { continue }
                    if (-not $foreignBySID.ContainsKey($foreignSID)) {
                        $foreignName = [string]$foreign.ResolvedName
                        if (-not $foreignName) { $foreignName = $foreignSID }
                        $foreignBySID[$foreignSID] = [PSCustomObject]@{
                            Name   = $foreignName
                            Groups = @()
                        }
                    }
                    $foreignGroup = [string]$foreign.PrivilegedGroup
                    if ($foreignGroup -and $foreignBySID[$foreignSID].Groups -notcontains $foreignGroup) {
                        $foreignBySID[$foreignSID].Groups += $foreignGroup
                    }
                }

                if ($foreignBySID.Count -gt 0) {
                    Show-Line "Участников из доверенного домена: $($foreignBySID.Count). adPEAS не может прочитать объекты по этим SID, поэтому группы из другого домена не раскрыты:" -Class Hint
                    foreach ($foreignSID in ($foreignBySID.Keys | Sort-Object)) {
                        $entry = $foreignBySID[$foreignSID]
                        Show-Line "  $($entry.Name) in $(@($entry.Groups) -join ', ')" -Class Hint
                    }
                }
            }

            # Output each unique member with full user object
            foreach ($dn in $MemberGroupMemberships.Keys) {
                $MemberData = $MemberGroupMemberships[$dn]
                $BasicInfo = $MemberData.MemberInfo

                # Get full user object for Show-Object
                $FullUserObject = $null

                if ($BasicInfo.IsForeign) {
                    # Foreign Security Principal - create display object
                    $FullUserObject = [PSCustomObject]@{
                        sAMAccountName = if ($BasicInfo.ResolvedName) { "[FOREIGN] $($BasicInfo.ResolvedName)" } else { "[FOREIGN] $($BasicInfo.SID)" }
                        distinguishedName = $BasicInfo.DistinguishedName
                        objectSid = $BasicInfo.SID
                        objectClass = "foreignSecurityPrincipal"
                    }
                } elseif ($BasicInfo.IsCrossDomain -and $BasicInfo.GCObject) {
                    # Cross-domain member resolved via GC - use GC object directly
                    # (local Get-DomainUser/Computer would fail because DN is in another partition)
                    $FullUserObject = $BasicInfo.GCObject
                    Write-Log "[Get-PrivilegedGroupMembers] Using GC-resolved object for cross-domain member: $($BasicInfo.SAMAccountName)"
                } else {
                    # Get full user/computer object with all attributes
                    $FullUserObject = @(Get-DomainUser -Identity $dn @CredParams)[0]

                    if (-not $FullUserObject) {
                        # Might be a computer - try Get-DomainComputer
                        $FullUserObject = @(Get-DomainComputer -Identity $dn @CredParams)[0]
                    }

                    if (-not $FullUserObject) {
                        # Might be a gMSA or other special account type - try Get-DomainObject
                        # gMSAs have objectClass=msDS-GroupManagedServiceAccount, not user/computer
                        $FullUserObject = @(Get-DomainObject -Identity $dn @CredParams)[0]
                    }

                    if (-not $FullUserObject) {
                        # Fallback to basic info
                        $FullUserObject = [PSCustomObject]@{
                            sAMAccountName = $BasicInfo.SAMAccountName
                            distinguishedName = $BasicInfo.DistinguishedName
                        }
                    }
                }

                # Remove memberOf from object to avoid duplication with privilegedGroups
                # The privilegedGroups property below shows the relevant group memberships
                if ($FullUserObject.PSObject.Properties['memberOf']) {
                    $FullUserObject.PSObject.Properties.Remove('memberOf')
                }

                # Build privilege groups with SID for tier classification
                # SID lookup directly from $AllGroupData (no separate hashtable needed)
                $GroupEntries = @()
                foreach ($grp in $MemberData.Groups) {
                    # Find SID from AllGroupData by group name
                    $grpData = $AllGroupData | Where-Object { $_.GroupName -eq $grp } | Select-Object -First 1
                    $grpSID = if ($grpData) { $grpData.GroupSID } else { $null }

                    $displayText = if ($PrimaryGroupOf[$dn] -eq $grp) {
                        # Not "(direct)": this account is not in the group's member
                        # attribute at all, and the fix is a different one.
                        "$grp (primary group)"
                    } elseif ($grp -in $MemberData.DirectGroups) {
                        "$grp (direct)"
                    } else {
                        $nestedPath = $MemberData.NestedPaths[$grp] -join ", "
                        "$grp (via $nestedPath)"
                    }
                    $GroupEntries += [PSCustomObject]@{
                        Name = $grp
                        SID = $grpSID
                        DisplayText = $displayText
                    }
                }
                # Add privilegedGroups as array property - Show-Object will format with proper alignment
                $FullUserObject | Add-Member -NotePropertyName 'privilegedGroups' -NotePropertyValue $GroupEntries -Force
                $FullUserObject | Add-Member -NotePropertyName '_adPEASObjectType' -NotePropertyValue 'PrivilegedGroupMember' -Force

                # Pass complete object to Show-Object (includes privilegedGroups)
                # Use -Class Hint: Privileged accounts are informational, not a finding per se
                # Individual problematic attributes (DONT_EXPIRE_PASSWORD, etc.) still show as Finding
                Show-Object $FullUserObject -Class Hint

                # Add blank line between accounts for readability
                Show-EmptyLine
            }

            # Show group summary if no members found
            if ($TotalMembers -eq 0) {
                Show-Line "Участники привилегированных групп не найдены" -Class Note
            }

            # ===== Accounts that are not computers but hold a DC group as primary =====
            #
            # Its own block rather than part of the enumeration above, because the groups
            # themselves stay out: -516 holds every domain controller and listing it would
            # bury everything else. What is asked here is the inverse - who holds one of
            # these as their PRIMARY group without being a computer.
            try {
                $dcPrimaryClauses = ($Script:DCPrimaryGroupRIDs.Keys | ForEach-Object { "(primaryGroupID=$_)" }) -join ''
                $dcPrimaryFilter = "(|$dcPrimaryClauses)"
                $dcPrimaryFindings = @()

                foreach ($dcAccount in @(Get-DomainObject -LDAPFilter $dcPrimaryFilter -Properties 'distinguishedName', 'sAMAccountName', 'name', 'objectSid', 'objectClass', 'primaryGroupID' @CredParams)) {
                    # A computer with primaryGroupID 516 is a domain controller doing what
                    # domain controllers do. Only the accounts that are not computers are a
                    # finding here - the class decides, not the name.
                    if (@($dcAccount.objectClass) -icontains 'computer') { continue }

                    $dcRID = "$($dcAccount.primaryGroupID)"
                    if (-not $Script:DCPrimaryGroupRIDs.ContainsKey($dcRID)) { continue }

                    $dcAccount | Add-Member -NotePropertyName 'primaryGroupIsDCGroup' -NotePropertyValue (
                        "$($Script:DCPrimaryGroupRIDs[$dcRID]) (RID $dcRID)") -Force
                    $dcAccount | Add-Member -NotePropertyName '_adPEASObjectType' -NotePropertyValue 'PrivilegedGroupMember' -Force
                    $dcPrimaryFindings += $dcAccount
                }

                if (@($dcPrimaryFindings).Count -gt 0) {
                    Show-Line "Учётных записей, не являющихся компьютерами, у которых первичная группа принадлежит к группам контроллеров домена: $(@($dcPrimaryFindings).Count)" -Class Finding
                    foreach ($dcFinding in $dcPrimaryFindings) {
                        Show-Object $dcFinding -Class Finding
                    }
                }
            } catch {
                # Coverage, not a reason to lose the rest of the check.
                Write-Log "[Get-PrivilegedGroupMembers] Primary-group query for the DC groups failed: $($_.Exception.Message)" -Level Warning
            }

            # ===== STEP 5: Check AdminSDHolder ACLs =====
            Show-SubHeader "Проверка списков управления доступом объекта AdminSDHolder..." -ObjectType "AdminSDHolderACL"

            $AdminSDHolderFindings = @()
            # The template's rules, for step 5c; $null while it could not be read.
            $AdminSDHolderRules = $null
            $DomainDN = $Script:LDAPContext.DomainDN
            $AdminSDHolderDN = "CN=AdminSDHolder,CN=System,$DomainDN"

            try {
                # Use auth-agnostic LDAP pipeline (works with Kerberos PTT, SimpleBind, etc.)
                $AdminSDHolderObj = @(Get-DomainObject -Identity $AdminSDHolderDN -Properties 'nTSecurityDescriptor' -Raw @connectionParams)[0]
                if (-not $AdminSDHolderObj -or -not $AdminSDHolderObj.nTSecurityDescriptor) {
                    Write-Log "[Get-PrivilegedGroupMembers] Could not retrieve AdminSDHolder security descriptor" -Level Error
                    throw "AdminSDHolder security descriptor not available"
                }

                $sdBytes = $AdminSDHolderObj.nTSecurityDescriptor
                $SecurityDescriptor = New-Object System.DirectoryServices.ActiveDirectorySecurity
                $SecurityDescriptor.SetSecurityDescriptorBinaryForm($sdBytes)

                if ($SecurityDescriptor) {
                    # Uses central privileged check from Test-IsPrivileged.ps1

                    # The dangerous rights of each trustee, gathered over all of its ACEs
                    $trusteeRights = [ordered]@{}

                    # GetAccessRules with SecurityIdentifier, not .Access. .Access asks for
                    # the rules as NTAccount, which makes the local machine name-resolve
                    # every SID and silently drops the ones it cannot. Against a domain
                    # this host is not joined to that is every domain principal, so the
                    # AdminSDHolder DACL came back holding only built-in identities - and
                    # a dangerous ACE on AdminSDHolder is a persistence mechanism that has
                    # to be seen.
                    $AdminSDHolderRules = $SecurityDescriptor.GetAccessRules($true, $true, [System.Security.Principal.SecurityIdentifier])

                    foreach ($ACE in $AdminSDHolderRules) {
                        if ($ACE.AccessControlType -ne 'Allow' -or $ACE.IsInherited) { continue }

                        # Get SID - IdentityReference may be SecurityIdentifier or NTAccount
                        $TrusteeSID = $null
                        $identRef = $ACE.IdentityReference
                        if ($identRef -is [System.Security.Principal.SecurityIdentifier]) {
                            $TrusteeSID = $identRef.Value
                        } else {
                            # NTAccount - use ConvertTo-SID for cross-domain support
                            $TrusteeSID = ConvertTo-SID -Identity $identRef.Value
                        }
                        if (-not $TrusteeSID) { continue }

                        # An inherit-only ACE grants nothing on AdminSDHolder, and nothing on
                        # the objects SDProp copies it onto - it reaches only their children.
                        #
                        # An InheritedObjectType does not take an ACE off the object either:
                        # it names the class of the children that may inherit the ACE (MS-DTYP,
                        # ACE), and the access check reads the ObjectType alone and skips only
                        # INHERIT_ONLY_ACE. "This object and descendant user objects" is full
                        # control over AdminSDHolder and, copied by SDProp, over every
                        # protected group and account. This skipped every ACE with a class.
                        if (([string]$ACE.PropagationFlags) -match 'InheritOnly') {
                            Write-Log "[Get-PrivilegedGroupMembers] Skipping inherit-only ACE on AdminSDHolder: Trustee=$TrusteeSID"
                            continue
                        }

                        # Check for dangerous permissions
                        $objectType = $ACE.ObjectType

                        # Test-ADRightsMask (adPEAS-GUIDs.ps1) expands generic access bits
                        # (GA/GR/GW/GX) before testing and requires an exact match for GenericAll,
                        # not just an overlap - a raw "-band" against $ACE.ActiveDirectoryRights
                        # would miss an ACE that grants full control only via the GA generic bit
                        # (e.g. the RBCD-style "O:BAD:(A;;GA;;;<sid>)" form), GenericAll included.
                        # Also, GenericAll only applies to the whole object if ObjectType is empty.
                        $HasGenericAll = (Test-ADRightsMask -Rights $ACE.ActiveDirectoryRights -Has ([System.DirectoryServices.ActiveDirectoryRights]::GenericAll)) -and
                                         (-not $objectType -or $objectType -eq [Guid]::Empty)

                        # WriteDacl (0x40000) and WriteOwner (0x80000) - only if ObjectType is empty
                        $HasWriteDacl = (Test-ADRightsMask -Rights $ACE.ActiveDirectoryRights -Has ([System.DirectoryServices.ActiveDirectoryRights]::WriteDacl)) -and
                                        (-not $objectType -or $objectType -eq [Guid]::Empty)
                        $HasWriteOwner = (Test-ADRightsMask -Rights $ACE.ActiveDirectoryRights -Has ([System.DirectoryServices.ActiveDirectoryRights]::WriteOwner)) -and
                                         (-not $objectType -or $objectType -eq [Guid]::Empty)

                        # The rights that add a MEMBER without controlling the object, which
                        # the three above do not cover. This is the heaviest consequence an
                        # ACE on AdminSDHolder can have: SDProp writes this descriptor onto
                        # every adminCount=1 object hourly, so one of these here means the
                        # trustee may add itself to Domain Admins, Enterprise Admins, Schema
                        # Admins and every other protected group - and keep that right,
                        # because a right granted here is the one that survives SDProp.
                        #
                        # Three forms, and the ObjectType decides which is which:
                        #   WriteProperty on the member GUID  - write the attribute directly
                        #   WriteProperty with no ObjectType  - write every attribute
                        #   Self on the member GUID           - the "add/remove self as
                        #                                       member" validated write
                        # GenericWrite with no ObjectType expands to WriteProperty over all
                        # attributes, which includes member; Test-ADRightsMask expands the
                        # generic bits, so it is caught by the WriteProperty test.
                        $memberGUID = $Script:PropertyGUIDs['member']
                        $objectTypeIsMember = ($objectType -and $memberGUID -and $objectType -eq $memberGUID)
                        $objectTypeIsEmpty = (-not $objectType -or $objectType -eq [Guid]::Empty)

                        $HasWriteMember = (Test-ADRightsMask -Rights $ACE.ActiveDirectoryRights -Has ([System.DirectoryServices.ActiveDirectoryRights]::WriteProperty)) -and
                                          ($objectTypeIsMember -or $objectTypeIsEmpty)
                        $HasSelfMember = (Test-ADRightsMask -Rights $ACE.ActiveDirectoryRights -Has ([System.DirectoryServices.ActiveDirectoryRights]::Self)) -and
                                         ($objectTypeIsMember -or $objectTypeIsEmpty)

                        # The rights that take over the protected ACCOUNTS, which the member
                        # rights above do not cover: SDProp writes this descriptor onto every
                        # protected user as well, so a write on one of these attributes here
                        # is that write on every administrator. Named attributes only - a
                        # WriteProperty without an ObjectType is already the member line
                        # above, and GenericAll covers everything.
                        #   msDS-KeyCredentialLink - add a key and authenticate as the account
                        #   servicePrincipalName   - give the account an SPN and roast it
                        #   altSecurityIdentities  - map a certificate onto the account (ESC14)
                        #   userAccountControl     - switch off pre-authentication or the
                        #                            password requirement (directly or through
                        #                            the User-Account-Restrictions set)
                        # and the extended right to reset the password, which an ACE with no
                        # ObjectType grants along with every other extended right.
                        $hasWriteProperty = Test-ADRightsMask -Rights $ACE.ActiveDirectoryRights -Has ([System.DirectoryServices.ActiveDirectoryRights]::WriteProperty)
                        $hasExtendedRight = Test-ADRightsMask -Rights $ACE.ActiveDirectoryRights -Has ([System.DirectoryServices.ActiveDirectoryRights]::ExtendedRight)
                        $HasWriteKeyCredential = $hasWriteProperty -and $objectType -and ($objectType -eq $Script:PropertyGUIDs['msDS-KeyCredentialLink'])
                        $HasWriteSPN = $hasWriteProperty -and $objectType -and ($objectType -eq $Script:PropertyGUIDs['servicePrincipalName'])
                        $HasWriteAltSecurity = $hasWriteProperty -and $objectType -and ($objectType -eq $Script:PropertyGUIDs['altSecurityIdentities'])
                        $HasWriteAccountControl = $hasWriteProperty -and $objectType -and (
                            ($objectType -eq $Script:PropertyGUIDs['userAccountControl']) -or
                            ($objectType -eq $Script:PropertySetGUIDs['User-Account-Restrictions']))
                        $resetPasswordGUID = [Guid]$Script:ExtendedRightsAliases['ForceChangePassword']
                        $HasResetPassword = $hasExtendedRight -and ($objectTypeIsEmpty -or ($objectType -eq $resetPasswordGUID))

                        $HasDangerousPermission = $HasGenericAll -or $HasWriteDacl -or $HasWriteOwner -or
                                                  $HasWriteMember -or $HasSelfMember -or
                                                  $HasWriteKeyCredential -or $HasWriteSPN -or $HasWriteAltSecurity -or
                                                  $HasWriteAccountControl -or $HasResetPassword

                        if (-not $HasDangerousPermission) { continue }

                        # Collected per trustee and judged once, below. The descriptor hands
                        # the ACEs back in an order nobody controls - measured, it re-sorts
                        # them on load - and the loop used to take the first dangerous ACE of
                        # a trustee and skip the others, so which of its rights the row named
                        # depended on that order.
                        if (-not $trusteeRights.Contains($TrusteeSID)) {
                            $trusteeRights[$TrusteeSID] = @{
                                GenericAll = $false; WriteDacl = $false; WriteOwner = $false
                                WriteMember = $false; SelfMember = $false; KeyCredential = $false
                                SPN = $false; AltSecurity = $false; AccountControl = $false
                                ResetPassword = $false; AllExtendedRights = $false
                            }
                        }
                        $collected = $trusteeRights[$TrusteeSID]
                        if ($HasGenericAll) { $collected.GenericAll = $true }
                        if ($HasWriteDacl) { $collected.WriteDacl = $true }
                        if ($HasWriteOwner) { $collected.WriteOwner = $true }
                        if ($HasWriteMember) { $collected.WriteMember = $true }
                        if ($HasSelfMember) { $collected.SelfMember = $true }
                        if ($HasWriteKeyCredential) { $collected.KeyCredential = $true }
                        if ($HasWriteSPN) { $collected.SPN = $true }
                        if ($HasWriteAltSecurity) { $collected.AltSecurity = $true }
                        if ($HasWriteAccountControl) { $collected.AccountControl = $true }
                        if ($HasResetPassword) {
                            if ($objectTypeIsEmpty) { $collected.AllExtendedRights = $true } else { $collected.ResetPassword = $true }
                        }
                    }

                    # The rights some trustees hold here by design: Key Admins and Enterprise
                    # Key Admins write msDS-KeyCredentialLink for Windows Hello for Business
                    # (DefaultRightHolders of the DomainRootACL scope). Left out of the row, so
                    # a right of theirs that is not by design is reported on its own.
                    $holderTable = $Script:SecurityScopes['DomainRootACL'].DefaultRightHolders

                    foreach ($TrusteeSID in @($trusteeRights.Keys)) {
                        $collected = $trusteeRights[$TrusteeSID]

                        $defaultRights = @()
                        if ($holderTable) {
                            $holderRID = Get-SIDRIDSuffix -SID $TrusteeSID
                            if ($holderTable.ContainsKey($TrusteeSID)) { $defaultRights = @($holderTable[$TrusteeSID]) }
                            elseif ($holderRID -and $holderTable.ContainsKey($holderRID)) { $defaultRights = @($holderTable[$holderRID]) }
                        }

                        # Each right by name and by what it does. Named for the consequence
                        # rather than for the bit, because that is what a reader has to see:
                        # this propagates to every protected group and account.
                        #
                        # Only GenericAll, WriteDacl and WriteOwner when GenericAll is on the
                        # row: full control over the whole object expands to every right
                        # below, so listing them beside it says the same thing several times.
                        $entries = New-Object System.Collections.ArrayList
                        if ($collected.GenericAll) { [void]$entries.Add(@('GenericAll', 'GenericAll')) }
                        if ($collected.WriteDacl) { [void]$entries.Add(@('WriteDacl', 'WriteDacl')) }
                        if ($collected.WriteOwner) { [void]$entries.Add(@('WriteOwner', 'WriteOwner')) }
                        if (-not $collected.GenericAll) {
                            if ($collected.WriteMember) { [void]$entries.Add(@('member', 'WriteProperty on member - may add a member to every protected group')) }
                            if ($collected.SelfMember) { [void]$entries.Add(@('Self-Membership', 'Self on member - may add itself to every protected group')) }
                            if ($collected.KeyCredential) { [void]$entries.Add(@('msDS-KeyCredentialLink', 'WriteProperty on msDS-KeyCredentialLink - may add a key credential to every protected account and log on as it')) }
                            if ($collected.SPN) { [void]$entries.Add(@('servicePrincipalName', 'WriteProperty on servicePrincipalName - may give every protected account an SPN and roast its password')) }
                            if ($collected.AltSecurity) { [void]$entries.Add(@('altSecurityIdentities', 'WriteProperty on altSecurityIdentities - may map a certificate onto every protected account')) }
                            if ($collected.AccountControl) { [void]$entries.Add(@('userAccountControl', 'WriteProperty on userAccountControl - may turn off pre-authentication or the password requirement on every protected account')) }
                            if ($collected.AllExtendedRights) {
                                [void]$entries.Add(@('User-Force-Change-Password', 'All extended rights - may reset the password of every protected account'))
                            } elseif ($collected.ResetPassword) {
                                # Not "Reset password ...": OU_PERM_PASSWORD_RESET matches that
                                # text, scores higher and describes an OU delegation.
                                [void]$entries.Add(@('User-Force-Change-Password', 'Password reset right - may reset the password of every protected account'))
                            }
                        }

                        $reported = @($entries | Where-Object { $defaultRights -notcontains $_[0] })
                        if (@($reported).Count -eq 0) {
                            Write-Log "[Get-PrivilegedGroupMembers] AdminSDHolder: $TrusteeSID holds only its default rights"
                            continue
                        }
                        $Permissions = @($reported | ForEach-Object { $_[1] })

                        # Resolve name for display
                        $TrusteeName = ConvertFrom-SID -SID $TrusteeSID

                        # Determine severity
                        $severity = 'Finding'

                        if (-not $IncludePrivileged) {
                            # Use scope-based check for Domain Root ACL (AdminSDHolder has same expectations)
                            $scopeResult = Test-IsExpectedInScope -Identity $TrusteeSID -Scope 'DomainRootACL' -ReturnDetails

                            if ($scopeResult.Severity -eq 'Expected') {
                                Write-Log "[Get-PrivilegedGroupMembers] AdminSDHolder expected: $TrusteeName - $($scopeResult.Reason)"
                                continue
                            }

                            if ($scopeResult.Severity -eq 'Attention') {
                                Write-Log "[Get-PrivilegedGroupMembers] AdminSDHolder attention: $TrusteeName - $($scopeResult.Reason) - skipped (use -IncludePrivileged to include)"
                                continue
                            }

                            $severity = $scopeResult.Severity
                        } else {
                            # -IncludePrivileged: Show ALL accounts, but mark privileged ones for yellow display
                            $scopeResult = Test-IsExpectedInScope -Identity $TrusteeSID -Scope 'DomainRootACL' -ReturnDetails
                            $severity = $scopeResult.Severity
                            Write-Log "[Get-PrivilegedGroupMembers] IncludePrivileged: Including AdminSDHolder $TrusteeName ($TrusteeSID) with severity $severity"
                        }

                        $finding = [PSCustomObject]@{
                            Name = $TrusteeName
                            Trustee = $TrusteeName
                            TrusteeSID = $TrusteeSID
                            dangerousRights = $Permissions
                        }
                        if ($severity -in @('Expected', 'Attention')) {
                            $finding | Add-Member -NotePropertyName 'dangerousRightsSeverity' -NotePropertyValue 'Hint' -Force
                        }
                        $finding | Add-Member -NotePropertyName '_adPEASObjectType' -NotePropertyValue 'AdminSDHolderACL' -Force
                        $AdminSDHolderFindings += $finding

                        Show-Object $finding -Class $(if ([string]$finding.dangerousRightsSeverity -in @('Expected', 'Attention', 'Hint')) { 'Hint' } else { 'Finding' })
                    }

                    # Two questions, and the loop above answers only the first.
                    #
                    # "What does SDProp propagate" is about the EXPLICIT Allow ACEs: those
                    # are the descriptor that gets written onto every protected object, and
                    # that is why the loop skips inherited and Deny.
                    #
                    # "Who can change AdminSDHolder itself" is a different question with a
                    # different answer. A GenericAll inherited onto CN=AdminSDHolder from
                    # CN=System or from the domain root is enough to rewrite the template,
                    # and the domain root is covered by Get-DangerousACLs while CN=System is
                    # covered by nobody. Said as its own line, because the remediation is a
                    # different one - the ACE has to be removed at the parent.
                    $inheritedControllers = @()
                    $denyTrustees = @()
                    foreach ($ACE in $AdminSDHolderRules) {
                        $identRef = $ACE.IdentityReference
                        $aceSID = if ($identRef -is [System.Security.Principal.SecurityIdentifier]) {
                            $identRef.Value
                        } else {
                            ConvertTo-SID -Identity $identRef.Value
                        }
                        if (-not $aceSID) { continue }

                        if ($ACE.AccessControlType -eq 'Deny') {
                            # A Deny on AdminSDHolder is itself worth a look when it can hide
                            # the template from the very administrators who would audit it:
                            # one on ReadControl keeps them from reading its DACL, one on reading
                            # or listing the whole object keeps them from seeing it at all.
                            #
                            # A Deny on writing one attribute hides nothing. Exchange setup
                            # writes four - Exchange Servers and Exchange Trusted Subsystem
                            # denied WriteProperty on userCertificate, altSecurityIdentities and
                            # servicePrincipalName, measured - so that a compromised Exchange
                            # server cannot plant a certificate mapping or an SPN on a
                            # protected account. They were listed as hiding the template.
                            $denyType = $ACE.ObjectType
                            $denyWholeObject = (-not $denyType -or $denyType -eq [Guid]::Empty)
                            $hidesTemplate = (Test-ADRightsMask -Rights $ACE.ActiveDirectoryRights -Has ([System.DirectoryServices.ActiveDirectoryRights]::ReadControl)) -or
                                ($denyWholeObject -and (
                                    (Test-ADRightsMask -Rights $ACE.ActiveDirectoryRights -Has ([System.DirectoryServices.ActiveDirectoryRights]::ReadProperty)) -or
                                    (Test-ADRightsMask -Rights $ACE.ActiveDirectoryRights -Has ([System.DirectoryServices.ActiveDirectoryRights]::ListChildren)) -or
                                    (Test-ADRightsMask -Rights $ACE.ActiveDirectoryRights -Has ([System.DirectoryServices.ActiveDirectoryRights]::ListObject))))
                            if (-not $hidesTemplate) {
                                Write-Log "[Get-PrivilegedGroupMembers] Deny on AdminSDHolder that hides nothing: $aceSID $($ACE.ActiveDirectoryRights) $denyType"
                                continue
                            }
                            $denyName = ConvertFrom-SID -SID $aceSID
                            if (-not $denyName) { $denyName = $aceSID }
                            if ($denyTrustees -notcontains $denyName) { $denyTrustees += $denyName }
                            continue
                        }

                        if (-not $ACE.IsInherited) { continue }
                        # An inherited copy for another class than AdminSDHolder's arrives
                        # inherit-only and grants nothing here.
                        if (([string]$ACE.PropagationFlags) -match 'InheritOnly') { continue }

                        $inheritedType = $ACE.ObjectType
                        $inheritedEmpty = (-not $inheritedType -or $inheritedType -eq [Guid]::Empty)
                        $controls = (
                            (Test-ADRightsMask -Rights $ACE.ActiveDirectoryRights -Has ([System.DirectoryServices.ActiveDirectoryRights]::GenericAll)) -or
                            (Test-ADRightsMask -Rights $ACE.ActiveDirectoryRights -Has ([System.DirectoryServices.ActiveDirectoryRights]::WriteDacl)) -or
                            (Test-ADRightsMask -Rights $ACE.ActiveDirectoryRights -Has ([System.DirectoryServices.ActiveDirectoryRights]::WriteOwner))
                        ) -and $inheritedEmpty
                        if (-not $controls) { continue }

                        # The four default holders of full control on everything are not a
                        # finding here either - same gate as above.
                        $inheritedScope = Test-IsExpectedInScope -Identity $aceSID -Scope 'DomainRootACL' -ReturnDetails
                        if ($inheritedScope.Severity -in @('Expected', 'Attention')) { continue }

                        $inheritedName = ConvertFrom-SID -SID $aceSID
                        if (-not $inheritedName) { $inheritedName = $aceSID }
                        if ($inheritedControllers -notcontains $inheritedName) { $inheritedControllers += $inheritedName }
                    }

                    # The owner of AdminSDHolder may rewrite its DACL whatever the DACL says,
                    # and the rewritten template is copied onto every protected object within
                    # the hour. Not asked before; the four default owners - Administrators,
                    # SYSTEM, Domain Admins, Enterprise Admins - are expected, as on the domain
                    # object.
                    $holderOwnerSID = $null
                    try { $holderOwnerSID = $SecurityDescriptor.GetOwner([System.Security.Principal.SecurityIdentifier]).Value } catch {
                        Write-Log "[Get-PrivilegedGroupMembers] Could not read the AdminSDHolder owner: $_"
                    }
                    if ($holderOwnerSID) {
                        $ownerScope = Test-IsExpectedInScope -Identity $holderOwnerSID -Scope 'DomainRootACL' -ReturnDetails
                        if ($ownerScope.Severity -notin @('Expected', 'Attention')) {
                            $ownerName = ConvertFrom-SID -SID $holderOwnerSID
                            if (-not $ownerName) { $ownerName = $holderOwnerSID }
                            $ownerFinding = [PSCustomObject]@{
                                Name = $ownerName
                                Trustee = $ownerName
                                TrusteeSID = $holderOwnerSID
                                dangerousRights = @('Owner of AdminSDHolder - may rewrite the template SDProp copies onto every protected group and account')
                                _adPEASObjectType = 'AdminSDHolderACL'
                            }
                            $AdminSDHolderFindings += $ownerFinding
                            Show-Object $ownerFinding -Class Finding
                        }
                    }

                    if (@($inheritedControllers).Count -gt 0) {
                        Show-Line "Субъектов с унаследованным ACE, позволяющим изменить AdminSDHolder: $(@($inheritedControllers).Count). Удаляйте разрешение у родителя:" -Class Finding
                        foreach ($controller in $inheritedControllers) {
                            Show-Line "  $controller" -Class Finding
                        }
                    }

                    if (@($denyTrustees).Count -gt 0) {
                        Show-Line "Субъектов в ACE типа Deny у AdminSDHolder: $(@($denyTrustees).Count). Такой запрет способен скрывать шаблон от проверяющих:" -Class Hint
                        foreach ($denied in $denyTrustees) {
                            Show-Line "  $denied" -Class Hint
                        }
                    }
                }
                $adminSDHolderRead = $true
            } catch {
                Write-Log "[Get-PrivilegedGroupMembers] Error checking AdminSDHolder: $_" -Level Error
                $adminSDHolderRead = $false
            }

            if (-not $adminSDHolderRead) {
                # Without this branch a failed read fell through to the Secure message
                # below, so a blind check was indistinguishable from a clean one.
                Show-Line "Не удалось прочитать AdminSDHolder; права доступа не оценены" -Class Finding
            }
            elseif (@($AdminSDHolderFindings).Count -eq 0) {
                Show-Line "Разрешения ACL на AdminSDHolder соответствуют безопасной конфигурации" -Class Secure
            }

            # ===== STEP 5b: The DACL of the privileged groups AdminSDHolder does not protect =====
            # Its own try: a failure here must not read as clean, and must not take the steps
            # around it with it.
            try {
                $adminSDExcludedGroups = Get-AdminSDHolderExcludedGroup -ConnectionParams $connectionParams
                Show-UnprotectedGroupACL -Groups @($GroupsForACLReview.Values) -IncludePrivileged:$IncludePrivileged `
                    -ConnectionParams $connectionParams -AccountOperatorMembers $accountOperatorMembers `
                    -AdminSDExcludedGroups $adminSDExcludedGroups
            } catch {
                Write-Log "[Get-PrivilegedGroupMembers] Group ACL analysis failed: $_" -Level Error
                Show-Line "Ошибка анализа ACL групп: не удалось оценить привилегированные группы вне защиты AdminSDHolder: $_" -Class Finding
            }

            # ===== STEP 5c: The DACL of the privileged accounts =====
            # Users and managed service accounts of this domain. Computers are left to
            # Get-NonDefaultComputerOwners, which reads the explicit entries on every computer
            # object; an account behind a trust (IsForeign) or in another domain of the forest
            # (IsCrossDomain, set where the member was resolved) is not read here.
            try {
                # What taking an account over is worth: that of the heaviest privileged group it
                # is in, as for the groups of step 5b - Get-GroupTakeoverWeight. DnsAdmins and
                # ESX Admins are worth the domain.
                $topLevelWeights = @{}
                foreach ($weighedGroup in @($AllGroupData)) {
                    if ($weighedGroup.GroupType -eq 'Dynamic') {
                        $topLevelWeights[[string]$weighedGroup.GroupName] = 'Finding'
                    } else {
                        $topLevelWeights[[string]$weighedGroup.GroupName] = Get-GroupTakeoverWeight -GroupSID ([string]$weighedGroup.GroupSID)
                    }
                }
                $AccountsForACLReview = @(foreach ($memberDN in @($MemberGroupMemberships.Keys)) {
                    $memberInfo = $MemberGroupMemberships[$memberDN].MemberInfo
                    if (-not $memberInfo -or $memberInfo.IsForeign -or $memberInfo.IsCrossDomain) { continue }
                    if ([string]$memberInfo.ObjectClass -eq 'computer') { continue }
                    # Groups holds the names of the groups in $AllGroupData, each weighed above.
                    $accountWeight = 'Hint'
                    foreach ($memberGroupName in @($MemberGroupMemberships[$memberDN].Groups)) {
                        if ($topLevelWeights[[string]$memberGroupName] -eq 'Finding') { $accountWeight = 'Finding' }
                    }
                    [PSCustomObject]@{
                        DistinguishedName = [string]$memberDN
                        Name              = $(if ($memberInfo.SAMAccountName) { [string]$memberInfo.SAMAccountName } else { [string]$memberInfo.Name })
                        SID               = [string]$memberInfo.SID
                        ObjectClass       = [string]$memberInfo.ObjectClass
                        Groups            = @($MemberGroupMemberships[$memberDN].Groups)
                        Weight            = $accountWeight
                    }
                })
                Show-PrivilegedAccountACL -Accounts $AccountsForACLReview -TemplateRules $AdminSDHolderRules -IncludePrivileged:$IncludePrivileged `
                    -ConnectionParams $connectionParams -AccountOperatorMembers $accountOperatorMembers
            } catch {
                Write-Log "[Get-PrivilegedGroupMembers] Account ACL analysis failed: $_" -Level Error
                Show-Line "Ошибка анализа ACL привилегированных учётных записей: $_" -Class Finding
            }

            # ===== STEP 6: Check Pre-Windows 2000 Compatible Access =====
            Show-SubHeader "Проверка группы Pre-Windows 2000 Compatible Access..." -ObjectType "PreWindows2000Access"

            $PreWin2000Findings = @()
            $PreWin2000Rows = @()
            $PreWin2000Unresolved = @()
            $preWin2000Read = $false
            # Use Well-Known SID S-1-5-32-554 for language-independent lookup
            $PreWin2000SID = 'S-1-5-32-554'

            try {
                $PreWin2000Group = Select-LocalDomainGroup (Get-DomainGroup -Identity $PreWin2000SID @CredParams)

                if ($PreWin2000Group) { $preWin2000Read = $true }

                if ($PreWin2000Group -and $PreWin2000Group.member) {
                    foreach ($MemberDN in @($PreWin2000Group.member)) {
                        if ([string]::IsNullOrWhiteSpace($MemberDN)) { continue }

                        # The SID out of the DN first, and only then a query. A well-known
                        # principal added to a domain group becomes a
                        # foreignSecurityPrincipal whose CN *is* its SID, so the lookup is
                        # not needed at all - and the module already reads FSPs this way
                        # where it walks the privileged groups above.
                        $MemberSID = $null
                        if ($MemberDN -match '^CN=(S-1-[0-9-]+?)(?:,|$)') {
                            $MemberSID = $Matches[1]
                        }

                        if (-not $MemberSID) {
                            # The other place AD keeps these: CN=WellKnown Security
                            # Principals under the Configuration partition, where the
                            # objects are named by their display name rather than by SID.
                            # That is a different naming context, and a subtree search
                            # under the domain DN does not reach it - so the search base
                            # comes from the member's own DN. Without it the lookup
                            # returned nothing, the member was skipped in silence, and the
                            # check reported a clean group.
                            $memberParams = @{}
                            foreach ($key in $CredParams.Keys) { $memberParams[$key] = $CredParams[$key] }
                            if ($MemberDN -match ',(CN=Configuration,.+)$') {
                                $memberParams['SearchBase'] = $Matches[1]
                            }

                            $MemberObj = @(Get-DomainObject -Identity $MemberDN @memberParams)[0]
                            if ($MemberObj -and $MemberObj.objectSid) {
                                $MemberSID = [string]$MemberObj.objectSid
                            }
                        }

                        if (-not $MemberSID) {
                            $PreWin2000Unresolved += $MemberDN
                            Write-Log "[Get-PrivilegedGroupMembers] Pre-Windows 2000 member could not be resolved to a SID: $MemberDN" -Level Warning
                            continue
                        }

                        # The central lists, not a private copy of three of them. The copy
                        # knew Everyone, Anonymous Logon and Authenticated Users, so
                        # Domain Users - the ordinary result of installing the domain with
                        # pre-Windows 2000 compatible permissions - was reported as
                        # "No dangerous members".
                        if (-not (Test-IsBroadTrustee -SID $MemberSID)) { continue }

                        $MemberName = ConvertFrom-SID -SID $MemberSID
                        if ([string]::IsNullOrWhiteSpace($MemberName)) { $MemberName = $MemberSID }

                        # Name carries the card title ({Name} in the ObjectType's
                        # TitleFormat). Without it the title resolved to
                        # "Pre-Windows 2000 Compatible Access: Unknown", because none of
                        # the properties Get-ObjectTypeTitle looks for were present.
                        $finding = [PSCustomObject]@{
                            Name       = $MemberName
                            MemberName = $MemberName
                            MemberSID  = $MemberSID
                        }

                        # One of two statements, each on an attribute of its own. The
                        # object used to carry Severity = 'Critical' or 'High', which are
                        # not adPEAS severity classes: META_SEVERITY_PASSTHROUGH matches
                        # only Finding, Hint, Note and Secure, so the row stayed colourless
                        # and named no finding card for one of the classic legacy findings
                        # there is.
                        # Three cases, because three different things are true. The
                        # value is the member name: the sentence these attributes used to
                        # carry is the card's Description word for word, so the console
                        # was repeating the tooltip in 160 characters.
                        $memberClass = 'Finding'
                        if ($MemberSID -eq 'S-1-5-7') {
                            # No credentials at all - the strongest of the three.
                            $finding | Add-Member -NotePropertyName 'prewin2000AnonymousMember' -NotePropertyValue $MemberName -Force
                        } elseif ($MemberSID -eq 'S-1-5-11') {
                            # The Microsoft default: still pre-populated in new forests on
                            # Server 2022 and 2025, and removing it breaks ADFS 3.0
                            # WebForms and Cisco ISE among others. Hardening worth doing,
                            # with dependencies to check first - not a finding against the
                            # configuration as shipped.
                            $finding | Add-Member -NotePropertyName 'prewin2000DefaultMember' -NotePropertyValue $MemberName -Force
                            $memberClass = 'Hint'
                        } else {
                            # Everyone, or anyone added by hand. The legacy mode.
                            $finding | Add-Member -NotePropertyName 'prewin2000BroadMember' -NotePropertyValue $MemberName -Force
                        }

                        $finding | Add-Member -NotePropertyName '_adPEASObjectType' -NotePropertyValue 'PreWindows2000Access' -Force
                        $PreWin2000Findings += $finding
                        $PreWin2000Rows += [PSCustomObject]@{ Finding = $finding; Class = $memberClass }
                    }

                    # One line for the group, then its members. Each member used to get a
                    # line of its own - "<name> is a member" - directly above an object
                    # whose only row named the same member again. The object carries the
                    # member and its class; the line says how many there are.
                    if (@($PreWin2000Rows).Count -gt 0) {
                        $headerClass = 'Hint'
                        if (@($PreWin2000Rows | Where-Object { $_.Class -eq 'Finding' }).Count -gt 0) { $headerClass = 'Finding' }
                        Show-Line "Обнаружены широко доступные субъекты в группе Pre-Windows 2000 Compatible Access: $(@($PreWin2000Rows).Count)" -Class $headerClass
                        foreach ($row in $PreWin2000Rows) {
                            Show-Object $row.Finding -Class $row.Class
                        }
                    }
                }

                if (-not $preWin2000Read) {
                    # A failed read used to fall through to the Secure message below, so a
                    # blind check looked exactly like a clean one.
                    Show-Line "Не удалось прочитать состав Pre-Windows 2000 Compatible Access; членство не оценивалось" -Class Finding
                }
                elseif (@($PreWin2000Findings).Count -eq 0 -and @($PreWin2000Unresolved).Count -eq 0) {
                    Show-Line "В группе Pre-Windows 2000 Compatible Access опасные участники не обнаружены" -Class Secure
                }

                if (@($PreWin2000Unresolved).Count -gt 0) {
                    Show-Line "Участников Pre-Windows 2000 Compatible Access, которые не разрешены до SID и потому не оценивались: $(@($PreWin2000Unresolved).Count)" -Class Hint
                }
            } catch {
                Write-Log "[Get-PrivilegedGroupMembers] Error checking Pre-Windows 2000 Compatible Access: $_" -Level Error
                Show-Line "Не удалось прочитать состав Pre-Windows 2000 Compatible Access; членство не оценивалось" -Class Finding
            }

        } catch {
            Write-Log "[Get-PrivilegedGroupMembers] Error: $_" -Level Error
            Show-Line "Ошибка проверки: не удалось оценить членство в привилегированных группах: $_" -Class Finding
        }
    }

    end {
        Write-Log "[Get-PrivilegedGroupMembers] Privileged group enumeration completed"
    }
}

<#
.SYNOPSIS
    The operator groups dsHeuristics takes out of AdminSDHolder protection.

.DESCRIPTION
    Character 16 of dsHeuristics (dwAdminSDExMask, MS-ADTS 3.1.1.6.1.4) excludes Account,
    Server, Print and Backup Operators, and their direct and transitive members, from the
    protection operation, in every domain of the forest. SDProp then leaves them alone - but
    the adminCount=1 it set before stays, because nothing clears it, so step 5b would take
    them for protected. Get-LDAPConfiguration reports the setting itself.

    The attribute is read here rather than handed over, so the check keeps working on its
    own. A read that fails is logged and returns nothing excluded: step 5b then measures by
    adminCount alone, as it did before it knew of the setting.

.PARAMETER ConnectionParams
    Domain/Server/Credential hashtable, passed through unchanged.

.OUTPUTS
    Hashtable SID -> group name; empty when nothing is excluded or the attribute could not
    be read.
#>
function Get-AdminSDHolderExcludedGroup {
    [CmdletBinding()]
    [OutputType([hashtable])]
    param(
        [Parameter(Mandatory=$false)]
        [hashtable]$ConnectionParams = @{}
    )

    $excluded = @{}
    $configDN = $Script:LDAPContext.ConfigurationNamingContext
    if (-not $configDN) { return $excluded }

    try {
        $dirService = @(Get-DomainObject -Identity "CN=Directory Service,CN=Windows NT,CN=Services,$configDN" -Properties 'dSHeuristics' @ConnectionParams)[0]
        if ($dirService) {
            foreach ($operatorGroup in @((ConvertFrom-DSHeuristics -Value ([string]$dirService.dSHeuristics)).AdminSDExcludedGroups)) {
                $excluded[$operatorGroup.SID] = $operatorGroup.Name
            }
        }
    } catch {
        Write-Log "[Get-PrivilegedGroupMembers] Could not read dsHeuristics for the AdminSDHolder exclusions: $_"
    }
    return $excluded
}

<#
.SYNOPSIS
    What taking over a privileged group is worth: Finding or Hint.

.DESCRIPTION
    Step 5b reported every principal that may change an unprotected privileged group as a
    finding, and the groups it reads are not equally privileged. A Tier-0 group - one
    Test-IsPrivileged files as Privileged - is the domain: Finding. Everything else it is
    asked about is a foothold short of it: the operator groups (Group Policy Creator Owners
    creates policies and links none, Cert Publishers writes certificates, an operator group
    dsHeuristics excludes), Remote Management Users (WinRM on the domain controllers) and
    Hyper-V Administrators (Hyper-V on the domain controllers): Hint. DnsAdmins, ESX Admins
    and the Exchange groups are given Finding by their callers - Test-IsPrivileged does not
    know them by SID.

.PARAMETER GroupSID
    The SID of the privileged group a group was reached from. Without one: Finding, the
    weight nobody has argued down.

.OUTPUTS
    [string] 'Finding' or 'Hint'.
#>
function Get-GroupTakeoverWeight {
    [CmdletBinding()]
    [OutputType([string])]
    param(
        [Parameter(Mandatory=$false)]
        [AllowEmptyString()]
        [string]$GroupSID
    )

    if (-not $GroupSID) { return 'Finding' }
    if ((Test-IsPrivileged -Identity $GroupSID).Category -eq 'Privileged') { return 'Finding' }
    return 'Hint'
}

<#
.SYNOPSIS
    Reports who may change a privileged group that AdminSDHolder does not protect.

.DESCRIPTION
    Step 5b of Get-PrivilegedGroupMembers (review accounts 22, user decision 2026-10-16).
    AdminSDHolder protects a fixed set of groups - Microsoft lists Account Operators,
    Administrators, Backup Operators, Domain Admins, Domain Controllers, Enterprise Admins,
    Enterprise Key Admins, Key Admins, Print Operators, Read-only Domain Controllers,
    Replicator, Schema Admins and Server Operators - and SDProp resets their DACL to its
    template every hour, which is why step 5 reads the template. Every other group keeps
    whatever ACEs it is given, and several of them are privileged in all but name: DnsAdmins
    can load code into the DNS service on the domain controllers, Group Policy Creator
    Owners create policy, the Exchange groups hold rights on the domain, and a group nested
    into one of them passes its membership on.

    Which groups are unprotected is measured, not listed: SDProp sets adminCount=1 on every
    group it protects, so the groups without it are read. adminCount is never cleared, so a
    group that was protected once and is no longer keeps a stale 1 and is not read here -
    with one exception that can be known: character 16 of dsHeuristics takes Account,
    Server, Print or Backup Operators and their members out of AdminSDHolder protection
    (MS-ADTS 3.1.1.6.1.4). A group that is one of those, or reached only through them, is
    read whatever its adminCount says.

    The rights that take a group over: writing its member attribute (WriteProperty on member
    or on every attribute, which GenericWrite includes), the Self-Membership validated write,
    WriteDacl, WriteOwner, GenericAll, and owning it. Explicit and inherited ACEs alike - both
    apply to the group itself - but not an inherit-only one, and not an Allow that an
    explicit Deny for the same trustee cancels completely. Who counts as expected is decided
    by the same gate as the AdminSDHolder step, and an Exchange service group's rights are
    by design, as in the other ACL checks.

    One holder is reported apart: Account Operators. The default security descriptor of the
    group class grants them full control - (A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;AO) on
    learn.microsoft.com, adschema - so they control every group AdminSDHolder does not
    protect, in every domain, by design. Listed per group that would be the same finding in
    every report; it is said once instead, as a hint while the group has members and a note
    while it is empty.

    A holder is a finding where a group it can take over is worth the domain - DnsAdmins,
    ESX Admins, the Exchange groups, a Tier-0 group - and a hint where all of them are
    operator-level, such as Group Policy Creator Owners or Cert Publishers: the weight each
    group carries from the privileged group it was reached from (Get-GroupTakeoverWeight).
    Every one of them was a finding, which put a group that creates policies beside one
    that runs code on the domain controllers.

    What was read goes out as one UnprotectedPrivilegedGroups object, not as lines of group
    names that ran past the width of the console.

.PARAMETER Groups
    The groups to read: DistinguishedName, Name and Source ("privileged group", "nested in
    <group>", "Exchange group").

.PARAMETER IncludePrivileged
    Also list the expected and privileged holders, as hints.

.PARAMETER ConnectionParams
    Domain/Server/Credential hashtable, passed through unchanged.

.PARAMETER AccountOperatorMembers
    How many members Account Operators has, or $null when the group was not found.

.PARAMETER AdminSDExcludedGroups
    The operator groups dsHeuristics takes out of AdminSDHolder protection, SID -> name
    (Get-AdminSDHolderExcludedGroup). A group whose Roots are all among them is read even
    with adminCount=1.
#>
function Show-UnprotectedGroupACL {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [AllowEmptyCollection()]
        [object[]]$Groups,

        [Parameter(Mandatory=$false)]
        [switch]$IncludePrivileged,

        [Parameter(Mandatory=$false)]
        [hashtable]$ConnectionParams = @{},

        [Parameter(Mandatory=$false)]
        [AllowNull()]
        $AccountOperatorMembers,

        [Parameter(Mandatory=$false)]
        [hashtable]$AdminSDExcludedGroups = @{}
    )

    Show-SubHeader "Проверка ACL привилегированных групп вне защиты AdminSDHolder..." -ObjectType 'PrivilegedGroupACL'

    $accountOperatorsSID = 'S-1-5-32-548'
    $memberGUID = $Script:PropertyGUIDs['member']

    # Per trustee: the rights it holds, and on which groups.
    $byTrustee = [ordered]@{}
    $examinedGroups = @()
    $unreadGroups = @()
    $excludedRead = @()
    $accountOperatorGroups = @()
    $suppressed = @{}

    foreach ($group in @($Groups)) {
        if (-not $group -or -not $group.DistinguishedName) { continue }

        # Where a nested or an Exchange group came from belongs beside its name.
        $groupLabel = $group.Name
        if ($group.Source -and $group.Source -ne 'privileged group') { $groupLabel = "$($group.Name) ($($group.Source))" }

        $groupObject = $null
        try {
            $groupObject = @(Get-DomainObject -Identity $group.DistinguishedName -Properties 'nTSecurityDescriptor', 'adminCount' -Raw @ConnectionParams)[0]
        } catch {
            Write-Log "[Get-PrivilegedGroupMembers] Could not read $($group.DistinguishedName): $_"
        }
        if (-not $groupObject -or -not $groupObject.nTSecurityDescriptor) {
            $unreadGroups += $groupLabel
            continue
        }

        # Protected: step 5 read its template - unless every privileged group it was reached
        # from is one dsHeuristics takes out of the protection. SDProp then leaves it alone,
        # and the adminCount=1 it set before stays.
        if ("$($groupObject.adminCount)" -eq '1') {
            # No recorded path is no evidence of an exclusion.
            $roots = @($group.Roots)
            $excludedOnly = ($roots.Count -gt 0 -and
                @($roots | Where-Object { -not $AdminSDExcludedGroups.ContainsKey([string]$_) }).Count -eq 0)
            if (-not $excludedOnly) { continue }
            $excludedRead += $group.Name
        }

        $descriptor = New-Object System.DirectoryServices.ActiveDirectorySecurity
        try {
            $descriptor.SetSecurityDescriptorBinaryForm([byte[]]$groupObject.nTSecurityDescriptor)
        } catch {
            Write-Log "[Get-PrivilegedGroupMembers] Could not parse the descriptor of $($group.DistinguishedName): $_"
            $unreadGroups += $groupLabel
            continue
        }
        $examinedGroups += $groupLabel

        # SecurityIdentifier, not .Access - see the AdminSDHolder step.
        $rules = @($descriptor.GetAccessRules($true, $true, [System.Security.Principal.SecurityIdentifier]))
        $denyRules = @($rules | Where-Object { $_.AccessControlType -eq [System.Security.AccessControl.AccessControlType]::Deny })

        # Trustee SID -> the rights it holds on this group.
        $onThisGroup = [ordered]@{}

        foreach ($ace in $rules) {
            if ($ace.AccessControlType -ne [System.Security.AccessControl.AccessControlType]::Allow) { continue }
            if (([string]$ace.PropagationFlags) -match 'InheritOnly') { continue }

            $trusteeSID = $ace.IdentityReference.Value
            # SELF and CREATOR OWNER: the group itself cannot sign in, and the creator's
            # rights are the owner's, which is read below.
            if ($trusteeSID -in @('S-1-5-10', 'S-1-3-0')) { continue }
            if ($denyRules.Count -gt 0 -and (Test-ACEFullyDenied -ACE $ace -DenyACEs $denyRules)) { continue }

            $objectType = $ace.ObjectType
            $objectTypeIsEmpty = (-not $objectType -or $objectType -eq [Guid]::Empty)
            $objectTypeIsMember = ($objectType -and $memberGUID -and $objectType -eq $memberGUID)

            # Test-ADRightsMask expands the generic bits, GenericWrite into WriteProperty
            # over every attribute among them - see the AdminSDHolder step.
            $rights = @()
            if ((Test-ADRightsMask -Rights $ace.ActiveDirectoryRights -Has ([System.DirectoryServices.ActiveDirectoryRights]::GenericAll)) -and $objectTypeIsEmpty) {
                # Full control says everything below; listing them beside it would turn one
                # ACE into five rows that say the same.
                $rights += 'GenericAll'
            } else {
                if ((Test-ADRightsMask -Rights $ace.ActiveDirectoryRights -Has ([System.DirectoryServices.ActiveDirectoryRights]::WriteDacl)) -and $objectTypeIsEmpty) {
                    $rights += 'WriteDacl'
                }
                if ((Test-ADRightsMask -Rights $ace.ActiveDirectoryRights -Has ([System.DirectoryServices.ActiveDirectoryRights]::WriteOwner)) -and $objectTypeIsEmpty) {
                    $rights += 'WriteOwner'
                }
                if ((Test-ADRightsMask -Rights $ace.ActiveDirectoryRights -Has ([System.DirectoryServices.ActiveDirectoryRights]::WriteProperty)) -and ($objectTypeIsMember -or $objectTypeIsEmpty)) {
                    $rights += 'WriteProperty on member - may add a member to the group'
                }
                if ((Test-ADRightsMask -Rights $ace.ActiveDirectoryRights -Has ([System.DirectoryServices.ActiveDirectoryRights]::Self)) -and ($objectTypeIsMember -or $objectTypeIsEmpty)) {
                    $rights += 'Self on member - may add itself to the group'
                }
            }
            if ($rights.Count -eq 0) { continue }

            if (-not $onThisGroup.Contains($trusteeSID)) {
                $onThisGroup[$trusteeSID] = [PSCustomObject]@{ Rights = @() }
            }
            foreach ($right in $rights) {
                if ($onThisGroup[$trusteeSID].Rights -notcontains $right) { $onThisGroup[$trusteeSID].Rights += $right }
            }
        }

        # The owner may rewrite the DACL whatever it says - the same as WriteDacl.
        $ownerSID = $null
        try { $ownerSID = $descriptor.GetOwner([System.Security.Principal.SecurityIdentifier]).Value } catch { $ownerSID = $null }
        if ($ownerSID) {
            if (-not $onThisGroup.Contains($ownerSID)) {
                $onThisGroup[$ownerSID] = [PSCustomObject]@{ Rights = @() }
            }
            $onThisGroup[$ownerSID].Rights += 'Owner of the group - may rewrite its DACL'
        }

        foreach ($trusteeSID in @($onThisGroup.Keys)) {
            $held = $onThisGroup[$trusteeSID]

            if ($trusteeSID -eq $accountOperatorsSID) {
                $accountOperatorGroups += $group.Name
                if (-not $IncludePrivileged) { continue }
                $severity = 'Attention'
            } else {
                # The AdminSDHolder step's gate: the default holders of everything, and the
                # members of those groups, are expected.
                $scopeResult = Test-IsExpectedInScope -Identity $trusteeSID -Scope 'DomainRootACL' -ReturnDetails
                $severity = $scopeResult.Severity
                if ($severity -notin @('Expected', 'Attention')) {
                    $exchangeCheck = Test-IsExchangeServiceGroup -Identity $trusteeSID
                    if ($exchangeCheck -and $exchangeCheck.IsExchangeService) { $severity = 'Attention' }
                }
                if ($severity -in @('Expected', 'Attention') -and -not $IncludePrivileged) {
                    $suppressed[$trusteeSID] = $true
                    continue
                }
            }

            if (-not $byTrustee.Contains($trusteeSID)) {
                $byTrustee[$trusteeSID] = [PSCustomObject]@{ Rights = @(); Groups = @(); Severity = $severity; Weight = 'Hint' }
            }
            $entry = $byTrustee[$trusteeSID]
            foreach ($right in $held.Rights) {
                if ($entry.Rights -notcontains $right) { $entry.Rights += $right }
            }
            # Whether the ACE is inherited is not said here: the card says where an
            # inherited one has to be removed, and the suffix pushed the row past the line.
            $entry.Groups += "$($group.Name) ($($group.Source))"
            # The heaviest group decides; one without a weight counts as Finding.
            $groupWeight = 'Finding'
            if ($group.PSObject.Properties['Weight'] -and $group.Weight) { $groupWeight = [string]$group.Weight }
            if ($groupWeight -eq 'Finding') { $entry.Weight = 'Finding' }
        }
    }

    # What was read, as an object rather than as lines of group names, which ran past the
    # width of the console. Group names only where the group was found as itself, with
    # where it came from for a nested or an Exchange group.
    if ($examinedGroups.Count -gt 0 -or $unreadGroups.Count -gt 0) {
        $scope = [PSCustomObject]@{ groupsRead = @($examinedGroups) }
        if ($excludedRead.Count -gt 0) {
            # adminCount=1 from an earlier SDProp run, but dsHeuristics takes the groups
            # they were reached from out of the protection - the card says so.
            $scope | Add-Member -NotePropertyName 'readDespiteAdminCount' -NotePropertyValue @($excludedRead) -Force
        }
        if ($unreadGroups.Count -gt 0) {
            $scope | Add-Member -NotePropertyName 'groupsNotRead' -NotePropertyValue @($unreadGroups) -Force
        }
        $scope | Add-Member -NotePropertyName '_adPEASObjectType' -NotePropertyValue 'UnprotectedPrivilegedGroups' -Force
        Show-Line "Привилегированные группы вне защиты AdminSDHolder:" -Class Note
        Show-Object $scope -Class Note
    }

    # Account Operators: the default, said once - see the description. Short: what a member
    # of Account Operators can do with it is the card's.
    if ($accountOperatorGroups.Count -gt 0) {
        $aoReach = if ($accountOperatorGroups.Count -eq $examinedGroups.Count) { "$($examinedGroups.Count) из $($examinedGroups.Count)" } else { "$($accountOperatorGroups.Count) из $($examinedGroups.Count)" }
        $aoMembers = ''
        $aoClass = 'Note'
        if ($null -ne $AccountOperatorMembers -and [int]$AccountOperatorMembers -gt 0) {
            $aoMembers = " (участников: $AccountOperatorMembers)"
            $aoClass = 'Hint'
        } elseif ($null -ne $AccountOperatorMembers) {
            $aoMembers = ' (нет участников)'
        }
        Show-Line "Группа Account Operators$aoMembers по умолчанию имеет права управления: $aoReach группами, не защищёнными AdminSDHolder" -Class $aoClass -FindingId 'PRIVILEGED_GROUP_ACL'
    }

    $findingRows = @()
    $operatorRows = @()
    $hintRows = @()
    foreach ($trusteeSID in @($byTrustee.Keys)) {
        $entry = $byTrustee[$trusteeSID]
        $trusteeName = ConvertFrom-SID -SID $trusteeSID
        if (-not $trusteeName) { $trusteeName = $trusteeSID }

        $row = [PSCustomObject]@{
            Name            = $trusteeName
            Trustee         = $trusteeName
            TrusteeSID      = $trusteeSID
            dangerousRights = @($entry.Rights)
            affectedGroups  = @($entry.Groups)
        }
        $row | Add-Member -NotePropertyName '_adPEASObjectType' -NotePropertyValue 'PrivilegedGroupACL' -Force
        if ($entry.Severity -in @('Expected', 'Attention')) {
            $row | Add-Member -NotePropertyName 'dangerousRightsSeverity' -NotePropertyValue 'Hint' -Force
            $hintRows += $row
        } elseif ($entry.Weight -eq 'Finding') {
            $findingRows += $row
        } else {
            # Only operator-level groups: a foothold, not the domain - see
            # Get-GroupTakeoverWeight. dangerousRightsSeverity turns the rows yellow.
            $row | Add-Member -NotePropertyName 'dangerousRightsSeverity' -NotePropertyValue 'Hint' -Force
            $operatorRows += $row
        }
    }

    if ($findingRows.Count -gt 0) {
        Show-Line ("Обнаружены субъекты, способные получить контроль над привилегированной группой вне защиты AdminSDHolder: $($findingRows.Count). " +
                   "Проверьте их фактические права.") -Class Finding -FindingId 'PRIVILEGED_GROUP_ACL'
        foreach ($row in $findingRows) { Show-Object $row -Class Finding }
    }
    if ($operatorRows.Count -gt 0) {
        Show-Line ("Обнаружены субъекты, способные получить контроль над операторской группой вне защиты AdminSDHolder: $($operatorRows.Count). " +
                   "Проверьте разрешения этих субъектов.") -Class Hint -FindingId 'PRIVILEGED_GROUP_ACL'
        foreach ($row in $operatorRows) { Show-Object $row -Class Hint }
    }
    if ($hintRows.Count -gt 0) {
        Show-Line "Ожидаемые либо привилегированные субъекты с такими же разрешениями: $($hintRows.Count)" -Class Hint
        foreach ($row in $hintRows) { Show-Object $row -Class Hint }
    }

    if ($findingRows.Count -eq 0 -and $operatorRows.Count -eq 0 -and $hintRows.Count -eq 0) {
        if ($examinedGroups.Count -eq 0) {
            if ($unreadGroups.Count -eq 0) {
                Show-Line "Все найденные привилегированные группы защищаются AdminSDHolder" -Class Note
            }
            return
        }
        $cleanClass = 'Secure'
        if ($unreadGroups.Count -gt 0) { $cleanClass = 'Note' }
        $cleanText = "No principal beyond the expected ones can change the $($examinedGroups.Count) privileged group(s) AdminSDHolder does not protect"
        if ($suppressed.Count -gt 0) {
            $cleanText += " - $($suppressed.Count) expected or privileged holder(s) hidden, use -IncludePrivileged to see them"
        }
        Show-Line $cleanText -Class $cleanClass
    }
}

<#
.SYNOPSIS
    The rights one ACE grants that take over the account carrying it.

.DESCRIPTION
    Internal helper of Show-PrivilegedAccountACL. Returns one object per right, Key being
    the name DefaultRightHolders and the AdminSDHolder comparison use and Text the row a
    reader sees. Full control is named alone - it contains every right below, and listing
    them beside it would say the same several times.

.PARAMETER Rule
    An ActiveDirectoryAccessRule.

.PARAMETER ObjectClass
    The class of the account; msDS-GroupMSAMembership counts on a group or delegated
    managed service account only, the two classes that have the attribute.
#>
function Get-AccountTakeoverRight {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        $Rule,

        [Parameter(Mandatory = $false)]
        [string]$ObjectClass
    )

    $mask = $Rule.ActiveDirectoryRights
    $objectType = $Rule.ObjectType
    $objectTypeIsEmpty = (-not $objectType -or $objectType -eq [Guid]::Empty)

    # Test-ADRightsMask expands the generic bits - see the AdminSDHolder step.
    if ($objectTypeIsEmpty -and (Test-ADRightsMask -Rights $mask -Has ([System.DirectoryServices.ActiveDirectoryRights]::GenericAll))) {
        [PSCustomObject]@{ Key = 'GenericAll'; Text = 'GenericAll' }
        return
    }

    $hasWriteProperty = Test-ADRightsMask -Rights $mask -Has ([System.DirectoryServices.ActiveDirectoryRights]::WriteProperty)
    $hasExtendedRight = Test-ADRightsMask -Rights $mask -Has ([System.DirectoryServices.ActiveDirectoryRights]::ExtendedRight)

    if ($objectTypeIsEmpty) {
        if (Test-ADRightsMask -Rights $mask -Has ([System.DirectoryServices.ActiveDirectoryRights]::WriteDacl)) {
            [PSCustomObject]@{ Key = 'WriteDacl'; Text = 'WriteDacl' }
        }
        if (Test-ADRightsMask -Rights $mask -Has ([System.DirectoryServices.ActiveDirectoryRights]::WriteOwner)) {
            [PSCustomObject]@{ Key = 'WriteOwner'; Text = 'WriteOwner' }
        }
        if ($hasWriteProperty) {
            [PSCustomObject]@{ Key = 'WriteProperty'; Text = 'WriteProperty on every attribute - may add a key credential or an SPN to the account' }
        }
        if ($hasExtendedRight) {
            [PSCustomObject]@{ Key = 'AllExtendedRights'; Text = 'All extended rights - may reset the password of the account' }
        }
        return
    }

    $objectTypeText = ([string]$objectType).ToLowerInvariant()
    if ($hasExtendedRight -and $objectTypeText -eq [string]$Script:ExtendedRightsAliases['ForceChangePassword']) {
        # Not "Reset password ...": OU_PERM_PASSWORD_RESET matches that text - see the
        # AdminSDHolder step.
        [PSCustomObject]@{ Key = 'User-Force-Change-Password'; Text = 'Password reset right - may set a new password for the account' }
    }
    if (-not $hasWriteProperty) { return }

    $written = @(
        @{ Guid = $Script:PropertyGUIDs['msDS-KeyCredentialLink']; Key = 'msDS-KeyCredentialLink'
           Text = 'WriteProperty on msDS-KeyCredentialLink - may add a key credential and log on as the account' }
        @{ Guid = $Script:PropertyGUIDs['servicePrincipalName']; Key = 'servicePrincipalName'
           Text = 'WriteProperty on servicePrincipalName - may give the account an SPN and roast its password' }
        @{ Guid = $Script:PropertyGUIDs['altSecurityIdentities']; Key = 'altSecurityIdentities'
           Text = 'WriteProperty on altSecurityIdentities - may map a certificate onto the account' }
        @{ Guid = $Script:PropertyGUIDs['userAccountControl']; Key = 'userAccountControl'
           Text = 'WriteProperty on userAccountControl - may turn off pre-authentication or the password requirement of the account' }
        @{ Guid = $Script:PropertySetGUIDs['User-Account-Restrictions']; Key = 'userAccountControl'
           Text = 'WriteProperty on userAccountControl - may turn off pre-authentication or the password requirement of the account' }
        @{ Guid = $Script:PropertyGUIDs['scriptPath']; Key = 'scriptPath'
           Text = 'WriteProperty on scriptPath - may set a logon script the account runs' }
    )
    if ($ObjectClass -eq 'msDS-GroupManagedServiceAccount') {
        # msDS-GroupMSAMembership (schemaIDGUID 888eedd6-ce04-df40-b462-b8a50e41ba38) is the
        # list of who may read the managed password.
        $written += @{ Guid = '888eedd6-ce04-df40-b462-b8a50e41ba38'; Key = 'msDS-GroupMSAMembership'
                       Text = 'WriteProperty on msDS-GroupMSAMembership - may allow itself to read the password of the account' }
    } elseif ($ObjectClass -eq 'msDS-DelegatedManagedServiceAccount') {
        # The same attribute on a dMSA names who may request its ticket. Nobody reads a
        # dMSA's password, so the row says what the write gets instead.
        $written += @{ Guid = '888eedd6-ce04-df40-b462-b8a50e41ba38'; Key = 'msDS-GroupMSAMembership'
                       Text = 'WriteProperty on msDS-GroupMSAMembership - may allow itself to use the account' }
    }
    foreach ($entry in $written) {
        if ($entry.Guid -and $objectTypeText -eq ([string]$entry.Guid).ToLowerInvariant()) {
            [PSCustomObject]@{ Key = $entry.Key; Text = $entry.Text }
        }
    }
}

<#
.SYNOPSIS
    Reports who may take over a privileged account through the account's own DACL.

.DESCRIPTION
    Step 5c of Get-PrivilegedGroupMembers (coverage gap A1, 2026-10-17). Step 5 reads the
    AdminSDHolder template and step 5b the DACL of the privileged groups it does not
    protect; the DACL of the privileged accounts themselves was read by nobody. A password
    reset right put on a DnsAdmins member, a key credential write on the group managed
    service account in Domain Admins, an OU delegation that reaches an administrator whose
    account still inherits - each takes the account, and with it the group, over.

    Read are the privileged users and managed service accounts of this domain the steps
    above found. Computers are not: Get-NonDefaultComputerOwners reports the explicit
    entries on every computer object. An account in another domain is not read over this
    connection. Explicit and inherited ACEs alike - both apply to the account - but not an
    inherit-only one, and not an Allow that an explicit Deny for the same trustee cancels
    completely. Whether an ACE is inherited is not said on the row: the card says that an
    inherited one has to be removed at the container it comes from, and the suffix pushed
    the row past the width of the console.

    A holder is a Finding where one account it can take over is in a group worth the
    domain, and a Hint, under a yellow line of its own, where every one is in operator-level
    groups only - each account carries the weight of the heaviest privileged group it is in
    (Get-GroupTakeoverWeight), as the groups of step 5b do. What was read is one object
    (PrivilegedAccountsRead) rather than a line of counts and names.

    An account SDProp protects (adminCount=1) carries the template as explicit ACEs. A right
    the template grants the same trustee is step 5's finding and is not repeated per account;
    a right beyond it was added after SDProp's last run, or the account is no longer
    protected and keeps a stale copy - reported either way. Without the template (step 5 could
    not read it) every ACE is judged on its own.

    The rights: GenericAll, WriteDacl, WriteOwner, a write of every attribute, all extended
    rights, the password reset right, and a write of msDS-KeyCredentialLink (shadow
    credentials), servicePrincipalName (targeted Kerberoasting), altSecurityIdentities
    (certificate mapping), userAccountControl or the User-Account-Restrictions set
    (pre-authentication, password requirement), scriptPath (logon script) and - on a group
    managed service account - msDS-GroupMSAMembership. And the owner, who may rewrite the
    DACL whatever it says.

    Who counts as expected is decided by the gate of steps 5 and 5b, told the rights in
    question: Key Admins and Enterprise Key Admins write msDS-KeyCredentialLink on every user
    by design. Account Operators hold full control over every user AdminSDHolder does not
    protect through the default security descriptor of the user class -
    (A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;AO) on learn.microsoft.com, adschema - which is said
    once, as for the groups.

.PARAMETER Accounts
    The accounts to read: DistinguishedName, Name, SID, ObjectClass, Groups (the
    privileged groups the account is in) and Weight ('Finding' or 'Hint'; none counts as
    'Finding').

.PARAMETER TemplateRules
    The access rules of AdminSDHolder from step 5, or $null when step 5 could not read them.

.PARAMETER IncludePrivileged
    Also list the expected and privileged holders, as hints.

.PARAMETER ConnectionParams
    Domain/Server/Credential hashtable, passed through unchanged.

.PARAMETER AccountOperatorMembers
    How many members Account Operators has, or $null when the group was not found.
#>
function Show-PrivilegedAccountACL {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [AllowEmptyCollection()]
        [object[]]$Accounts,

        [Parameter(Mandatory=$false)]
        [AllowNull()]
        $TemplateRules,

        [Parameter(Mandatory=$false)]
        [switch]$IncludePrivileged,

        [Parameter(Mandatory=$false)]
        [hashtable]$ConnectionParams = @{},

        [Parameter(Mandatory=$false)]
        [AllowNull()]
        $AccountOperatorMembers
    )

    Show-SubHeader "Проверка ACL привилегированных учётных записей..." -ObjectType 'PrivilegedAccountACL'

    $accountOperatorsSID = 'S-1-5-32-548'
    $allowType = [System.Security.AccessControl.AccessControlType]::Allow

    # The template as trustee|right pairs - what SDProp writes onto a protected account.
    # Built for a managed service account, so the one right only that class has is in it.
    $templatePairs = @{}
    foreach ($templateRule in @($TemplateRules)) {
        if (-not $templateRule) { continue }
        if ($templateRule.AccessControlType -ne $allowType -or $templateRule.IsInherited) { continue }
        if (([string]$templateRule.PropagationFlags) -match 'InheritOnly') { continue }
        $templateSID = $templateRule.IdentityReference.Value
        foreach ($right in @(Get-AccountTakeoverRight -Rule $templateRule -ObjectClass 'msDS-GroupManagedServiceAccount')) {
            $templatePairs["$templateSID|$($right.Key)"] = $true
        }
    }

    # Per trustee: the rights it holds, and on which accounts.
    $byTrustee = [ordered]@{}
    $examinedAccounts = 0
    $protectedAccounts = 0
    $unreadAccounts = @()
    $accountOperatorAccounts = @()
    $suppressed = @{}

    foreach ($account in @($Accounts)) {
        if (-not $account -or -not $account.DistinguishedName) { continue }
        $accountName = $(if ($account.Name) { [string]$account.Name } else { [string]$account.DistinguishedName })

        $accountObject = $null
        try {
            $accountObject = @(Get-DomainObject -Identity $account.DistinguishedName -Properties 'nTSecurityDescriptor', 'adminCount' -Raw @ConnectionParams)[0]
        } catch {
            Write-Log "[Get-PrivilegedGroupMembers] Could not read $($account.DistinguishedName): $_"
        }
        if (-not $accountObject -or -not $accountObject.nTSecurityDescriptor) {
            $unreadAccounts += $accountName
            continue
        }

        $descriptor = New-Object System.DirectoryServices.ActiveDirectorySecurity
        try {
            $descriptor.SetSecurityDescriptorBinaryForm([byte[]]$accountObject.nTSecurityDescriptor)
        } catch {
            Write-Log "[Get-PrivilegedGroupMembers] Could not parse the descriptor of $($account.DistinguishedName): $_"
            $unreadAccounts += $accountName
            continue
        }
        $examinedAccounts++
        $isProtected = ("$($accountObject.adminCount)" -eq '1')
        if ($isProtected) { $protectedAccounts++ }

        # SecurityIdentifier, not .Access - see the AdminSDHolder step.
        $rules = @($descriptor.GetAccessRules($true, $true, [System.Security.Principal.SecurityIdentifier]))
        $denyRules = @($rules | Where-Object { $_.AccessControlType -eq [System.Security.AccessControl.AccessControlType]::Deny })

        # Trustee SID -> the rights it holds on this account.
        $onThisAccount = [ordered]@{}

        foreach ($ace in $rules) {
            if ($ace.AccessControlType -ne $allowType) { continue }
            if (([string]$ace.PropagationFlags) -match 'InheritOnly') { continue }

            $trusteeSID = $ace.IdentityReference.Value
            # SELF, CREATOR OWNER and the account itself: whoever holds them is the account.
            if ($trusteeSID -in @('S-1-5-10', 'S-1-3-0')) { continue }
            if ($account.SID -and $trusteeSID -eq [string]$account.SID) { continue }
            if ($denyRules.Count -gt 0 -and (Test-ACEFullyDenied -ACE $ace -DenyACEs $denyRules)) { continue }

            $rights = @(Get-AccountTakeoverRight -Rule $ace -ObjectClass ([string]$account.ObjectClass))
            if ($isProtected -and -not $ace.IsInherited) {
                $rights = @($rights | Where-Object { -not $templatePairs.ContainsKey("$trusteeSID|$($_.Key)") })
            }
            if ($rights.Count -eq 0) { continue }

            if (-not $onThisAccount.Contains($trusteeSID)) {
                $onThisAccount[$trusteeSID] = [PSCustomObject]@{ Rights = @() }
            }
            $held = $onThisAccount[$trusteeSID]
            foreach ($right in $rights) {
                if (@($held.Rights | ForEach-Object { $_.Key }) -notcontains $right.Key) { $held.Rights += $right }
            }
        }

        # The owner may rewrite the DACL whatever it says - the same as WriteDacl.
        $ownerSID = $null
        try { $ownerSID = $descriptor.GetOwner([System.Security.Principal.SecurityIdentifier]).Value } catch { $ownerSID = $null }
        if ($ownerSID -and -not ($account.SID -and $ownerSID -eq [string]$account.SID)) {
            if (-not $onThisAccount.Contains($ownerSID)) {
                $onThisAccount[$ownerSID] = [PSCustomObject]@{ Rights = @() }
            }
            $onThisAccount[$ownerSID].Rights += [PSCustomObject]@{ Key = 'Owner'; Text = 'Owner of the account - may rewrite its DACL' }
        }

        $accountText = $accountName
        if (@($account.Groups).Count -gt 0) { $accountText += " ($(@($account.Groups) -join ', '))" }
        # One without a weight counts as Finding.
        $accountWeight = 'Finding'
        if ($account.PSObject.Properties['Weight'] -and $account.Weight) { $accountWeight = [string]$account.Weight }

        foreach ($trusteeSID in @($onThisAccount.Keys)) {
            $held = $onThisAccount[$trusteeSID]
            $heldKeys = @($held.Rights | ForEach-Object { $_.Key })

            if ($trusteeSID -eq $accountOperatorsSID) {
                $accountOperatorAccounts += $accountName
                if (-not $IncludePrivileged) { continue }
                $severity = 'Attention'
            } else {
                # The gate of steps 5 and 5b, told the rights: Key Admins hold the key
                # credential write by design and nothing else here.
                $scopeResult = Test-IsExpectedInScope -Identity $trusteeSID -Scope 'DomainRootACL' -Rights $heldKeys -ReturnDetails
                $severity = $scopeResult.Severity
                if ($severity -notin @('Expected', 'Attention')) {
                    $exchangeCheck = Test-IsExchangeServiceGroup -Identity $trusteeSID
                    if ($exchangeCheck -and $exchangeCheck.IsExchangeService) { $severity = 'Attention' }
                }
                if ($severity -in @('Expected', 'Attention') -and -not $IncludePrivileged) {
                    $suppressed[$trusteeSID] = $true
                    continue
                }
            }

            if (-not $byTrustee.Contains($trusteeSID)) {
                $byTrustee[$trusteeSID] = [PSCustomObject]@{ Rights = @(); Accounts = @(); Severity = $severity; Weight = 'Hint' }
            }
            $entry = $byTrustee[$trusteeSID]
            foreach ($right in $held.Rights) {
                if ($entry.Rights -notcontains $right.Text) { $entry.Rights += $right.Text }
            }
            # Whether the ACE is inherited is not said here - see the description.
            $entry.Accounts += $accountText
            # The heaviest account decides.
            if ($accountWeight -eq 'Finding') { $entry.Weight = 'Finding' }
        }
    }

    # What was read, as an object rather than as a line of counts that ran past the width of
    # the console. That the template's grants on a protected account are reported with
    # AdminSDHolder is the card's.
    if ($examinedAccounts -gt 0 -or $unreadAccounts.Count -gt 0) {
        $scope = [PSCustomObject]@{ accountsRead = $examinedAccounts }
        if ($protectedAccounts -gt 0) {
            $scope | Add-Member -NotePropertyName 'protectedByAdminSDHolder' -NotePropertyValue $protectedAccounts -Force
        }
        if ($unreadAccounts.Count -gt 0) {
            $scope | Add-Member -NotePropertyName 'accountsNotRead' -NotePropertyValue @($unreadAccounts) -Force
        }
        $scope | Add-Member -NotePropertyName '_adPEASObjectType' -NotePropertyValue 'PrivilegedAccountsRead' -Force
        Show-Line "Прочитанные привилегированные учётные записи:" -Class Note
        Show-Object $scope -Class Note
    }

    # Account Operators: the default, said once - see the description. Short: what a member
    # of Account Operators can do with it is the card's.
    if ($accountOperatorAccounts.Count -gt 0) {
        $aoReach = if ($accountOperatorAccounts.Count -eq $examinedAccounts) { "$examinedAccounts из $examinedAccounts" } else { "$($accountOperatorAccounts.Count) из $examinedAccounts" }
        $aoMembers = ''
        $aoClass = 'Note'
        if ($null -ne $AccountOperatorMembers -and [int]$AccountOperatorMembers -gt 0) {
            $aoMembers = " (участников: $AccountOperatorMembers)"
            $aoClass = 'Hint'
        } elseif ($null -ne $AccountOperatorMembers) {
            $aoMembers = ' (нет участников)'
        }
        Show-Line "Группа Account Operators$aoMembers по умолчанию имеет права управления: $aoReach учётными записями, не защищёнными AdminSDHolder" -Class $aoClass -FindingId 'PRIVILEGED_ACCOUNT_ACL'
    }

    $accountFindingRows = @()
    $accountOperatorRows = @()
    $accountHintRows = @()
    foreach ($trusteeSID in @($byTrustee.Keys)) {
        $entry = $byTrustee[$trusteeSID]
        $trusteeName = ConvertFrom-SID -SID $trusteeSID
        if (-not $trusteeName) { $trusteeName = $trusteeSID }

        $row = [PSCustomObject]@{
            Name             = $trusteeName
            Trustee          = $trusteeName
            TrusteeSID       = $trusteeSID
            dangerousRights  = @($entry.Rights)
            affectedAccounts = @($entry.Accounts)
        }
        $row | Add-Member -NotePropertyName '_adPEASObjectType' -NotePropertyValue 'PrivilegedAccountACL' -Force
        if ($entry.Severity -in @('Expected', 'Attention')) {
            $row | Add-Member -NotePropertyName 'dangerousRightsSeverity' -NotePropertyValue 'Hint' -Force
            $accountHintRows += $row
        } elseif ($entry.Weight -eq 'Finding') {
            $accountFindingRows += $row
        } else {
            # Members of operator-level groups only: a foothold, not the domain - see
            # Get-GroupTakeoverWeight. dangerousRightsSeverity turns the rows yellow.
            $row | Add-Member -NotePropertyName 'dangerousRightsSeverity' -NotePropertyValue 'Hint' -Force
            $accountOperatorRows += $row
        }
    }

    if ($accountFindingRows.Count -gt 0) {
        Show-Line "Субъекты, способные получить контроль над привилегированной учётной записью: $($accountFindingRows.Count)" -Class Finding -FindingId 'PRIVILEGED_ACCOUNT_ACL'
        foreach ($row in $accountFindingRows) { Show-Object $row -Class Finding }
    }
    if ($accountOperatorRows.Count -gt 0) {
        Show-Line "Субъекты, способные получить контроль над участником операторской группы: $($accountOperatorRows.Count)" -Class Hint -FindingId 'PRIVILEGED_ACCOUNT_ACL'
        foreach ($row in $accountOperatorRows) { Show-Object $row -Class Hint }
    }
    if ($accountHintRows.Count -gt 0) {
        Show-Line "Ожидаемые либо привилегированные субъекты с такими же разрешениями: $($accountHintRows.Count)" -Class Hint
        foreach ($row in $accountHintRows) { Show-Object $row -Class Hint }
    }

    if ($accountFindingRows.Count -eq 0 -and $accountOperatorRows.Count -eq 0 -and $accountHintRows.Count -eq 0) {
        if ($examinedAccounts -eq 0) {
            if ($unreadAccounts.Count -eq 0) {
                Show-Line "Не найдено привилегированных пользовательских или служебных учётных записей домена" -Class Note
            }
            return
        }
        $accountCleanClass = 'Secure'
        if ($unreadAccounts.Count -gt 0) { $accountCleanClass = 'Note' }
        $accountCleanText = "No principal beyond the expected ones can take over the $examinedAccounts privileged account(s) read"
        if ($suppressed.Count -gt 0) {
            $accountCleanText += " - $($suppressed.Count) expected or privileged holder(s) hidden, use -IncludePrivileged to see them"
        }
        Show-Line $accountCleanText -Class $accountCleanClass
    }
}

