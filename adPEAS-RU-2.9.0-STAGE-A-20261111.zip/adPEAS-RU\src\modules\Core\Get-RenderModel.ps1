﻿<#
.SYNOPSIS
    Central RenderModel builder for adPEAS output.

.DESCRIPTION
    Produces a unified RenderModel that both Console and HTML renderers consume.
    This is the SINGLE SOURCE OF TRUTH for:
    - Which attributes are shown (via Get-OrderedAttributes / PrimaryAttributes)
    - What severity each attribute has (via Get-TriggerMatch)
    - What tooltip each value gets (via Get-TriggerMatch FindingId)
    - How values are transformed (via AttributeTransformers)

    The RenderModel architecture provides a single pipeline where attribute selection,
    severity, and formatting are determined once, then consumed by both
    Render-ConsoleObject.ps1 (console) and Render-HtmlObject.ps1 (HTML).

.NOTES
    Author: Alexander Sturz (@_61106960_)
    Requires: adPEAS-AttributeOrder.ps1, adPEAS-FindingDefinitions.ps1, AttributeTransformers.ps1
#>

# ============================================================================
# Transformer Registry
# Maps attribute names to transformer functions.
# Attributes not in this registry use the default transformer.
# Populated by AttributeTransformers.ps1 after it loads.
# ============================================================================
$Script:AttributeTransformers = @{}

# ============================================================================
# Factory Functions
# ============================================================================

<#
.SYNOPSIS
    Creates a new RenderValue object.
.PARAMETER Display
    The display text for this value (resolved name, formatted string, etc.)
.PARAMETER Severity
    Per-value severity: Finding, Hint, Secure, Note, or Standard.
.PARAMETER FindingId
    Optional FindingDefinition ID for HTML tooltip.
.PARAMETER RawValue
    The original unprocessed value.
.PARAMETER Metadata
    Optional hashtable with extra info (SID, DN, etc.)
#>
function New-RenderValue {
    [CmdletBinding()]
    param(
        # AllowEmptyString: a blank display value must never abort rendering. Mandatory [string]
        # otherwise rejects '' and the exception propagates out of Show-Object, so a single
        # attribute with a blank line silently costs the caller the whole object.
        [Parameter(Mandatory=$true)]
        [AllowEmptyString()]
        [string]$Display,

        [Parameter(Mandatory=$false)]
        [string]$Severity = 'Standard',

        [Parameter(Mandatory=$false)]
        [string]$FindingId = $null,

        [Parameter(Mandatory=$false)]
        $RawValue = $null,

        [Parameter(Mandatory=$false)]
        [hashtable]$Metadata = @{}
    )

    [PSCustomObject]@{
        PSTypeName = 'adPEAS.RenderValue'
        Display    = $Display
        Severity   = $Severity
        FindingId  = $FindingId
        RawValue   = $RawValue
        Metadata   = $Metadata
    }
}

<#
.SYNOPSIS
    Creates a new RenderRow object.
.PARAMETER Name
    Display name for the attribute.
.PARAMETER RawName
    Original attribute name.
.PARAMETER RowType
    SingleValue, MultiValue, Image, or Hash.
.PARAMETER OverallSeverity
    Aggregate severity for the attribute label.
.PARAMETER FindingId
    Optional row-level FindingId.
.PARAMETER Values
    Array of RenderValue objects.
.PARAMETER ForceAttributeClass
    Whether to force attribute name coloring even if all values are Standard.
#>
function New-RenderRow {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [string]$Name,

        [Parameter(Mandatory=$false)]
        [string]$RawName = $Name,

        [Parameter(Mandatory=$false)]
        [string]$RowType = 'SingleValue',

        [Parameter(Mandatory=$false)]
        [string]$OverallSeverity = 'Standard',

        [Parameter(Mandatory=$false)]
        [string]$FindingId = $null,

        [Parameter(Mandatory=$false)]
        [array]$Values = @(),

        [Parameter(Mandatory=$false)]
        [bool]$ForceAttributeClass = $false
    )

    [PSCustomObject]@{
        PSTypeName         = 'adPEAS.RenderRow'
        Name               = $Name
        RawName            = $RawName
        RowType            = $RowType
        OverallSeverity    = $OverallSeverity
        FindingId          = $FindingId
        Values             = $Values
        ForceAttributeClass = $ForceAttributeClass
    }
}

# ============================================================================
# Default Transformer
# ============================================================================

<#
.SYNOPSIS
    Default transformer for attributes without a registered custom transformer.
.DESCRIPTION
    Determines severity and FindingId via Get-TriggerMatch,
    and handles common value types (scalar, array, multi-line string, ImageData).
#>
function Convert-DefaultToRenderValues {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [string]$Name,

        [Parameter(Mandatory=$true)]
        $Value,

        [Parameter(Mandatory=$true)]
        $Context
    )

    # Handle ImageData objects (thumbnailPhoto, jpegPhoto)
    if ($Value -is [PSCustomObject] -and ($Value.psobject.TypeNames -contains 'adPEAS.ImageData')) {
        return @{
            RowType         = 'Image'
            OverallSeverity = 'Standard'
            ForceAttributeClass = $false
            Values          = @(
                New-RenderValue -Display $Value.DisplayText -Severity 'Standard' -RawValue $Value
            )
        }
    }

    # A structured value that brings its own display line - a certificate from
    # Convert-CertificateToInfo - or whose parts do - a security descriptor from
    # ConvertFrom-SecurityDescriptor, shown as its owner and then one line per ACE. Such a
    # value used to fall through to the scalar path below, and the card showed what
    # [string] makes of an object: "@{Owner=; ACEs=System.Object[]}".
    if ($Value -is [System.Management.Automation.PSCustomObject]) {
        $displayItems = @()
        if ($Value.PSObject.Properties['DisplayText']) {
            $displayItems = @($Value)
        } else {
            foreach ($property in $Value.PSObject.Properties) {
                foreach ($part in @($property.Value)) {
                    if ($part -is [System.Management.Automation.PSCustomObject] -and $part.PSObject.Properties['DisplayText']) {
                        $displayItems += $part
                    }
                }
            }
        }

        if ($displayItems.Count -gt 0) {
            $renderValues = @()
            foreach ($item in $displayItems) {
                $itemDisplay = [string]$item.DisplayText
                if ([string]::IsNullOrEmpty($itemDisplay)) { continue }
                $itemMatch = Get-TriggerMatch -Name $Name -Value $item -IsComputer $Context.IsComputer -SourceObject $Context.SourceObject
                $renderValues += New-RenderValue -Display $itemDisplay -Severity $itemMatch.Severity -FindingId $itemMatch.FindingId -RawValue $item
            }
            if ($renderValues.Count -eq 0) { return $null }
            $maxSev = Get-MaxSeverityFromValues -Values $renderValues
            return @{
                RowType         = 'MultiValue'
                OverallSeverity = $maxSev
                ForceAttributeClass = ($maxSev -ne 'Standard')
                Values          = $renderValues
            }
        }
    }

    # Handle multi-line strings (e.g., siteIPSubnets, domainControllers)
    if ($Value -is [string] -and $Value -match "`n") {
        $lines = $Value -split "`n"
        $renderValues = @()
        foreach ($line in $lines) {
            # Blank lines carry no information and would render as empty rows. AD free-text
            # attributes (description, info) routinely contain them and trailing newlines.
            $line = $line.TrimEnd("`r")
            if ([string]::IsNullOrWhiteSpace($line)) { continue }
            $lineMatch = Get-TriggerMatch -Name $Name -Value $line -IsComputer $Context.IsComputer -SourceObject $Context.SourceObject
            $renderValues += New-RenderValue -Display $line -Severity $lineMatch.Severity -FindingId $lineMatch.FindingId -RawValue $line
        }
        if ($renderValues.Count -eq 0) { return $null }
        $maxSev = Get-MaxSeverityFromValues -Values $renderValues
        return @{
            RowType         = 'MultiValue'
            OverallSeverity = $maxSev
            ForceAttributeClass = ($maxSev -ne 'Standard')
            Values          = $renderValues
        }
    }

    # Handle arrays
    if ($Value -is [array]) {
        # Check if array contains objects with DisplayText (e.g., privilegedGroups structured format)
        $firstItem = $Value | Select-Object -First 1
        if ($firstItem -is [PSCustomObject] -and $firstItem.PSObject.Properties['DisplayText']) {
            # Array of objects with DisplayText - use DisplayText for display
            $renderValues = @()
            foreach ($item in $Value) {
                $itemDisplay = [string]$item.DisplayText
                if ([string]::IsNullOrEmpty($itemDisplay)) { continue }
                $itemMatch = Get-TriggerMatch -Name $Name -Value $item -IsComputer $Context.IsComputer -SourceObject $Context.SourceObject
                $renderValues += New-RenderValue -Display $itemDisplay -Severity $itemMatch.Severity -FindingId $itemMatch.FindingId -RawValue $item
            }
            if ($renderValues.Count -eq 0) { return $null }
            $maxSev = Get-MaxSeverityFromValues -Values $renderValues
            return @{
                RowType         = 'MultiValue'
                OverallSeverity = $maxSev
                ForceAttributeClass = ($maxSev -ne 'Standard')
                Values          = $renderValues
            }
        }

        # Check if array contains LinkedOUs objects (from Get-GPOLinkage)
        if ($firstItem -is [PSCustomObject] -and $firstItem.PSObject.Properties['DistinguishedName'] -and $firstItem.PSObject.Properties['Scope']) {
            # Display full DistinguishedName with LinkStatus for clarity
            $renderValues = @()
            foreach ($item in $Value) {
                $ouDisplay = $item.DistinguishedName
                if ([string]::IsNullOrWhiteSpace($ouDisplay)) { continue }

                # Append LinkStatus if not standard Enabled (show Disabled/Enforced explicitly)
                if ($item.LinkStatus -and $item.LinkStatus -ne 'Enabled') {
                    $ouDisplay = "$ouDisplay ($($item.LinkStatus))"
                }

                # Check each OU individually for trigger matches (e.g., domain-level GPO links)
                $itemMatch = Get-TriggerMatch -Name $Name -Value $item.DistinguishedName -IsComputer $Context.IsComputer -SourceObject $Context.SourceObject
                $renderValues += New-RenderValue -Display $ouDisplay -Severity $itemMatch.Severity -FindingId $itemMatch.FindingId -RawValue $item
            }
            if ($renderValues.Count -eq 0) { return $null }
            $maxSev = Get-MaxSeverityFromValues -Values $renderValues
            return @{
                RowType         = 'MultiValue'
                OverallSeverity = $maxSev
                ForceAttributeClass = ($maxSev -ne 'Standard')
                Values          = $renderValues
            }
        }

        # Simple array of strings - render as MultiValue (one line per item)
        # Skip empty arrays (e.g., LinkedOUs = @() on GPO tasks)
        if ($Value.Count -eq 0) { return $null }
        $renderValues = @()
        foreach ($item in $Value) {
            # A DateTime through Format-adPEASDate, as for a single value below.
            $itemIsDate = $item -is [datetime]
            $itemStr = if ($itemIsDate) { Format-adPEASDate -Date $item } else { [string]$item }
            if ([string]::IsNullOrEmpty($itemStr)) { continue }
            $itemMatch = Get-TriggerMatch -Name $Name -Value $(if ($itemIsDate) { $item } else { $itemStr }) -IsComputer $Context.IsComputer -SourceObject $Context.SourceObject
            $renderValues += New-RenderValue -Display $itemStr -Severity $itemMatch.Severity -FindingId $itemMatch.FindingId -RawValue $item
        }
        if ($renderValues.Count -eq 0) { return $null }
        $maxSev = Get-MaxSeverityFromValues -Values $renderValues
        return @{
            RowType         = 'MultiValue'
            OverallSeverity = $maxSev
            ForceAttributeClass = ($maxSev -ne 'Standard')
            Values          = $renderValues
        }
    }

    # Simple scalar value. A DateTime goes through Format-adPEASDate: cast to [string] it
    # takes the invariant culture's MM/dd/yyyy, and "07/04/2025" reads as the 7th of April
    # to most readers of a report that means the 4th of July - pwdLastSet and
    # lastLogonTimestamp of every object came out that way.
    $displayValue = if ($Value -is [datetime]) { Format-adPEASDate -Date $Value } else { [string]$Value }
    # Skip empty scalar values that slipped through the filter
    if ([string]::IsNullOrEmpty($displayValue)) { return $null }
    # Pass original $Value (not $displayValue) so typed objects (DateTime, Int64) are preserved
    # for Custom triggers like pwdAge_gt_1825 that need Get-DateFromValue to work correctly
    $scalarMatch = Get-TriggerMatch -Name $Name -Value $Value -IsComputer $Context.IsComputer -SourceObject $Context.SourceObject
    return @{
        RowType         = 'SingleValue'
        OverallSeverity = $scalarMatch.Severity
        ForceAttributeClass = $false
        Values          = @(
            New-RenderValue -Display $displayValue -Severity $scalarMatch.Severity -FindingId $scalarMatch.FindingId -RawValue $Value
        )
    }
}

# ============================================================================
# Helper Functions
# ============================================================================

<#
.SYNOPSIS
    Gets the maximum severity from an array of RenderValue objects.
#>
function Get-MaxSeverityFromValues {
    [CmdletBinding()]
    param([array]$Values)

    $priority = @{ 'Finding' = 4; 'Secure' = 3; 'Hint' = 2; 'Note' = 1; 'Standard' = 0 }
    $maxPriority = 0
    $maxSeverity = 'Standard'

    foreach ($v in $Values) {
        $p = $priority[$v.Severity]
        if ($null -ne $p -and $p -gt $maxPriority) {
            $maxPriority = $p
            $maxSeverity = $v.Severity
            if ($maxSeverity -eq 'Finding') { return 'Finding' }
        }
    }
    return $maxSeverity
}

<#
.SYNOPSIS
    Builds a RenderRow from a transformer result hashtable.
#>
function Build-RenderRow {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [string]$Name,

        [Parameter(Mandatory=$true)]
        [hashtable]$TransformResult,

        # Per-ObjectType label from $Script:AttributeLabels, when one is configured for
        # this attribute. Used where the property name is not what a reader should see -
        # a GPO's LDAP `Name`, which is its GUID.
        [Parameter(Mandatory=$false)]
        [string]$Label
    )

    # A transformer's own DisplayName wins: it is attribute-specific and may encode the
    # value's state (e.g. "Owner (non-default)"). The type label is the next most
    # specific, and the property name is the fallback.
    $displayName = if ($TransformResult.DisplayName) {
        $TransformResult.DisplayName
    } elseif ($Label) {
        $Label
    } else {
        $Name
    }

    # Row-level FindingId: if single value with FindingId, promote to row level
    $rowFindingId = $TransformResult.FindingId
    if (-not $rowFindingId -and $TransformResult.Values.Count -eq 1 -and $TransformResult.Values[0].FindingId) {
        $rowFindingId = $TransformResult.Values[0].FindingId
    }

    New-RenderRow -Name $displayName `
                  -RawName $Name `
                  -RowType ($TransformResult.RowType) `
                  -OverallSeverity ($TransformResult.OverallSeverity) `
                  -FindingId $rowFindingId `
                  -Values ($TransformResult.Values) `
                  -ForceAttributeClass ([bool]$TransformResult.ForceAttributeClass)
}

# ============================================================================
# Object Type Detection and Activity Status (used by Get-RenderModel)
# ============================================================================

<#
.SYNOPSIS
    Detects if an object is a Computer account.
.PARAMETER Object
    The object to check.
.RETURNS
    $true if the object is a Computer, $false otherwise.
#>
function Test-IsComputerObject {
    param($Object)

    return (($Object.objectClass -contains "computer") -or ($Object.sAMAccountName -like '*$'))
}

<#
.SYNOPSIS
    Converts an AD timestamp value to a DateTime.
.DESCRIPTION
    Handles the timestamp representations that occur on AD objects:
    - DateTime objects (pass through)
    - FileTime integers (lastLogonTimestamp, pwdLastSet)
    - FileTime as string
    - Generalized Time strings (whenCreated, e.g. "20180101000000.0Z")
    - Generic DateTime strings (fallback)
    Returns $null for "never" / unset values (0, Int64.MaxValue) or on failure.
.PARAMETER Value
    The raw timestamp value (may be wrapped in a single-element array).
#>
function ConvertTo-ActivityDate {
    param($Value)

    if ($null -eq $Value) { return $null }
    if ($Value -is [array]) {
        if ($Value.Count -eq 0) { return $null }
        $Value = $Value[0]
    }

    if ($Value -is [DateTime]) { return $Value }

    if ($Value -is [long] -or $Value -is [int]) {
        if ($Value -le 0 -or $Value -eq 9223372036854775807) { return $null }
        try { return [DateTime]::FromFileTime([long]$Value) } catch { return $null }
    }

    if ($Value -is [string]) {
        # Generalized Time (e.g. "20180101000000.0Z" / "20180101000000Z" / bare digits).
        # Checked before the FileTime parse, and anchored to the end: without the
        # trailing Z a generalized time is 14 plain digits, which [long]::TryParse
        # happily accepts. "20180101000000" was then read as a FileTime and came back
        # as 1601-01-24 - four centuries off, and silently, because a valid DateTime
        # came out the other end. Add-ActivityStatus dates never-logged-on accounts by
        # whenCreated, so that turned a brand new account into an ancient one and
        # produced exactly the false positive the guard there exists to prevent.
        # The anchor matters as much as the order: an 18-digit FileTime string starts
        # with 14 digits too, and a loose prefix match would claim it.
        if ($Value -match '^(\d{14})(?:\.\d+)?Z?$') {
            $gtDate = [DateTime]::MinValue
            if ([DateTime]::TryParseExact($Matches[1], 'yyyyMMddHHmmss', [System.Globalization.CultureInfo]::InvariantCulture, [System.Globalization.DateTimeStyles]::AssumeUniversal -bor [System.Globalization.DateTimeStyles]::AdjustToUniversal, [ref]$gtDate)) {
                return $gtDate.ToLocalTime()
            }
        }

        # FileTime stored as string
        $parsed = 0L
        if ([long]::TryParse($Value, [ref]$parsed)) {
            if ($parsed -le 0 -or $parsed -eq 9223372036854775807) { return $null }
            try { return [DateTime]::FromFileTime($parsed) } catch { return $null }
        }

        # Generic DateTime string
        $parsedDate = [DateTime]::MinValue
        if ([DateTime]::TryParse($Value, [ref]$parsedDate)) {
            return $parsedDate
        }
    }

    return $null
}

<#
.SYNOPSIS
    Adds activity status to an object based on logon / password / creation age.
.DESCRIPTION
    Determines whether an account is inactive and, if so, adds an activityStatus
    property (rendered as a Hint). Uses $Script:DefaultInactiveDays by default.

    Detection logic:
    - lastLogonTimestamp present  -> inactive if older than the threshold
    - lastLogonTimestamp missing  -> fall back to pwdLastSet (machine accounts
      rotate their password ~every 30 days, so a stale pwdLastSet means the host
      is effectively dead even though it never recorded a replicated logon).
      If the password was never set either, the account is flagged as
      "never logged on" only when whenCreated proves it is old enough - this
      guards against false positives on freshly created / not-yet-replicated
      accounts.
.PARAMETER Object
    The object to check and potentially modify.
.PARAMETER InactiveDays
    Number of days without login to consider inactive.
    Default: Uses $Script:DefaultInactiveDays (typically 90 days) set by Invoke-adPEAS.
#>
function Add-ActivityStatus {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        $Object,

        [Parameter(Mandatory=$false)]
        [int]$InactiveDays = 0  # 0 = use $Script:DefaultInactiveDays
    )

    # Skip if already classified
    if ($Object.activityStatus) {
        return
    }

    # Only user / computer accounts have a meaningful logon history. Groups,
    # GPOs, OUs, certificate templates, etc. carry whenCreated but never log
    # on, so the whenCreated fallback below would otherwise mark every
    # long-lived group as "INACTIVE (never logged on)".
    $objectClasses = @($Object.objectClass)
    $isAccountObject = ($objectClasses -contains 'user') -or
                       ($objectClasses -contains 'computer') -or
                       ($Object.sAMAccountName -like '*$')
    if (-not $isAccountObject) {
        return
    }

    # Resolve InactiveDays from global constant if not explicitly set
    $effectiveInactiveDays = if ($InactiveDays -gt 0) {
        $InactiveDays
    } elseif ($Script:DefaultInactiveDays) {
        $Script:DefaultInactiveDays
    } else {
        90  # Fallback if global not set
    }

    $cutoffDate = (Get-Date).AddDays(-$effectiveInactiveDays)
    $lastLogonDate = ConvertTo-ActivityDate -Value $Object.lastLogonTimestamp

    if ($lastLogonDate) {
        # Primary signal: a replicated logon timestamp exists
        if ($lastLogonDate -lt $cutoffDate) {
            $Object | Add-Member -NotePropertyName 'activityStatus' -NotePropertyValue "INACTIVE (no login for >$effectiveInactiveDays days)" -Force
        }
        return
    }

    # No lastLogonTimestamp - fall back to secondary signals so old/dead
    # accounts are not silently rendered as if they were alive.
    $pwdLastSetDate = ConvertTo-ActivityDate -Value $Object.pwdLastSet

    if ($pwdLastSetDate) {
        if ($pwdLastSetDate -lt $cutoffDate) {
            $Object | Add-Member -NotePropertyName 'activityStatus' -NotePropertyValue "INACTIVE (no logon recorded, password not changed for >$effectiveInactiveDays days)" -Force
        }
        # Recent password change -> live host whose lastLogonTimestamp simply
        # has not replicated yet. Do not flag (avoids false positives).
        return
    }

    # Password was never set either. Only flag as "never logged on" when
    # whenCreated proves the account is older than the threshold; otherwise it
    # may be a brand-new / not-yet-replicated account.
    $createdDate = ConvertTo-ActivityDate -Value $Object.whenCreated
    if ($createdDate -and $createdDate -lt $cutoffDate) {
        $Object | Add-Member -NotePropertyName 'activityStatus' -NotePropertyValue "INACTIVE (never logged on, account created >$effectiveInactiveDays days ago)" -Force
    }
}

# ============================================================================
# Main Function: Get-RenderModel
# ============================================================================

<#
.SYNOPSIS
    Builds a unified RenderModel from an AD object.
.DESCRIPTION
    Central function that produces a RenderModel consumed by both Console and HTML
    renderers. Determines attribute selection (via Get-OrderedAttributes), severity
    (via Get-TriggerMatch), and transformations (via AttributeTransformers).

    This function is the SINGLE SOURCE OF TRUTH for all output decisions.
.PARAMETER Object
    The AD object or PSCustomObject to render.
.RETURNS
    A PSCustomObject with ObjectType, IsComputer, Primary, Extended, and PostObject arrays.
#>
function Get-RenderModel {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        $Object
    )

    # 1. Detect object type and computer status
    $objectType = Get-ObjectTypeForOrdering -Object $Object
    $isComputer = Test-IsComputerObject -Object $Object

    # 2. Enrich object with activity status if inactive (mutates input object)
    Add-ActivityStatus -Object $Object

    # 3. Build context for transformers
    $context = [PSCustomObject]@{
        IsComputer              = $isComputer
        IsExchangeGroup         = [bool]$Object._isExchangeGroup
        DangerousRightsSeverity = $Object.dangerousRightsSeverity
        CredentialType          = $Object.credentialType
        OwnerSID                = $Object.OwnerSID
        ObjectType              = $objectType
        SourceObject            = $Object
    }

    # 4. Get ordered attribute lists (Primary/Extended)
    $orderedAttrs = Get-OrderedAttributes -Object $Object -PromoteNonStandard -IsComputer $isComputer

    # 5. Transform each attribute into RenderRows
    $primaryRows = [System.Collections.ArrayList]@()
    $extendedRows = [System.Collections.ArrayList]@()
    $postObjectRows = [System.Collections.ArrayList]@()

    # Track attributes for PostObject (rendered after the card in console)
    $postObjectAttributes = @('KerberoastingHash', 'ASREPRoastingHash')

    # Row labels configured for this object type, if any. $null for most types.
    $typeLabels = $Script:AttributeLabels[$objectType]

    foreach ($section in @(
        @{ Source = $orderedAttrs.Primary; Target = 'Primary' },
        @{ Source = $orderedAttrs.Extended; Target = 'Extended' }
    )) {
        foreach ($attrInfo in $section.Source) {
            $name = $attrInfo.Name
            $value = $attrInfo.Value

            # Route PostObject attributes (roasting hashes)
            $isPostObject = $name -in $postObjectAttributes

            # Look up transformer or use default
            $transformer = $Script:AttributeTransformers[$name]
            if ($transformer) {
                $result = & $transformer -Name $name -Value $value -Context $context
            } else {
                $result = Convert-DefaultToRenderValues -Name $name -Value $value -Context $context
            }

            # Skip if transformer returns $null (e.g., Owner that IS default)
            if ($null -eq $result) { continue }

            $rowLabel = if ($typeLabels) { [string]$typeLabels[$name] } else { $null }
            $row = Build-RenderRow -Name $name -TransformResult $result -Label $rowLabel

            if ($isPostObject) {
                [void]$postObjectRows.Add($row)
            } elseif ($section.Target -eq 'Primary') {
                [void]$primaryRows.Add($row)
            } else {
                [void]$extendedRows.Add($row)
            }
        }
    }

    # 6. Return the model
    [PSCustomObject]@{
        PSTypeName  = 'adPEAS.RenderModel'
        ObjectType  = $objectType
        IsComputer  = $isComputer
        Primary     = $primaryRows.ToArray()
        Extended    = $extendedRows.ToArray()
        PostObject  = $postObjectRows.ToArray()
    }
}
