﻿<#
.SYNOPSIS
    Conversion of raw LDAP attribute values into the form the checks consume.

.DESCRIPTION
    Everything adPEAS reads out of the directory passes through ConvertFrom-LDAPAttribute
    below: Invoke-LDAPSearch calls it once per attribute per object, and every check module
    sees only what it returns.

    This used to live inline in Invoke-LDAPSearch's result loop, together with the three
    Convert-* helpers above it, which were declared inside its process block. Nothing could
    test any of it: reaching the conversion meant calling Invoke-LDAPSearch itself, which
    needs a real System.DirectoryServices.Protocols.SearchResponse - and SearchResultEntry
    has no public constructor. The helpers were reachable from the conversion only through
    PowerShell's dynamic scoping, which works when Invoke-LDAPSearch is the caller and
    nowhere else.

    gPLink is deliberately NOT converted here, and must not be. It used to be rewritten
    into a readable list - "GPO {GUID} [Enabled]" per link - which threw away the GPO's
    distinguished name and the link option digit and turned a single string into an array.
    Nothing displays gPLink, so that readability reached no one, while three callers that
    need the attribute itself were reading a rendering of it:

      - Get-GPOLinkage parses "[LDAP://<dn>;<options>]" per entry. With the option digit
        gone it could not read link status at all, and once its pattern was tightened to
        require the raw form it matched nothing, so every GPO in the report came out
        "NOT LINKED".
      - Invoke-adPEASCollector parses the same form for BloodHound's GPO link edges.
      - Set-DomainGPO -LinkTo prepends its new entry to the current value and writes the
        result back with a Replace modification. Handed the rendering, it would have
        replaced every existing link on the target OU with unparseable text.

    Rendering belongs where something is displayed, not in the layer that reads the
    directory.

.NOTES
    Author: Alexander Sturz (@_61106960_)
    Requires: adPEAS-OIDs.ps1 (Convert-OIDsToNames, ConvertFrom-OID), ConvertFrom-SID.ps1,
              ConvertFrom-SecurityDescriptor.ps1, ConvertFrom-KeyCredentialLink.ps1,
              ConvertFrom-LAPSEncryptedPassword.ps1, ConvertFrom-TSProperties.ps1,
              ConvertFrom-TSClientLicense.ps1
#>

# ============================================================================
# Attribute name sets consulted for every non-binary single value
# ============================================================================
# Constant lookup tables, built once at load time (and therefore not part of
# Clear-SessionState). Inside the conversion these were rebuilt for every attribute of
# every object - a scan of 10.000 objects with 30 attributes each allocated both arrays
# 300.000 times for nothing. HashSet for the same reason Invoke-LDAPSearch keeps its
# binary-attribute list as one; the names are compared case-insensitively, which is what
# the previous -contains on an array of lowercase names did.

# Windows FILETIME - 100-nanosecond intervals since 1601-01-01.
#
# The five domain policy intervals (maxpwdage, minpwdage, lockoutduration,
# lockoutobservationwindow, forcelogoff) are in here although they are negative durations
# rather than timestamps. [DateTime]::FromFileTime throws on those, the conversion below
# catches it and hands back the raw interval string, and Get-DomainPasswordPolicy converts
# that itself - see the note there. Keeping them listed is what produces that raw value;
# removing them would change what every consumer of those five attributes receives.
$Script:LDAPFileTimeAttributes = [System.Collections.Generic.HashSet[string]]::new(
    [string[]]@(
        'lastlogon', 'lastlogontimestamp', 'pwdlastset', 'badpasswordtime',
        'lockouttime', 'accountexpires', 'lastlogoff', 'maxpwdage', 'minpwdage',
        'forcelogoff', 'lockoutduration', 'lockoutobservationwindow',
        'creationtime', 'lastsettime'
    ),
    [System.StringComparer]::OrdinalIgnoreCase)

# Generalized Time (ISO 8601: YYYYMMDDHHmmss.0Z).
$Script:LDAPGeneralizedTimeAttributes = [System.Collections.Generic.HashSet[string]]::new(
    [string[]]@('whenchanged', 'whencreated', 'msexchwhenmailboxcreated'),
    [System.StringComparer]::OrdinalIgnoreCase)

# Helper: Convert X.509 certificate bytes to structured object
function Convert-CertificateToInfo {
    param([byte[]]$CertBytes)
    try {
        $Cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2 -ArgumentList @(,$CertBytes)

        # Extract Subject CN
        $SubjectCN = if ($Cert.Subject -match 'CN=([^,]+)') { $Matches[1] } else { $Cert.Subject }

        # Extract Issuer CN
        $IssuerCN = if ($Cert.Issuer -match 'CN=([^,]+)') { $Matches[1] } else { $Cert.Issuer }

        # Determine certificate status
        $Status = if ((Get-Date) -gt $Cert.NotAfter) { "EXPIRED" }
                  elseif ((Get-Date) -lt $Cert.NotBefore) { "Not yet valid" }
                  else { "Valid" }

        # Extract Subject Alternative Name (SAN) - OID 2.5.29.17
        $SAN = $null
        $SANExtension = $Cert.Extensions | Where-Object { $_.Oid.Value -eq "2.5.29.17" }
        if ($SANExtension) {
            # Format the SAN for display
            $SANFormatted = $SANExtension.Format($false)
            if ($SANFormatted) {
                $SAN = $SANFormatted
            }
        }

        # Extract Enhanced Key Usage (EKU)
        $EKU = $null
        $EKUExtension = $Cert.Extensions | Where-Object { $_ -is [System.Security.Cryptography.X509Certificates.X509EnhancedKeyUsageExtension] }
        if ($EKUExtension) {
            $EKUList = @()
            foreach ($oid in $EKUExtension.EnhancedKeyUsages) {
                $EKUList += "$($oid.FriendlyName) ($($oid.Value))"
            }
            $EKU = $EKUList -join ", "
        }

        # Signature Algorithm (e.g., sha256RSA, sha1RSA)
        $SigAlgo = $Cert.SignatureAlgorithm.FriendlyName

        # Public Key Length
        $KeyLength = 0
        try {
            if ($Cert.PublicKey -and $Cert.PublicKey.Key) {
                $KeyLength = $Cert.PublicKey.Key.KeySize
            }
        } catch {
            # Some key types may not expose KeySize
        }

        # Basic Constraints (OID 2.5.29.19) - CA flag and path length
        $HasBasicConstraints = $false
        $BasicConstraintsPathLength = 0
        $bcExt = $Cert.Extensions | Where-Object { $_.Oid.Value -eq '2.5.29.19' }
        if ($bcExt) {
            $HasBasicConstraints = $true
            try {
                $bcTyped = [System.Security.Cryptography.X509Certificates.X509BasicConstraintsExtension]$bcExt
                if ($bcTyped.HasPathLengthConstraint) {
                    $BasicConstraintsPathLength = $bcTyped.PathLengthConstraint
                }
            } catch { }
        }

        # One URL per line of the multi-line Format($true). Windows prints a URL that needs
        # escaping twice - "URL=<as stored> (<percent-encoded>)" - and the stored form of an
        # LDAP URL has commas and spaces in its DN (CN=Public Key Services), so the URL is
        # the rest of the line minus that encoded copy. Cutting at the first comma or space,
        # as this did, turned every AD CS LDAP location into "ldap:///CN=<CA name>", once for
        # each copy.
        $urlLinePattern = '^\s*URL=(?<url>.+?)(?:\s\([a-z][a-z0-9+.-]*://[^\s)]*\))?\s*$'

        # CRL Distribution Points (OID 2.5.29.31)
        $CRLDistributionPoints = @()
        $crlExt = $Cert.Extensions | Where-Object { $_.Oid.Value -eq '2.5.29.31' }
        if ($crlExt) {
            try {
                # "[1]CRL Distribution Point\r\n  Distribution Point Name:\r\n    Full Name:\r\n      URL=..."
                $crlFormatted = $crlExt.Format($true)
                $CRLDistributionPoints = @(foreach ($line in ($crlFormatted -split '\r?\n')) {
                    if ($line -match $urlLinePattern) { $Matches['url'] }
                })
            } catch { }
        }

        # Authority Information Access (OID 1.3.6.1.5.5.7.1.1) - OCSP and CA Issuer URLs
        $OCSPURLs = @()
        $AIAURLs = @()
        $aiaExt = $Cert.Extensions | Where-Object { $_.Oid.Value -eq '1.3.6.1.5.5.7.1.1' }
        if ($aiaExt) {
            try {
                # Format($true) returns one line per item:
                # "Access Method=On-line Certificate Status Protocol (1.3.6.1.5.5.7.48.1)\r\nAlternative Name:\r\n  URL=http://ocsp...."
                # "Access Method=Certification Authority Issuer (1.3.6.1.5.5.7.48.2)\r\nAlternative Name:\r\n  URL=http://..."
                # Format($false), which this used to call, puts all of it on one line - the
                # access method matched there and the URL on the same line never did, so
                # neither list ever held anything.
                $aiaFormatted = $aiaExt.Format($true)
                # Process each URL with the access method above it
                $lines = $aiaFormatted -split '\r?\n'
                $currentIsOCSP = $false
                $currentIsCAIssuer = $false
                foreach ($line in $lines) {
                    if ($line -match '1\.3\.6\.1\.5\.5\.7\.48\.1') { $currentIsOCSP = $true; $currentIsCAIssuer = $false }
                    elseif ($line -match '1\.3\.6\.1\.5\.5\.7\.48\.2') { $currentIsOCSP = $false; $currentIsCAIssuer = $true }
                    elseif ($line -match $urlLinePattern) {
                        $url = $Matches['url']
                        if ($currentIsOCSP) { $OCSPURLs += $url }
                        elseif ($currentIsCAIssuer) { $AIAURLs += $url }
                    }
                }
            } catch { }
        }

        $CertInfo = [PSCustomObject]@{
            Subject      = $SubjectCN
            SubjectFull  = $Cert.Subject
            Issuer       = $IssuerCN
            IssuerFull   = $Cert.Issuer
            SerialNumber = $Cert.SerialNumber
            NotBefore    = $Cert.NotBefore
            NotAfter     = $Cert.NotAfter
            Status       = $Status
            Thumbprint   = $Cert.Thumbprint
            SAN          = $SAN
            EKU          = $EKU
            SignatureAlgorithm      = $SigAlgo
            PublicKeyLength         = $KeyLength
            HasBasicConstraints     = $HasBasicConstraints
            BasicConstraintsPathLength = $BasicConstraintsPathLength
            CRLDistributionPoints   = $CRLDistributionPoints
            OCSPURLs                = $OCSPURLs
            AIAURLs                 = $AIAURLs
            # The line a report shows for this certificate. Without it the HTML card printed
            # the whole object - "@{Subject=...; CRLDistributionPoints=System.Object[]; ...}"
            # - under userCertificate; the fields above stay for whoever needs them.
            DisplayText             = "$SubjectCN - issued by $IssuerCN, valid $(Format-adPEASDate $Cert.NotBefore 'yyyy-MM-dd') to $(Format-adPEASDate $Cert.NotAfter 'yyyy-MM-dd') ($Status)"
        }

        $Cert.Dispose()
        return $CertInfo
    } catch {
        # Return error object if certificate parsing fails
        return [PSCustomObject]@{
            Subject      = "[Invalid Certificate]"
            SubjectFull  = $null
            Issuer       = $null
            IssuerFull   = $null
            SerialNumber = $null
            NotBefore    = $null
            NotAfter     = $null
            Status       = "Parse Error"
            Thumbprint   = $null
            SAN          = $null
            EKU          = $null
            SignatureAlgorithm      = $null
            PublicKeyLength         = 0
            HasBasicConstraints     = $false
            BasicConstraintsPathLength = 0
            CRLDistributionPoints   = @()
            OCSPURLs                = @()
            AIAURLs                 = @()
            ErrorInfo    = if ($CertBytes.Length -gt 0) { "$($CertBytes.Length) bytes" } else { "Empty" }
            DisplayText  = if ($CertBytes.Length -gt 0) { "[Invalid Certificate] ($($CertBytes.Length) bytes)" } else { "[Invalid Certificate] (empty)" }
        }
    }
}

# Helper: Convert KeyCredentialLink to readable info
# msDS-KeyCredentialLink is a DNWithBinary attribute: B:Length:HexData:DN
# Uses ConvertFrom-KeyCredentialLink helper for full LTV parsing
function Convert-KeyCredentialToInfo {
    param($KeyCredValue)

    try {
        # Handle string format (DNWithBinary)
        if ($KeyCredValue -is [string]) {
            # Format: B:Length:HexData:DN
            if ($KeyCredValue -match '^B:(\d+):([0-9A-Fa-f]+)(?::(.+))?$') {
                # Use the full parser to extract DeviceID, CreationTime, etc.
                return ConvertFrom-KeyCredentialLink -DNWithBinary $KeyCredValue
            }
            # Return as-is if not matching DNWithBinary format
            return $KeyCredValue
        }

        # Handle byte array (raw binary)
        if ($KeyCredValue -is [byte[]]) {
            return ConvertFrom-KeyCredentialLink -KeyCredentialBytes $KeyCredValue
        }

        # Handle COM objects (IADsDNWithBinary) from DirectoryServices
        # COM interop requires using GetType().InvokeMember() for property access
        if ($KeyCredValue -and $KeyCredValue.GetType().IsCOMObject) {
            try {
                # Use COM Reflection to access BinaryValue property
                $binaryValue = $KeyCredValue.GetType().InvokeMember(
                    'BinaryValue',
                    [System.Reflection.BindingFlags]::GetProperty,
                    $null,
                    $KeyCredValue,
                    $null
                )
                if ($binaryValue -is [byte[]]) {
                    return ConvertFrom-KeyCredentialLink -KeyCredentialBytes $binaryValue
                }
            } catch {
                # COM reflection failed, try direct access
            }
        }

        # Method 2: Try direct property access (works for some COM wrappers)
        if ($KeyCredValue.PSObject.Properties['DNString'] -and $KeyCredValue.PSObject.Properties['BinaryValue']) {
            $binaryValue = $KeyCredValue.BinaryValue
            if ($binaryValue -is [byte[]]) {
                return ConvertFrom-KeyCredentialLink -KeyCredentialBytes $binaryValue
            }
        }

        # Try converting to string and parsing as DNWithBinary
        $strValue = $KeyCredValue.ToString()
        if ($strValue -match '^B:(\d+):([0-9A-Fa-f]+)(?::(.+))?$') {
            return ConvertFrom-KeyCredentialLink -DNWithBinary $strValue
        }

        return "KeyCredential (unknown format)"
    } catch {
        return "[KeyCredential - parse error: $($_.Exception.Message)]"
    }
}

# Helper: Convert SID byte array to string
function Convert-SIDToString {
    param([byte[]]$SIDBytes)
    try {
        return (New-Object System.Security.Principal.SecurityIdentifier($SIDBytes, 0)).Value
    } catch {
        return $null
    }
}

<#
.SYNOPSIS
    Converts one raw LDAP attribute value into the form the checks consume.

.DESCRIPTION
    A wrong conversion here is not a defect in one module but in all of them at once, and it
    is invisible from above, because a check only ever sees the converted value - never the
    raw one. That is the reason this is a function of its own: name and raw value in, the
    properties to set out, drivable from a table without an LDAP connection.

    The body is the original block, moved unchanged apart from two mechanical rewrites: the
    Add-Member calls became assignments into $ConvertedProperties, and the 'continue' that
    ended each multi-value branch became 'return $ConvertedProperties'. The variables
    $PropName / $PropNameLower / $PropValue are rebuilt under their original names rather
    than renaming roughly two hundred references.

    The accumulator is deliberately not called $result: the extensionData branch keeps a
    local $result of its own and would overwrite it mid-branch.

.PARAMETER Name
    The attribute name exactly as the directory returned it. It decides the output property
    name; the branch matching below is case-insensitive throughout.

.PARAMETER Value
    The raw value collection for that attribute - an array of strings, or of byte[] for
    binary attributes. A lone byte[] is accepted and wrapped.

.OUTPUTS
    [ordered] dictionary of property name -> converted value. Three shapes occur and all
    three matter:
      - one entry, the ordinary case
      - no entry at all, when the raw value carried nothing usable (an empty sIDHistory, a
        msDS-KeyCredentialLink that parsed to nothing). That is not the same as a null
        value, and the caller must not invent a property for it
      - three entries for msLAPS-Password, which also yields msLAPS-Account and
        msLAPS-Updated out of the same JSON blob

.EXAMPLE
    ConvertFrom-LDAPAttribute -Name 'userAccountControl' -Value @('512')
    Returns @{ userAccountControl = @('NORMAL_ACCOUNT') }
#>
function ConvertFrom-LDAPAttribute {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Name,

        [Parameter(Mandatory = $false)]
        [AllowNull()]
        $Value
    )

    # Normalise to the array shape the body expects: an Object[] whose elements are the
    # individual raw values, exactly what Invoke-LDAPSearch builds for an attribute.
    #
    # Written as an if STATEMENT with an assignment per branch, deliberately. As an
    # expression - $PropValue = if (...) { ,$Value } - the captured output is unrolled again
    # and the comma is undone: a byte[] comes back out as a byte[] of its own bytes, and a
    # string as a string, so $PropValue[0] then yields the first byte or the first character
    # instead of the value. Every branch below reads $PropValue[0].
    if ($null -eq $Value) {
        $PropValue = @()
    } elseif ($Value -is [byte[]]) {
        # byte[] is itself an array, so a lone binary value has to be wrapped explicitly -
        # @($bytes) would unroll it into single bytes and every byte[] branch would miss.
        $PropValue = ,$Value
    } elseif ($Value -is [array]) {
        $PropValue = $Value
    } else {
        $PropValue = ,$Value
    }

    $PropName = $Name
    $PropNameLower = $PropName.ToLower()

    # Ordered, so properties reach the object in the order the conversion produced them.
    $ConvertedProperties = [ordered]@{}
        # =====================================================================
        # Handle multi-value attributes that need special processing
        # These are processed BEFORE single-value check
        # =====================================================================

        # Unix, LDAP and Samba password attributes. All of them are octet strings, so they
        # arrive as byte[] and without this they reach the report as bytes - PowerShell
        # renders that as space-separated decimals, "83 111 109 109 101 114", where the
        # whole purpose of Get-UnixPasswordAccounts is to show what the attribute says.
        #
        # The value is text in every case that matters: cleartext or a crypt(3) hash for
        # the first three, the hex form of an NT or LM hash for the Samba pair. Handled
        # here, with the other multi-valued attributes, because userPassword may legally
        # hold more than one value and the single-value path below would not see those.
        if ($PropName -iin @('userPassword', 'unixUserPassword', 'msSFU30Password',
                             'sambaNTPassword', 'sambaLMPassword')) {
            $passwordValues = @(
                foreach ($entry in $PropValue) {
                    if ($entry -is [byte[]]) {
                        $decoded = [System.Text.Encoding]::UTF8.GetString($entry)
                        # A control character other than tab, CR or LF means this is not
                        # text. Such a value is shown as hex rather than pushed through a
                        # decoder, which would substitute the undecodable bytes and leave
                        # a hash that no longer matches itself.
                        if ($decoded -match '[\x00-\x08\x0B\x0C\x0E-\x1F]') {
                            ([System.BitConverter]::ToString($entry) -replace '-', '')
                        } else {
                            $decoded
                        }
                    } elseif ($null -ne $entry) {
                        [string]$entry
                    }
                }
            )
            if ($passwordValues.Count -eq 1) {
                $ConvertedProperties[$PropName] = $passwordValues[0]
            } elseif ($passwordValues.Count -gt 1) {
                $ConvertedProperties[$PropName] = $passwordValues
            }
            return $ConvertedProperties
        }

        # sIDHistory - Multi-valued SID attribute (critical for SID History Injection detection)
        # The three tokenGroups attributes are lists of SIDs as well.
        if ($PropName -iin @('sIDHistory', 'tokenGroups', 'tokenGroupsGlobalAndUniversal', 'tokenGroupsNoGCAcceptable')) {
            $sidStrings = @()
            foreach ($sidBytes in $PropValue) {
                if ($sidBytes -is [byte[]]) {
                    $sidString = Convert-SIDToString -SIDBytes $sidBytes
                    if ($sidString) {
                        $sidStrings += $sidString
                    }
                } elseif ($sidBytes -is [string]) {
                    $sidStrings += $sidBytes
                }
            }
            if ($sidStrings.Count -eq 1) {
                $ConvertedProperties[$PropName] = $sidStrings[0]
            } elseif ($sidStrings.Count -gt 1) {
                $ConvertedProperties[$PropName] = $sidStrings
            }
            return $ConvertedProperties
        }

        # userCertificate / cACertificate - Multi-valued X.509 certificates
        if ($PropName -ieq "userCertificate" -or $PropName -ieq "cACertificate") {
            $certInfos = @()
            foreach ($certBytes in $PropValue) {
                if ($certBytes -is [byte[]]) {
                    $certInfo = Convert-CertificateToInfo -CertBytes $certBytes
                    $certInfos += $certInfo
                }
            }
            if ($certInfos.Count -eq 1) {
                $ConvertedProperties[$PropName] = $certInfos[0]
            } elseif ($certInfos.Count -gt 1) {
                $ConvertedProperties[$PropName] = $certInfos
            }
            return $ConvertedProperties
        }

        # msDS-KeyCredentialLink - Multi-valued DNWithBinary (Windows Hello for Business, etc.)
        if ($PropName -ieq "msDS-KeyCredentialLink") {
            $keyInfos = @()
            foreach ($keyValue in $PropValue) {
                $keyInfo = Convert-KeyCredentialToInfo -KeyCredValue $keyValue
                if ($keyInfo) {
                    $keyInfos += $keyInfo
                }
            }
            if ($keyInfos.Count -gt 0) {
                $ConvertedProperties[$PropName] = $keyInfos
            }
            return $ConvertedProperties
        }

        # msLAPS-EncryptedPasswordHistory - Multi-valued (array of encrypted blobs)
        if ($PropName -ieq "msLAPS-EncryptedPasswordHistory") {
            # LAPS v2 Encrypted Password History - Array of encrypted password blobs
            try {
                $historyEntries = @()
                $entryIndex = 0

                foreach ($historyBlob in $PropValue) {
                    $entryIndex++
                    try {
                        $historyInfo = ConvertFrom-LAPSEncryptedPassword -Blob $historyBlob
                        if ($historyInfo -and $historyInfo.UpdateTimestamp) {
                            $historyEntries += "[$entryIndex] $(Format-adPEASDate $historyInfo.UpdateTimestamp 'yyyy-MM-dd HH:mm:ss')"
                        } else {
                            $historyEntries += "[$entryIndex] [Encrypted - $($historyBlob.Length) bytes]"
                        }
                    } catch {
                        $historyEntries += "[$entryIndex] [Encrypted - $($historyBlob.Length) bytes]"
                    }
                }

                if ($historyEntries.Count -gt 0) {
                    $ConvertedProperties[$PropName] = $historyEntries
                }
            } catch {
                $ConvertedProperties[$PropName] = "[History: $($PropValue.Count) entries]"
            }
            return $ConvertedProperties
        }

        # protocolSettings - Exchange's per-user protocol overrides.
        # Each entry has the form '<Protocol>SEP<Enabled 0/1>SEP<UseDefaults 0/1>SEP<encoding flags...>'
        # where SEP is U+00A7 (section sign, see the Split below). For security review
        # only the protocol + enabled state matter;
        # the trailing per-user encoding overrides (mail format, MIME charset, etc.) are noise.
        if ($PropName -ieq "protocolSettings") {
            $protoLines = @()
            foreach ($entry in $PropValue) {
                $entryStr = [string]$entry
                if ([string]::IsNullOrWhiteSpace($entryStr)) { continue }
                $fields = $entryStr.Split([char]0x00A7)
                $proto = if ($fields[0]) { $fields[0] } else { '<unknown>' }
                $state = if ($fields.Count -ge 2 -and -not [string]::IsNullOrEmpty($fields[1])) {
                    switch ($fields[1]) {
                        '0'     { 'disabled' }
                        '1'     { 'enabled' }
                        default { "unknown=$($fields[1])" }
                    }
                } else { 'no enable flag' }
                $protoLines += "${proto}: $state"
            }
            if ($protoLines.Count -eq 1) {
                $ConvertedProperties[$PropName] = $protoLines[0]
            } elseif ($protoLines.Count -gt 1) {
                $ConvertedProperties[$PropName] = $protoLines
            }
            return $ConvertedProperties
        }

        # pKIExtendedKeyUsage - Multi-valued OID array (convert to friendly names)
        if ($PropName -ieq "pKIExtendedKeyUsage") {
            # Convert EKU OIDs to friendly names using central OID mapping
            $ekuNames = Convert-OIDsToNames -OIDs $PropValue -IncludeOID
            if ($ekuNames.Count -eq 1) {
                $ConvertedProperties[$PropName] = $ekuNames[0]
            } elseif ($ekuNames.Count -gt 1) {
                $ConvertedProperties[$PropName] = $ekuNames
            } else {
                $ConvertedProperties[$PropName] = @("Any Purpose")
            }
            return $ConvertedProperties
        }

        # msPKI-Certificate-Application-Policy - Multi-valued OID array (convert to friendly names)
        if ($PropName -ieq "msPKI-Certificate-Application-Policy") {
            # Convert Application Policy OIDs to friendly names using central OID mapping
            $policyNames = Convert-OIDsToNames -OIDs $PropValue -IncludeOID
            if ($policyNames.Count -eq 1) {
                $ConvertedProperties[$PropName] = $policyNames[0]
            } elseif ($policyNames.Count -gt 1) {
                $ConvertedProperties[$PropName] = $policyNames
            }
            return $ConvertedProperties
        }

        # msPKI-RA-Application-Policies / msPKI-RA-Policies - Registration Authority
        # requirements (ESC3 condition 2). Values are normally OIDs, but schema v3+/v4
        # templates may store non-OID qualifier strings here - those are passed through
        # unchanged so they stay visible instead of being mangled by the OID lookup.
        if ($PropName -iin @("msPKI-RA-Application-Policies", "msPKI-RA-Policies")) {
            $raNames = @()
            foreach ($raValue in @($PropValue)) {
                $raString = [string]$raValue
                if ($raString -match '^\d+(\.\d+)+$') {
                    $raNames += (ConvertFrom-OID -OID $raString -IncludeOID)
                } elseif ($raString) {
                    $raNames += $raString
                }
            }
            if ($raNames.Count -eq 1) {
                $ConvertedProperties[$PropName] = $raNames[0]
            } elseif ($raNames.Count -gt 1) {
                $ConvertedProperties[$PropName] = $raNames
            }
            return $ConvertedProperties
        }

        # pKICriticalExtensions - Multi-valued OID array (convert to friendly names)
        if ($PropName -ieq "pKICriticalExtensions") {
            # Convert Critical Extensions OIDs to friendly names using central OID mapping
            $critExtNames = Convert-OIDsToNames -OIDs $PropValue -IncludeOID
            if ($critExtNames.Count -eq 1) {
                $ConvertedProperties[$PropName] = $critExtNames[0]
            } elseif ($critExtNames.Count -gt 1) {
                $ConvertedProperties[$PropName] = $critExtNames
            }
            return $ConvertedProperties
        }

        # thumbnailPhoto / jpegPhoto - Image data (JPEG/PNG)
        # Store as object with metadata for console and Base64 for HTML rendering
        if ($PropName -iin @("thumbnailPhoto", "jpegPhoto")) {
            if ($PropValue.Count -ge 1 -and $PropValue[0] -is [byte[]]) {
                $imageBytes = $PropValue[0]
                $imageSizeKB = [math]::Round($imageBytes.Length / 1024, 1)

                # Detect image type from magic bytes
                $imageType = "unknown"
                $mimeType = "application/octet-stream"
                if ($imageBytes.Length -ge 3) {
                    # JPEG: FF D8 FF
                    if ($imageBytes[0] -eq 0xFF -and $imageBytes[1] -eq 0xD8 -and $imageBytes[2] -eq 0xFF) {
                        $imageType = "JPEG"
                        $mimeType = "image/jpeg"
                    }
                    # PNG: 89 50 4E 47
                    elseif ($imageBytes[0] -eq 0x89 -and $imageBytes[1] -eq 0x50 -and $imageBytes[2] -eq 0x4E -and $imageBytes.Length -ge 4 -and $imageBytes[3] -eq 0x47) {
                        $imageType = "PNG"
                        $mimeType = "image/png"
                    }
                    # GIF: 47 49 46
                    elseif ($imageBytes[0] -eq 0x47 -and $imageBytes[1] -eq 0x49 -and $imageBytes[2] -eq 0x46) {
                        $imageType = "GIF"
                        $mimeType = "image/gif"
                    }
                    # BMP: 42 4D
                    elseif ($imageBytes[0] -eq 0x42 -and $imageBytes[1] -eq 0x4D) {
                        $imageType = "BMP"
                        $mimeType = "image/bmp"
                    }
                }

                # Create structured object with image data
                $imageObj = [PSCustomObject]@{
                    PSTypeName = 'adPEAS.ImageData'
                    ImageType = $imageType
                    MimeType = $mimeType
                    SizeBytes = $imageBytes.Length
                    SizeKB = $imageSizeKB
                    Base64 = [Convert]::ToBase64String($imageBytes)
                    DisplayText = "[$imageType image, $imageSizeKB KB]"
                }

                $ConvertedProperties[$PropName] = $imageObj
            }
            return $ConvertedProperties
        }

        # mSMQDigests - Multi-valued binary (MD5 message digests, 16 bytes each)
        if ($PropName -ieq "mSMQDigests") {
            $digestValues = @()
            foreach ($bytes in $PropValue) {
                if ($bytes -is [byte[]] -and $bytes.Length -eq 16) {
                    # MD5 digest - display as hex string
                    $hexStr = ($bytes | ForEach-Object { $_.ToString('X2') }) -join ''
                    $digestValues += $hexStr
                } elseif ($bytes -is [byte[]]) {
                    # Non-standard length - show with byte count
                    $hexStr = ($bytes | ForEach-Object { $_.ToString('X2') }) -join ''
                    $digestValues += "$hexStr ($($bytes.Length) bytes)"
                } else {
                    $digestValues += [string]$bytes
                }
            }
            if ($digestValues.Count -eq 1) {
                $ConvertedProperties[$PropName] = $digestValues[0]
            } elseif ($digestValues.Count -gt 1) {
                $ConvertedProperties[$PropName] = $digestValues
            }
            return $ConvertedProperties
        }

        # mSMQSignCertificates - Multi-valued binary (X.509 certificates)
        if ($PropName -ieq "mSMQSignCertificates") {
            $certValues = @()
            foreach ($bytes in $PropValue) {
                if ($bytes -is [byte[]]) {
                    try {
                        # Try to parse as X.509 certificate
                        $cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2 -ArgumentList @(,$bytes)
                        $subject = $cert.Subject
                        $thumbprint = $cert.Thumbprint
                        $notAfter = (Format-adPEASDate $cert.NotAfter 'yyyy-MM-dd')
                        $certValues += "$subject (Thumbprint: $thumbprint, Expires: $notAfter)"
                        $cert.Dispose()
                    } catch {
                        # Not a valid certificate - show as binary info
                        $certValues += "[Certificate: $($bytes.Length) bytes]"
                    }
                } else {
                    $certValues += [string]$bytes
                }
            }
            if ($certValues.Count -eq 1) {
                $ConvertedProperties[$PropName] = $certValues[0]
            } elseif ($certValues.Count -gt 1) {
                $ConvertedProperties[$PropName] = $certValues
            }
            return $ConvertedProperties
        }

        # extensionData - Multi-valued binary blob (Exchange mailbox data, etc.)
        # Format: UTF-16LE header string + null terminator + binary data
        if ($PropName -ieq "extensionData") {
            $decodedValues = @()
            foreach ($bytes in $PropValue) {
                if ($bytes -is [byte[]]) {
                    $result = $null

                    # Exchange extensionData format: UTF-16LE header followed by binary data
                    # Examples: "MBXEXTDATA", "MBXEXTCTIDATA", "DVPROPERTYSTREAMID", etc.
                    # Pattern: Look for UTF-16LE header (alternating nulls) terminated by double-null

                    # Check for UTF-16LE pattern (alternating nulls in first 20+ bytes)
                    $hasAlternatingNulls = $false
                    if ($bytes.Length -ge 4) {
                        $nullCount = 0
                        for ($i = 1; $i -lt [Math]::Min($bytes.Length, 40); $i += 2) {
                            if ($bytes[$i] -eq 0) { $nullCount++ }
                        }
                        $hasAlternatingNulls = ($nullCount -ge 3)
                    }

                    if ($hasAlternatingNulls) {
                        # Find the null terminator (00 00) that ends the UTF-16LE string
                        $headerEndIndex = -1
                        for ($i = 0; $i -lt $bytes.Length - 1; $i += 2) {
                            if ($bytes[$i] -eq 0 -and $bytes[$i + 1] -eq 0) {
                                $headerEndIndex = $i
                                break
                            }
                        }

                        if ($headerEndIndex -gt 0) {
                            # Extract and decode just the header portion
                            $headerBytes = $bytes[0..($headerEndIndex - 1)]
                            $header = [System.Text.Encoding]::Unicode.GetString($headerBytes)

                            # Check if header is printable text
                            if ($header -match '^[\x20-\x7E\xA0-\xFF]+$') {
                                $dataLength = $bytes.Length - $headerEndIndex - 2
                                $result = "$header ($dataLength bytes binary data)"
                            }
                        }

                        # If no header found, try full decode (for pure text values)
                        if (-not $result) {
                            $decoded = [System.Text.Encoding]::Unicode.GetString($bytes)
                            $decoded = $decoded.TrimEnd([char]0)
                            if ($decoded -match '^[\x20-\x7E\xA0-\xFF]+$') {
                                $result = $decoded
                            }
                        }
                    }

                    # Try UTF-8 for non-UTF16LE data
                    if (-not $result) {
                        try {
                            $decoded = [System.Text.Encoding]::UTF8.GetString($bytes)
                            $decoded = $decoded.TrimEnd([char]0)
                            # Check if mostly printable
                            $printable = ($decoded -replace '[^\x20-\x7E\xA0-\xFF]', '').Length
                            if ($decoded.Length -gt 0 -and $printable -ge ($decoded.Length * 0.8)) {
                                $result = $decoded -replace '[^\x20-\x7E\xA0-\xFF]', '?'
                            }
                        } catch { }
                    }

                    # Try ASCII
                    if (-not $result) {
                        $decoded = [System.Text.Encoding]::ASCII.GetString($bytes)
                        $decoded = $decoded.TrimEnd([char]0)
                        $printable = ($decoded -replace '[^\x20-\x7E]', '').Length
                        if ($decoded.Length -gt 0 -and $printable -ge ($decoded.Length * 0.7)) {
                            $result = $decoded -replace '[^\x20-\x7E]', '?'
                        }
                    }

                    # Fallback: Show as hex string if not decodable
                    if (-not $result -or $result.Length -eq 0) {
                        $hexStr = ($bytes | ForEach-Object { $_.ToString('X2') }) -join ' '
                        if ($hexStr.Length -gt 100) {
                            $result = "[Binary: $($hexStr.Substring(0, 100))... ($($bytes.Length) bytes)]"
                        } else {
                            $result = "[Binary: $hexStr]"
                        }
                    }

                    $decodedValues += $result
                } else {
                    $decodedValues += [string]$bytes
                }
            }

            if ($decodedValues.Count -eq 1) {
                $ConvertedProperties[$PropName] = $decodedValues[0]
            } elseif ($decodedValues.Count -gt 1) {
                $ConvertedProperties[$PropName] = $decodedValues
            }
            return $ConvertedProperties
        }

        # If single value, process with full conversion
        if ($PropValue.Count -eq 1) {
            # Convert byte arrays (e.g., objectSid, objectGUID, LAPS)
            # NOTE: Use -ieq for case-insensitive comparison because LdapConnection returns lowercase attribute names
            if ($PropValue[0] -is [byte[]]) {
                # securityIdentifier is the domain SID of the partner on a trust object; it
                # arrived as bytes, which a report row cannot show.
                if ($PropName -ieq "objectSid" -or $PropName -ieq "securityIdentifier") {
                    try {
                        $ConvertedProperties[$PropName] = (New-Object System.Security.Principal.SecurityIdentifier($PropValue[0], 0)).Value
                    } catch {
                        $ConvertedProperties[$PropName] = $PropValue[0]
                    }
                } elseif ($PropName -ieq "ms-DS-CreatorSID") {
                    try {
                        $ConvertedProperties[$PropName] = (New-Object System.Security.Principal.SecurityIdentifier($PropValue[0], 0)).Value
                    } catch {
                        $ConvertedProperties[$PropName] = $PropValue[0]
                    }
                } elseif ($PropName -ieq "objectGUID" -or $PropName -ieq "msExchMailboxGuid") {
                    try {
                        $ConvertedProperties[$PropName] = ([System.Guid]$PropValue[0]).ToString()
                    } catch {
                        $ConvertedProperties[$PropName] = $PropValue[0]
                    }
                } elseif ($PropName -ieq "msDS-GenerationId") {
                    try {
                        $GenIdBytes = $PropValue[0]
                        if ($GenIdBytes.Length -eq 16) {
                            $GenIdGuid = [System.Guid]::new($GenIdBytes)
                            $ConvertedProperties[$PropName] = $GenIdGuid.ToString()
                        } elseif ($GenIdBytes.Length -eq 8) {
                            $HexString = ($GenIdBytes | ForEach-Object { $_.ToString('X2') }) -join '-'
                            $ConvertedProperties[$PropName] = $HexString
                        } else {
                            $HexString = ($GenIdBytes | ForEach-Object { $_.ToString('X2') }) -join ''
                            $ConvertedProperties[$PropName] = "0x$HexString"
                        }
                    } catch {
                        $ConvertedProperties[$PropName] = $PropValue[0]
                    }
                } elseif ($PropName -ieq "msExchMasterAccountSid") {
                    try {
                        $ConvertedProperties[$PropName] = (New-Object System.Security.Principal.SecurityIdentifier($PropValue[0], 0)).Value
                    } catch {
                        $ConvertedProperties[$PropName] = $PropValue[0]
                    }
                } elseif ($PropName -ieq "msDS-GroupMSAMembership") {
                    try {
                        # gMSA membership uses same unified structure as nTSecurityDescriptor
                        $SDResult = ConvertFrom-SecurityDescriptor -SecurityDescriptorBytes $PropValue[0]
                        $ConvertedProperties[$PropName] = $SDResult
                    } catch {
                        $ConvertedProperties[$PropName] = $PropValue[0]
                    }
                } elseif ($PropName -ieq "msDS-ManagedPasswordId" -or $PropName -ieq "msDS-ManagedPasswordPreviousId") {
                    try {
                        # MS-GKDI KEY_ID structure (used by gMSA/dMSA managed password IDs):
                        #   Offset  0: Version   (4 bytes, = 1)
                        #   Offset  4: Magic     (4 bytes, = "KDSK")
                        #   Offset  8: Flags     (4 bytes)
                        #   Offset 12: L0 Index  (4 bytes)
                        #   Offset 16: L1 Index  (4 bytes)
                        #   Offset 20: L2 Index  (4 bytes)
                        #   Offset 24: Root Key Identifier (16 bytes, GUID)
                        #   followed by length fields and domain/forest name (UTF-16)
                        # The Root Key Identifier tells us which KDS root key derived the password,
                        # the L0/L1/L2 indexes identify the key generation within that root key.
                        $PasswordIdBytes = $PropValue[0]
                        if ($PasswordIdBytes -is [byte[]] -and $PasswordIdBytes.Length -ge 40 -and
                            $PasswordIdBytes[4] -eq 0x4B -and $PasswordIdBytes[5] -eq 0x44 -and
                            $PasswordIdBytes[6] -eq 0x53 -and $PasswordIdBytes[7] -eq 0x4B) {

                            $L0Index = [BitConverter]::ToInt32($PasswordIdBytes, 12)
                            $L1Index = [BitConverter]::ToInt32($PasswordIdBytes, 16)
                            $L2Index = [BitConverter]::ToInt32($PasswordIdBytes, 20)

                            $RootKeyBytes = [byte[]]::new(16)
                            [Array]::Copy($PasswordIdBytes, 24, $RootKeyBytes, 0, 16)
                            $RootKeyId = [System.Guid]::new($RootKeyBytes)

                            $ConvertedProperties[$PropName] = "RootKeyId: $($RootKeyId.ToString()), L0/L1/L2: $L0Index/$L1Index/$L2Index"
                        } elseif ($PasswordIdBytes -is [byte[]]) {
                            # Unknown structure - fall back to full hex representation
                            $HexString = ($PasswordIdBytes | ForEach-Object { $_.ToString('X2') }) -join '-'
                            $ConvertedProperties[$PropName] = $HexString
                        } else {
                            $ConvertedProperties[$PropName] = $PropValue[0]
                        }
                    } catch {
                        $ConvertedProperties[$PropName] = $PropValue[0]
                    }
                } elseif ($PropName -ieq "ms-DS-ConsistencyGuid") {
                    try {
                        $GuidBytes = $PropValue[0]
                        if ($GuidBytes -is [byte[]] -and $GuidBytes.Length -eq 16) {
                            $ByteArray = [byte[]]$GuidBytes
                            $GuidObj = [System.Guid]::new($ByteArray)
                            $ConvertedProperties[$PropName] = $GuidObj.ToString()
                        } else {
                            $ConvertedProperties[$PropName] = $PropValue[0]
                        }
                    } catch {
                        $ConvertedProperties[$PropName] = $PropValue[0]
                    }
                } elseif ($PropName -ieq "nTSecurityDescriptor") {
                    try {
                        $SDResult = ConvertFrom-SecurityDescriptor -SecurityDescriptorBytes $PropValue[0]
                        $ConvertedProperties[$PropName] = $SDResult
                    } catch {
                        $ConvertedProperties[$PropName] = $PropValue[0]
                    }
                } elseif ($PropName -ieq "msExchMailboxSecurityDescriptor") {
                    try {
                        $SDResult = ConvertFrom-SecurityDescriptor -SecurityDescriptorBytes $PropValue[0] -MailboxRights
                        $ConvertedProperties[$PropName] = $SDResult
                    } catch {
                        $ConvertedProperties[$PropName] = $PropValue[0]
                    }
                } elseif ($PropName -ieq "msDS-AllowedToActOnBehalfOfOtherIdentity") {
                    # RBCD: extract principal names from the security descriptor who are allowed to delegate
                    try {
                        $SD = New-Object System.DirectoryServices.ActiveDirectorySecurity
                        $SD.SetSecurityDescriptorBinaryForm($PropValue[0])

                        # Extract only Allow ACEs - these are the principals allowed to delegate.
                        #
                        # GetAccessRules, not the .Access property: .Access is an extended
                        # type member that Microsoft.PowerShell.Security registers. In a host
                        # where that module is not loaded the expression is $null with no
                        # error, the loop runs zero times, and EVERY RBCD target in the
                        # domain came back as "[SD present, no Allow ACEs]" - a silent total
                        # loss of the finding. Get-DomainUser already uses this call for the
                        # gMSA descriptor.
                        $rbcdPrincipals = @()
                        $rbcdRules = $SD.GetAccessRules($true, $true, [System.Security.Principal.SecurityIdentifier])
                        foreach ($ACE in $rbcdRules) {
                            if ($ACE.AccessControlType -eq 'Allow') {
                                $Principal = $ACE.IdentityReference.Value
                                # Resolve SID to name if needed
                                if ($Principal -match '^S-1-') {
                                    $PrincipalName = ConvertFrom-SID -SID $Principal
                                } else {
                                    $PrincipalName = $Principal
                                }
                                # Keep the SID when it cannot be resolved. Without this a
                                # deleted or foreign trustee became a $null entry, and a
                                # single one made the whole attribute $null - the resource
                                # then looked unconfigured.
                                if (-not $PrincipalName) { $PrincipalName = $Principal }
                                $rbcdPrincipals += $PrincipalName
                            }
                        }

                        if ($rbcdPrincipals.Count -eq 1) {
                            $ConvertedProperties[$PropName] = $rbcdPrincipals[0]
                        } elseif ($rbcdPrincipals.Count -gt 1) {
                            $ConvertedProperties[$PropName] = $rbcdPrincipals
                        } else {
                            # SD parsed but no Allow ACEs found - attribute is set but SD has no delegates.
                            # Still set the property so it appears in display (attribute is present in AD).
                            $ConvertedProperties[$PropName] = "[SD present, no Allow ACEs]"
                        }
                    } catch {
                        $ConvertedProperties[$PropName] = $PropValue[0]
                    }
                } elseif ($PropName -ieq "msExchSafeSendersHash" -or $PropName -ieq "msExchBlockedSendersHash") {
                    # Exchange Safe/Blocked Senders Hash - MD5 hash of sender list
                    # Display as compact hex string (these are hashes, not text)
                    try {
                        $bytes = $PropValue[0]
                        $hexStr = ($bytes | ForEach-Object { $_.ToString('X2') }) -join ''
                        $ConvertedProperties[$PropName] = $hexStr
                    } catch {
                        $ConvertedProperties[$PropName] = "[Hash: $($PropValue[0].Length) bytes]"
                    }
                } elseif ($PropName -ieq "msLAPS-EncryptedPassword") {
                    # LAPS v2 Encrypted Password (single value) - binary blob
                    try {
                        $encryptedInfo = ConvertFrom-LAPSEncryptedPassword -Blob $PropValue[0]
                        if ($encryptedInfo -and $encryptedInfo.UpdateTimestamp) {
                            $ConvertedProperties[$PropName] = "[Encrypted - Updated: $(Format-adPEASDate $encryptedInfo.UpdateTimestamp 'yyyy-MM-dd HH:mm:ss')]"
                        } else {
                            $ConvertedProperties[$PropName] = "[Encrypted - $($PropValue[0].Length) bytes]"
                        }
                    } catch {
                        $ConvertedProperties[$PropName] = "[Encrypted - $($PropValue[0].Length) bytes]"
                    }
                } elseif ($PropName -ieq "logonHours") {
                    # logonHours is a 21-byte array (168 bits = 24 hours * 7 days)
                    # Each bit represents one hour, starting Sunday 00:00 UTC
                    try {
                        $bytes = $PropValue[0]
                        if ($bytes -is [byte[]] -and $bytes.Length -eq 21) {
                            # Check if all hours are allowed (all bits set = 0xFF for all bytes)
                            $allAllowed = $true
                            foreach ($b in $bytes) {
                                if ($b -ne 0xFF) { $allAllowed = $false; break }
                            }

                            if ($allAllowed) {
                                $ConvertedProperties[$PropName] = "All hours (no restriction)"
                            } else {
                                # Check if all hours are denied (all bits clear)
                                $allDenied = $true
                                foreach ($b in $bytes) {
                                    if ($b -ne 0x00) { $allDenied = $false; break }
                                }

                                if ($allDenied) {
                                    $ConvertedProperties[$PropName] = "No hours allowed (logon blocked)"
                                } else {
                                    # Parse restricted hours - show summary per day
                                    $days = @('Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat')
                                    $restrictions = @()

                                    for ($day = 0; $day -lt 7; $day++) {
                                        $dayStart = $day * 24
                                        $allowedHours = @()

                                        for ($hour = 0; $hour -lt 24; $hour++) {
                                            $bitIndex = $dayStart + $hour
                                            $byteIndex = [Math]::Floor($bitIndex / 8)
                                            $bitPosition = $bitIndex % 8
                                            $isAllowed = ($bytes[$byteIndex] -band (1 -shl $bitPosition)) -ne 0

                                            if ($isAllowed) {
                                                $allowedHours += $hour
                                            }
                                        }

                                        if ($allowedHours.Count -eq 0) {
                                            $restrictions += "$($days[$day]): Blocked"
                                        } elseif ($allowedHours.Count -eq 24) {
                                            $restrictions += "$($days[$day]): All day"
                                        } else {
                                            # Find contiguous ranges
                                            $ranges = @()
                                            $rangeStart = $allowedHours[0]
                                            $rangeEnd = $rangeStart

                                            for ($i = 1; $i -lt $allowedHours.Count; $i++) {
                                                if ($allowedHours[$i] -eq $rangeEnd + 1) {
                                                    $rangeEnd = $allowedHours[$i]
                                                } else {
                                                    $ranges += "{0:D2}:00-{1:D2}:00" -f $rangeStart, ($rangeEnd + 1)
                                                    $rangeStart = $allowedHours[$i]
                                                    $rangeEnd = $rangeStart
                                                }
                                            }
                                            $ranges += "{0:D2}:00-{1:D2}:00" -f $rangeStart, (($rangeEnd + 1) % 24)
                                            $restrictions += "$($days[$day]): $($ranges -join ', ')"
                                        }
                                    }

                                    $ConvertedProperties[$PropName] = $restrictions
                                }
                            }
                        } else {
                            # Unexpected format - show as hex
                            $hexStr = ($bytes | ForEach-Object { $_.ToString('X2') }) -join ''
                            $ConvertedProperties[$PropName] = "[LogonHours: $hexStr]"
                        }
                    } catch {
                        $ConvertedProperties[$PropName] = $PropValue[0]
                    }
                } elseif ($PropName -ieq "pKIExpirationPeriod" -or $PropName -ieq "pKIOverlapPeriod") {
                    # Convert PKI time period byte arrays to readable duration
                    try {
                        $Bytes = $PropValue[0]
                        if ($Bytes.Length -eq 8) {
                            $Int64Value = [BitConverter]::ToInt64($Bytes, 0)
                            $Seconds = [Math]::Abs($Int64Value) / 10000000

                            if ($Seconds -ge 31536000) {
                                $Years = [Math]::Floor($Seconds / 31536000)
                                $ConvertedProperties[$PropName] = "$Years year(s)"
                            } elseif ($Seconds -ge 86400) {
                                $Days = [Math]::Floor($Seconds / 86400)
                                $ConvertedProperties[$PropName] = "$Days day(s)"
                            } elseif ($Seconds -ge 3600) {
                                $Hours = [Math]::Floor($Seconds / 3600)
                                $ConvertedProperties[$PropName] = "$Hours hour(s)"
                            } else {
                                $Minutes = [Math]::Floor($Seconds / 60)
                                $ConvertedProperties[$PropName] = "$Minutes minute(s)"
                            }
                        } else {
                            $ConvertedProperties[$PropName] = $PropValue[0]
                        }
                    } catch {
                        $ConvertedProperties[$PropName] = $PropValue[0]
                    }
                } elseif ($PropName -ieq "pKIKeyUsage") {
                    # Convert PKI Key Usage byte array to readable flags
                    try {
                        $Bytes = $PropValue[0]
                        if ($Bytes.Length -ge 2) {
                            $KeyUsage = [int]$Bytes[0] + ([int]$Bytes[1] -shl 8)
                            $KeyUsageList = @()

                            if ($KeyUsage -band 0x0080) { $KeyUsageList += "Digital Signature" }
                            if ($KeyUsage -band 0x0040) { $KeyUsageList += "Non Repudiation" }
                            if ($KeyUsage -band 0x0020) { $KeyUsageList += "Key Encipherment" }
                            if ($KeyUsage -band 0x0010) { $KeyUsageList += "Data Encipherment" }
                            if ($KeyUsage -band 0x0008) { $KeyUsageList += "Key Agreement" }
                            if ($KeyUsage -band 0x0004) { $KeyUsageList += "Key Cert Sign" }
                            if ($KeyUsage -band 0x0002) { $KeyUsageList += "CRL Sign" }
                            if ($KeyUsage -band 0x0001) { $KeyUsageList += "Encipher Only" }
                            if ($KeyUsage -band 0x8000) { $KeyUsageList += "Decipher Only" }

                            if ($KeyUsageList.Count -gt 0) {
                                $ConvertedProperties[$PropName] = $KeyUsageList
                            } else {
                                $ConvertedProperties[$PropName] = @("NONE")
                            }
                        } else {
                            $ConvertedProperties[$PropName] = $PropValue[0]
                        }
                    } catch {
                        $ConvertedProperties[$PropName] = $PropValue[0]
                    }
                } elseif ($PropNameLower -eq 'userparameters') {
                    # TSPropertyArray ([MS-TSTS] 2.2.1.1) - per-user TS settings.
                    $tsLines = ConvertFrom-TSProperties -Bytes $PropValue
                    if ($tsLines) {
                        if ($tsLines.Count -eq 1) {
                            $ConvertedProperties[$PropName] = $tsLines[0]
                        } else {
                            $ConvertedProperties[$PropName] = $tsLines
                        }
                    } else {
                        $byteLen = if ($PropValue[0] -is [byte[]]) { $PropValue[0].Length } else { 0 }
                        $ConvertedProperties[$PropName] = "[userParameters blob: $byteLen bytes, no recognised TSPropertyArray signature]"
                    }
                } elseif ($PropNameLower -eq 'terminalserver') {
                    # Per-User CAL tracking token written by Remote Desktop Licensing.
                    $licLines = ConvertFrom-TSClientLicense -Bytes $PropValue
                    if ($licLines) {
                        if ($licLines.Count -eq 1) {
                            $ConvertedProperties[$PropName] = $licLines[0]
                        } else {
                            $ConvertedProperties[$PropName] = $licLines
                        }
                    } else {
                        $byteLen = if ($PropValue[0] -is [byte[]]) { $PropValue[0].Length } else { 0 }
                        $ConvertedProperties[$PropName] = "[terminalServer blob: $byteLen bytes, unknown format]"
                    }
                } else {
                    # Generic byte array handling
                    $ConvertedProperties[$PropName] = $PropValue[0]
                }
            } else {
                # Non-byte array single values - apply type conversions
                # The two attribute-name sets live at script scope (top of this file) - they
                # used to be rebuilt inside this branch, i.e. once per attribute per object.

                if ($Script:LDAPFileTimeAttributes.Contains($PropNameLower)) {
                    # Convert FileTime to DateTime
                    try {
                        $ftValue = [long]$PropValue[0]
                        # Handle special values: 0 = never, 9223372036854775807 = never expires
                        if ($ftValue -eq 0 -or $ftValue -eq 9223372036854775807) {
                            $ConvertedProperties[$PropName] = $PropValue[0]
                        } else {
                            $dateTime = [DateTime]::FromFileTime($ftValue)
                            $ConvertedProperties[$PropName] = $dateTime
                        }
                    } catch {
                        # Fallback to raw value if conversion fails
                        $ConvertedProperties[$PropName] = $PropValue[0]
                    }
                } elseif ($Script:LDAPGeneralizedTimeAttributes.Contains($PropNameLower)) {
                    # Convert Generalized Time (YYYYMMDDHHmmss.0Z) to DateTime
                    try {
                        $gtValue = [string]$PropValue[0]
                        # Parse format: 20260105135347.0Z
                        if ($gtValue -match '^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})') {
                            $dateTime = [DateTime]::new(
                                [int]$Matches[1],  # Year
                                [int]$Matches[2],  # Month
                                [int]$Matches[3],  # Day
                                [int]$Matches[4],  # Hour
                                [int]$Matches[5],  # Minute
                                [int]$Matches[6],  # Second
                                [DateTimeKind]::Utc
                            )
                            $ConvertedProperties[$PropName] = $dateTime
                        } else {
                            $ConvertedProperties[$PropName] = $PropValue[0]
                        }
                    } catch {
                        $ConvertedProperties[$PropName] = $PropValue[0]
                    }
                } elseif ($PropNameLower -eq 'useraccountcontrol') {
                    # Convert userAccountControl to readable flags
                    try {
                        $UACValue = [Int32]$PropValue[0]
                        $UACFlags = @()

                        # Define UAC flags (MS-ADTS 2.2.16)
                        $FlagMap = @{
                            1 = "SCRIPT"
                            2 = "ACCOUNTDISABLE"
                            8 = "HOMEDIR_REQUIRED"
                            16 = "LOCKOUT"
                            32 = "PASSWD_NOTREQD"
                            64 = "PASSWD_CANT_CHANGE"
                            128 = "ENCRYPTED_TEXT_PWD_ALLOWED"
                            256 = "TEMP_DUPLICATE_ACCOUNT"
                            512 = "NORMAL_ACCOUNT"
                            2048 = "INTERDOMAIN_TRUST_ACCOUNT"
                            4096 = "WORKSTATION_TRUST_ACCOUNT"
                            8192 = "SERVER_TRUST_ACCOUNT"
                            65536 = "DONT_EXPIRE_PASSWORD"
                            131072 = "MNS_LOGON_ACCOUNT"
                            262144 = "SMARTCARD_REQUIRED"
                            524288 = "TRUSTED_FOR_DELEGATION"
                            1048576 = "NOT_DELEGATED"
                            2097152 = "USE_DES_KEY_ONLY"
                            4194304 = "DONT_REQ_PREAUTH"
                            8388608 = "PASSWORD_EXPIRED"
                            16777216 = "TRUSTED_TO_AUTH_FOR_DELEGATION"
                            33554432 = "NO_AUTH_DATA_REQUIRED"
                            67108864 = "PARTIAL_SECRETS_ACCOUNT"
                        }

                        foreach ($Flag in $FlagMap.Keys) {
                            if ($UACValue -band $Flag) {
                                $UACFlags += $FlagMap[$Flag]
                            }
                        }

                        $ConvertedProperties[$PropName] = $UACFlags
                    } catch {
                        $ConvertedProperties[$PropName] = $PropValue[0]
                    }
                } elseif ($PropNameLower -eq 'msds-supportedencryptiontypes') {
                    # Convert supported encryption types to readable flags
                    try {
                        $EncTypes = [Int32]$PropValue[0]
                        $EncTypeFlags = @()

                        # Encryption types (MS-KILE 2.2.7, bits A-E and J-L). 0x40 and 0x80
                        # are the SHA-2 variants of AES (RFC 8009); they were read as the
                        # FAST and compound-identity flags.
                        if ($EncTypes -band 0x1) { $EncTypeFlags += "DES-CBC-CRC" }
                        if ($EncTypes -band 0x2) { $EncTypeFlags += "DES-CBC-MD5" }
                        if ($EncTypes -band 0x4) { $EncTypeFlags += "RC4-HMAC" }
                        if ($EncTypes -band 0x8) { $EncTypeFlags += "AES128-CTS-HMAC-SHA1-96" }
                        if ($EncTypes -band 0x10) { $EncTypeFlags += "AES256-CTS-HMAC-SHA1-96" }
                        if ($EncTypes -band 0x20) { $EncTypeFlags += "AES256-CTS-HMAC-SHA1-96-SK" }
                        if ($EncTypes -band 0x40) { $EncTypeFlags += "AES128-CTS-HMAC-SHA256-128" }
                        if ($EncTypes -band 0x80) { $EncTypeFlags += "AES256-CTS-HMAC-SHA384-192" }

                        # No encryption type in the value - only the session-key bit or
                        # the feature flags below - leaves the account on the domain's
                        # default types, which is what "Not configured" says everywhere
                        # else. A computer with only compound identity set (0x20000) was
                        # "Not configured" by accident before; now it is on purpose.
                        if (($EncTypes -band 0xDF) -eq 0) { $EncTypeFlags = @("Not configured") + $EncTypeFlags }

                        # Kerberos feature flags, bits F-I: 0x10000 upwards, not 0x40
                        # upwards as this read them.
                        if ($EncTypes -band 0x10000) { $EncTypeFlags += "FAST-Supported" }
                        if ($EncTypes -band 0x20000) { $EncTypeFlags += "Compound-Identity-Supported" }
                        if ($EncTypes -band 0x40000) { $EncTypeFlags += "Claims-Supported" }
                        if ($EncTypes -band 0x80000) { $EncTypeFlags += "Resource-SID-Compression-Disabled" }

                        $ConvertedProperties[$PropName] = $EncTypeFlags
                    } catch {
                        $ConvertedProperties[$PropName] = $PropValue[0]
                    }
                } elseif ($PropNameLower -eq 'samaccounttype') {
                    # Convert sAMAccountType to readable value
                    try {
                        $SamType = [Int32]$PropValue[0]
                        $SamTypeName = switch ($SamType) {
                            268435456 { "GROUP_OBJECT" }
                            268435457 { "NON_SECURITY_GROUP_OBJECT" }
                            536870912 { "ALIAS_OBJECT" }
                            536870913 { "NON_SECURITY_ALIAS_OBJECT" }
                            805306368 { "USER_OBJECT" }
                            805306369 { "MACHINE_ACCOUNT" }
                            805306370 { "TRUST_ACCOUNT" }
                            1073741824 { "APP_BASIC_GROUP" }
                            1073741825 { "APP_QUERY_GROUP" }
                            default { "UNKNOWN ($SamType)" }
                        }
                        $ConvertedProperties[$PropName] = $SamTypeName
                    } catch {
                        $ConvertedProperties[$PropName] = $PropValue[0]
                    }
                } elseif ($PropNameLower -eq 'grouptype') {
                    # Convert groupType to readable flags
                    try {
                        $GroupType = [Int32]$PropValue[0]
                        $GroupScope = if ($GroupType -band 2) { "Global" }
                                      elseif ($GroupType -band 4) { "Domain Local" }
                                      elseif ($GroupType -band 8) { "Universal" }
                                      elseif ($GroupType -band 1) { "Builtin Local" }
                                      else { "Unknown Scope" }

                        $GroupTypeName = if ($GroupType -band [int]0x80000000) {
                            "$GroupScope Security Group"
                        } else {
                            "$GroupScope Distribution Group"
                        }

                        $ConvertedProperties[$PropName] = $GroupTypeName
                    } catch {
                        $ConvertedProperties[$PropName] = $PropValue[0]
                    }
                } elseif ($PropNameLower -eq 'instancetype') {
                    # Convert instanceType to readable value
                    try {
                        $InstType = [Int32]$PropValue[0]
                        if ($InstType -eq 4) {
                            $ConvertedProperties[$PropName] = "Writable"
                        } else {
                            $InstTypeFlags = @()
                            if ($InstType -band 0x01) { $InstTypeFlags += "NC_HEAD" }
                            if ($InstType -band 0x02) { $InstTypeFlags += "NC_REPLICA" }
                            if ($InstType -band 0x04) { $InstTypeFlags += "NC_WRITABLE" }
                            if ($InstType -band 0x08) { $InstTypeFlags += "NC_ABOVE" }
                            if ($InstType -band 0x10) { $InstTypeFlags += "NC_BEING_CONSTRUCTED" }
                            if ($InstType -band 0x20) { $InstTypeFlags += "NC_BEING_REMOVED" }
                            $ConvertedProperties[$PropName] = ($InstTypeFlags -join ", ")
                        }
                    } catch {
                        $ConvertedProperties[$PropName] = $PropValue[0]
                    }
                } elseif ($PropNameLower -eq 'systemflags') {
                    # Convert systemFlags to readable flags
                    try {
                        $SysFlags = [Int32]$PropValue[0]
                        $SysFlagsArray = @()

                        $SysFlagsMap = @{
                            0x00000001 = "FLAG_DISALLOW_DELETE"
                            0x00000002 = "FLAG_CONFIG_ALLOW_RENAME"
                            0x00000004 = "FLAG_CONFIG_ALLOW_MOVE"
                            0x00000010 = "FLAG_ATTR_NOT_REPLICATED"
                            0x04000000 = "FLAG_ATTR_IS_CONSTRUCTED"
                            0x10000000 = "FLAG_DOMAIN_DISALLOW_RENAME"
                            0x20000000 = "FLAG_DOMAIN_DISALLOW_MOVE"
                            0x40000000 = "FLAG_CR_NTDS_NC"
                            0x80000000 = "FLAG_CR_NTDS_DOMAIN"
                        }

                        foreach ($Flag in $SysFlagsMap.Keys) {
                            if ($SysFlags -band $Flag) {
                                $SysFlagsArray += $SysFlagsMap[$Flag]
                            }
                        }

                        if ($SysFlagsArray.Count -gt 0) {
                            $ConvertedProperties[$PropName] = $SysFlagsArray
                        } else {
                            $ConvertedProperties[$PropName] = @("NONE")
                        }
                    } catch {
                        $ConvertedProperties[$PropName] = $PropValue[0]
                    }
                } elseif ($PropNameLower -eq 'trustdirection') {
                    # Convert trust direction to readable value (MS-ADTS 6.1.6.7.12)
                    try {
                        $TrustDir = [Int32]$PropValue[0]
                        $TrustDirName = switch ($TrustDir) {
                            0 { "Disabled" }
                            1 { "Inbound" }
                            2 { "Outbound" }
                            3 { "Bidirectional" }
                            default { "Unknown ($TrustDir)" }
                        }
                        $ConvertedProperties[$PropName] = $TrustDirName
                    } catch {
                        $ConvertedProperties[$PropName] = $PropValue[0]
                    }
                } elseif ($PropNameLower -eq 'trusttype') {
                    # Convert trust type to readable value (MS-ADTS 6.1.6.7.15). The
                    # constant names (DOWNLEVEL, UPLEVEL) are not repeated: the
                    # name of what the partner is says the same.
                    try {
                        $TrustTypeVal = [Int32]$PropValue[0]
                        $TrustTypeName = switch ($TrustTypeVal) {
                            1 { "Windows NT" }
                            2 { "Active Directory" }
                            3 { "MIT Kerberos Realm" }
                            4 { "DCE" }
                            5 { "Entra ID" }
                            default { "Unknown ($TrustTypeVal)" }
                        }
                        $ConvertedProperties[$PropName] = $TrustTypeName
                    } catch {
                        $ConvertedProperties[$PropName] = $PropValue[0]
                    }
                } elseif ($PropNameLower -eq 'trustattributes') {
                    # Convert trust attributes to readable flags (MS-ADTS 6.1.6.7.9)
                    try {
                        $TrustAttr = [Int32]$PropValue[0]
                        $TrustAttrFlags = @()

                        if ($TrustAttr -band 0x00000001) { $TrustAttrFlags += "NON_TRANSITIVE" }
                        if ($TrustAttr -band 0x00000002) { $TrustAttrFlags += "UPLEVEL_ONLY" }
                        if ($TrustAttr -band 0x00000004) { $TrustAttrFlags += "QUARANTINED_DOMAIN" }
                        if ($TrustAttr -band 0x00000008) { $TrustAttrFlags += "FOREST_TRANSITIVE" }
                        if ($TrustAttr -band 0x00000010) { $TrustAttrFlags += "CROSS_ORGANIZATION" }
                        if ($TrustAttr -band 0x00000020) { $TrustAttrFlags += "WITHIN_FOREST" }
                        if ($TrustAttr -band 0x00000040) { $TrustAttrFlags += "TREAT_AS_EXTERNAL" }
                        if ($TrustAttr -band 0x00000080) { $TrustAttrFlags += "USES_RC4_ENCRYPTION" }
                        if ($TrustAttr -band 0x00000200) { $TrustAttrFlags += "CROSS_ORGANIZATION_NO_TGT_DELEGATION" }
                        if ($TrustAttr -band 0x00000400) { $TrustAttrFlags += "PIM_TRUST" }

                        if ($TrustAttrFlags.Count -gt 0) {
                            $ConvertedProperties[$PropName] = $TrustAttrFlags
                        } else {
                            $ConvertedProperties[$PropName] = @("NONE")
                        }
                    } catch {
                        $ConvertedProperties[$PropName] = $PropValue[0]
                    }
                } elseif ($PropNameLower -eq 'pwdproperties') {
                    # Convert password properties to readable flags (MS-SAMR, Domain Fields: PasswordProperties)
                    try {
                        $PwdProps = [Int32]$PropValue[0]
                        $PwdPropsFlags = @()

                        if ($PwdProps -band 1) { $PwdPropsFlags += "DOMAIN_PASSWORD_COMPLEX" }
                        if ($PwdProps -band 2) { $PwdPropsFlags += "DOMAIN_PASSWORD_NO_ANON_CHANGE" }
                        if ($PwdProps -band 4) { $PwdPropsFlags += "DOMAIN_PASSWORD_NO_CLEAR_CHANGE" }
                        if ($PwdProps -band 8) { $PwdPropsFlags += "DOMAIN_LOCKOUT_ADMINS" }
                        if ($PwdProps -band 16) { $PwdPropsFlags += "DOMAIN_PASSWORD_STORE_CLEARTEXT" }
                        if ($PwdProps -band 32) { $PwdPropsFlags += "DOMAIN_REFUSE_PASSWORD_CHANGE" }

                        if ($PwdPropsFlags.Count -gt 0) {
                            $ConvertedProperties[$PropName] = $PwdPropsFlags
                        } else {
                            $ConvertedProperties[$PropName] = @("NONE")
                        }
                    } catch {
                        $ConvertedProperties[$PropName] = $PropValue[0]
                    }
                # There used to be a branch here rendering the five domain policy intervals
                # as "42 days" / "30 minutes" / "Not set" / "Never". It was dead code: all
                # five are listed in $Script:LDAPFileTimeAttributes, so the FileTime branch
                # above claims them first and never falls through to here. What consumers
                # actually receive is the raw interval string, and Get-DomainPasswordPolicy
                # converts it itself - deliberately, see the note at the head of this file.
                # Removed rather than made reachable: reviving it would change the value of
                # maxPwdAge, minPwdAge, lockoutDuration, lockOutObservationWindow and
                # forceLogoff for every consumer, which is a decision about report data, not
                # a cleanup.
                } elseif ($PropNameLower -eq 'ms-mcs-admpwdexpirationtime' -or $PropNameLower -eq 'mslaps-passwordexpirationtime') {
                    # LAPS Expiration Times
                    try {
                        $ExpirationInt64 = [Int64]$PropValue[0]
                        # 0 and Int64::MaxValue are not timestamps - the same two special
                        # values the generic FileTime branch above passes through raw. 0 is
                        # the documented way to force an immediate rotation, and
                        # FromFileTime(0) is 1601-01-01, which reached Get-LAPSConfiguration
                        # as a rotation date: a machine whose password is rotating right now
                        # became the worst finding in the domain, "155510 days overdue".
                        # Passed through raw, so a caller testing for [DateTime] can see
                        # that it is not one.
                        if ($ExpirationInt64 -eq 0 -or $ExpirationInt64 -eq 9223372036854775807) {
                            $ConvertedProperties[$PropName] = $PropValue[0]
                        } else {
                            $ConvertedProperties[$PropName] = [DateTime]::FromFileTime($ExpirationInt64)
                        }
                    } catch {
                        $ConvertedProperties[$PropName] = $PropValue[0]
                    }
                } elseif ($PropNameLower -eq 'mslaps-password') {
                    # LAPS Native Plaintext Password - JSON format: {"n":"Account","t":"HexFILETIME","p":"Password"}
                    try {
                        $LAPSObj = $PropValue[0] | ConvertFrom-Json
                        if ($LAPSObj.p) {
                            $ConvertedProperties[$PropName] = $LAPSObj.p
                            if ($LAPSObj.n) {
                                $ConvertedProperties['msLAPS-Account'] = $LAPSObj.n
                            }
                            if ($LAPSObj.t) {
                                try {
                                    $LAPSFileTime = [Convert]::ToInt64($LAPSObj.t, 16)
                                    $ConvertedProperties['msLAPS-Updated'] = ([DateTime]::FromFileTimeUtc($LAPSFileTime))
                                } catch { }
                            }
                        } else {
                            $ConvertedProperties[$PropName] = $PropValue[0]
                        }
                    } catch {
                        $ConvertedProperties[$PropName] = $PropValue[0]
                    }
                } elseif ($PropNameLower -eq 'msexchrecipientdisplaytype') {
                    # Convert Exchange Recipient Display Type
                    try {
                        $DisplayType = [Int64]$PropValue[0]
                        $DisplayTypeName = switch ($DisplayType) {
                            0 { "MailboxUser" }
                            1 { "DistributionGroup" }
                            2 { "PublicFolder" }
                            3 { "DynamicDistributionGroup" }
                            4 { "Organization" }
                            5 { "PrivateDistributionList" }
                            6 { "RemoteMailUser" }
                            7 { "ConferenceRoomMailbox" }
                            8 { "EquipmentMailbox" }
                            10 { "ArbitrationMailbox" }
                            11 { "MailboxPlan" }
                            12 { "LinkedUser" }
                            15 { "RoomList" }
                            1073741824 { "ACLableMailboxUser" }
                            1073741830 { "ACLableRemoteMailUser" }
                            -2147483642 { "SyncedMailboxUser" }
                            -2147483391 { "SyncedUDGasUDG" }
                            -2147483386 { "SyncedUDGasContact" }
                            -2147483130 { "SyncedPublicFolder" }
                            -2147482874 { "SyncedDynamicDistributionGroup" }
                            -2147482106 { "SyncedRemoteMailUser" }
                            -2147481850 { "SyncedConferenceRoomMailbox" }
                            -2147481594 { "SyncedEquipmentMailbox" }
                            -2147481343 { "SyncedUSGasUDG" }
                            -2147481338 { "SyncedUSGasContact" }
                            -1073741818 { "ACLableSyncedMailboxUser" }
                            -1073740282 { "ACLableSyncedRemoteMailUser" }
                            -1073739514 { "ACLableSyncedUSGasContact" }
                            -1073739511 { "SyncedUSGasUSG" }
                            -1073741824 { "SecurityDistributionGroup" }
                            default { "Type $DisplayType" }
                        }
                        $ConvertedProperties[$PropName] = $DisplayTypeName
                    } catch {
                        $ConvertedProperties[$PropName] = $PropValue[0]
                    }
                } elseif ($PropNameLower -eq 'msexchrecipienttypedetails') {
                    # Convert Exchange Recipient Type Details
                    try {
                        $TypeDetails = [Int64]$PropValue[0]
                        $TypeName = switch ($TypeDetails) {
                            1 { "UserMailbox" }
                            2 { "LinkedMailbox" }
                            4 { "SharedMailbox" }
                            8 { "LegacyMailbox" }
                            16 { "RoomMailbox" }
                            32 { "EquipmentMailbox" }
                            64 { "MailContact" }
                            128 { "MailUser" }
                            256 { "MailUniversalDistributionGroup" }
                            512 { "MailNonUniversalGroup" }
                            1024 { "MailUniversalSecurityGroup" }
                            2048 { "DynamicDistributionGroup" }
                            4096 { "PublicFolder" }
                            8192 { "SystemAttendantMailbox" }
                            16384 { "SystemMailbox" }
                            32768 { "MailForestContact" }
                            65536 { "User" }
                            131072 { "Contact" }
                            262144 { "UniversalDistributionGroup" }
                            524288 { "UniversalSecurityGroup" }
                            1048576 { "NonUniversalGroup" }
                            2097152 { "DisabledUser" }
                            4194304 { "MicrosoftExchange" }
                            8388608 { "ArbitrationMailbox" }
                            16777216 { "MailboxPlan" }
                            33554432 { "LinkedUser" }
                            268435456 { "RoomList" }
                            536870912 { "DiscoveryMailbox" }
                            1073741824 { "RoleGroup" }
                            2147483648 { "RemoteUserMailbox" }
                            4294967296 { "Computer" }
                            8589934592 { "RemoteRoomMailbox" }
                            17179869184 { "RemoteEquipmentMailbox" }
                            34359738368 { "RemoteSharedMailbox" }
                            68719476736 { "PublicFolderMailbox" }
                            137438953472 { "TeamMailbox" }
                            549755813888 { "MonitoringMailbox" }
                            1099511627776 { "GroupMailbox" }
                            2199023255552 { "LinkedRoomMailbox" }
                            4398046511104 { "AuditLogMailbox" }
                            17592186044416 { "SchedulingMailbox" }
                            35184372088832 { "GuestMailUser" }
                            default { "Type $TypeDetails" }
                        }
                        $ConvertedProperties[$PropName] = $TypeName
                    } catch {
                        $ConvertedProperties[$PropName] = $PropValue[0]
                    }
                } elseif ($PropNameLower -eq 'mspki-certificate-name-flag') {
                    # Convert Certificate Name Flag to readable flags (ADCS ESC1)
                    try {
                        $CertNameFlag = [Int32]$PropValue[0]
                        $CertNameFlags = @()

                        # CT_FLAG_ENROLLEE_SUPPLIES_SUBJECT (0x00000001) - ESC1 indicator
                        if ($CertNameFlag -band 0x00000001) { $CertNameFlags += "ENROLLEE_SUPPLIES_SUBJECT" }
                        # CT_FLAG_ENROLLEE_SUPPLIES_SUBJECT_ALT_NAME (0x00010000)
                        if ($CertNameFlag -band 0x00010000) { $CertNameFlags += "ENROLLEE_SUPPLIES_SUBJECT_ALT_NAME" }
                        # CT_FLAG_SUBJECT_ALT_REQUIRE_DOMAIN_DNS (0x00400000)
                        if ($CertNameFlag -band 0x00400000) { $CertNameFlags += "SUBJECT_ALT_REQUIRE_DOMAIN_DNS" }
                        # CT_FLAG_SUBJECT_ALT_REQUIRE_SPN (0x00800000)
                        if ($CertNameFlag -band 0x00800000) { $CertNameFlags += "SUBJECT_ALT_REQUIRE_SPN" }
                        # CT_FLAG_SUBJECT_ALT_REQUIRE_DIRECTORY_GUID (0x01000000)
                        if ($CertNameFlag -band 0x01000000) { $CertNameFlags += "SUBJECT_ALT_REQUIRE_DIRECTORY_GUID" }
                        # CT_FLAG_SUBJECT_ALT_REQUIRE_UPN (0x02000000)
                        if ($CertNameFlag -band 0x02000000) { $CertNameFlags += "SUBJECT_ALT_REQUIRE_UPN" }
                        # CT_FLAG_SUBJECT_ALT_REQUIRE_EMAIL (0x04000000)
                        if ($CertNameFlag -band 0x04000000) { $CertNameFlags += "SUBJECT_ALT_REQUIRE_EMAIL" }
                        # CT_FLAG_SUBJECT_ALT_REQUIRE_DNS (0x08000000)
                        if ($CertNameFlag -band 0x08000000) { $CertNameFlags += "SUBJECT_ALT_REQUIRE_DNS" }
                        # CT_FLAG_SUBJECT_REQUIRE_DNS_AS_CN (0x10000000)
                        if ($CertNameFlag -band 0x10000000) { $CertNameFlags += "SUBJECT_REQUIRE_DNS_AS_CN" }
                        # CT_FLAG_SUBJECT_REQUIRE_EMAIL (0x20000000)
                        if ($CertNameFlag -band 0x20000000) { $CertNameFlags += "SUBJECT_REQUIRE_EMAIL" }
                        # CT_FLAG_SUBJECT_REQUIRE_COMMON_NAME (0x40000000)
                        if ($CertNameFlag -band 0x40000000) { $CertNameFlags += "SUBJECT_REQUIRE_COMMON_NAME" }
                        # CT_FLAG_SUBJECT_REQUIRE_DIRECTORY_PATH (0x80000000)
                        if ($CertNameFlag -band 0x80000000) { $CertNameFlags += "SUBJECT_REQUIRE_DIRECTORY_PATH" }
                        # CT_FLAG_OLD_CERT_SUPPLIES_SUBJECT_AND_ALT_NAME (0x00000008)
                        if ($CertNameFlag -band 0x00000008) { $CertNameFlags += "OLD_CERT_SUPPLIES_SUBJECT_AND_ALT_NAME" }

                        if ($CertNameFlags.Count -gt 0) {
                            $ConvertedProperties[$PropName] = $CertNameFlags
                        } else {
                            $ConvertedProperties[$PropName] = @("NONE")
                        }
                    } catch {
                        $ConvertedProperties[$PropName] = $PropValue[0]
                    }
                } elseif ($PropNameLower -eq 'mspki-enrollment-flag') {
                    # Convert Enrollment Flag to readable flags (ADCS ESC2/ESC9)
                    try {
                        $EnrollFlag = [Int32]$PropValue[0]
                        $EnrollFlags = @()

                        # CT_FLAG_INCLUDE_SYMMETRIC_ALGORITHMS (0x00000001)
                        if ($EnrollFlag -band 0x00000001) { $EnrollFlags += "INCLUDE_SYMMETRIC_ALGORITHMS" }
                        # CT_FLAG_PEND_ALL_REQUESTS (0x00000002) - Manager approval required
                        if ($EnrollFlag -band 0x00000002) { $EnrollFlags += "PEND_ALL_REQUESTS" }
                        # CT_FLAG_PUBLISH_TO_KRA_CONTAINER (0x00000004)
                        if ($EnrollFlag -band 0x00000004) { $EnrollFlags += "PUBLISH_TO_KRA_CONTAINER" }
                        # CT_FLAG_PUBLISH_TO_DS (0x00000008)
                        if ($EnrollFlag -band 0x00000008) { $EnrollFlags += "PUBLISH_TO_DS" }
                        # CT_FLAG_AUTO_ENROLLMENT_CHECK_USER_DS_CERTIFICATE (0x00000010)
                        if ($EnrollFlag -band 0x00000010) { $EnrollFlags += "AUTO_ENROLLMENT_CHECK_USER_DS_CERTIFICATE" }
                        # CT_FLAG_AUTO_ENROLLMENT (0x00000020)
                        if ($EnrollFlag -band 0x00000020) { $EnrollFlags += "AUTO_ENROLLMENT" }
                        # CT_FLAG_PREVIOUS_APPROVAL_VALIDATE_REENROLLMENT (0x00000040)
                        if ($EnrollFlag -band 0x00000040) { $EnrollFlags += "PREVIOUS_APPROVAL_VALIDATE_REENROLLMENT" }
                        # CT_FLAG_USER_INTERACTION_REQUIRED (0x00000100)
                        if ($EnrollFlag -band 0x00000100) { $EnrollFlags += "USER_INTERACTION_REQUIRED" }
                        # CT_FLAG_REMOVE_INVALID_CERTIFICATE_FROM_PERSONAL_STORE (0x00000400)
                        if ($EnrollFlag -band 0x00000400) { $EnrollFlags += "REMOVE_INVALID_CERTIFICATE_FROM_PERSONAL_STORE" }
                        # CT_FLAG_ALLOW_ENROLL_ON_BEHALF_OF (0x00000800)
                        if ($EnrollFlag -band 0x00000800) { $EnrollFlags += "ALLOW_ENROLL_ON_BEHALF_OF" }
                        # CT_FLAG_ADD_OCSP_NOCHECK (0x00001000)
                        if ($EnrollFlag -band 0x00001000) { $EnrollFlags += "ADD_OCSP_NOCHECK" }
                        # CT_FLAG_ENABLE_KEY_REUSE_ON_NT_TOKEN_KEYSET_STORAGE_FULL (0x00002000)
                        if ($EnrollFlag -band 0x00002000) { $EnrollFlags += "ENABLE_KEY_REUSE_ON_NT_TOKEN_KEYSET_STORAGE_FULL" }
                        # CT_FLAG_NOREVOCATIONINFOINISSUEDCERTS (0x00004000)
                        if ($EnrollFlag -band 0x00004000) { $EnrollFlags += "NOREVOCATIONINFOINISSUEDCERTS" }
                        # CT_FLAG_INCLUDE_BASIC_CONSTRAINTS_FOR_EE_CERTS (0x00008000)
                        if ($EnrollFlag -band 0x00008000) { $EnrollFlags += "INCLUDE_BASIC_CONSTRAINTS_FOR_EE_CERTS" }
                        # CT_FLAG_ALLOW_PREVIOUS_APPROVAL_KEYBASEDRENEWAL_VALIDATE_REENROLLMENT (0x00010000)
                        if ($EnrollFlag -band 0x00010000) { $EnrollFlags += "ALLOW_PREVIOUS_APPROVAL_KEYBASEDRENEWAL_VALIDATE_REENROLLMENT" }
                        # CT_FLAG_ISSUANCE_POLICIES_FROM_REQUEST (0x00020000)
                        if ($EnrollFlag -band 0x00020000) { $EnrollFlags += "ISSUANCE_POLICIES_FROM_REQUEST" }
                        # CT_FLAG_SKIP_AUTO_RENEWAL (0x00040000)
                        if ($EnrollFlag -band 0x00040000) { $EnrollFlags += "SKIP_AUTO_RENEWAL" }
                        # CT_FLAG_NO_SECURITY_EXTENSION (0x00080000) - ESC9 indicator
                        if ($EnrollFlag -band 0x00080000) { $EnrollFlags += "NO_SECURITY_EXTENSION" }

                        if ($EnrollFlags.Count -gt 0) {
                            $ConvertedProperties[$PropName] = $EnrollFlags
                        } else {
                            $ConvertedProperties[$PropName] = @("NONE")
                        }
                    } catch {
                        $ConvertedProperties[$PropName] = $PropValue[0]
                    }
                } elseif ($PropNameLower -eq 'mspki-private-key-flag') {
                    # Convert Private Key Flag to readable flags
                    try {
                        $PrivKeyFlag = [Int32]$PropValue[0]
                        $PrivKeyFlags = @()

                        # CT_FLAG_REQUIRE_PRIVATE_KEY_ARCHIVAL (0x00000001)
                        if ($PrivKeyFlag -band 0x00000001) { $PrivKeyFlags += "REQUIRE_PRIVATE_KEY_ARCHIVAL" }
                        # CT_FLAG_EXPORTABLE_KEY (0x00000010)
                        if ($PrivKeyFlag -band 0x00000010) { $PrivKeyFlags += "EXPORTABLE_KEY" }
                        # CT_FLAG_STRONG_KEY_PROTECTION_REQUIRED (0x00000020)
                        if ($PrivKeyFlag -band 0x00000020) { $PrivKeyFlags += "STRONG_KEY_PROTECTION_REQUIRED" }
                        # CT_FLAG_REQUIRE_ALTERNATE_SIGNATURE_ALGORITHM (0x00000040)
                        if ($PrivKeyFlag -band 0x00000040) { $PrivKeyFlags += "REQUIRE_ALTERNATE_SIGNATURE_ALGORITHM" }
                        # CT_FLAG_REQUIRE_SAME_KEY_RENEWAL (0x00000080)
                        if ($PrivKeyFlag -band 0x00000080) { $PrivKeyFlags += "REQUIRE_SAME_KEY_RENEWAL" }
                        # CT_FLAG_USE_LEGACY_PROVIDER (0x00000100)
                        if ($PrivKeyFlag -band 0x00000100) { $PrivKeyFlags += "USE_LEGACY_PROVIDER" }
                        # CT_FLAG_ATTEST_NONE (0x00000000) - implicit
                        # CT_FLAG_ATTEST_REQUIRED (0x00002000)
                        if ($PrivKeyFlag -band 0x00002000) { $PrivKeyFlags += "ATTEST_REQUIRED" }
                        # CT_FLAG_ATTEST_PREFERRED (0x00001000)
                        if ($PrivKeyFlag -band 0x00001000) { $PrivKeyFlags += "ATTEST_PREFERRED" }
                        # CT_FLAG_ATTESTATION_WITHOUT_POLICY (0x00004000)
                        if ($PrivKeyFlag -band 0x00004000) { $PrivKeyFlags += "ATTESTATION_WITHOUT_POLICY" }
                        # CT_FLAG_EK_TRUST_ON_USE (0x00000200)
                        if ($PrivKeyFlag -band 0x00000200) { $PrivKeyFlags += "EK_TRUST_ON_USE" }
                        # CT_FLAG_EK_VALIDATE_CERT (0x00000400)
                        if ($PrivKeyFlag -band 0x00000400) { $PrivKeyFlags += "EK_VALIDATE_CERT" }
                        # CT_FLAG_EK_VALIDATE_KEY (0x00000800)
                        if ($PrivKeyFlag -band 0x00000800) { $PrivKeyFlags += "EK_VALIDATE_KEY" }
                        # CT_FLAG_HELLO_LOGON_KEY (0x00200000)
                        if ($PrivKeyFlag -band 0x00200000) { $PrivKeyFlags += "HELLO_LOGON_KEY" }

                        if ($PrivKeyFlags.Count -gt 0) {
                            $ConvertedProperties[$PropName] = $PrivKeyFlags
                        } else {
                            $ConvertedProperties[$PropName] = @("NONE")
                        }
                    } catch {
                        $ConvertedProperties[$PropName] = $PropValue[0]
                    }
                } elseif ($PropNameLower -eq 'pkidefaultkeyspec') {
                    # Convert pKIDefaultKeySpec to readable value
                    try {
                        $KeySpec = [Int32]$PropValue[0]
                        $KeySpecName = switch ($KeySpec) {
                            1 { "AT_KEYEXCHANGE (Key Exchange)" }
                            2 { "AT_SIGNATURE (Digital Signature)" }
                            default { "Unknown ($KeySpec)" }
                        }
                        $ConvertedProperties[$PropName] = $KeySpecName
                    } catch {
                        $ConvertedProperties[$PropName] = $PropValue[0]
                    }
                } elseif ($PropNameLower -eq 'msrassavedframedipaddress') {
                    # Convert IP address from signed Int32 to dotted decimal notation
                    try {
                        $IPBytes = [BitConverter]::GetBytes([Int32]$PropValue[0])
                        $IPAddr = [System.Net.IPAddress]::new($IPBytes)
                        $ConvertedProperties[$PropName] = $IPAddr.ToString()
                    } catch {
                        $ConvertedProperties[$PropName] = $PropValue[0]
                    }
                } elseif ($PropNameLower -eq 'msexchversion') {
                    # Convert Exchange Version to readable format
                    try {
                        $Version = [Int64]$PropValue[0]
                        $Major = ($Version -shr 48) -band 0xFFFF
                        $Minor = ($Version -shr 32) -band 0xFFFF
                        $Build = ($Version -shr 16) -band 0xFFFF
                        $Revision = $Version -band 0xFFFF
                        $VersionString = "$Major.$Minor.$Build.$Revision"
                        $ConvertedProperties[$PropName] = $VersionString
                    } catch {
                        $ConvertedProperties[$PropName] = $PropValue[0]
                    }
                } elseif ($PropNameLower -eq 'msexchelcmailboxflags') {
                    # Convert Exchange ELC Mailbox Flags to readable flags
                    try {
                        $ELCFlags = [Int32]$PropValue[0]
                        $ELCFlagList = @()

                        if ($ELCFlags -band 1) { $ELCFlagList += "MRM_POLICY_APPLIED" }
                        if ($ELCFlags -band 2) { $ELCFlagList += "SINGLE_ITEM_RECOVERY" }
                        if ($ELCFlags -band 4) { $ELCFlagList += "CALENDAR_VERSION_STORE" }
                        if ($ELCFlags -band 8) { $ELCFlagList += "LITIGATION_HOLD" }
                        if ($ELCFlags -band 16) { $ELCFlagList += "DUMPSTER_EXTENDED" }
                        if ($ELCFlags -band 32) { $ELCFlagList += "SITE_MAILBOX_HOLD" }
                        if ($ELCFlags -band 64) { $ELCFlagList += "ARCHIVE_ENABLED" }
                        if ($ELCFlags -band 128) { $ELCFlagList += "ELC_PROCESSING_DISABLED" }

                        if ($ELCFlagList.Count -gt 0) {
                            $ConvertedProperties[$PropName] = $ELCFlagList
                        } else {
                            $ConvertedProperties[$PropName] = @("NONE")
                        }
                    } catch {
                        $ConvertedProperties[$PropName] = $PropValue[0]
                    }
                } elseif ($PropNameLower -match '^msexch.*quota$' -or $PropNameLower -eq 'mdbstoragequota' -or $PropNameLower -eq 'mdboverquotalimit' -or $PropNameLower -eq 'mdboverhardquotalimit') {
                    # Convert Exchange quota attributes from bytes to human-readable format
                    try {
                        $QuotaBytes = [Int64]$PropValue[0]

                        if ($QuotaBytes -eq 0) {
                            $QuotaString = "Unlimited"
                        } elseif ($QuotaBytes -lt 1KB) {
                            $QuotaString = "$QuotaBytes bytes"
                        } elseif ($QuotaBytes -lt 1MB) {
                            $QuotaKB = [Math]::Round($QuotaBytes / 1KB, 2)
                            $QuotaString = "$QuotaKB KB"
                        } elseif ($QuotaBytes -lt 1GB) {
                            $QuotaMB = [Math]::Round($QuotaBytes / 1MB, 2)
                            $QuotaString = "$QuotaMB MB"
                        } elseif ($QuotaBytes -lt 1TB) {
                            $QuotaGB = [Math]::Round($QuotaBytes / 1GB, 2)
                            $QuotaString = "$QuotaGB GB"
                        } else {
                            $QuotaTB = [Math]::Round($QuotaBytes / 1TB, 2)
                            $QuotaString = "$QuotaTB TB"
                        }

                        $ConvertedProperties[$PropName] = $QuotaString
                    } catch {
                        $ConvertedProperties[$PropName] = $PropValue[0]
                    }
                } else {
                    # Default: add as-is
                    $ConvertedProperties[$PropName] = $PropValue[0]
                }
            }
        } else {
            # Multiple values - add as array
            $ConvertedProperties[$PropName] = @($PropValue)
        }
    return $ConvertedProperties
}
