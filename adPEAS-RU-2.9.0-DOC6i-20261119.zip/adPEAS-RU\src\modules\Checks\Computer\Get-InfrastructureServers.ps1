﻿<#
.SYNOPSIS
    Reports the non-computer accounts that carry one of a service's SPNs.

.DESCRIPTION
    An SPN sits on the identity the service authenticates as. Where SQL Server, SCCM or
    SCOM runs under a domain service account - routine in a managed environment, and the
    precondition for Kerberos against the service rather than an exception - the SPN is on
    a user or gMSA object, and a query over computer objects sees none of it. The inventory
    a reader bases their attack surface on then understates it, without saying so.

    The host part of the SPN is what names the target system, so it is reported with the
    account: the account is the credential, the host is what runs there.

    objectCategory, not objectClass: a gMSA carries 'computer' among its object classes, so
    (!(objectClass=computer)) would exclude the very accounts this is looking for.
    objectCategory names the most specific class, which is what tells the two apart.

.PARAMETER ServiceName
    How the service is called in the report, e.g. 'MSSQL'.

.PARAMETER SPNFilter
    The same LDAP filter clause the computer query uses, e.g. "(servicePrincipalName=MSSQLSvc/*)".

.PARAMETER SPNPrefix
    The SPN prefixes whose host part is worth printing, e.g. @('MSSQLSvc/').

.PARAMETER ConnectionParams
    Domain/Server/Credential, as the caller received them.

.PARAMETER PrivilegedFindingId
    When given, each account is also checked for privileged rights in the domain, and the
    privileged ones are reported under this finding. A service runs its code as the account
    and the host stores the account's password, so whoever controls the service or its host
    holds the account's rights - for SQL Server, a sysadmin reaches them through xp_cmdshell.
    Without it the accounts are listed and nothing more.

.NOTES
    Internal helper function
#>
function Show-SPNServiceAccounts {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [string]$ServiceName,

        [Parameter(Mandatory=$true)]
        [string]$SPNFilter,

        [Parameter(Mandatory=$true)]
        [string[]]$SPNPrefix,

        [Parameter(Mandatory=$false)]
        [hashtable]$ConnectionParams = @{},

        [Parameter(Mandatory=$false)]
        [string]$PrivilegedFindingId
    )

    $accounts = @()
    try {
        $accounts = @(Get-DomainObject -LDAPFilter "(&$SPNFilter(!(objectCategory=computer)))" `
            -Properties 'sAMAccountName', 'servicePrincipalName', 'objectClass', 'objectSid' @ConnectionParams)
    } catch {
        Write-Log "[Get-InfrastructureServers] $ServiceName — ошибка поиска служебной учётной записи: $_" -Level Error
        Show-Line "Учётные записи службы $ServiceName прочитать не удалось — результат неизвестен, а не пуст" -Class "Note"
        return
    }

    if (@($accounts).Count -eq 0) { return }

    $described = @()
    $privileged = @()
    $unevaluated = @()
    foreach ($account in $accounts) {
        $hostNames = @()
        foreach ($spn in @($account.servicePrincipalName)) {
            foreach ($prefix in $SPNPrefix) {
                if ("$spn" -like "$prefix*") {
                    # MSSQLSvc/host.contoso.com:1433 and MSSQLSvc/host:INSTANCE both end the
                    # host at the first colon; SMS and CCM SPNs carry no port.
                    $hostPart = ("$spn".Substring($prefix.Length) -split '[:/]')[0]
                    if ($hostPart -and ($hostNames -notcontains $hostPart)) { $hostNames += $hostPart }
                }
            }
        }

        $label = "$($account.sAMAccountName)"
        if (@($hostNames).Count -gt 0) { $label = $label + ' (' + (@($hostNames) -join ', ') + ')' }
        $described += $label

        if (-not $PrivilegedFindingId) { continue }

        # Operators included: Backup and Server Operators reach a domain controller as
        # surely as Domain Admins do, and the service hands either to whoever controls it.
        # An account whose privileges cannot be told is named as unknown rather than
        # counted with the unprivileged ones.
        $privilegeCheck = $null
        $accountSID = "$($account.objectSid)"
        if (-not [string]::IsNullOrWhiteSpace($accountSID)) {
            try {
                $privilegeCheck = Test-IsPrivileged -Identity $accountSID -IncludeOperators
            } catch {
                Write-Log "[Get-InfrastructureServers] Не удалось проверить привилегии $($account.sAMAccountName): $_"
            }
        }

        if ($null -eq $privilegeCheck -or $null -eq $privilegeCheck.IsPrivileged) {
            $unevaluated += "$($account.sAMAccountName)"
        } elseif ($privilegeCheck.IsPrivileged -eq $true) {
            $via = if ($privilegeCheck.MatchedGroup) { $privilegeCheck.MatchedGroup } else { $privilegeCheck.Reason }
            $privileged += "$($account.sAMAccountName) ($via)"
        }
    }

    Show-Line "Служба $ServiceName также работает под $(@($described).Count) доменными записями; узел определён по SPN: $(@($described) -join '; ')" -Class "Hint"

    if (@($privileged).Count -gt 0) {
        Show-Line "Из них $(@($privileged).Count) имеют привилегии в домене; управляющий службой или её узлом также получает эти полномочия: $(@($privileged) -join '; ')" -Class "Finding" -FindingId $PrivilegedFindingId
    }
    if (@($unevaluated).Count -gt 0) {
        Show-Line "Для $(@($unevaluated).Count) записей не удалось оценить полномочия — результат неизвестен, а не отсутствие привилегий: $(@($unevaluated) -join '; ')" -Class "Note"
    }
}

<#
.SYNOPSIS
    Names the computer accounts of a service that show no recent activity.

.DESCRIPTION
    Test-AccountActivity -IsEnabled filters disabled accounts, not idle ones. A machine
    that was decommissioned without being disabled keeps its SPN, so it was reported as a
    live server of that kind - the other error direction of the same inventory, and a
    reader cannot tell which rows are real.

    A Note rather than a finding: an idle account is not a weakness, and the count stays
    separate from the inventory line above it so neither number is diluted.

.PARAMETER ServiceName
    How the service is called in the report, e.g. 'MSSQL'.

.PARAMETER Server
    The objects the inventory reported, annotated by Test-AccountActivity -IncludeDetails.

.NOTES
    Internal helper function
#>
function Show-SPNIdleServers {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [string]$ServiceName,

        [Parameter(Mandatory=$false)]
        [AllowNull()]
        [AllowEmptyCollection()]
        $Server
    )

    $idle = @(@($Server) | Where-Object {
        $_ -and $_.PSObject.Properties['ActivityDetails'] -and $_.ActivityDetails -and (-not $_.ActivityDetails.IsActive)
    })
    if (@($idle).Count -eq 0) { return }

    $names = @($idle | ForEach-Object { "$($_.sAMAccountName)" -replace '\$$', '' })
    Show-Line "У $(@($idle).Count) компьютерных записей службы $ServiceName нет недавних входов — возможно, узлы выведены из эксплуатации: $(@($names) -join ', ')" -Class "Note"
}
<#
.SYNOPSIS
    Returns the computer DNs the configuration partition registers as Domain Controllers.

.DESCRIPTION
    A promotion creates a server object under CN=Sites whose serverReference names the
    computer account, and below it the NTDS Settings object (nTDSDSA, nTDSDSARO for an
    RODC). The role flag on the computer account is only userAccountControl: whoever holds
    DS-Install-Replica on the domain object and may write the account's
    userAccountControl can set SERVER_TRUST_ACCOUNT, which makes the account's primary
    group Domain Controllers - with its replication rights - and creates neither object.

    Sites are forest-wide, so the set holds the Domain Controllers of every domain in the
    forest; the caller compares it with its own accounts.

.OUTPUTS
    Hashtable keyed by computer DN - case-insensitive, as every PowerShell hashtable -
    or $null when the configuration partition could not be read. Every forest has an NTDS
    Settings object, so none at all counts as not read rather than as no Domain Controller.

.NOTES
    Internal helper function
#>
function Get-RegisteredDomainControllerDN {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$false)]
        [string]$Domain,

        [Parameter(Mandatory=$false)]
        [string]$Server,

        [Parameter(Mandatory=$false)]
        [System.Management.Automation.PSCredential]$Credential
    )

    $configNC = $Script:LDAPContext.ConfigurationNamingContext
    if (-not $configNC) { return $null }
    $sitesContainer = "CN=Sites,$configNC"

    try {
        # nTDSDSARO is a subclass of nTDSDSA, so one clause finds both kinds.
        $serversWithSettings = @{}
        foreach ($settings in @(Get-DomainObject -LDAPFilter '(objectClass=nTDSDSA)' -SearchBase $sitesContainer -Properties 'distinguishedName' @PSBoundParameters)) {
            # The NTDS Settings object's parent is the server object.
            if ([string]$settings.distinguishedName -match '^CN=(?:[^,\\]|\\.)+,(.+)$') {
                $serversWithSettings[$Matches[1]] = $true
            }
        }
        if ($serversWithSettings.Count -eq 0) { return $null }

        $registered = @{}
        foreach ($serverObject in @(Get-DomainObject -LDAPFilter '(&(objectClass=server)(serverReference=*))' -SearchBase $sitesContainer -Properties 'distinguishedName', 'serverReference' @PSBoundParameters)) {
            if ($serversWithSettings.ContainsKey([string]$serverObject.distinguishedName)) {
                $registered[[string]$serverObject.serverReference] = $true
            }
        }
        return $registered
    } catch {
        Write-Log "[Get-RegisteredDomainControllerDN] Не удалось прочитать раздел Configuration: $_"
        return $null
    }
}

function Get-InfrastructureServers {
    <#
    .SYNOPSIS
    Inventories the infrastructure servers of the domain.

    .DESCRIPTION
    Enumerates the servers worth knowing about before anything else is analysed. Each kind
    is looked up the way that kind actually records itself, which is not always an SPN.

    Detected Server Types:
    - Domain Controllers (the userAccountControl role bit, via Get-DomainComputer -DomainController,
      and a primary group of Domain Controllers), each checked against the NTDS Settings
      object a promotion creates - an account with the role and without that object holds
      the rights of a Domain Controller and is a finding
    - Exchange Servers (msExchExchangeServer objects in the Configuration partition,
      falling back to the exchangeAB/, exchangeRFR/, exchangeMDB/ SPNs)
    - MSSQL Servers (MSSQLSvc/)
    - SCCM/ConfigMgr (SMS*, CCM*)
    - SCOM (MSOMHSvc/, MSOMSdkSvc/)

    For the three SPN-based kinds the service accounts are reported too. An SPN sits on
    the identity the service authenticates as, so where SQL Server, SCCM or SCOM runs
    under a domain account - routine, and the precondition for Kerberos against the
    service - the SPN is on a user or gMSA object and a computer query sees none of it.
    The host part of the SPN names the system it runs on.

    The other error direction is named as well: a machine that was decommissioned
    without being disabled keeps its SPN and was reported as a live server of that kind.
    Those accounts are listed separately as showing no recent logon.
    - AD FS (the DKM container under CN=ADFS,CN=Microsoft,CN=Program Data, plus adfssrv/)
    - Entra ID Connect (MSOL_/ADSync/AAD_ accounts, azureadconnect SPN)

    Every section runs on its own, so one that cannot be read does not take the others with
    it and says so rather than reporting an empty result.

    .PARAMETER Domain
    Target domain (optional, uses current domain if not specified)

    .PARAMETER Server
    Domain Controller to query (optional, uses auto-discovery if not specified)

    .PARAMETER Credential
    PSCredential object for authentication (optional, uses current user if not specified)

    .EXAMPLE
    Get-InfrastructureServers

    .EXAMPLE
    Get-InfrastructureServers -Domain "contoso.com" -Credential (Get-Credential)

    .NOTES
    Category: Computer
    Author: Alexander Sturz (@_61106960_)
    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$false)]
        [string]$Domain,

        [Parameter(Mandatory=$false)]
        [string]$Server,

        [Parameter(Mandatory=$false)]
        [System.Management.Automation.PSCredential]$Credential
    )

    begin {
        Write-Log "[Get-InfrastructureServers] Начата проверка"
    }

    process {
        # Every section runs under its own try/catch. One try around all six meant the
        # first failure ended the check: an Exchange group that could not be read took
        # MSSQL, SCCM, SCOM and Entra ID Connect down with it, and the report showed
        # nothing for them - indistinguishable from a domain that has none of those.
        # A failed section now says so and the remaining ones still run.
        if (-not (Ensure-LDAPConnection @PSBoundParameters)) {
            return
        }

        # ===== Domain Controllers =====
        Show-SubHeader "Поиск контроллеров домена..." -ObjectType "DomainController"

        try {
            # What counts as a domain controller is defined once, in Get-DomainComputer, so
            # this inventory and the delegation checks cannot drift apart on the question.
            $domainControllers = @(Get-DomainComputer -DomainController @PSBoundParameters | Test-AccountActivity -IsEnabled)

            # And the computers whose primary group is Domain Controllers without the role
            # flag: in the token they are Domain Controllers, to -DomainController not. The
            # query returns the real ones again; they are dropped by DN rather than by a
            # second spelling of the role flag here.
            $listedDNs = @{}
            foreach ($dc in $domainControllers) { $listedDNs[[string]$dc.distinguishedName] = $true }
            foreach ($primaryGroupHolder in @(Get-DomainComputer -LDAPFilter '(primaryGroupID=516)' @PSBoundParameters | Test-AccountActivity -IsEnabled)) {
                if (-not $listedDNs.ContainsKey([string]$primaryGroupHolder.distinguishedName)) {
                    $domainControllers += $primaryGroupHolder
                }
            }

            if ($domainControllers.Count -gt 0) {
                # Which of them a promotion actually made a Domain Controller. The role flag
                # can be set on any computer account by whoever holds DS-Install-Replica and
                # may write its userAccountControl, and gives it the replication rights of
                # Domain Controllers without a server ever being promoted.
                $registered = Get-RegisteredDomainControllerDN @PSBoundParameters
                $listedDCs = @()
                $unregisteredDCs = @()
                foreach ($dc in $domainControllers) {
                    $dc | Add-Member -NotePropertyName '_adPEASObjectType' -NotePropertyValue 'DomainController' -Force
                    if ($null -ne $registered -and -not $registered.ContainsKey([string]$dc.distinguishedName)) {
                        $dc | Add-Member -NotePropertyName 'directoryRegistration' -NotePropertyValue 'NOT REGISTERED - no NTDS Settings object in the configuration partition, yet the account holds the rights of a Domain Controller' -Force
                        $unregisteredDCs += $dc
                    } else {
                        $listedDCs += $dc
                    }
                }

                if ($listedDCs.Count -gt 0) {
                    Show-Line "Обнаружено контроллеров домена: $($listedDCs.Count)" -Class "Hint"
                    foreach ($dc in $listedDCs) { $dc | Show-Object -Class Hint }
                }
                if ($unregisteredDCs.Count -gt 0) {
                    Show-Line "$($unregisteredDCs.Count) компьютерных записей имеют роль контроллера домена, но не зарегистрированы как контроллеры домена:" -Class "Finding"
                    foreach ($dc in $unregisteredDCs) { $dc | Show-Object -Class Finding }
                }
                if ($null -eq $registered) {
                    Show-Line "Раздел конфигурации прочитать не удалось — записи контроллеров домена не сверялись с NTDS Settings" -Class "Note"
                }
            } else {
                Show-Line "Контроллеры домена не найдены (неожиданный результат)" -Class "Note"
            }
        } catch {
            Write-Log "[Get-InfrastructureServers] Ошибка перечисления контроллеров домена: $_" -Level Error
            Show-Line "Не удалось перечислить контроллеры домена; результат неизвестен, их отсутствие не подтверждено" -Class "Note"
        }

        # ===== Exchange Servers =====
        # ExchangeServerBasic, the type of the objects below - like the SCCM and SCOM
        # sections. ExchangeServer belongs to the analysis in Get-ExchangeInfrastructure,
        # and the report titles a card by its header's object type: both came out as
        # "Exchange Servers" with that analysis's help text.
        Show-SubHeader "Поиск серверов Microsoft Exchange..." -ObjectType "ExchangeServerBasic"

        try {
            # Exchange records its own servers in the Configuration partition, one
            # msExchExchangeServer object each, and that list is authoritative.
            #
            # Detection used to read the membership of a group found by the literal name
            # "Exchange Servers": name-based, so it broke on a renamed or localized group,
            # and it cost one LDAP query per member. It also contradicted this function's
            # own documentation, which promised SPN-based detection that the code never did.
            $exchangeVersionByName = @{}
            $configNC = $Script:LDAPContext.ConfigurationNamingContext
            if ($configNC) {
                foreach ($exchObject in @(Get-DomainObject -LDAPFilter "(objectClass=msExchExchangeServer)" `
                        -SearchBase "CN=Services,$configNC" @PSBoundParameters)) {
                    $exchName = "$($exchObject.cn)"
                    if ([string]::IsNullOrWhiteSpace($exchName)) { continue }
                    # serialNumber carries the build - the part that decides whether the
                    # server is still getting patches - with an offset: "Version 15.2
                    # (Build 31544.4)" is 15.2.1544.4, Exchange 2019. Shown as the build
                    # Microsoft publishes; a value in another form is shown as written.
                    $serialValue = "$($exchObject.serialNumber)"
                    $serialBuild = ConvertFrom-ExchangeSerialNumber -SerialNumber $serialValue
                    $exchangeVersionByName[$exchName.ToLowerInvariant()] = $(if ($serialBuild) { $serialBuild } else { $serialValue })
                }
            } else {
                Write-Log "[Get-InfrastructureServers] Отсутствует контекст Configuration — для Exchange используется поиск по SPN"
            }

            $exchangeServers = @()
            if ($exchangeVersionByName.Count -gt 0) {
                $clauses = ''
                foreach ($exchName in $exchangeVersionByName.Keys) {
                    $clauses += ('(sAMAccountName=' + (Escape-LDAPFilterValue -Value $exchName) + '$)')
                }
                $exchangeFilter = $(if ($exchangeVersionByName.Count -eq 1) { $clauses } else { '(|' + $clauses + ')' })
                $exchangeServers = @(Get-DomainComputer -LDAPFilter $exchangeFilter @PSBoundParameters | Test-AccountActivity -IsEnabled)
            } else {
                # No Exchange object in the Configuration partition, or it could not be read.
                # The SPN fallback is what the documentation always described; Domain
                # Controllers are excluded there because they carry Exchange SPNs for
                # Autodiscover without being Exchange servers.
                $exchangeServers = @(Get-DomainComputer -KnownSPN Exchange @PSBoundParameters | Test-AccountActivity -IsEnabled)
            }

            if ($exchangeServers.Count -gt 0) {
                Show-Line "Обнаружено серверов Exchange: $($exchangeServers.Count)" -Class "Hint"
                foreach ($exch in $exchangeServers) {
                    $exchKey = "$($exch.sAMAccountName)".TrimEnd('$').ToLowerInvariant()
                    if ($exchangeVersionByName.ContainsKey($exchKey) -and $exchangeVersionByName[$exchKey]) {
                        $exch | Add-Member -NotePropertyName 'exchangeVersion' -NotePropertyValue $exchangeVersionByName[$exchKey] -Force
                    }
                    $exch | Add-Member -NotePropertyName '_adPEASObjectType' -NotePropertyValue 'ExchangeServerBasic' -Force
                    $exch | Show-Object -Class Hint
                }
            } else {
                Show-Line "Серверы Exchange не найдены" -Class "Note"
            }
        } catch {
            Write-Log "[Get-InfrastructureServers] Ошибка перечисления серверов Exchange: $_" -Level Error
            Show-Line "Ошибка перечисления серверов Exchange; результат неизвестен" -Class "Note"
        }

        # ===== MSSQL Servers =====
        Show-SubHeader "Поиск серверов Microsoft SQL Server..." -ObjectType "MSSQLServer"

        try {
            $mssqlServers = @(Get-DomainComputer -LDAPFilter "(servicePrincipalName=MSSQLSvc/*)" @PSBoundParameters | Test-AccountActivity -IsEnabled -IncludeDetails)

            if ($mssqlServers.Count -gt 0) {
                Show-Line "Обнаружено серверов SQL Server: $($mssqlServers.Count)" -Class "Hint"
                foreach ($sql in $mssqlServers) {
                    $sql | Add-Member -NotePropertyName '_adPEASObjectType' -NotePropertyValue 'MSSQLServer' -Force
                    $sql | Show-Object -Class Hint
                }

                Show-SPNIdleServers -ServiceName 'MSSQL' -Server $mssqlServers
            } else {
                Show-Line "Серверы SQL Server по SPN не обнаружены" -Class "Note"
            }

            # The identity the service authenticates as may be a domain account rather
            # than the machine, and then the SPN is not on a computer object at all. Only
            # this call asks for the accounts' privileges: a sysadmin on the instance runs
            # operating system commands as the account. SCOM service accounts are judged
            # by Get-SCOMInfrastructure.
            Show-SPNServiceAccounts -ServiceName 'MSSQL' -SPNFilter "(servicePrincipalName=MSSQLSvc/*)" `
                -SPNPrefix @('MSSQLSvc/') -ConnectionParams $PSBoundParameters `
                -PrivilegedFindingId 'MSSQL_SERVICE_ACCOUNT_PRIVILEGED'
        } catch {
            Write-Log "[Get-InfrastructureServers] Ошибка перечисления серверов MSSQL: $_" -Level Error
            Show-Line "Ошибка перечисления SQL Server; результат неизвестен" -Class "Note"
        }

        # ===== SCCM/ConfigMgr Servers =====
        Show-SubHeader "Поиск серверов Microsoft Configuration Manager..." -ObjectType "SCCMServerBasic"

        try {
            # SCCM SPNs: SMS_Site_*, SMS_MP, SMS_DP, CCMSetup, etc.
            $sccmServers = @(Get-DomainComputer -LDAPFilter "(|(servicePrincipalName=SMS*)(servicePrincipalName=CCM*))" @PSBoundParameters | Test-AccountActivity -IsEnabled -IncludeDetails)

            if ($sccmServers.Count -gt 0) {
                Show-Line "Обнаружено серверов SCCM/ConfigMgr: $($sccmServers.Count)" -Class "Hint"
                foreach ($sccm in $sccmServers) {
                    $sccm | Add-Member -NotePropertyName '_adPEASObjectType' -NotePropertyValue 'SCCMServerBasic' -Force
                    $sccm | Show-Object -Class Hint
                }

                Show-SPNIdleServers -ServiceName 'SCCM' -Server $sccmServers
            } else {
                Show-Line "Серверы SCCM по SPN не обнаружены" -Class "Note"
            }

            # The identity the service authenticates as may be a domain account rather
            # than the machine, and then the SPN is not on a computer object at all.
            Show-SPNServiceAccounts -ServiceName 'SCCM' -SPNFilter "(|(servicePrincipalName=SMS*)(servicePrincipalName=CCM*))" `
                -SPNPrefix @('SMS_', 'CCM') -ConnectionParams $PSBoundParameters
        } catch {
            Write-Log "[Get-InfrastructureServers] Ошибка перечисления серверов SCCM: $_" -Level Error
            Show-Line "Не удалось перечислить серверы SCCM — результат неизвестен, а не пуст" -Class "Note"
        }

        # ===== SCOM Servers =====
        Show-SubHeader "Поиск серверов Microsoft Operations Manager..." -ObjectType "SCOMServerBasic"

        try {
            # SCOM SPNs: MSOMHSvc (Health Service), MSOMSdkSvc (SDK Service)
            $scomServers = @(Get-DomainComputer -LDAPFilter "(|(servicePrincipalName=MSOMHSvc/*)(servicePrincipalName=MSOMSdkSvc/*))" @PSBoundParameters | Test-AccountActivity -IsEnabled -IncludeDetails)

            if ($scomServers.Count -gt 0) {
                Show-Line "Обнаружено серверов SCOM: $($scomServers.Count)" -Class "Hint"
                foreach ($scom in $scomServers) {
                    $scom | Add-Member -NotePropertyName '_adPEASObjectType' -NotePropertyValue 'SCOMServerBasic' -Force
                    $scom | Show-Object -Class Hint
                }

                Show-SPNIdleServers -ServiceName 'SCOM' -Server $scomServers
            } else {
                Show-Line "Серверы SCOM по SPN не обнаружены" -Class "Note"
            }

            # The identity the service authenticates as may be a domain account rather
            # than the machine, and then the SPN is not on a computer object at all.
            Show-SPNServiceAccounts -ServiceName 'SCOM' -SPNFilter "(|(servicePrincipalName=MSOMHSvc/*)(servicePrincipalName=MSOMSdkSvc/*))" `
                -SPNPrefix @('MSOMHSvc/', 'MSOMSdkSvc/') -ConnectionParams $PSBoundParameters
        } catch {
            Write-Log "[Get-InfrastructureServers] Ошибка перечисления серверов SCOM: $_" -Level Error
            Show-Line "Не удалось перечислить серверы SCOM — результат неизвестен, а не пуст" -Class "Note"
        }

        # ===== AD FS (Active Directory Federation Services) =====
        Show-SubHeader "Поиск серверов служб федерации AD FS..." -ObjectType "ADFSServer"

        try {
            $adfsIndicators = @()

            # The DKM container. AD FS stores the key that its token-signing certificate is
            # encrypted with as an attribute of a contact object under
            # CN=ADFS,CN=Microsoft,CN=Program Data,<domainDN>. Its existence is the one
            # domain-side fact that says AD FS is deployed here, independent of any SPN.
            #
            # It matters more than the inventory entry suggests: whoever reads that key,
            # together with the AD FS configuration database, can mint SAML tokens for any
            # user in the federation - Golden SAML - and that is authentication into the
            # cloud tenant that no on-premises password reset and no MFA on the IdP undoes.
            $domainDN = $Script:LDAPContext.DomainDN
            if ($domainDN) {
                $dkmBase = "CN=ADFS,CN=Microsoft,CN=Program Data,$domainDN"
                $dkmObjects = @()
                try {
                    $dkmObjects = @(Get-DomainObject -LDAPFilter "(objectClass=contact)" -SearchBase $dkmBase @PSBoundParameters)
                } catch {
                    # An absent container is the normal case in a domain without AD FS and
                    # must not read as an error
                    Write-Log "[Get-InfrastructureServers] Контейнер DKM AD FS по пути $dkmBase не найден: $_"
                }

                if ($dkmObjects.Count -gt 0) {
                    # This row is a place in the directory, not an account, and it is named
                    # like the other synthetic rows in the reports - the LAPS OU rows, the
                    # trust rows - after what it is rather than with a bare 'Name'.
                    $dkmObject = [PSCustomObject]@{
                        adfsContainer    = 'AD FS DKM container'
                        containerDN      = $dkmBase
                        dkmKeyObjects    = @($dkmObjects).Count
                        adfsDkmContainer = 'AD FS stores the decryption key for its token-signing certificate here. Whoever can read this key and reach the AD FS configuration database can sign SAML tokens for any federated user, which is authentication into the connected cloud tenant that changing on-premises passwords does not revoke.'
                    }
                    $dkmObject | Add-Member -NotePropertyName '_adPEASObjectType' -NotePropertyValue 'ADFSServer' -Force
                    $adfsIndicators += $dkmObject
                }
            }

            # The servers themselves, by their service SPN. Under its own try for the same
            # reason the sections have one each: the two halves are independent evidence,
            # and a failing computer query must not discard a DKM container already found.
            try {
                foreach ($adfsServer in @(Get-DomainComputer -KnownSPN ADFS @PSBoundParameters | Test-AccountActivity -IsEnabled)) {
                    $adfsServer | Add-Member -NotePropertyName '_adPEASObjectType' -NotePropertyValue 'ADFSServer' -Force
                    $adfsIndicators += $adfsServer
                }
            } catch {
                Write-Log "[Get-InfrastructureServers] Ошибка поиска серверов AD FS: $_" -Level Error
                Show-Line "Не удалось перечислить серверы AD FS; найденные контейнеры DKM при этом отображаются отдельно" -Class "Note"
            }

            if ($adfsIndicators.Count -gt 0) {
                Show-Line "Обнаружено признаков инфраструктуры AD FS: $($adfsIndicators.Count)" -Class "Hint"
                foreach ($adfsIndicator in $adfsIndicators) {
                    $adfsIndicator | Show-Object -Class Hint
                }
            } else {
                Show-Line "Развёртывание AD FS не обнаружено" -Class "Note"
            }
        } catch {
            Write-Log "[Get-InfrastructureServers] Ошибка перечисления AD FS: $_" -Level Error
            Show-Line "Ошибка перечисления AD FS; результат неизвестен, отсутствие серверов не подтверждено" -Class "Note"
        }

        # ===== Entra ID Connect (Azure AD Connect) =====
        Show-SubHeader "Поиск серверов Microsoft Entra Connect..." -ObjectType "EntraConnect"

        try {
            $entraConnectIndicators = @()

            # Method 1: Look for MSOL_ accounts (service accounts created by Azure AD Connect)
            $msolAccounts = @(Get-DomainUser -LDAPFilter "(sAMAccountName=MSOL_*)" @PSBoundParameters)
            if ($msolAccounts.Count -gt 0) {
                $entraConnectIndicators += $msolAccounts
            }

            # Method 2: Look for ADSync service accounts
            $adsyncAccounts = @(Get-DomainUser -LDAPFilter "(|(sAMAccountName=ADSync*)(sAMAccountName=AAD_*))" @PSBoundParameters)
            if ($adsyncAccounts.Count -gt 0) {
                $entraConnectIndicators += $adsyncAccounts
            }

            # Method 3: Look for Entra Connect health agent SPN
            $entraHealthServers = @(Get-DomainComputer -LDAPFilter "(servicePrincipalName=*azureadconnect*)" @PSBoundParameters |
                Test-AccountActivity -IsEnabled)
            if ($entraHealthServers.Count -gt 0) {
                $entraConnectIndicators += $entraHealthServers
            }

            if ($entraConnectIndicators.Count -gt 0) {
                Show-Line "Обнаружено признаков Entra ID Connect: $($entraConnectIndicators.Count)" -Class "Hint"
                foreach ($indicator in $entraConnectIndicators) {
                    # Parse description to extract server name and tenant
                    # Pattern: "...running on computer SERVERNAME configured to synchronize to tenant TENANT.onmicrosoft.com..."
                    if ($indicator.description -match 'running on computer\s+(\S+)\s+configured to synchronize to tenant\s+(\S+)') {
                        $entraServerName = $Matches[1]

                        # TrimEnd('.'): the tenant name ends the sentence in the
                        # description - "...to tenant contoso.onmicrosoft.com. This account
                        # must..." - and \S+ swallows the full stop along with it, because a
                        # period is not whitespace. The server name is anchored by the
                        # "configured" that follows it and needs no such trim. A tenant name
                        # never legitimately ends in a dot, and the value is one a tester
                        # copies straight into another tool.
                        $entraTenant = ([string]$Matches[2]).TrimEnd('.')

                        # Add parsed information as NoteProperties
                        $indicator | Add-Member -NotePropertyName 'entraConnectServer' -NotePropertyValue $entraServerName -Force
                        $indicator | Add-Member -NotePropertyName 'entraM365Tenant' -NotePropertyValue $entraTenant -Force
                    }

                    $indicator | Add-Member -NotePropertyName '_adPEASObjectType' -NotePropertyValue 'EntraConnect' -Force
                    $indicator | Show-Object -Class Hint
                }
            } else {
                Show-Line "Серверы Microsoft Entra Connect не найдены" -Class "Note"
            }
        } catch {
            Write-Log "[Get-InfrastructureServers] Ошибка перечисления Entra ID Connect: $_" -Level Error
            Show-Line "Не удалось перечислить серверы Entra ID Connect; результат неизвестен" -Class "Note"
        }
    }

    end {
        Write-Log "[Get-InfrastructureServers] Проверка завершена"
    }
}
