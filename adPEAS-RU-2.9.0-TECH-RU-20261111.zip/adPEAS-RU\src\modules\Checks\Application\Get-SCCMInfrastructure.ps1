﻿function Get-SCCMInfrastructure {
    <#
    .SYNOPSIS
    Detects Microsoft System Center Configuration Manager (SCCM/MECM) infrastructure.

    .DESCRIPTION
    Performs passive detection of SCCM/MECM infrastructure components using LDAP queries.
    Identifies site servers, management points, site hierarchy, service accounts, PXE/WDS servers, and the System Management container.

    Detection Methods:
    1. System Management container (CN=System Management,CN=System,<Domain DN>), including
       who can write to it - a management point published there is trusted by every client
       that uses Active Directory site discovery
    2. mSSMSSite objects (SCCM site codes and hierarchy)
    3. mSSMSManagementPoint objects (MP hostnames, site type determination)
    4. Computers with SCCM-related SPNs (SMS*, SMSSQLBKUP*)
    5. PXE/WDS boot servers (connectionPoint, intellimirrorSCP)
    6. User accounts with SCCM-related SPNs
    7. SCCM-related security groups (*SCCM*, *SMS*, *ConfigMgr*, *MECM*)

    .PARAMETER Domain
    Target domain (optional, uses current domain if not specified)

    .PARAMETER Server
    Domain Controller to query (optional, uses auto-discovery if not specified)

    .PARAMETER Credential
    PSCredential object for authentication (optional, uses current user if not specified)

    .EXAMPLE
    Get-SCCMInfrastructure

    .EXAMPLE
    Get-SCCMInfrastructure -Domain "contoso.com" -Credential (Get-Credential)

    .NOTES
    Category: Application
    Author: Alexander Sturz (@_61106960_)
    Based on research from Misconfiguration-Manager (@subat0mik)
    Reference: https://github.com/subat0mik/Misconfiguration-Manager
    #>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$false)]
        [string]$Domain,

        [Parameter(Mandatory=$false)]
        [string]$Server,

        [Parameter(Mandatory=$false)]
        [System.Management.Automation.PSCredential]$Credential
    )

    begin {
        Write-Log "[Get-SCCMInfrastructure] Starting check"
    }

    process {
        try {
            # Ensure LDAP connection (displays error if needed)
            if (-not (Ensure-LDAPConnection @PSBoundParameters)) {
                # Return without output to avoid redundant error display
                return
            }

            $domainDN = $Script:LDAPContext.DomainDN

            # ===== Step 1: Check for SCCM Infrastructure =====
            Show-SubHeader "Поиск инфраструктуры SCCM/MECM..." -ObjectType "SCCMServer"

            $sccmDetected = $false
            $systemManagementPath = "CN=System Management,CN=System,$domainDN"
            $systemMgmt = $null

            # Detection Method 1: System Management Container
            try {
                $systemMgmt = Get-DomainObject -Identity $systemManagementPath @PSBoundParameters
                if ($systemMgmt) {
                    $sccmDetected = $true
                }
            } catch {
                Write-Log "[Get-SCCMInfrastructure] System Management container not found"
            }

            # Detection Method 2: SCCM SPNs on computers (lightweight, only for detection)
            if (-not $sccmDetected) {
                $sccmDetectionComputers = Get-DomainComputer -LDAPFilter "(servicePrincipalName=SMS*)" -Properties "cn" @PSBoundParameters
                if ($sccmDetectionComputers) {
                    $sccmDetected = $true
                }
            }

            # Detection Method 3: SCCM-related groups (lightweight, only for detection)
            if (-not $sccmDetected) {
                $sccmDetectionGroups = Get-DomainGroup -LDAPFilter "(|(cn=*SCCM*)(cn=*ConfigMgr*)(cn=*MECM*))" -Properties "cn" @PSBoundParameters
                if ($sccmDetectionGroups) {
                    $sccmDetected = $true
                }
            }

            # If no SCCM detected, stop here
            if (-not $sccmDetected) {
                Show-Line "Инфраструктура SCCM/MECM не обнаружена" -Class Note
                return
            }

            # ===== SCCM Detected - Continue with detailed enumeration =====
            Show-Line "SCCM/MECM infrastructure detected" -Class Hint

            # ===== Step 2: System Management Container Details =====
            Show-SubHeader "Анализ контейнера System Management..." -ObjectType "SCCMServer"

            # Reuse result from Detection Method 1 (no duplicate query)
            if ($systemMgmt) {
                Show-Line "System Management container found at: $systemManagementPath" -Class Hint
            } else {
                # SCCM was detected by SPN or by group name, which this module supports
                # deliberately. Everything the three steps below read lives inside this
                # container, so each of them has to say that it did not read anything
                # rather than that it found nothing: Invoke-LDAPSearch answers a missing
                # SearchBase with an empty result and no error, and the two are
                # indistinguishable from the caller's side.
                Show-Line "System Management container not found - sites, management points and its permissions were not read" -Class Hint
            }

            # ===== Step 3: SCCM Sites via mSSMSSite =====
            Show-SubHeader "Перечисление сайтов SCCM по объектам каталога AD..." -ObjectType "SCCMSite"

            $sccmSiteInfos = @{}  # Hashtable for cross-reference in Step 4

            try {
                $sccmSiteObjects = @()
                if ($systemMgmt) {
                    $sccmSiteObjects = @(Get-DomainObject -LDAPFilter "(objectClass=mSSMSSite)" -SearchBase $systemManagementPath -Properties "mSSMSSiteCode","mSSMSSourceForest","mSSMSHealthState","cn","distinguishedName" @PSBoundParameters)
                }

                if ($sccmSiteObjects.Count -gt 0) {
                    Show-Line "Обнаружено сайтов SCCM, опубликованных в Active Directory: $($sccmSiteObjects.Count)" -Class Hint

                    foreach ($site in $sccmSiteObjects) {
                        $siteCode = $site.mSSMSSiteCode
                        $sourceForest = $site.mSSMSSourceForest

                        # Extract GUID from mSSMSHealthState (format: "SITECODE.{GUID}")
                        $siteGuid = $null
                        if ($site.mSSMSHealthState -match '\{([0-9a-fA-F\-]+)\}') {
                            $siteGuid = $Matches[1]
                        }

                        # Store for cross-reference with management points
                        if ($siteCode) {
                            $sccmSiteInfos[$siteCode] = @{
                                SourceForest = $sourceForest
                                SiteGuid = $siteGuid
                                CN = $site.cn
                            }
                        }

                        # Build display object for Show-Object (dynamic fallback renders all properties)
                        $siteObj = [PSCustomObject]@{
                            Name = $siteCode
                            SiteCode = $siteCode
                            SourceForest = $sourceForest
                            SiteGUID = $siteGuid
                            DistinguishedName = $site.distinguishedName
                        }
                        $siteObj | Add-Member -NotePropertyName '_adPEASObjectType' -NotePropertyValue 'SCCMSite' -Force
                        Show-Object $siteObj -Class Hint
                    }
                } elseif (-not $systemMgmt) {
                    Show-Line "The System Management container does not exist - no site object could be read" -Class Note
                } else {
                    Show-Line "No mSSMSSite objects found in System Management container" -Class Note
                }
            } catch {
                Write-Log "[Get-SCCMInfrastructure] Error querying mSSMSSite: $_" -Level Warning
            }

            # ===== Step 4: Management Points + Site Hierarchy =====
            Show-SubHeader "Поиск точек управления SCCM и иерархии сайтов..." -ObjectType "SCCMManagementPoint"

            $casDetected = $false

            # Filled by the loop below and read by the container ACL step further down,
            # which has to know which computer accounts are supposed to hold rights there.
            # Declared here rather than inside the loop: a domain with no management point
            # never enters it, and reading an unset variable is an error under
            # Set-StrictMode -Version Latest.
            $sccmManagementPointNames = @()

            try {
                $mgmtPoints = @()
                if ($systemMgmt) {
                    $mgmtPoints = @(Get-DomainObject -LDAPFilter "(objectClass=mSSMSManagementPoint)" -SearchBase $systemManagementPath -Properties "mSSMSMPName","mSSMSSiteCode","mSSMSCapabilities","cn","distinguishedName" @PSBoundParameters)
                }

                if ($mgmtPoints.Count -gt 0) {
                    Show-Line "Обнаружено точек управления SCCM (Management Point): $($mgmtPoints.Count)" -Class Hint

                    foreach ($mp in $mgmtPoints) {
                        $mpName = $mp.mSSMSMPName
                        $mpSiteCode = $mp.mSSMSSiteCode

                        # Collected for the container ACL step further down (declared above
                        # the try, so a domain without management points still has a list).
                        if ($mpName) { $sccmManagementPointNames += [string]$mpName }

                        # Parse mSSMSCapabilities XML for site hierarchy
                        $cmdLineSiteCode = $null
                        $rootSiteCode = $null
                        $forest = $null
                        $siteType = "Unknown"

                        if ($mp.mSSMSCapabilities) {
                            $xmlText = [string]$mp.mSSMSCapabilities
                            try {
                                # Clean entities for safe XML parsing
                                $xmlText = $xmlText -replace '&(?!amp;|lt;|gt;|quot;|apos;)', '&amp;'
                                $xmlDoc = [xml]$xmlText

                                # Extract CommandLine SMSSITECODE
                                $cmdLine = $xmlDoc.ClientOperationalSettings.CCM.CommandLine
                                if ($cmdLine -match 'SMSSITECODE=(\w+)') {
                                    $cmdLineSiteCode = $Matches[1]
                                }

                                # Extract RootSiteCode
                                $rootSiteCode = $xmlDoc.ClientOperationalSettings.RootSiteCode

                                # Extract Forest
                                $forest = $xmlDoc.ClientOperationalSettings.Forest.Value
                            } catch {
                                # XML parsing failed - try regex fallback for SMSSITECODE
                                if ($xmlText -match 'SMSSITECODE=(\w+)') {
                                    $cmdLineSiteCode = $Matches[1]
                                }
                                Write-Log "[Get-SCCMInfrastructure] XML parse warning for MP $mpName - using regex fallback" -Level Warning
                            }
                        }

                        # Determine site type (same logic as ConfigManBearPig)
                        if ($cmdLineSiteCode -and $mpSiteCode) {
                            if ($cmdLineSiteCode -eq $mpSiteCode) {
                                $siteType = "Primary Site"
                            } elseif ($rootSiteCode -eq $mpSiteCode) {
                                $siteType = "Central Administration Site (CAS)"
                                $casDetected = $true
                            } else {
                                $siteType = "Secondary Site"
                            }
                        }

                        # Build display object for Show-Object
                        $mpObj = [PSCustomObject]@{
                            Name = $mpName
                            ManagementPoint = $mpName
                            SiteCode = $mpSiteCode
                            SiteType = $siteType
                        }
                        if ($cmdLineSiteCode -and $cmdLineSiteCode -ne $mpSiteCode) {
                            $mpObj | Add-Member -NotePropertyName 'CommandLineSiteCode' -NotePropertyValue $cmdLineSiteCode -Force
                        }
                        if ($rootSiteCode) {
                            $mpObj | Add-Member -NotePropertyName 'RootSiteCode' -NotePropertyValue $rootSiteCode -Force
                        }
                        if ($forest) {
                            $mpObj | Add-Member -NotePropertyName 'Forest' -NotePropertyValue $forest -Force
                        }
                        $mpObj | Add-Member -NotePropertyName '_adPEASObjectType' -NotePropertyValue 'SCCMManagementPoint' -Force
                        Show-Object $mpObj -Class Hint
                    }

                    # CAS Finding
                    if ($casDetected) {
                        # Hint, which is what SCCM_SITE_HIERARCHY itself says (Risk = Hint,
                        # BaseScore 30). A hierarchy with a central administration site is a
                        # normal SCCM build: the finding is "there is one more Tier-0 system
                        # here", not "something is wrong here". Red spends the colour that
                        # the container ACL findings need.
                        Show-Line "Обнаружен центральный административный сайт (CAS): в SCCM есть иерархия нескольких сайтов" -Class Hint -FindingId "SCCM_SITE_HIERARCHY"
                    }
                } elseif (-not $systemMgmt) {
                    Show-Line "The System Management container does not exist - no management point could be read" -Class Note
                } else {
                    Show-Line "No mSSMSManagementPoint objects found in System Management container" -Class Note
                }
            } catch {
                Write-Log "[Get-SCCMInfrastructure] Error querying mSSMSManagementPoint: $_" -Level Warning
            }

            # ===== Step 5: Enumerate SCCM Servers =====
            Show-SubHeader "Поиск серверов сайтов SCCM..." -ObjectType "SCCMServer"

            $sccmServers = [System.Collections.ArrayList]::new()
            $seenServerDNs = @{}

            $servers = Get-DomainComputer -LDAPFilter "(|(servicePrincipalName=SMS*)(servicePrincipalName=SMSSQLBKUP*))" @PSBoundParameters
                # $srv, not $server: the check declares a [string]$Server parameter, and
                # PowerShell keeps that type constraint on the loop variable. Every AD object
                # was coerced to its ToString() form, distinguishedName came back empty, the
                # dedup guard never fired and no SCCM site server was ever reported.

            if ($servers) {
                foreach ($srv in @($servers)) {
                    $dn = $srv.distinguishedName
                    if ($dn -and -not $seenServerDNs.ContainsKey($dn)) {
                        $seenServerDNs[$dn] = $true
                        [void]$sccmServers.Add($srv)
                    }
                }
            }

            if ($sccmServers.Count -gt 0) {
                Show-Line "Обнаружено серверов SCCM: $($sccmServers.Count)" -Class Hint

                foreach ($srv in $sccmServers) {
                    $srv | Add-Member -NotePropertyName '_adPEASObjectType' -NotePropertyValue 'SCCMServer' -Force
                    Show-Object $srv -Class Hint
                }
            } else {
                Show-Line "Поиск SPN не выявил серверы SCCM" -Class Note
            }

            # ===== Step 5b: Who can write to the System Management container =====
            #
            # The container is where Configuration Manager publishes its sites and its
            # management points, and a client configured for AD site discovery believes
            # what it finds there. Whoever can write to it can publish a management point
            # of their own, and every client that picks it up takes its policy - and its
            # software - from a server the attacker controls.
            #
            # Unlike almost everything else SCCM touches, this container is created by hand
            # before setup runs, by an administrator following a docs page that says to grant
            # the site server Full Control. What else gets granted along the way is exactly
            # what this reads.
            #
            # The site server computer accounts are supposed to have Full Control here, so
            # they are added to the expected set rather than reported. They are the ones the
            # steps above discovered, which is why this runs after them.
            Show-SubHeader "Проверка разрешений на контейнер System Management..." -ObjectType "SCCMContainerPermission"

            try {
                $sccmServerSIDs = @{}
                foreach ($knownServer in @($sccmServers)) {
                    if ($knownServer.objectSid) { $sccmServerSIDs["$($knownServer.objectSid)"] = $true }
                }

                # The management points as well, resolved by the host name they publish.
                # The expected set came from one source only - the SPN query above - and
                # the module prints "No SCCM servers found via SPN detection" itself, which
                # is exactly when that set is empty: every legitimate site server with Full
                # Control on the container then came out as a finding. A management point
                # publishes its own name in mSSMSMPName and is supposed to hold rights here.
                foreach ($knownMP in @($sccmManagementPointNames)) {
                    if ([string]::IsNullOrWhiteSpace($knownMP)) { continue }
                    $mpHost = ([string]$knownMP).Split('.')[0]
                    if ([string]::IsNullOrWhiteSpace($mpHost)) { continue }
                    try {
                        $mpComputer = @(Get-DomainComputer -Identity $mpHost -Properties 'objectSid', 'dNSHostName' @PSBoundParameters)[0]
                        if ($mpComputer -and $mpComputer.objectSid) {
                            $sccmServerSIDs["$($mpComputer.objectSid)"] = $true
                        } else {
                            # A management point in another domain of the forest cannot be
                            # resolved from here. Its ACE stays reported, which is the
                            # honest outcome - the alternative would be to excuse an ACE
                            # because a name looked familiar.
                            Write-Log "[Get-SCCMInfrastructure] Management point '$knownMP' could not be resolved to a computer account - its ACE stays reported"
                        }
                    } catch {
                        Write-Log "[Get-SCCMInfrastructure] Error resolving management point '$knownMP': $_"
                    }
                }

                # -Raw for the byte[] form of nTSecurityDescriptor: the converted object
                # does not carry the ACEs this needs.
                $containerRaw = $null
                if ($systemMgmt) {
                    $containerRaw = @(Get-DomainObject -Identity $systemManagementPath -Properties 'nTSecurityDescriptor' -Raw @PSBoundParameters)[0]
                }

                if (-not $systemMgmt) {
                    # Named apart from the unreadable case below. Both leave the
                    # permissions unknown, but one is a missing read right on an existing
                    # container and the other is a container nobody created.
                    Show-Line "The System Management container does not exist - its permissions could not be read" -Class Note
                } elseif (-not $containerRaw -or -not $containerRaw.nTSecurityDescriptor) {
                    # Reading the security descriptor needs READ_CONTROL, which a plain
                    # domain user has on this container - but say so rather than let an
                    # unreadable ACL look like a clean one.
                    Show-Line "The security descriptor of the System Management container could not be read - result unknown, not clean" -Class Note
                } else {
                    $sccmDescriptor = New-Object System.DirectoryServices.ActiveDirectorySecurity
                    $sccmDescriptor.SetSecurityDescriptorBinaryForm($containerRaw.nTSecurityDescriptor)
                    $sccmACEs = $sccmDescriptor.GetAccessRules($true, $true, [System.Security.Principal.SecurityIdentifier])

                    $containerFindings = @{}
                    foreach ($ace in $sccmACEs) {
                        if ($ace.AccessControlType -ne 'Allow') { continue }

                        # An inherit-only ACE grants nothing on the container itself.
                        if (-not (Test-ACEAppliesToSelf -ACE $ace)) { continue }

                        # ConvertTo-ExpandedADRightsName, not the string form: the SDDL
                        # generic bits have no named value in the enum, so an ACE written
                        # as "(A;;GA;;;<sid>)" came out as the bare number 268435456 and
                        # matched nothing below. The container is where a client finds its
                        # management point, so a full-control ACE on it was reported as
                        # "Only the site servers and the expected administrators can write
                        # to the System Management container".
                        $aceRights = ConvertTo-ExpandedADRightsName -Rights $ace.ActiveDirectoryRights

                        # An object ACE grants its mask on the class or attribute its GUID
                        # names (MS-ADTS 5.1.3.3.3): never GenericAll, WriteDacl or
                        # WriteOwner on the container, and the write of one of the
                        # container's own attributes publishes no management point. What it
                        # can do is create children of its class - a management point when
                        # the class is one of the mSSMS schema extensions, which the GUID
                        # table does not know, so a class it cannot name counts. A class it
                        # can name publishes nothing a client reads: those are the users,
                        # computers, groups, OUs and contacts Exchange setup lets Exchange
                        # Windows Permissions create in every container of the domain, which
                        # this container inherits like any other.
                        $sccmScope = $ace.ObjectType
                        if ($null -ne $sccmScope -and $sccmScope -ne [Guid]::Empty) {
                            if ($aceRights -notmatch 'GenericAll|CreateChild') { continue }
                            $sccmScopeResolved = Resolve-ObjectTypeGUID -GUID $sccmScope
                            if ($sccmScopeResolved -and $sccmScopeResolved.Name -notlike 'mSSMS*') { continue }
                            $sccmScopeName = if ($sccmScopeResolved) { $sccmScopeResolved.Name } else { [string]$sccmScope }
                            $aceRights = "CreateChild ($sccmScopeName)"
                        }

                        # Write access is the whole question: CreateChild publishes a
                        # management point, the others get there in one more step.
                        if ($aceRights -notmatch 'GenericAll|GenericWrite|WriteDacl|WriteOwner|WriteProperty|CreateChild') { continue }

                        $aceSID = $ace.IdentityReference.Value
                        if ($sccmServerSIDs.ContainsKey($aceSID)) { continue }

                        $scopeResult = Test-IsExpectedInScope -Identity $aceSID -Scope 'SCCMContainer' -ReturnDetails
                        # 'Attention' is kept rather than filtered: it means a principal
                        # that is privileged but not one of the four this container expects,
                        # and an Account Operator that can publish a management point is a
                        # shorter path than the one it already has.
                        if ($scopeResult.Severity -eq 'Expected') { continue }

                        if (-not $containerFindings.ContainsKey($aceSID)) {
                            $containerFindings[$aceSID] = [PSCustomObject]@{
                                SID      = $aceSID
                                Rights   = New-Object System.Collections.Generic.List[string]
                                Severity = $scopeResult.Severity
                            }
                        }
                        if (-not $containerFindings[$aceSID].Rights.Contains($aceRights)) {
                            [void]$containerFindings[$aceSID].Rights.Add($aceRights)
                        }
                    }

                    if ($containerFindings.Count -gt 0) {
                        Show-Line "$($containerFindings.Count) principal(s) can write to the System Management container and are not a site server" -Class Finding

                        foreach ($containerFinding in $containerFindings.Values) {
                            $sidHex = ConvertTo-LDAPSIDHex -SID $containerFinding.SID
                            $aceObject = $null
                            if ($sidHex) {
                                $aceObject = @(Get-DomainObject -LDAPFilter "(objectSid=$sidHex)" @PSBoundParameters)[0]
                            }

                            if (-not $aceObject) {
                                $aceObject = [PSCustomObject]@{
                                    sAMAccountName = (ConvertFrom-SID -SID $containerFinding.SID)
                                    objectSid      = $containerFinding.SID
                                    objectClass    = 'foreignSecurityPrincipal'
                                }
                            }

                            $aceObject | Add-Member -NotePropertyName 'containerDN' -NotePropertyValue $systemManagementPath -Force
                            $aceObject | Add-Member -NotePropertyName 'dangerousRights' -NotePropertyValue (($containerFinding.Rights) -join ', ') -Force
                            $aceObject | Add-Member -NotePropertyName 'dangerousRightsSeverity' -NotePropertyValue $containerFinding.Severity -Force
                            $aceObject | Add-Member -NotePropertyName 'sccmContainerWrite' -NotePropertyValue 'This principal can write to the container Configuration Manager publishes its management points in. A management point published here is trusted by every client that uses Active Directory site discovery.' -Force
                            $aceObject | Add-Member -NotePropertyName '_adPEASObjectType' -NotePropertyValue 'SCCMContainerPermission' -Force
                            Show-Object $aceObject -Class $(if ([string]$aceObject.dangerousRightsSeverity -in @('Expected', 'Attention', 'Hint')) { 'Hint' } else { 'Finding' })
                        }
                    } else {
                        Show-Line "Only the site servers and the expected administrators can write to the System Management container" -Class Secure
                    }
                }
            }
            catch {
                Write-Log "[Get-SCCMInfrastructure] Error reading the System Management container ACL: $_" -Level Warning
                Show-Line "The System Management container permissions could not be analysed - result unknown, not clean" -Class Note
            }

            # ===== Step 6: PXE/WDS Discovery =====
            Show-SubHeader "Поиск серверов сетевой загрузки PXE/WDS..." -ObjectType "SCCMPXEServer"

            $pxeServersFound = $false

            try {
                # PXE Boot Servers via connectionPoint with netbootserver
                $pxePoints = @(Get-DomainObject -LDAPFilter "(&(objectClass=connectionPoint)(netbootserver=*))" -Properties "cn","distinguishedName","netbootserver" @PSBoundParameters)

                if ($pxePoints.Count -gt 0) {
                    $pxeServersFound = $true
                    Show-Line "Обнаружено серверов загрузки PXE: $($pxePoints.Count)" -Class Hint

                    foreach ($pxe in $pxePoints) {
                        $parentDN = $pxe.distinguishedName -replace '^[^,]+,', ''
                        # netbootserver holds the DN of the server object, not a host name.
                        # Printing the DN in a field called PXEServer read as a name nobody
                        # could resolve; the RDN is the name, and the DN stays beside it.
                        $pxeServerDN = "$($pxe.netbootserver)"
                        $pxeServerName = if ($pxeServerDN -match '^CN=([^,]+),') { $Matches[1] } else { $pxeServerDN }
                        $pxeObj = [PSCustomObject]@{
                            Name = $pxeServerName
                            PXEServer = $pxeServerName
                            PXEServerDN = $pxeServerDN
                            ParentObject = $parentDN
                        }
                        $pxeObj | Add-Member -NotePropertyName '_adPEASObjectType' -NotePropertyValue 'SCCMPXEServer' -Force
                        Show-Object $pxeObj -Class Hint
                    }
                }
            } catch {
                Write-Log "[Get-SCCMInfrastructure] Error querying PXE connectionPoints: $_" -Level Warning
            }

            try {
                # WDS Service Connection Points
                $wdsPoints = @(Get-DomainObject -LDAPFilter "(objectClass=intellimirrorSCP)" -Properties "cn","distinguishedName","serviceBindingInformation" @PSBoundParameters)

                if ($wdsPoints.Count -gt 0) {
                    $pxeServersFound = $true
                    Show-Line "Обнаружено точек подключения службы WDS: $($wdsPoints.Count)" -Class Hint

                    foreach ($wds in $wdsPoints) {
                        $parentDN = $wds.distinguishedName -replace '^[^,]+,', ''
                        $wdsObj = [PSCustomObject]@{
                            Name = $wds.cn
                            WDSServicePoint = $wds.cn
                            ParentObject = $parentDN
                        }
                        if ($wds.serviceBindingInformation) {
                            $wdsObj | Add-Member -NotePropertyName 'BindingInfo' -NotePropertyValue $wds.serviceBindingInformation -Force
                        }
                        $wdsObj | Add-Member -NotePropertyName '_adPEASObjectType' -NotePropertyValue 'SCCMPXEServer' -Force
                        Show-Object $wdsObj -Class Hint
                    }
                }
            } catch {
                Write-Log "[Get-SCCMInfrastructure] Error querying intellimirrorSCP: $_" -Level Warning
            }

            if ($pxeServersFound) {
                Show-Line "PXE/WDS servers detected" -Class Hint -FindingId "SCCM_PXE_EXPOSURE"
            } else {
                Show-Line "Серверы загрузки PXE/WDS не найдены" -Class Note
            }

            # ===== Step 7: SCCM Service Accounts =====
            Show-SubHeader "Поиск служебных учётных записей SCCM..." -ObjectType "SCCMServiceAccount"

            $serviceAccounts = Get-DomainUser -LDAPFilter "(servicePrincipalName=SMS*)" @PSBoundParameters

            if ($serviceAccounts) {
                Show-Line "Обнаружены служебные учётные записи SCCM с SPN вида SMS*: $(@($serviceAccounts).Count)" -Class Hint -FindingId "SCCM_SERVICE_ACCOUNT"

                foreach ($account in $serviceAccounts) {
                    $account | Add-Member -NotePropertyName '_adPEASObjectType' -NotePropertyValue 'SCCMServiceAccount' -Force
                    Show-Object $account -Class Hint
                }
            } else {
                Show-Line "Служебные учётные записи SCCM не найдены" -Class Secure
            }

            # ===== Step 8: SCCM-Related Groups =====
            Show-SubHeader "Поиск групп безопасности, связанных с SCCM..." -ObjectType "SCCMGroup"

            # Single LDAP query with OR filter (SMS_SiteToSiteConnection_ is SCCM-specific, avoids generic *SMS* false positives)
            $sccmGroupsFound = [System.Collections.ArrayList]::new()
            $seenGroupDNs = @{}

            $groups = Get-DomainGroup -LDAPFilter "(|(cn=*SCCM*)(cn=SMS_SiteToSiteConnection_*)(cn=SMS_SiteSystemToSiteServerConnection_*)(cn=*ConfigMgr*)(cn=*MECM*))" @PSBoundParameters

            if ($groups) {
                foreach ($group in @($groups)) {
                    $dn = $group.distinguishedName
                    if ($dn -and -not $seenGroupDNs.ContainsKey($dn)) {
                        $seenGroupDNs[$dn] = $true
                        [void]$sccmGroupsFound.Add($group)
                    }
                }
            }

            if ($sccmGroupsFound.Count -gt 0) {
                Show-Line "Обнаружено групп, связанных с SCCM: $($sccmGroupsFound.Count)" -Class Hint

                # The class each group is shown with, Finding where a broad group is a member.
                $groupClass = @{}
                foreach ($group in $sccmGroupsFound) {
                    $memberDNs = @(@($group.member) | Where-Object { $_ })
                    # A number, not "3 member(s)": the report sorts and compares this
                    # column, and a string sorts 10 before 2.
                    $group | Add-Member -NotePropertyName 'MemberCount' -NotePropertyValue $memberDNs.Count -Force
                    $groupClass[[string]$group.distinguishedName] = 'Hint'

                    if ($memberDNs.Count -gt 0) {
                        # The members by name, from the DNs the group already carries. Left
                        # to the renderer, every member would cost a SID lookup of its own.
                        # A foreign security principal is named by its SID; the well-known
                        # ones resolve without a query.
                        $memberNames = @($memberDNs | ForEach-Object {
                            if ("$_" -match '^CN=(S-1-[0-9-]+),CN=ForeignSecurityPrincipals,') {
                                $foreignSID = $Matches[1]
                                $foreignName = ConvertFrom-SID -SID $foreignSID
                                if ($foreignName) { $foreignName } else { $foreignSID }
                            } elseif ("$_" -match '^CN=((?:[^,\\]|\\.)+),') {
                                $Matches[1] -replace '\\(.)', '$1'
                            } else { "$_" }
                        } | Sort-Object)
                        $shownNames = @($memberNames | Select-Object -First 20) -join ', '
                        if ($memberNames.Count -gt 20) { $shownNames = "$shownNames, ... and $($memberNames.Count - 20) more" }
                        $group | Add-Member -NotePropertyName 'memberNames' -NotePropertyValue $shownNames -Force

                        # And whether a broad group is among them, from one query per group
                        # rather than one per member. Whatever SCCM access the group grants -
                        # the check knows it by name only - Domain Users or Authenticated
                        # Users in it hands that access to every account they cover.
                        try {
                            $escapedGroupDN = Escape-LDAPFilterDN -DistinguishedName ([string]$group.distinguishedName)
                            $broadNames = @()
                            foreach ($memberObject in @(Get-DomainObject -LDAPFilter "(memberOf=$escapedGroupDN)" -Properties 'objectSid', 'sAMAccountName' @PSBoundParameters)) {
                                $memberSID = [string]$memberObject.objectSid
                                if ($memberSID -and (Test-IsBroadTrustee -SID $memberSID)) {
                                    $broadNames += $(if ($memberObject.sAMAccountName) { [string]$memberObject.sAMAccountName } else { ConvertFrom-SID -SID $memberSID })
                                }
                            }
                            if ($broadNames.Count -gt 0) {
                                $group | Add-Member -NotePropertyName 'broadMembers' -NotePropertyValue "BROAD - $(@($broadNames | Sort-Object) -join ', ') - every account it covers holds whatever SCCM access this group grants" -Force
                                $groupClass[[string]$group.distinguishedName] = 'Finding'
                            }
                        } catch {
                            Write-Log "[Get-SCCMInfrastructure] Members of $($group.distinguishedName) could not be read: $_" -Level Warning
                            $group | Add-Member -NotePropertyName 'broadMembers' -NotePropertyValue 'Unknown - the members could not be read' -Force
                        }
                    }

                    # Remove member attribute to prevent Extended-attribute rendering from triggering
                    # per-DN SID resolution (Convert-DNsToMemberInfo -> ConvertTo-SID per member)
                    $group.PSObject.Properties.Remove('member')
                    $group | Add-Member -NotePropertyName '_adPEASObjectType' -NotePropertyValue 'SCCMGroup' -Force
                }

                $broadGroupCount = @($groupClass.Values | Where-Object { $_ -eq 'Finding' }).Count
                if ($broadGroupCount -gt 0) {
                    Show-Line "$broadGroupCount SCCM-related group(s) have a broad group as member" -Class Finding
                }
                foreach ($group in $sccmGroupsFound) {
                    Show-Object $group -Class $groupClass[[string]$group.distinguishedName]
                }
            } else {
                Show-Line "Группы, связанные с SCCM, не найдены" -Class Note
            }

        } catch {
            Write-Log "[Get-SCCMInfrastructure] Error: $_" -Level Error
            Show-Line "Error during check - the SCCM infrastructure could not be evaluated: $_" -Class Finding
        }
    }

    end {
        Write-Log "[Get-SCCMInfrastructure] Check completed"
    }
}
